########################################################################
## Description: Unificação das três bases padronizadas do capítulo -
##              Atlas Digital de Desastres, Copernicus ERA5 e MapBiomas -
##              em uma base única município x ano x mês, pronta para a
##              análise exploratória das relações entre variáveis e para
##              a modelagem estatística e de aprendizado de máquina...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: qui ago 20 14:00:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: Três bases padronizadas pelos scripts anteriores:
##                  - ../Dados/Outputs/Copernicus_ERA5/RData/
##                    ERA5_SC_completo.RData
##                    (dados_municipio_final: 38.443 linhas,
##                     37 municípios, 1940-01 a 2026-07, mensal)
##                  - ../Dados/Outputs/Atlas_Digital/RData/
##                    Atlas_SC_completo.RData
##                    (serie_mensal e serie_mensal_grupo: 35 municípios,
##                     1991-2025, grade mensal completa com zeros)
##                  - ../Dados/Outputs/MapBiomas/RData/
##                    MapBiomas_SC_completo.RData
##                    (series_anuais: 35 municípios, 1985-2024 na
##                     cobertura e 1992-2025 no tema Água, ANUAL)
##                Todas já vinculadas ao mesmo shapefile
##                (municipio_abrangencia_PMCAP-SC.shp) pelo geocódigo
##                IBGE, o que torna o pareamento exato e dispensa
##                qualquer casamento por nome.
##
### Commentary:
##
## Este script não produz análise: produz o OBJETO sobre o qual as
## análises seguintes serão feitas. Sua única obrigação é juntar as três
## fontes sem perder informação e sem inventar informação - duas
## exigências que, em uma união de bases com coberturas temporais e
## espaciais diferentes, entram em conflito o tempo todo e precisam ser
## arbitradas explicitamente.
##
## Seis decisões estruturam a consolidação, e todas elas são
## verificáveis nas tabelas de diagnóstico exportadas ao final:
##
##    (i) A GRADE MESTRA É A DA BASE MAIS LONGA. O ERA5 cobre 37
##        municípios de janeiro de 1940 a julho de 2026 - 1.039 meses -,
##        e é a única das três a cobrir todos os municípios do recorte.
##        A base consolidada adota exatamente essa grade: 37 x 1.039 =
##        38.443 linhas, uma por município-mês, sem exceção. As demais
##        fontes são ENCAIXADAS nela, e onde não alcançam o campo fica
##        NA. Nenhuma linha da grade é descartada por falta de dado, e
##        nenhuma fonte tem sua cobertura reduzida à da outra: a união é
##        um LEFT JOIN sobre a grade completa, e não a intersecção das
##        três;
##
##   (ii) NA E ZERO NÃO SÃO A MESMA COISA, E A DISTINÇÃO É PRESERVADA. As
##        séries do Atlas vêm em grade completa com ZERO nos meses sem
##        desastre - o zero é informação, significa calmaria observada.
##        Fora da janela 1991-2025, e nos dois municípios que o Atlas não
##        cobre (Camboriú e Paulo Lopes), o campo recebe NA: ausência de
##        observação, não ausência de desastre. Confundir os dois
##        transformaria 51 anos sem cobertura (1940-1990) em 51 anos sem
##        desastre, e qualquer modelo de contagem leria isso como
##        tendência de alta. O sinalizador tem_atlas separa os dois casos
##        em cada linha;
##
##  (iii) O MAPBIOMAS É ANUAL E É REPETIDO MÊS A MÊS - COM RESSALVA. A
##        cobertura da terra é uma variável de ESTOQUE: a área de
##        floresta de um município em 2010 é um estado que vale para o
##        ano inteiro, e repeti-la nos doze meses de 2010 não cria
##        informação falsa, apenas explicita que o estado é o mesmo. Isso
##        NÃO valeria para uma variável de fluxo: repetir uma contagem
##        anual de eventos nos doze meses multiplicaria o total por doze.
##        Por isso a repetição mensal é aplicada ao MapBiomas (áreas) e
##        JAMAIS às contagens do Atlas. A coluna mapb_ano_referencia
##        registra, em cada linha, de que ano veio o valor repetido, de
##        modo que a operação seja auditável e reversível;
##
##   (iv) NÃO HÁ EXTRAPOLAÇÃO PARA ALÉM DA COBERTURA DE CADA FONTE. A
##        cobertura do MapBiomas termina em 2024 e a base vai até julho
##        de 2026: os anos de 2025 e 2026 ficam com NA nas colunas de
##        cobertura, e não com o valor de 2024 arrastado para a frente.
##        Arrastar seria uma imputação - defensável em alguns contextos,
##        mas uma decisão de MODELAGEM, que não cabe a um script de
##        consolidação tomar em silêncio. Quem quiser o arrasto tem, na
##        base, tudo o que precisa para fazê-lo explicitamente;
##
##    (v) OS BLOCOS SÃO IDENTIFICADOS POR PREFIXO. Toda coluna vinda do
##        ERA5 começa por era5_, toda coluna do Atlas por atlas_ e toda
##        coluna do MapBiomas por mapb_. Sem os prefixos haveria colisão
##        real - as três fontes têm colunas de área, e duas delas têm
##        colunas chamadas municipio e data -, e a leitura de qualquer
##        modelo ajustado sobre esta base exigiria consultar a
##        procedência de cada variável. As chaves (geocodigo, municipio,
##        ano, mes, data), os atributos do município e os sinalizadores
##        de cobertura ficam sem prefixo, porque não pertencem a
##        nenhuma fonte em particular;
##
##   (vi) A BASE MENSAL É O PRODUTO PRINCIPAL; A ANUAL É DERIVADA DELA.
##        Como o MapBiomas é anual, boa parte da modelagem será feita em
##        escala anual, e refazer essa agregação em cada análise seria
##        repetir a mesma decisão em lugares diferentes. O script entrega
##        também uma base ANUAL, agregada a partir da mensal com regra
##        declarada por tipo de variável: SOMA para as contagens e
##        valores do Atlas (que são fluxos), MÉDIA para as variáveis de
##        estado do ERA5, e o PRÓPRIO VALOR para as do MapBiomas (que
##        são constantes dentro do ano). Anos incompletos são
##        sinalizados - 2026 tem sete meses de ERA5 -, para que não
##        sejam comparados com anos de doze meses sem que se saiba.
##        A base anual acrescenta ainda a contagem de eventos por
##        TIPOLOGIA de desastre, que o Atlas só disponibiliza nessa
##        escala.
##
## O que a base consolidada NÃO faz, e por que:
##
##   - não remove as seis variáveis estáticas do ERA5 (cvh, cvl, tvh,
##     tvl, lai_hv, lai_lv), as onze classes nulas do MapBiomas nem as
##     faixas constantes do risco climático. A AED de cada fonte já
##     identificou e documentou todas elas; removê-las aqui esconderia
##     do usuário da base uma informação que ele precisa ter. O
##     dicionário exportado marca cada uma com a ressalva pertinente;
##
##   - não padroniza, não centra e não escalona nada. Transformações são
##     decisões de modelagem e dependem do modelo;
##
##   - não imputa valor ausente algum. A única "imputação" do script é a
##     repetição anual do MapBiomas, que é expansão de um estado e está
##     sinalizada em coluna própria.
##
## Fluxo geral do processamento:
##
##   01) Leitura das três bases padronizadas e conferências de
##       integridade antes de qualquer junção;
##   02) Construção da grade mestra município x ano x mês e da tabela de
##       atributos dos municípios;
##   03) Preparo do bloco ERA5;
##   04) Preparo do bloco Atlas, no total do município e por grupo de
##       desastre;
##   05) Preparo do bloco MapBiomas em formato largo anual (cobertura,
##       urbanização, vegetação urbana, risco climático e água);
##   06) Junção das três fontes sobre a grade mestra;
##   07) Variáveis derivadas de tempo e sinalizadores de cobertura;
##   08) Dicionário de variáveis da base consolidada;
##   09) Diagnóstico de completude e conferências finais;
##   10) Construção da base anual derivada;
##   11) Exportação em Parquet e RData, no conjunto e por município.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem (formato longo <-> largo)
library(purrr)          ## Programação funcional
library(stringi)        ## Transliteração de acentos (nomes de coluna)
library(arrow)          ## Escrita de arquivos Parquet

######@> Resolução de conflitos de nomes...
## Mantida a mesma fixação explícita adotada nos demais scripts do
## projeto: evita erros silenciosos de seleção de colunas caso algum
## pacote carregado adiante mascare os verbos do dplyr.
select <- dplyr::select
filter <- dplyr::filter

######@> Opções globais...
## scipen alto impede que geocódigos e valores monetários apareçam em
## notação científica em qualquer mensagem ou exportação textual.
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente...
## Nenhuma etapa deste script é estocástica; a semente é fixada apenas
## por consistência com os demais scripts do projeto.
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
## O script assume execução a partir da pasta R_Work, portanto todos os
## caminhos são relativos a ela.
dir_dados <- "../Dados"
dir_out <- file.path(dir_dados, "Outputs")

arq_era5 <- file.path(dir_out, "Copernicus_ERA5", "RData",
                      "ERA5_SC_completo.RData")
arq_atlas <- file.path(dir_out, "Atlas_Digital", "RData",
                       "Atlas_SC_completo.RData")
arq_mapb <- file.path(dir_out, "MapBiomas", "RData",
                      "MapBiomas_SC_completo.RData")

######@> Diretórios de saída...
## A estrutura repete a das três bases de origem: um diretório por
## formato, com os arquivos por município em "Municipal/".
dir_cons <- file.path(dir_out, "Consolidado")
dir_pq <- file.path(dir_cons, "Parquet")
dir_rd <- file.path(dir_cons, "RData")
dir_pq_mun <- file.path(dir_pq, "Municipal")
dir_rd_mun <- file.path(dir_rd, "Municipal")

for(d in c(dir_cons, dir_pq, dir_rd, dir_pq_mun, dir_rd_mun)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> Parâmetros da consolidação...
## prefixos          : identificam a procedência de cada coluna;
## estacao_do_mes    : convenção meteorológica do hemisfério sul,
##                     idêntica à adotada na AED do ERA5;
## limiar_ano_completo: número mínimo de meses para que um ano seja
##                     considerado completo na base anual derivada.
prefixo_era5 <- "era5_"
prefixo_atlas <- "atlas_"
prefixo_mapb <- "mapb_"

estacao_do_mes <- c("Verão", "Verão", "Outono", "Outono", "Outono",
                    "Inverno", "Inverno", "Inverno", "Primavera",
                    "Primavera", "Primavera", "Verão")

limiar_ano_completo <- 12

########################################################################
######@> Funções auxiliares...

######@> Transliteração de nomes em nomes seguros de coluna/arquivo...
## Os nomes de classe do MapBiomas têm acentos, espaços e vírgulas
## ("Vegetação Herbácea e Arbustiva", "Rio, Lago e Oceano"). Como eles
## viram NOMES DE COLUNA da base consolidada, precisam ser reduzidos a
## caracteres ASCII sem espaço - do contrário exigiriam crases em toda
## referência e quebrariam a leitura do Parquet em outras linguagens.
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Versão minúscula, usada nos nomes de coluna...
nome_coluna <- function(x) {
    tolower(limpar_nome(x))
}

######@> Formatação de inteiros com separador de milhar...
## big.mark = "." sozinho dispara aviso, porque no locale padrão do R o
## separador DECIMAL também é "."; declarar decimal.mark = "," (a
## convenção brasileira) elimina a ambiguidade.
fmt_int <- function(x) {
    formatC(x, format = "f", digits = 0, big.mark = ".",
            decimal.mark = ",")
}

######@> Prefixação de colunas preservando as chaves...
## Recebe uma tabela e devolve a mesma tabela com todas as colunas
## prefixadas, EXCETO as chaves de junção. Centralizar isso evita o erro
## mais provável desta etapa: prefixar a chave por engano e, com isso,
## produzir um join vazio que passaria despercebido porque devolve NA em
## vez de erro.
prefixar <- function(dados, prefixo,
                     chaves = c("geocodigo", "ano", "mes")) {
    alvos <- setdiff(names(dados), chaves)
    names(dados)[match(alvos, names(dados))] <- paste0(prefixo, alvos)
    return(dados)
}

######@> Soma tolerante a ausência total...
## sum(x, na.rm = TRUE) sobre um vetor inteiramente NA devolve ZERO, o
## que aqui seria um erro grave: transformaria "ano sem cobertura do
## Atlas" em "ano sem nenhum desastre". Esta variante devolve NA quando
## não há observação alguma, e soma normalmente quando há.
soma_ou_na <- function(x) {
    if(all(is.na(x))) return(NA_real_)
    sum(x, na.rm = TRUE)
}

######@> Média tolerante a ausência total...
media_ou_na <- function(x) {
    if(all(is.na(x))) return(NA_real_)
    mean(x, na.rm = TRUE)
}

######@> Primeiro valor não ausente...
## Usada nas colunas do MapBiomas ao agregar para o ano: como o valor é
## constante nos doze meses, tomar o primeiro não-NA é exato - e é
## preferível à média, que introduziria erro de ponto flutuante.
primeiro_ou_na <- function(x) {
    x <- x[!is.na(x)]
    if(length(x) == 0) return(NA_real_)
    return(x[1])
}

######@> Número de dias de cada mês...
## Necessário para converter as taxas diárias do ERA5 (mm/dia) em
## totais mensais, e para ponderar corretamente a agregação anual da
## precipitação. Calculado a partir das datas, e não por tabela fixa, o
## que resolve os anos bissextos sem caso especial.
dias_do_mes <- function(datas) {
    as.numeric(as.Date(format(datas + 32, "%Y-%m-01")) -
               as.Date(format(datas, "%Y-%m-01")))
}

########################################################################
######@> Etapa 01 - Leitura das três bases e conferências...

message("=== Consolidação das bases - início ===")

######@> Conferência de existência dos insumos...
## A mensagem nomeia o script que precisa ser executado antes, para que
## a falha seja acionável e não apenas um erro de arquivo inexistente.
insumos <- c(ERA5 = arq_era5, Atlas = arq_atlas, MapBiomas = arq_mapb)
scripts_origem <- c(ERA5 = "script_ERA5_extracao_municipios_ver01.R",
                    Atlas = "script_Atlas_Digital_extracao_municipios_ver00.R",
                    MapBiomas = "script_MapBiomas_extracao_municipios_ver00.R")

for(fonte in names(insumos)) {
    if(!file.exists(insumos[fonte])) {
        stop("Base ", fonte, " não encontrada em ", insumos[fonte],
             ". Execute antes ", scripts_origem[fonte])
    }
}

######@> Leitura em ambientes separados...
## Os três RData trazem objetos de MESMO NOME - diagnostico e
## resumo_municipios existem nos três, dicionario em dois -, e carregá-los
## no ambiente global faria o último load() sobrescrever os anteriores em
## silêncio. Ambientes separados tornam a procedência de cada objeto
## explícita em todo o restante do script.
message("Lendo bases padronizadas...")

amb_era5 <- new.env()
amb_atlas <- new.env()
amb_mapb <- new.env()

load(arq_era5, envir = amb_era5)
load(arq_atlas, envir = amb_atlas)
load(arq_mapb, envir = amb_mapb)

era5_bruto <- get("dados_municipio_final", envir = amb_era5)
atlas_mensal <- get("serie_mensal", envir = amb_atlas)
atlas_mensal_grupo <- get("serie_mensal_grupo", envir = amb_atlas)
atlas_anual_tipologia <- get("serie_anual_tipologia", envir = amb_atlas)
atlas_resumo <- get("resumo_municipios", envir = amb_atlas)
mapb_series <- get("series_anuais", envir = amb_mapb)
mapb_resumo <- get("resumo_municipios", envir = amb_mapb)
era5_dicionario <- get("dicionario", envir = amb_era5)
atlas_dicionario <- get("dicionario_variaveis", envir = amb_atlas)

message("ERA5      : ", fmt_int(nrow(era5_bruto)), " linhas | ",
        n_distinct(era5_bruto$geocodigo), " municípios | ",
        min(era5_bruto$ano), "-", max(era5_bruto$ano))
message("Atlas     : ", fmt_int(nrow(atlas_mensal)), " linhas | ",
        n_distinct(atlas_mensal$geocodigo), " municípios | ",
        min(atlas_mensal$ano), "-", max(atlas_mensal$ano))
message("MapBiomas : ", fmt_int(nrow(mapb_series)), " linhas | ",
        n_distinct(mapb_series$geocodigo), " municípios | ",
        min(mapb_series$ano), "-", max(mapb_series$ano))

######@> Conferência das chaves de junção...
## Três verificações que, se falharem, invalidam a consolidação inteira:
## (a) a chave município-ano-mês precisa ser ÚNICA em cada fonte mensal,
## sob pena de o join multiplicar linhas; (b) o geocódigo precisa ser
## do mesmo tipo nas três, sob pena de join vazio por incompatibilidade
## silenciosa entre texto e número; (c) todo geocódigo do Atlas e do
## MapBiomas precisa existir no ERA5, que é a base de referência
## espacial.
stopifnot(
    nrow(era5_bruto) ==
        nrow(distinct(era5_bruto, geocodigo, ano, mes)),
    nrow(atlas_mensal) ==
        nrow(distinct(atlas_mensal, geocodigo, ano, mes)),
    nrow(atlas_mensal_grupo) ==
        nrow(distinct(atlas_mensal_grupo, geocodigo, ano, mes,
                      grupo_desastre)),
    nrow(mapb_series) ==
        nrow(distinct(mapb_series, geocodigo, tema, relatorio,
                      exportado_como_serie, classe_caminho, ano)))

stopifnot(is.character(era5_bruto$geocodigo),
          is.character(atlas_mensal$geocodigo),
          is.character(mapb_series$geocodigo))

fora_do_era5 <- union(setdiff(unique(atlas_mensal$geocodigo),
                              unique(era5_bruto$geocodigo)),
                      setdiff(unique(mapb_series$geocodigo),
                              unique(era5_bruto$geocodigo)))

if(length(fora_do_era5) > 0) {
    stop("Geocódigos presentes no Atlas ou no MapBiomas e ausentes no ",
         "ERA5: ", paste(fora_do_era5, collapse = ", "),
         ". A grade mestra ficaria incompleta.")
}

######@> Conferência da grafia dos nomes de município...
## O pareamento é feito pelo geocódigo, e não pelo nome - mas uma
## divergência de grafia entre as fontes indicaria que alguma delas não
## foi vinculada ao mesmo shapefile, o que mereceria investigação antes
## de prosseguir.
nomes_era5 <- era5_bruto %>% distinct(geocodigo, municipio)
nomes_atlas <- atlas_mensal %>% distinct(geocodigo, municipio)
nomes_mapb <- mapb_series %>% distinct(geocodigo, municipio)

divergencias <- nomes_era5 %>%
    left_join(nomes_atlas, by = "geocodigo",
              suffix = c("", "_atlas")) %>%
    left_join(nomes_mapb %>% rename(municipio_mapb = municipio),
              by = "geocodigo") %>%
    filter((!is.na(municipio_atlas) & municipio != municipio_atlas) |
           (!is.na(municipio_mapb) & municipio != municipio_mapb))

if(nrow(divergencias) > 0) {
    warning("Divergência de grafia entre fontes em ",
            nrow(divergencias), " município(s): ",
            paste(divergencias$municipio, collapse = ", "))
}

message("Chaves conferidas      : geocódigo idêntico nas três fontes, ",
        "sem duplicidade e sem divergência de grafia")

########################################################################
######@> Etapa 02 - Grade mestra e atributos dos municípios...

######@> Universo de municípios...
## O universo é o do ERA5 - a única fonte que cobre os 37 municípios do
## recorte. Os dois municípios sem Atlas e sem MapBiomas (Camboriú e
## Paulo Lopes) PERMANECEM na base, com NA nas colunas dessas fontes:
## excluí-los seria descartar a informação climática que existe para
## eles, e abriria um vazio no litoral em qualquer mapa produzido a
## partir daqui.
municipios <- era5_bruto %>%
    distinct(geocodigo, municipio, area_km2 = area_km2,
             lon_centroide, lat_centroide, n_pixels) %>%
    rename(era5_n_pixels = n_pixels, era5_area_km2 = area_km2) %>%
    left_join(atlas_resumo %>%
                  select(geocodigo, area_km2_shape,
                         atlas_ano_primeiro = ano_primeiro,
                         atlas_ano_ultimo = ano_ultimo,
                         atlas_n_eventos_total = n_eventos,
                         atlas_grupo_predominante = grupo_predominante,
                         atlas_tipologia_predominante =
                             tipologia_predominante,
                         tem_atlas = tem_registro_atlas),
              by = "geocodigo") %>%
    left_join(mapb_resumo %>%
                  select(geocodigo,
                         mapb_area_ha = area_ha_mapbiomas,
                         mapb_area_ha_terrestre = area_ha_terrestre,
                         mapb_area_ha_agua = area_ha_agua,
                         mapb_pct_area_agua = pct_area_agua,
                         tem_mapbiomas),
              by = "geocodigo") %>%
    mutate(tem_atlas = !is.na(tem_atlas) & tem_atlas,
           tem_mapbiomas = !is.na(tem_mapbiomas) & tem_mapbiomas,
           n_fontes_municipio = 1 + tem_atlas + tem_mapbiomas) %>%
    arrange(desc(lat_centroide))

message("\nMunicípios na base     : ", nrow(municipios),
        " | com Atlas: ", sum(municipios$tem_atlas),
        " | com MapBiomas: ", sum(municipios$tem_mapbiomas))

municipios_sem_atlas <- municipios$municipio[!municipios$tem_atlas]
if(length(municipios_sem_atlas) > 0) {
    message("  Sem Atlas            : ",
            paste(municipios_sem_atlas, collapse = ", "))
}

######@> Grade mestra município x ano x mês...
## Construída a partir da SEQUÊNCIA DE DATAS do ERA5, e não do produto
## cartesiano de anos e meses: 2026 tem apenas sete meses de reanálise,
## e o produto cartesiano criaria cinco meses inexistentes ao final da
## série, que nenhuma fonte preencheria e que apareceriam como linhas
## inteiramente vazias.
datas_grade <- sort(unique(era5_bruto$data))

grade <- expand_grid(geocodigo = sort(unique(era5_bruto$geocodigo)),
                     data = datas_grade) %>%
    mutate(ano = as.integer(format(data, "%Y")),
           mes = as.integer(format(data, "%m"))) %>%
    left_join(municipios %>% select(geocodigo, municipio),
              by = "geocodigo") %>%
    select(geocodigo, municipio, ano, mes, data) %>%
    arrange(geocodigo, data)

stopifnot(nrow(grade) == nrow(municipios) * length(datas_grade),
          nrow(grade) == nrow(distinct(grade, geocodigo, ano, mes)))

message("Grade mestra           : ", fmt_int(nrow(grade)), " linhas (",
        nrow(municipios), " municípios x ", length(datas_grade),
        " meses, de ", format(min(datas_grade), "%m/%Y"), " a ",
        format(max(datas_grade), "%m/%Y"), ")")

########################################################################
######@> Etapa 03 - Preparo do bloco ERA5...

######@> Seleção das colunas...
## Saem as colunas de identidade do município (municipio, data,
## area_km2, centroides, n_pixels), que são constantes no tempo e já
## estão na grade e na tabela de municípios. Permanecem TODAS as
## variáveis medidas: as 20 médias, seus três acompanhantes de dispersão
## (_dp, _min, _max) e as 11 derivadas em unidades usuais - inclusive as
## seis estáticas, que a AED do ERA5 identificou como campos fixos e que
## seguem úteis como descritores de superfície do município.
colunas_identidade_era5 <- c("municipio", "data", "area_km2",
                             "lon_centroide", "lat_centroide",
                             "n_pixels")

bloco_era5 <- era5_bruto %>%
    select(-all_of(colunas_identidade_era5)) %>%
    prefixar(prefixo_era5) %>%
    arrange(geocodigo, ano, mes)

message("\nBloco ERA5             : ", ncol(bloco_era5) - 3,
        " variáveis climáticas")

########################################################################
######@> Etapa 04 - Preparo do bloco Atlas...

######@> Total do município...
## As mesmas colunas de identidade saem pelo mesmo motivo. O que resta
## são as 24 métricas do Atlas: contagens de evento, danos humanos
## (dh_*), danos materiais (dm_*), prejuízos públicos e privados (pe*) e
## o impacto econômico total.
colunas_identidade_atlas <- c("municipio", "data", "area_km2_shape",
                              "lon_centroide", "lat_centroide")

bloco_atlas_total <- atlas_mensal %>%
    select(-all_of(colunas_identidade_atlas)) %>%
    prefixar(prefixo_atlas) %>%
    arrange(geocodigo, ano, mes)

######@> Recorte por grupo de desastre...
## Os quatro grupos do Atlas (Climatológico, Hidrológico, Meteorológico
## e Outros) entram em formato largo, mas apenas nas quatro métricas de
## maior interesse para a modelagem: a contagem de eventos - candidata
## natural a variável resposta -, os afetados, os mortos e o impacto
## econômico. As demais métricas por grupo permanecem disponíveis na
## base do Atlas; trazê-las todas acrescentaria uma centena de colunas
## de altíssima esparsidade a uma base que já é larga.
metricas_grupo <- c("n_eventos", "dh_afetados_total", "dh_mortos",
                    "impacto_economico_total")

bloco_atlas_grupo <- atlas_mensal_grupo %>%
    select(geocodigo, ano, mes, grupo_desastre,
           all_of(metricas_grupo)) %>%
    mutate(grupo_rotulo = nome_coluna(grupo_desastre)) %>%
    select(-grupo_desastre) %>%
    pivot_wider(names_from = grupo_rotulo,
                values_from = all_of(metricas_grupo),
                names_glue = "{.value}_{grupo_rotulo}") %>%
    prefixar(prefixo_atlas) %>%
    arrange(geocodigo, ano, mes)

######@> Conferência da decomposição por grupo...
## A soma dos quatro grupos precisa reproduzir exatamente o total do
## município em cada mês. Se não reproduzir, ou há evento fora dos
## grupos ou o pivot perdeu linha - e o erro passaria despercebido,
## porque ambas as tabelas continuariam parecendo íntegras.
conferencia_grupos <- bloco_atlas_grupo %>%
    mutate(soma_grupos = rowSums(across(
               starts_with(paste0(prefixo_atlas, "n_eventos_"))))) %>%
    select(geocodigo, ano, mes, soma_grupos) %>%
    inner_join(bloco_atlas_total %>%
                   select(geocodigo, ano, mes,
                          total = paste0(prefixo_atlas, "n_eventos")),
               by = c("geocodigo", "ano", "mes"))

stopifnot(all(conferencia_grupos$soma_grupos ==
              conferencia_grupos$total))

message("Bloco Atlas            : ",
        ncol(bloco_atlas_total) - 3, " métricas no total do município + ",
        ncol(bloco_atlas_grupo) - 3, " por grupo de desastre",
        " (soma dos grupos confere com o total)")

########################################################################
######@> Etapa 05 - Preparo do bloco MapBiomas (anual, formato largo)...

######@> Recorte do que é série anual...
## A base do MapBiomas reúne quatro temas e catorze relatórios, dos
## quais apenas parte é série anual - o restante são agregados do
## período 1985-2024 e coortes de urbanização, que descrevem o intervalo
## inteiro em uma linha e não têm onde se encaixar em uma base
## município-mês. A triagem repete a da AED do MapBiomas e usa o mesmo
## critério: exportado_como_serie verdadeiro.
mapb_serie <- mapb_series %>% filter(exportado_como_serie)

######@> Cobertura da terra...
## Entram todas as classes COM OCORRÊNCIA no litoral, em todos os quatro
## níveis da hierarquia. As onze classes identicamente nulas (Lavoura
## Perene e suas subclasses, Algodão, Cana, Formação Savânica, Floresta
## Alagável, Afloramento Rochoso e Usina Fotovoltaica) são omitidas por
## serem constantes iguais a zero em 35 municípios e 40 anos: manter
## onze colunas de zeros não acrescentaria informação e ampliaria a base
## sem contrapartida. A relação completa fica registrada no dicionário.
##
## O nível é preservado no nome da coluna (cob_n1_, cob_n2_, ...),
## porque as classes são ANINHADAS: somar colunas de níveis diferentes
## contaria a mesma área duas vezes, e o nome precisa impedir que isso
## aconteça por descuido.
mapb_cobertura_bruta <- mapb_serie %>%
    filter(tema == "Cobertura 30m")

classes_com_ocorrencia <- mapb_cobertura_bruta %>%
    group_by(nivel_profundidade, classe_caminho, classe) %>%
    summarise(area_max_ha = max(area_ha), .groups = "drop") %>%
    filter(area_max_ha > 0) %>%
    mutate(coluna = paste0("cob_n", nivel_profundidade, "_",
                           nome_coluna(classe)))

classes_nulas <- mapb_cobertura_bruta %>%
    group_by(nivel_profundidade, classe_caminho, classe) %>%
    summarise(area_max_ha = max(area_ha), .groups = "drop") %>%
    filter(area_max_ha == 0)

stopifnot(!any(duplicated(classes_com_ocorrencia$coluna)))

bloco_cobertura <- mapb_cobertura_bruta %>%
    inner_join(classes_com_ocorrencia %>%
                   select(classe_caminho, coluna),
               by = "classe_caminho") %>%
    select(geocodigo, ano, coluna, area_ha, area_pct) %>%
    pivot_wider(names_from = coluna,
                values_from = c(area_ha, area_pct),
                names_glue = "{coluna}_{.value}") %>%
    rename_with(~ sub("_area_ha$", "_ha", .x)) %>%
    rename_with(~ sub("_area_pct$", "_pct", .x))

message("\nBloco MapBiomas - cobertura: ",
        nrow(classes_com_ocorrencia), " classes com ocorrência (",
        nrow(classes_nulas), " nulas omitidas)")

######@> Urbanização anual...
## Relatório de classe única (Área Urbanizada), e a série mais
## diretamente ligada à exposição a desastres: onde há mancha urbana, há
## população e patrimônio expostos.
bloco_urbano <- mapb_serie %>%
    filter(grepl("Urbanização anual", relatorio)) %>%
    select(geocodigo, ano, urb_area_ha = area_ha,
           urb_pct_area = area_pct)

######@> Vegetação dentro da mancha urbana...
## O relatório de vegetação urbana reparte a área urbanizada em vegetada
## e não vegetada. A fração vegetada tem consequência direta para
## desastres: superfície impermeável concentra escoamento.
bloco_veg_urbana <- mapb_serie %>%
    filter(grepl("Vegetação urbana", relatorio),
           classe_caminho %in%
           c("Área Urbanizada > Área Urbana Vegetada",
             "Área Urbanizada > Área Urbanizada não Vegetada")) %>%
    mutate(coluna = ifelse(grepl("não Vegetada", classe_caminho),
                           "urb_nao_vegetada_ha",
                           "urb_vegetada_ha")) %>%
    select(geocodigo, ano, coluna, area_ha) %>%
    pivot_wider(names_from = coluna, values_from = area_ha) %>%
    mutate(urb_total_vegetacao_ha = urb_vegetada_ha +
               urb_nao_vegetada_ha,
           urb_pct_vegetada = ifelse(urb_total_vegetacao_ha > 0,
                                     100 * urb_vegetada_ha /
                                     urb_total_vegetacao_ha,
                                     NA_real_))

######@> Risco climático...
## Área urbana em cada faixa de suscetibilidade a inundação, alagamento
## ou enxurrada. A AED do MapBiomas mostrou que as faixas Médio e Alto
## são CONSTANTES ao longo dos 40 anos em todos os municípios cobertos -
## a suscetibilidade é atributo do terreno - e que só a faixa Muito Alto
## varia, acompanhando o avanço da mancha urbana. As três entram na
## base, com essa ressalva registrada no dicionário. O tema não cobre
## São João do Sul, que fica com NA.
rotulos_risco <- c("Médio" = "risco_medio_ha",
                   "Alto" = "risco_alto_ha",
                   "Muito Alto" = "risco_muito_alto_ha")

bloco_risco <- mapb_serie %>%
    filter(tema == "Risco Climático") %>%
    mutate(coluna = rotulos_risco[classe]) %>%
    select(geocodigo, ano, coluna, area_ha) %>%
    pivot_wider(names_from = coluna, values_from = area_ha) %>%
    mutate(risco_total_ha = rowSums(across(all_of(
               unname(rotulos_risco))), na.rm = TRUE))

######@> Água - tendência da superfície...
## Incluído com ressalva explícita. Suas classes NÃO são estados da
## paisagem, e sim FAIXAS DE TENDÊNCIA da superfície de água ("≤ -0,66 -
## Forte decréscimo"), que não fecham a área do município; e sua
## cobertura CRESCE ao longo do tempo - um município em 1992, mais de
## vinte a partir de 2005 -, de modo que qualquer agregado regional
## confundiria entrada de município com mudança real. A AED do MapBiomas
## descartou o tema como série por essas duas razões.
##
## Ainda assim ele entra na base consolidada: o critério deste script é
## a menor perda de informação possível, e o dado existe. O que não pode
## faltar é o aviso, que está no dicionário e aqui.
rotulos_agua <- c("≤ -0,66 - Forte decréscimo" = "agua_forte_decrescimo_ha",
                  "-0,66 a -0,33 - Médio decréscimo" =
                      "agua_medio_decrescimo_ha",
                  "-0,33 a 0 - Leve decréscimo" =
                      "agua_leve_decrescimo_ha",
                  "0 a 0,33 - Leve acréscimo" = "agua_leve_acrescimo_ha",
                  "0,33 a 0,66 - Médio acréscimo" =
                      "agua_medio_acrescimo_ha",
                  "≥ 0,66 - Forte acréscimo" = "agua_forte_acrescimo_ha")

stopifnot(all(unique(mapb_serie$classe[mapb_serie$tema ==
                                       "Água Mensal"]) %in%
              names(rotulos_agua)))

bloco_agua <- mapb_serie %>%
    filter(tema == "Água Mensal") %>%
    mutate(coluna = rotulos_agua[classe]) %>%
    select(geocodigo, ano, coluna, area_ha) %>%
    pivot_wider(names_from = coluna, values_from = area_ha) %>%
    mutate(agua_balanco_ha =
               rowSums(across(c(agua_leve_acrescimo_ha,
                                agua_medio_acrescimo_ha,
                                agua_forte_acrescimo_ha)),
                       na.rm = TRUE) -
               rowSums(across(c(agua_leve_decrescimo_ha,
                                agua_medio_decrescimo_ha,
                                agua_forte_decrescimo_ha)),
                       na.rm = TRUE))

######@> Montagem do bloco anual do MapBiomas...
## Os cinco recortes têm coberturas temporais e espaciais DIFERENTES
## entre si - a cobertura vai a 2024 e a água a 2025; o risco não cobre
## um município -, e por isso são unidos por full_join sobre
## município-ano: usar left_join a partir de um deles amputaria os anos
## que só o outro tem.
bloco_mapb <- list(bloco_cobertura, bloco_urbano, bloco_veg_urbana,
                   bloco_risco, bloco_agua) %>%
    reduce(full_join, by = c("geocodigo", "ano")) %>%
    prefixar(prefixo_mapb, chaves = c("geocodigo", "ano")) %>%
    arrange(geocodigo, ano)

message("Bloco MapBiomas        : ", ncol(bloco_mapb) - 2,
        " variáveis anuais | ", min(bloco_mapb$ano), "-",
        max(bloco_mapb$ano), " | ", n_distinct(bloco_mapb$geocodigo),
        " municípios")

########################################################################
######@> Etapa 06 - Junção das três fontes sobre a grade mestra...

######@> Junção...
## Todos os joins são LEFT a partir da grade: nenhuma linha da grade
## some, nenhuma linha nova aparece. O MapBiomas entra por
## município-ANO, e é essa junção - de uma tabela anual a uma grade
## mensal - que produz a repetição do valor anual nos doze meses.
message("\nUnindo as fontes sobre a grade mestra...")

base_mensal <- grade %>%
    left_join(bloco_era5, by = c("geocodigo", "ano", "mes")) %>%
    left_join(bloco_atlas_total, by = c("geocodigo", "ano", "mes")) %>%
    left_join(bloco_atlas_grupo, by = c("geocodigo", "ano", "mes")) %>%
    left_join(bloco_mapb, by = c("geocodigo", "ano"))

######@> Conferência imediata da junção...
## Duas checagens que separam um join correto de um join que multiplicou
## linhas ou perdeu chave: a contagem de linhas precisa ser idêntica à
## da grade, e o ERA5 - que cobre a grade inteira - não pode ter
## nenhum NA em uma variável de referência.
stopifnot(nrow(base_mensal) == nrow(grade),
          nrow(base_mensal) ==
              nrow(distinct(base_mensal, geocodigo, ano, mes)),
          !any(is.na(base_mensal[[paste0(prefixo_era5, "t2m")]])))

message("Base unida             : ", fmt_int(nrow(base_mensal)),
        " linhas x ", ncol(base_mensal), " colunas")

########################################################################
######@> Etapa 07 - Variáveis derivadas e sinalizadores de cobertura...

######@> Variáveis de tempo...
## Acrescentadas porque toda análise posterior precisará delas e porque
## calculá-las uma única vez, aqui, evita divergência entre análises -
## em especial na definição de estação do ano, que segue a convenção
## meteorológica do hemisfério sul adotada na AED do ERA5.
##
## dias_no_mes serve a dois propósitos: converter as taxas diárias do
## ERA5 em totais mensais e ponderar corretamente a agregação anual da
## precipitação.
base_mensal <- base_mensal %>%
    mutate(trimestre = as.integer(ceiling(mes / 3)),
           estacao = factor(estacao_do_mes[mes],
                            levels = c("Verão", "Outono", "Inverno",
                                       "Primavera")),
           dias_no_mes = dias_do_mes(data),
           tempo_indice = as.integer(12 * (ano - min(ano)) + mes),
           .after = mes)

######@> Precipitação acumulada no mês...
## O ERA5 entrega a precipitação como taxa média diária do mês
## (tp_mm_dia). O total mensal - grandeza usualmente relatada e a que se
## compara com registros pluviométricos - é a taxa multiplicada pelo
## número de dias do mês.
base_mensal <- base_mensal %>%
    mutate(era5_tp_mm_mes = era5_tp_mm_dia * dias_no_mes,
           era5_cp_mm_mes = era5_cp_mm_dia * dias_no_mes,
           .after = era5_tp_mm_dia)

######@> Sinalizadores de cobertura por linha...
## São a resposta operacional à distinção entre NA e zero declarada na
## abertura: em cada linha, dizem QUAIS fontes efetivamente observaram
## aquele município naquele mês. Sem eles, um modelo que filtrasse
## linhas completas descartaria silenciosamente 51 anos de ERA5 sem
## Atlas, e uma contagem de desastres que tratasse NA como zero
## inventaria meio século de calmaria.
##
## O sinalizador do MapBiomas registra também DE QUE ANO veio o valor
## repetido, tornando a expansão anual auditável e reversível.
coluna_ref_atlas <- paste0(prefixo_atlas, "n_eventos")
coluna_ref_mapb <- paste0(prefixo_mapb, "cob_n1_floresta_ha")

base_mensal <- base_mensal %>%
    mutate(tem_era5 = !is.na(.data[[paste0(prefixo_era5, "t2m")]]),
           tem_atlas = !is.na(.data[[coluna_ref_atlas]]),
           tem_mapbiomas = !is.na(.data[[coluna_ref_mapb]]),
           mapb_ano_referencia = ifelse(tem_mapbiomas, ano,
                                        NA_integer_),
           n_fontes = as.integer(tem_era5) + as.integer(tem_atlas) +
               as.integer(tem_mapbiomas))

######@> Ordenação final das colunas...
## Chaves e tempo primeiro, sinalizadores em seguida, depois os três
## blocos na ordem em que foram descritos. A ordem não altera o
## conteúdo, mas torna a base legível quando aberta em planilha.
base_mensal <- base_mensal %>%
    select(geocodigo, municipio, ano, mes, data, trimestre, estacao,
           dias_no_mes, tempo_indice,
           tem_era5, tem_atlas, tem_mapbiomas, n_fontes,
           mapb_ano_referencia,
           starts_with(prefixo_era5),
           starts_with(prefixo_atlas),
           starts_with(prefixo_mapb)) %>%
    arrange(geocodigo, data)

message("\nCobertura por linha:")
message("  com ERA5             : ", fmt_int(sum(base_mensal$tem_era5)),
        " (", sprintf("%.1f%%", 100 * mean(base_mensal$tem_era5)), ")")
message("  com Atlas            : ", fmt_int(sum(base_mensal$tem_atlas)),
        " (", sprintf("%.1f%%", 100 * mean(base_mensal$tem_atlas)), ")")
message("  com MapBiomas        : ",
        fmt_int(sum(base_mensal$tem_mapbiomas)),
        " (", sprintf("%.1f%%", 100 * mean(base_mensal$tem_mapbiomas)),
        ")")
message("  com as três fontes   : ",
        fmt_int(sum(base_mensal$n_fontes == 3)),
        " (", sprintf("%.1f%%", 100 * mean(base_mensal$n_fontes == 3)),
        ")")

########################################################################
######@> Etapa 08 - Dicionário de variáveis da base consolidada...

######@> Estatísticas de cada coluna...
## Calculadas sobre a base pronta, e não sobre as fontes: é a cobertura
## EFETIVA na base consolidada que interessa a quem for modelar. Para
## cada coluna, quantos valores faltam, em que janela de anos ela existe
## e em quantos municípios.
estatisticas_colunas <- map_dfr(names(base_mensal), function(v) {
    x <- base_mensal[[v]]
    presente <- !is.na(x)
    tibble(variavel = v,
           tipo_r = class(x)[1],
           n_ausentes = sum(!presente),
           pct_ausente = 100 * mean(!presente),
           ano_min = if(any(presente))
               min(base_mensal$ano[presente]) else NA_integer_,
           ano_max = if(any(presente))
               max(base_mensal$ano[presente]) else NA_integer_,
           n_municipios = n_distinct(base_mensal$geocodigo[presente]))
})

######@> Descrições do bloco ERA5...
## Reaproveitam o dicionário da própria base do ERA5. As colunas com
## sufixo não constam lá - são derivadas na extração -, e por isso a
## descrição é montada a partir da variável-base mais o significado do
## sufixo, exatamente como documentado no objeto sufixos daquela base.
significado_sufixo <- c(
    "_dp" = "desvio-padrão entre os pixels do município no mês",
    "_min" = "menor valor entre os pixels do município no mês",
    "_max" = "maior valor entre os pixels do município no mês")

descrever_era5 <- function(variaveis) {
    nomes <- sub(paste0("^", prefixo_era5), "", variaveis)
    map2_chr(nomes, variaveis, function(nome, original) {
        direto <- era5_dicionario$descricao[
            era5_dicionario$variavel == nome]
        if(length(direto) == 1) return(direto)
        sufixo <- names(significado_sufixo)[
            vapply(names(significado_sufixo),
                   function(s) grepl(paste0(s, "$"), nome),
                   logical(1))]
        if(length(sufixo) == 1) {
            base_nome <- sub(paste0(sufixo, "$"), "", nome)
            base_desc <- era5_dicionario$descricao[
                era5_dicionario$variavel == base_nome]
            if(length(base_desc) == 1) {
                return(paste0(base_desc, " - ",
                              significado_sufixo[[sufixo]]))
            }
        }
        return("Variável do ERA5 (ver dicionário da base de origem)")
    })
}

unidade_era5 <- function(variaveis) {
    nomes <- sub(paste0("^", prefixo_era5), "", variaveis)
    map_chr(nomes, function(nome) {
        direto <- era5_dicionario$unidade[
            era5_dicionario$variavel == nome]
        if(length(direto) == 1) return(direto)
        base_nome <- sub("_(dp|min|max)$", "", nome)
        base_unid <- era5_dicionario$unidade[
            era5_dicionario$variavel == base_nome]
        if(length(base_unid) == 1) return(base_unid)
        return("-")
    })
}

######@> Variáveis estáticas do ERA5...
## A AED do ERA5 mostrou que quatro variáveis (cvh, cvl, tvh, tvl) têm
## desvio-padrão temporal exatamente zero e que outras duas (lai_hv,
## lai_lv) repetem a mesma climatologia mensal em todos os anos. São
## descritores fixos do município, não séries - e a base precisa dizer
## isso a quem for usá-las como preditoras dinâmicas.
variaveis_estaticas_era5 <- c("cvh", "cvl", "tvh", "tvl")
variaveis_climatologicas_era5 <- c("lai_hv", "lai_lv")

######@> Descrições do bloco Atlas...
descrever_atlas <- function(variaveis) {
    nomes <- sub(paste0("^", prefixo_atlas), "", variaveis)
    grupos_conhecidos <- nome_coluna(sort(unique(
        atlas_mensal_grupo$grupo_desastre)))
    map_chr(nomes, function(nome) {
        direto <- atlas_dicionario$descricao[
            atlas_dicionario$variavel == nome]
        if(length(direto) >= 1) return(direto[1])
        grupo <- grupos_conhecidos[
            vapply(grupos_conhecidos,
                   function(g) grepl(paste0("_", g, "$"), nome),
                   logical(1))]
        if(length(grupo) == 1) {
            metrica <- sub(paste0("_", grupo, "$"), "", nome)
            base_desc <- atlas_dicionario$descricao[
                atlas_dicionario$variavel == metrica]
            rotulo <- sort(unique(atlas_mensal_grupo$grupo_desastre))[
                match(grupo, grupos_conhecidos)]
            if(length(base_desc) >= 1) {
                return(paste0(base_desc[1], " - grupo ", rotulo))
            }
            return(paste0("Métrica do Atlas por grupo de desastre - ",
                          rotulo))
        }
        return("Variável do Atlas (ver dicionário da base de origem)")
    })
}

######@> Descrições do bloco MapBiomas...
## Montadas a partir do caminho hierárquico da classe, que é a
## informação que o nome curto da coluna não carrega: saber que
## "cob_n2_mangue_ha" é "Floresta > Mangue" evita somar mangue com
## floresta.
mapa_descricao_mapb <- classes_com_ocorrencia %>%
    transmute(coluna_ha = paste0(prefixo_mapb, coluna, "_ha"),
              coluna_pct = paste0(prefixo_mapb, coluna, "_pct"),
              caminho = classe_caminho,
              nivel = nivel_profundidade) %>%
    pivot_longer(c(coluna_ha, coluna_pct), names_to = "medida",
                 values_to = "variavel") %>%
    mutate(descricao = paste0(
               "Cobertura MapBiomas, nível ", nivel, " - ", caminho,
               ifelse(medida == "coluna_ha", " (área)",
                      " (percentual da área do município)")),
           unidade = ifelse(medida == "coluna_ha", "ha", "%")) %>%
    select(variavel, descricao, unidade)

descricoes_mapb_fixas <- tribble(
    ~variavel, ~descricao, ~unidade,
    "urb_area_ha", "Área urbanizada do município (relatório Urbanização anual)", "ha",
    "urb_pct_area", "Área urbanizada como percentual da área do município", "%",
    "urb_vegetada_ha", "Área urbana classificada como vegetada", "ha",
    "urb_nao_vegetada_ha", "Área urbana classificada como não vegetada", "ha",
    "urb_total_vegetacao_ha", "Soma das áreas urbana vegetada e não vegetada", "ha",
    "urb_pct_vegetada", "Fração vegetada da mancha urbana", "%",
    "risco_medio_ha", "Área urbana em suscetibilidade média a inundação, alagamento ou enxurrada", "ha",
    "risco_alto_ha", "Área urbana em suscetibilidade alta a inundação, alagamento ou enxurrada", "ha",
    "risco_muito_alto_ha", "Área urbana em suscetibilidade muito alta a inundação, alagamento ou enxurrada", "ha",
    "risco_total_ha", "Soma das três faixas de suscetibilidade", "ha",
    "agua_forte_decrescimo_ha", "Superfície de água com tendência de forte decréscimo (<= -0,66)", "ha",
    "agua_medio_decrescimo_ha", "Superfície de água com tendência de médio decréscimo (-0,66 a -0,33)", "ha",
    "agua_leve_decrescimo_ha", "Superfície de água com tendência de leve decréscimo (-0,33 a 0)", "ha",
    "agua_leve_acrescimo_ha", "Superfície de água com tendência de leve acréscimo (0 a 0,33)", "ha",
    "agua_medio_acrescimo_ha", "Superfície de água com tendência de médio acréscimo (0,33 a 0,66)", "ha",
    "agua_forte_acrescimo_ha", "Superfície de água com tendência de forte acréscimo (>= 0,66)", "ha",
    "agua_balanco_ha", "Diferença entre as faixas de acréscimo e as de decréscimo", "ha") %>%
    mutate(variavel = paste0(prefixo_mapb, variavel))

descricoes_mapb <- bind_rows(mapa_descricao_mapb,
                             descricoes_mapb_fixas)

######@> Descrições das chaves e derivadas...
descricoes_chaves <- tribble(
    ~variavel, ~descricao, ~unidade,
    "geocodigo", "Código IBGE do município (chave primária)", "-",
    "municipio", "Nome do município conforme o shapefile do projeto", "-",
    "ano", "Ano civil", "-",
    "mes", "Mês do ano (1 a 12)", "-",
    "data", "Primeiro dia do mês (chave temporal)", "data",
    "trimestre", "Trimestre civil (1 a 4)", "-",
    "estacao", "Estação do ano, convenção meteorológica do hemisfério sul", "-",
    "dias_no_mes", "Número de dias do mês, usado para converter taxas diárias em totais", "dias",
    "tempo_indice", "Índice sequencial de meses desde o início da série", "meses",
    "tem_era5", "A linha tem observação do ERA5", "lógico",
    "tem_atlas", "A linha tem observação do Atlas (zero é observação; NA não é)", "lógico",
    "tem_mapbiomas", "A linha tem observação do MapBiomas", "lógico",
    "n_fontes", "Quantas das três fontes observaram esta linha", "-",
    "mapb_ano_referencia", "Ano do qual veio o valor anual repetido nos meses", "-")

######@> Montagem do dicionário...
dicionario_variaveis <- estatisticas_colunas %>%
    mutate(fonte = case_when(
               grepl(paste0("^", prefixo_era5), variavel) ~ "ERA5",
               grepl(paste0("^", prefixo_atlas), variavel) ~ "Atlas",
               variavel == "mapb_ano_referencia" ~ "Consolidação",
               grepl(paste0("^", prefixo_mapb), variavel) ~ "MapBiomas",
               TRUE ~ "Consolidação"),
           bloco = case_when(
               variavel %in% descricoes_chaves$variavel &
               !grepl("^tem_|^n_fontes$", variavel) ~ "Chave/tempo",
               grepl("^tem_|^n_fontes$", variavel) ~ "Cobertura",
               fonte == "ERA5" ~ "Clima (mensal)",
               fonte == "Atlas" &
               grepl("_(climatologico|hidrologico|meteorologico|outros)$",
                     variavel) ~ "Desastres por grupo (mensal)",
               fonte == "Atlas" ~ "Desastres (mensal)",
               grepl("cob_n", variavel) ~ "Cobertura da terra (anual)",
               grepl("_urb_", variavel) ~ "Urbanização (anual)",
               grepl("_risco_", variavel) ~ "Risco climático (anual)",
               grepl("_agua_", variavel) ~ "Água (anual)",
               TRUE ~ "Consolidação")) %>%
    left_join(bind_rows(descricoes_chaves, descricoes_mapb),
              by = "variavel") %>%
    mutate(descricao = case_when(
               !is.na(descricao) ~ descricao,
               fonte == "ERA5" ~ descrever_era5(variavel),
               fonte == "Atlas" ~ descrever_atlas(variavel),
               TRUE ~ "-"),
           unidade = case_when(
               !is.na(unidade) ~ unidade,
               fonte == "ERA5" ~ unidade_era5(variavel),
               fonte == "Atlas" ~ "contagem ou R$",
               TRUE ~ "-"),
           ## Ressalvas herdadas das três análises exploratórias. São a
           ## memória do que já se sabe sobre cada bloco, e o lugar certo
           ## para elas é junto da variável - não em um relatório à parte
           ## que ninguém abre ao montar um modelo.
           ressalva = case_when(
               fonte == "ERA5" &
               sub("^era5_", "", variavel) %in%
               c(variaveis_estaticas_era5,
                 paste0(rep(variaveis_estaticas_era5, each = 3),
                        c("_dp", "_min", "_max"))) ~
                   paste("Campo ESTÁTICO do ERA5: constante no tempo.",
                         "Descritor de superfície, não série temporal"),
               fonte == "ERA5" &
               sub("^era5_", "", variavel) %in%
               c(variaveis_climatologicas_era5,
                 paste0(rep(variaveis_climatologicas_era5, each = 3),
                        c("_dp", "_min", "_max"))) ~
                   paste("Climatologia mensal fixa: varia dentro do ano,",
                         "mas é idêntica entre anos. Não é série observada"),
               variavel == paste0(prefixo_era5, "vento_dir_graus") ~
                   paste("Variável CIRCULAR: média aritmética não tem",
                         "sentido; usar média vetorial (u10, v10)"),
               variavel == paste0(prefixo_era5, "vento_vel_m_s") ~
                   paste("Módulo do vento MÉDIO; para intensidade use",
                         "si10, que é a média das velocidades"),
               fonte == "ERA5" & grepl("_(dp|min|max)$", variavel) ~
                   paste("Dispersão ENTRE PIXELS do município no mês,",
                         "não extremo temporal"),
               fonte == "ERA5" ~
                   "Reanálise (saída de modelo), não observação direta",
               fonte == "Atlas" ~
                   paste("Zero = mês sem desastre registrado;",
                         "NA = fora da cobertura 1991-2025 ou município",
                         "sem Atlas"),
               grepl("_agua_", variavel) ~
                   paste("Faixa de TENDÊNCIA, não estado da paisagem;",
                         "cobertura cresce ao longo do tempo e não fecha",
                         "a área do município"),
               variavel %in% paste0(prefixo_mapb,
                                    c("risco_medio_ha",
                                      "risco_alto_ha")) ~
                   paste("Constante ao longo dos 40 anos em todos os",
                         "municípios cobertos: a suscetibilidade é",
                         "atributo do terreno"),
               grepl("cob_n1_.*_pct$", variavel) ~
                   paste("Composição FECHADA: as cinco classes de nível 1",
                         "somam 100%. Não usar todas como preditoras",
                         "independentes"),
               grepl("cob_n", variavel) ~
                   paste("Valor ANUAL repetido nos meses do ano;",
                         "classes são ANINHADAS entre níveis"),
               fonte == "MapBiomas" ~
                   "Valor ANUAL repetido nos meses do ano",
               TRUE ~ "-")) %>%
    select(variavel, fonte, bloco, unidade, descricao, tipo_r,
           ano_min, ano_max, n_municipios, n_ausentes, pct_ausente,
           ressalva)

message("\nDicionário montado     : ", nrow(dicionario_variaveis),
        " variáveis")
print(as.data.frame(dicionario_variaveis %>%
                    count(fonte, bloco, name = "variaveis")),
      right = FALSE)

########################################################################
######@> Etapa 09 - Diagnóstico de completude e conferências finais...

######@> Cobertura de cada fonte, município a município...
## Responde à pergunta que todo usuário da base fará antes de modelar:
## de quantos meses eu disponho, em cada município, para cada fonte?
diagnostico_cobertura <- base_mensal %>%
    group_by(geocodigo, municipio) %>%
    summarise(meses_na_grade = n(),
              meses_era5 = sum(tem_era5),
              meses_atlas = sum(tem_atlas),
              meses_mapbiomas = sum(tem_mapbiomas),
              meses_tres_fontes = sum(n_fontes == 3),
              ano_ini_era5 = min(ano[tem_era5]),
              ano_fim_era5 = max(ano[tem_era5]),
              ano_ini_atlas = if(any(tem_atlas))
                  min(ano[tem_atlas]) else NA_integer_,
              ano_fim_atlas = if(any(tem_atlas))
                  max(ano[tem_atlas]) else NA_integer_,
              ano_ini_mapbiomas = if(any(tem_mapbiomas))
                  min(ano[tem_mapbiomas]) else NA_integer_,
              ano_fim_mapbiomas = if(any(tem_mapbiomas))
                  max(ano[tem_mapbiomas]) else NA_integer_,
              .groups = "drop") %>%
    mutate(pct_tres_fontes = 100 * meses_tres_fontes / meses_na_grade) %>%
    arrange(desc(meses_tres_fontes))

######@> Cobertura ao longo do tempo...
## A mesma informação vista pelo outro eixo: em cada ano, quantos
## municípios cada fonte cobre. É a tabela que mostra, em uma olhada,
## onde começa e onde termina a janela em que as três fontes convivem.
diagnostico_temporal <- base_mensal %>%
    group_by(ano) %>%
    summarise(meses = n(),
              municipios_era5 = n_distinct(geocodigo[tem_era5]),
              municipios_atlas = n_distinct(geocodigo[tem_atlas]),
              municipios_mapbiomas = n_distinct(geocodigo[tem_mapbiomas]),
              .groups = "drop")

######@> Janela de convivência das três fontes...
anos_tres_fontes <- diagnostico_temporal %>%
    filter(municipios_era5 > 0, municipios_atlas > 0,
           municipios_mapbiomas > 0)

message("\nJanela com as três fontes: ", min(anos_tres_fontes$ano),
        "-", max(anos_tres_fontes$ano), " (",
        nrow(anos_tres_fontes), " anos)")

######@> Reconciliação de valores com as bases de origem...
## As conferências anteriores garantiram que a JUNÇÃO não multiplicou
## nem perdeu linhas. Estas garantem que os VALORES chegaram intactos -
## o erro que nenhuma contagem de linhas revela, porque um join com
## chave parcialmente errada devolve NA e não erro.
##
## Uma verificação por fonte, sobre uma grandeza somável:
##   Atlas     - total de eventos registrados;
##   ERA5      - soma da temperatura média (identidade exata);
##   MapBiomas - área de floresta em um município-ano tomado ao acaso.
total_eventos_origem <- sum(atlas_mensal$n_eventos)
total_eventos_base <- sum(base_mensal[[coluna_ref_atlas]],
                          na.rm = TRUE)

soma_t2m_origem <- sum(era5_bruto$t2m)
soma_t2m_base <- sum(base_mensal[[paste0(prefixo_era5, "t2m")]])

amostra_mapb <- mapb_cobertura_bruta %>%
    filter(classe_caminho == "Floresta") %>%
    slice(round(nrow(.) / 3))

valor_mapb_origem <- amostra_mapb$area_ha
valor_mapb_base <- base_mensal %>%
    filter(geocodigo == amostra_mapb$geocodigo,
           ano == amostra_mapb$ano) %>%
    pull(!!coluna_ref_mapb) %>%
    unique()

stopifnot(total_eventos_origem == total_eventos_base,
          isTRUE(all.equal(soma_t2m_origem, soma_t2m_base)),
          length(valor_mapb_base) == 1,
          isTRUE(all.equal(valor_mapb_origem, valor_mapb_base)))

message("Reconciliação de valores:")
message("  Atlas - eventos      : ", fmt_int(total_eventos_base),
        " na base = ", fmt_int(total_eventos_origem), " na origem")
message("  ERA5 - soma de t2m   : idêntica à origem")
message("  MapBiomas - amostra  : ", amostra_mapb$municipio, "/",
        amostra_mapb$ano, " = ", sprintf("%.2f", valor_mapb_base),
        " ha de floresta, repetidos em ",
        sum(base_mensal$geocodigo == amostra_mapb$geocodigo &
            base_mensal$ano == amostra_mapb$ano), " meses")

######@> Colunas inteiramente vazias...
## Uma coluna toda NA pode ter duas causas muito diferentes: falha de
## junção neste script - que seria um erro grave e silencioso - ou
## ausência HERDADA da base de origem. O ERA5, por exemplo, entrega
## tvh_dp e tvl_dp inteiramente vazias, porque o desvio-padrão de uma
## variável categórica (o tipo de vegetação, resumido pela moda) não é
## definido. A verificação separa os dois casos comparando cada coluna
## vazia com sua contraparte na origem.
colunas_vazias <- dicionario_variaveis %>%
    filter(pct_ausente == 100) %>%
    pull(variavel)

vazia_na_origem <- function(coluna) {
    if(grepl(paste0("^", prefixo_era5), coluna)) {
        nome <- sub(paste0("^", prefixo_era5), "", coluna)
        return(nome %in% names(era5_bruto) &&
               all(is.na(era5_bruto[[nome]])))
    }
    if(grepl(paste0("^", prefixo_atlas), coluna)) {
        nome <- sub(paste0("^", prefixo_atlas), "", coluna)
        return(nome %in% names(atlas_mensal) &&
               all(is.na(atlas_mensal[[nome]])))
    }
    return(FALSE)
}

vazias_herdadas <- colunas_vazias[
    vapply(colunas_vazias, vazia_na_origem, logical(1))]
vazias_inesperadas <- setdiff(colunas_vazias, vazias_herdadas)

if(length(vazias_herdadas) > 0) {
    message("Colunas vazias herdadas: ",
            paste(vazias_herdadas, collapse = ", "),
            " (já vazias na base de origem)")
}
if(length(vazias_inesperadas) > 0) {
    warning("Colunas vazias SEM explicação na origem - possível falha ",
            "de junção: ", paste(vazias_inesperadas, collapse = ", "))
}
if(length(colunas_vazias) == 0) {
    message("Colunas vazias         : nenhuma")
}

######@> Registro da ausência total no dicionário...
## A coluna existe, mas não tem um único valor: quem for modelar precisa
## saber disso ao ler o dicionário, sem ter de conferir a base.
dicionario_variaveis <- dicionario_variaveis %>%
    mutate(ressalva = case_when(
               variavel %in% vazias_herdadas ~
                   paste0("COLUNA VAZIA (sem valor em toda a base), ",
                          "já vazia na origem. ", ressalva),
               variavel %in% vazias_inesperadas ~
                   paste0("COLUNA VAZIA e sem explicação na origem - ",
                          "conferir a junção. ", ressalva),
               TRUE ~ ressalva))

########################################################################
######@> Etapa 10 - Base anual derivada...

######@> Regra de agregação por bloco...
## Declarada uma única vez, aqui, e registrada no dicionário da base
## anual:
##
##   - ATLAS: SOMA. São fluxos - eventos, mortos, afetados, prejuízo -,
##     e o total do ano é a soma dos meses. A soma usa soma_ou_na, de
##     modo que um ano inteiramente fora da cobertura devolva NA e não
##     zero;
##
##   - ERA5: MÉDIA dos doze meses. São variáveis de ESTADO (temperatura,
##     nebulosidade, vento) ou taxas médias diárias, e a média mensal
##     simples é a agregação correta para ambas. A precipitação ganha,
##     além da média, o TOTAL acumulado do ano, que é a grandeza usual;
##
##   - MAPBIOMAS: o PRÓPRIO VALOR. É constante dentro do ano - foi ele
##     que a Etapa 06 repetiu -, e tomar o primeiro valor não-ausente é
##     exato, ao contrário da média, que introduziria erro numérico.
message("\nConstruindo a base anual derivada...")

colunas_era5 <- names(base_mensal)[
    grepl(paste0("^", prefixo_era5), names(base_mensal))]
colunas_atlas <- names(base_mensal)[
    grepl(paste0("^", prefixo_atlas), names(base_mensal))]
colunas_mapb <- names(base_mensal)[
    grepl(paste0("^", prefixo_mapb), names(base_mensal))]

base_anual <- base_mensal %>%
    group_by(geocodigo, municipio, ano) %>%
    summarise(n_meses = n(),
              n_meses_era5 = sum(tem_era5),
              n_meses_atlas = sum(tem_atlas),
              n_meses_mapbiomas = sum(tem_mapbiomas),
              dias_no_ano = sum(dias_no_mes),
              era5_tp_mm_ano = soma_ou_na(
                  .data[[paste0(prefixo_era5, "tp_mm_mes")]]),
              era5_cp_mm_ano = soma_ou_na(
                  .data[[paste0(prefixo_era5, "cp_mm_mes")]]),
              across(all_of(colunas_era5), media_ou_na),
              across(all_of(colunas_atlas), soma_ou_na),
              across(all_of(colunas_mapb), primeiro_ou_na),
              .groups = "drop") %>%
    mutate(ano_completo = n_meses >= limiar_ano_completo,
           tem_era5 = n_meses_era5 > 0,
           tem_atlas = n_meses_atlas > 0,
           tem_mapbiomas = n_meses_mapbiomas > 0,
           n_fontes = as.integer(tem_era5) + as.integer(tem_atlas) +
               as.integer(tem_mapbiomas),
           .after = ano)

######@> Contagem anual por tipologia de desastre...
## O Atlas classifica cada evento em 16 tipologias (Enxurradas,
## Inundações, Vendavais e Ciclones, Estiagem e Seca, ...), mas só
## disponibiliza esse recorte em escala ANUAL. Por isso ele entra aqui e
## não na base mensal: repetir uma contagem anual nos doze meses
## multiplicaria o total por doze - exatamente o erro que a repetição do
## MapBiomas não comete, porque área é estoque e contagem é fluxo.
##
## O sufixo "tip_" no nome da coluna NÃO é decorativo: "Outros" é ao
## mesmo tempo um GRUPO e uma TIPOLOGIA do Atlas, e sem ele a coluna da
## tipologia colidiria com a do grupo já presente na base - o join
## devolveria um par de colunas com sufixos .x e .y, e a conferência de
## totais falharia (foi exatamente o que aconteceu na primeira versão
## desta etapa).
bloco_tipologia <- atlas_anual_tipologia %>%
    mutate(coluna = paste0("n_eventos_tip_", nome_coluna(tipologia))) %>%
    select(geocodigo, ano, coluna, n_eventos) %>%
    pivot_wider(names_from = coluna, values_from = n_eventos) %>%
    prefixar(prefixo_atlas, chaves = c("geocodigo", "ano"))

base_anual <- base_anual %>%
    left_join(bloco_tipologia, by = c("geocodigo", "ano"))

######@> Conferência da base anual...
## O total de eventos precisa sobreviver às duas agregações - a mensal
## por grupo e a anual por tipologia -, e os anos incompletos precisam
## ser exatamente os que se sabe existirem (2026, com sete meses de
## reanálise).
total_eventos_anual <- sum(base_anual[[coluna_ref_atlas]],
                           na.rm = TRUE)
total_tipologia <- base_anual %>%
    select(starts_with(paste0(prefixo_atlas, "n_eventos_tip_"))) %>%
    sum(na.rm = TRUE)

stopifnot(total_eventos_anual == total_eventos_origem,
          total_tipologia == total_eventos_origem)

anos_incompletos <- base_anual %>%
    filter(!ano_completo) %>%
    distinct(ano, n_meses)

message("Base anual             : ", fmt_int(nrow(base_anual)),
        " linhas x ", ncol(base_anual), " colunas | ",
        min(base_anual$ano), "-", max(base_anual$ano))
message("  Anos incompletos     : ",
        ifelse(nrow(anos_incompletos) == 0, "nenhum",
               paste0(anos_incompletos$ano, " (",
                      anos_incompletos$n_meses, " meses)",
                      collapse = ", ")))
message("  Eventos conferidos   : ", fmt_int(total_eventos_anual),
        " no total e por tipologia")

######@> Dicionário da base anual...
## Herda a descrição de cada variável da base mensal e acrescenta a
## REGRA de agregação aplicada - sem a qual não é possível saber se uma
## coluna anual é soma, média ou repetição.
dicionario_anual <- tibble(variavel = names(base_anual)) %>%
    left_join(dicionario_variaveis %>%
                  select(variavel, fonte, bloco, unidade, descricao,
                         ressalva),
              by = "variavel") %>%
    mutate(regra_agregacao = case_when(
               variavel %in% colunas_atlas ~ "Soma dos meses",
               grepl(paste0("^", prefixo_atlas, "n_eventos_tip_"),
                     variavel) & is.na(fonte) ~
                   "Contagem anual por tipologia (origem já anual)",
               variavel %in% colunas_era5 ~ "Média dos meses",
               variavel %in% c("era5_tp_mm_ano", "era5_cp_mm_ano") ~
                   "Soma dos totais mensais",
               variavel %in% colunas_mapb ~
                   "Valor anual (constante nos meses)",
               TRUE ~ "Chave, contagem ou sinalizador"),
           fonte = case_when(
               !is.na(fonte) ~ fonte,
               grepl(paste0("^", prefixo_atlas), variavel) ~ "Atlas",
               grepl(paste0("^", prefixo_era5), variavel) ~ "ERA5",
               TRUE ~ "Consolidação"),
           bloco = case_when(
               !is.na(bloco) ~ bloco,
               grepl(paste0("^", prefixo_atlas, "n_eventos_tip_"),
                     variavel) ~ "Desastres por tipologia (anual)",
               TRUE ~ "Consolidação"),
           descricao = case_when(
               !is.na(descricao) ~ descricao,
               variavel == "era5_tp_mm_ano" ~
                   "Precipitação total acumulada no ano",
               variavel == "era5_cp_mm_ano" ~
                   "Precipitação convectiva acumulada no ano",
               variavel == "n_meses" ~
                   "Meses do ano presentes na grade",
               variavel == "dias_no_ano" ~
                   "Dias somados dos meses presentes",
               variavel == "ano_completo" ~
                   "O ano tem os doze meses na grade",
               grepl(paste0("^", prefixo_atlas, "n_eventos_tip_"),
                     variavel) ~
                   paste0("Eventos de desastre da tipologia ",
                          sub(paste0("^", prefixo_atlas,
                                     "n_eventos_tip_"), "", variavel)),
               grepl("^n_meses_", variavel) ~
                   paste0("Meses do ano com observação de ",
                          sub("^n_meses_", "", variavel)),
               TRUE ~ "-"),
           unidade = ifelse(is.na(unidade), "-", unidade),
           ressalva = case_when(
               !is.na(ressalva) ~ ressalva,
               grepl(paste0("^", prefixo_atlas, "n_eventos_tip_"),
                     variavel) ~
                   paste("Recorte por tipologia existe apenas em escala",
                         "anual; NA fora da cobertura 1991-2025"),
               TRUE ~ "-"))

########################################################################
######@> Etapa 11 - Exportação dos resultados...

######@> Exportação das bases consolidadas...
## Dois formatos, pelas mesmas razões adotadas nas três bases de origem:
## Parquet é colunar, compacto e legível por Python, R, DuckDB e
## qualquer ferramenta moderna - o que importa quando a etapa seguinte
## envolve aprendizado de máquina, muitas vezes fora do R; RData
## preserva os tipos nativos (fator, Date) e a estrutura exata dos
## objetos para quem seguir no R.
message("\nExportando bases consolidadas...")

write_parquet(base_mensal,
              file.path(dir_pq, "Consolidado_municipio_mes.parquet"))
write_parquet(base_anual,
              file.path(dir_pq, "Consolidado_municipio_ano.parquet"))
write_parquet(dicionario_variaveis,
              file.path(dir_pq, "Consolidado_dicionario_mensal.parquet"))
write_parquet(dicionario_anual,
              file.path(dir_pq, "Consolidado_dicionario_anual.parquet"))
write_parquet(municipios,
              file.path(dir_pq, "Consolidado_municipios.parquet"))
write_parquet(diagnostico_cobertura,
              file.path(dir_pq,
                        "Consolidado_diagnostico_cobertura.parquet"))
write_parquet(diagnostico_temporal,
              file.path(dir_pq,
                        "Consolidado_diagnostico_temporal.parquet"))

save(base_mensal, base_anual, dicionario_variaveis, dicionario_anual,
     municipios, diagnostico_cobertura, diagnostico_temporal,
     file = file.path(dir_rd, "Consolidado_SC.RData"))

######@> Exportação individual por município...
## Um par de arquivos por município, contendo suas séries mensal e
## anual. Os objetos são sempre salvos com os mesmos nomes
## ("dados_municipio_mes" e "dados_municipio_ano"), garantindo
## previsibilidade ao carregar qualquer um deles com load() - convenção
## idêntica à das três bases de origem.
message("Exportando arquivos por município...")

for(g in sort(unique(base_mensal$geocodigo))) {
    dados_municipio_mes <- base_mensal %>% filter(geocodigo == g)
    dados_municipio_ano <- base_anual %>% filter(geocodigo == g)

    nome_muni <- limpar_nome(unique(dados_municipio_mes$municipio))
    nome_base <- paste0("Consolidado_", g, "_", nome_muni)

    write_parquet(dados_municipio_mes,
                  file.path(dir_pq_mun, paste0(nome_base, ".parquet")))
    write_parquet(dados_municipio_ano,
                  file.path(dir_pq_mun,
                            paste0(nome_base, "_anual.parquet")))
    save(dados_municipio_mes, dados_municipio_ano,
         file = file.path(dir_rd_mun, paste0(nome_base, ".RData")))
}

message("  ", length(unique(base_mensal$geocodigo)),
        " municípios exportados (", 2 * length(unique(base_mensal$geocodigo)),
        " Parquet + ", length(unique(base_mensal$geocodigo)), " RData)")

######@> Resumo final do processamento...
message("\n=== Consolidação concluída ===")
message("Base mensal            : ", fmt_int(nrow(base_mensal)),
        " linhas x ", ncol(base_mensal), " colunas (",
        nrow(municipios), " municípios x ", length(datas_grade),
        " meses)")
message("Base anual             : ", fmt_int(nrow(base_anual)),
        " linhas x ", ncol(base_anual), " colunas")
message("Extensão temporal      : ", format(min(datas_grade), "%m/%Y"),
        " a ", format(max(datas_grade), "%m/%Y"),
        " (grade do ERA5, a mais longa das três fontes)")
message("Cobertura das fontes   : ERA5 ", min(era5_bruto$ano), "-",
        max(era5_bruto$ano), " | Atlas ", min(atlas_mensal$ano), "-",
        max(atlas_mensal$ano), " | MapBiomas ",
        min(bloco_mapb$ano), "-", max(bloco_mapb$ano))
message("Variáveis por fonte    : ERA5 ", length(colunas_era5),
        " | Atlas ", length(colunas_atlas), " (mensal) + ",
        sum(grepl(paste0("^", prefixo_atlas, "n_eventos_tip_"),
                  names(base_anual))), " (tipologia, anual) | MapBiomas ",
        length(colunas_mapb))
message("Linhas com as 3 fontes : ",
        fmt_int(sum(base_mensal$n_fontes == 3)), " (",
        sprintf("%.1f%%", 100 * mean(base_mensal$n_fontes == 3)),
        "), janela ", min(anos_tres_fontes$ano), "-",
        max(anos_tres_fontes$ano))
message("Dicionários            : ", nrow(dicionario_variaveis),
        " variáveis (mensal) | ", nrow(dicionario_anual), " (anual)")
message("Saídas em              : ", normalizePath(dir_cons))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
