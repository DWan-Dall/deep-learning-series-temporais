########################################################################
## Description: Download de dados ERA5 (monthly means) via Reticulate...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: sex ago 14 18:16:25 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info:
##
### Commentary:
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(reticulate)

######@> Keyring CDS...
## url: https://cds.climate.copernicus.eu/api
## key: e23a32ed-c13b-44fd-9c67-da4969aad231

########################################################################
######@> Function for Python...

######@> Python-R function...
download_era5_cds <- function(token,
                              url = "https://cds.climate.copernicus.eu/api",
                              dest_file = "era5_monthly_means.nc",
                              anos = as.character(1940:2026),
                              envname = NULL) {
    ## 1. Garantir que o pacote Python 'cdsapi' está disponível --------
    if (!is.null(envname)) use_virtualenv(envname, required = TRUE)
    if (!py_module_available("cdsapi")) {
        message("Instalando o pacote Python 'cdsapi'...")
        py_install("cdsapi", pip = TRUE)
    }
    cdsapi <- import("cdsapi")
    ## 2. Autenticar passando url e key diretamente ao Client ----------
    ##    (dispensa o arquivo ~/.cdsapirc)
    client <- cdsapi$Client(url = url, key = token)
    ## 3. Montar o request ---------------------------------------------
    ## Listas em R são convertidas para listas Python pelo reticulate
    dataset <- "reanalysis-era5-single-levels-monthly-means"
    request <- list(
        product_type = list("monthly_averaged_reanalysis"),
        variable = list("10m_u_component_of_wind",
                        "10m_v_component_of_wind",
                        "2m_temperature",
                        "total_precipitation",
                        "10m_wind_speed",
                        "surface_latent_heat_flux",
                        "surface_net_solar_radiation",
                        "total_cloud_cover",
                        "evaporation",
                        "potential_evaporation",
                        "convective_precipitation",
                        "large_scale_rain_rate",
                        "precipitation_type",
                        "total_column_rain_water",
                        "high_vegetation_cover",
                        "leaf_area_index_high_vegetation",
                        "leaf_area_index_low_vegetation",
                        "low_vegetation_cover",
                        "type_of_high_vegetation",
                        "type_of_low_vegetation"),
        year = as.list(anos),
        month = list("01", "02", "03", "04", "05", "06",
                     "07", "08", "09", "10", "11", "12"),
        time = list("00:00"),
        data_format = "netcdf",
        download_format = "unarchived",
        area = list(-23, -52, -30, -46)   # Norte, Oeste, Sul, Leste
    )
    ## 4. Submeter e baixar --------------------------------------------
    message("Submetendo requisição ao CDS (pode ficar na fila por um tempo)...")
    result <- client$retrieve(dataset, request)
    result$download(dest_file)
    message("Download concluído: ", normalizePath(dest_file))
    invisible(dest_file)
}

########################################################################
######@> Exemplo de uso...

######@> Uso direto - Porém, requisições grandes pode haver restrição do
######@> próprio CDS...
download_era5_cds(
    token = "e23a32ed-c13b-44fd-9c67-da4969aad231",
    dest_file = "era5_sul_brasil.nc"
)

######@> Looping para download dos dados da dissertação da Daiane
######@> Wan-Dall...
for(ano in 1940:2026) {
    download_era5_cds(
        token = Sys.getenv("CDS_TOKEN"),
        anos = as.character(ano),
        dest_file = sprintf("era5_sul_brasil_%d.nc", ano))
}

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
