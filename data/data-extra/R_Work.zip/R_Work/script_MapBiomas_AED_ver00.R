########################################################################
## Description: Análise exploratória de dados (AED) das séries anuais
##              de uso e cobertura da terra do MapBiomas por município
##              costeiro de Santa Catarina, com foco nos padrões
##              espaço-temporais da transformação da paisagem...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: qua ago 19 20:00:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: Base padronizada pelo
##                script_MapBiomas_extracao_municipios_ver00.R:
##                  - series_anuais        : município x tema x
##                                           relatório x classe x ano
##                                           (118.579 linhas)
##                  - agregados_periodo    : recortes de período e
##                                           coorte (1.051 linhas)
##                  - cobertura_larga_n1/n2: cobertura em formato largo
##                  - hierarquia_classes   : árvore de classes por tema
##                  - dicionario_relatorios: metadados dos relatórios
##                  - diagnostico          : completude por município
##                  - resumo_municipios    : áreas e cobertura
##                Complementada pelo shapefile de municípios.
##                Áreas em HECTARES. Quatro temas do MapBiomas
##                (Cobertura 30m, Urbano, Risco Climático e Água
##                Mensal), 35 municípios com dados, 1985-2024.
##
### Commentary:
##
## Esta é a análise exploratória que antecede a modelagem. Seu propósito
## não é responder às perguntas da dissertação, e sim estabelecer O QUE
## OS DADOS PERMITEM PERGUNTAR: quais das 118.579 linhas são de fato
## série temporal, em que nível da hierarquia de classes a análise deve
## ser conduzida, que estrutura de dependência sobra depois de tratada a
## natureza de ESTOQUE das séries de cobertura, e quanta informação
## espacial independente existe entre os 35 municípios.
##
## Oito achados da sondagem preliminar estruturam o documento e precisam
## ser declarados antes de qualquer resultado, porque cada um deles
## descarta uma análise que pareceria natural:
##
##    (i) NEM TODA LINHA DA BASE É UMA SÉRIE TEMPORAL. A base reúne
##        QUATRO temas do MapBiomas com semânticas distintas, e apenas
##        parte deles é série anual. Dos 14 relatórios inventariados,
##        cinco têm tipo temporal "ano" e estão marcados como série
##        (Cobertura por classe, Risco climático, Urbanização anual,
##        Vegetação urbana e Tendência da superfície de água); os demais
##        são AGREGADOS de período (número de mudanças, número de
##        classes, transições 1985-2024) ou de COORTE (períodos de
##        urbanização), que descrevem o intervalo inteiro em uma única
##        linha e não admitem ACF, tendência ou decomposição. O script
##        faz essa triagem na Etapa 02 e conduz as análises de série
##        apenas sobre o que é série, mantendo os agregados como
##        descritores do período;
##
##   (ii) AS CLASSES SÃO HIERÁRQUICAS E ANINHADAS. A coluna
##        classe_caminho guarda a árvore completa ("Agropecuária >
##        Agricultura > Lavoura Temporária > Arroz"), e a base traz
##        TODOS os níveis simultaneamente: somar todas as classes de um
##        município conta a mesma área até quatro vezes. Na Cobertura,
##        os cinco níveis 1 somam exatamente 100% em todos os 1.400
##        pares município-ano, e cada nível seguinte reparte o nível
##        anterior. Toda análise composicional deste script declara o
##        nível em que opera, e nenhuma mistura níveis;
##
##  (iii) A COMPOSIÇÃO É FECHADA, E ISSO CONTAMINA AS CORRELAÇÕES. Como
##        as proporções somam 100%, o ganho de uma classe é
##        necessariamente a perda de outra: no litoral, a floresta perde
##        44.190 ha entre 1985 e 2024 e a área não vegetada ganha
##        45.249 ha - números quase idênticos que NÃO constituem
##        evidência independente. A correlação bruta entre Agropecuária
##        e Floresta é -0,776, mas parte disso é imposta pelo
##        fechamento, não observada: sob a transformação log-razão
##        centrada (CLR) o mesmo par passa a +0,43 - INVERTE DE SINAL -,
##        e o mesmo ocorre em 6 dos 10 pares de classes. Uma leitura
##        ingênua da matriz de correlação levaria à conclusão oposta à
##        correta na maioria dos pares. A Etapa 13 refaz a matriz e a
##        PCA sobre o CLR, que é a leitura estatisticamente adequada de
##        dados composicionais, e apresenta as duas versões lado a
##        lado;
##
##   (iv) ONZE CLASSES SÃO IDENTICAMENTE NULAS NO LITORAL. Lavoura
##        Perene e suas quatro subclasses (Café, Citrus, Dendê e Outras
##        Lavouras Perenes), Algodão, Cana, Formação Savânica, Floresta
##        Alagável, Afloramento Rochoso e Usina Fotovoltaica valem zero
##        em TODOS os municípios e em TODOS os anos. São classes do dicionário nacional do MapBiomas sem
##        ocorrência neste recorte, e submetê-las a ACF ou a teste de
##        tendência produziria resultado formalmente calculável e
##        substantivamente vazio. A Etapa 02 as identifica e as demais
##        etapas operam apenas sobre as classes com ocorrência;
##
##    (v) AS SÉRIES DE COBERTURA SÃO DE ESTOQUE, NÃO DE FLUXO. A área de
##        floresta de um município em 2010 é a de 2009 mais o saldo do
##        ano: a autocorrelação é alta POR CONSTRUÇÃO, e não porque
##        exista memória no processo de transformação. A ACF de lag 1 da
##        série em nível fica entre 0,85 e 0,92 conforme a classe, e cai
##        para 0,14 a 0,48 nas PRIMEIRAS DIFERENÇAS - que são a série de
##        fluxo, isto é, a taxa anual de conversão. Todos os
##        correlogramas deste script são apresentados nas duas versões,
##        porque a primeira responde "como é a paisagem" e apenas a
##        segunda responde "quanto a conversão de um ano informa sobre a
##        do ano seguinte";
##
##   (vi) OS 35 MUNICÍPIOS NÃO SÃO REDUNDANTES - AO CONTRÁRIO DO ERA5.
##        Este é o achado que mais distingue esta base da climática. Na
##        reanálise, um único componente principal explicava 96,5% da
##        variância conjunta das anomalias térmicas municipais, e
##        efeitos espaciais livres não se justificavam. Aqui, a
##        correlação mediana entre as PRIMEIRAS DIFERENÇAS da série de
##        floresta é de apenas 0,139, o primeiro componente explica
##        23,4% da variância e são necessários 17 componentes para
##        atingir 95%. A conversão ANO A ANO é um processo local,
##        governado por decisões municipais, e cada município carrega
##        informação própria. Efeitos municipais livres são não apenas
##        admissíveis como necessários - a Etapa 13 quantifica isso
##        classe a classe.
##
##        Duas ressalvas impedem que isso seja lido como ausência de
##        estrutura espacial. A primeira: em NÍVEL as mesmas séries
##        parecem redundantes (PC1 de 96,5% na área urbanizada, o mesmo
##        patamar do ERA5), mas isso é artefato da tendência comum -
##        todas as manchas urbanas crescem, e séries crescentes
##        correlacionam-se entre si independentemente de qualquer
##        sincronia real. A segunda, e mais importante: o SALDO de
##        quarenta anos É espacialmente estruturado. A perda florestal
##        concentra-se no terço norte do litoral, no entorno da
##        conurbação Joinville-Itajaí, com índice de Moran de 0,63
##        (p < 0,001) e um agrupamento local significativo de sete
##        municípios contíguos (Etapa 14). Não há contradição: os
##        municípios do norte caminharam na mesma direção ao longo de
##        quatro décadas sem que suas conversões anuais fossem
##        simultâneas;
##
##  (vii) O TEMA RISCO CLIMÁTICO É QUASE ESTÁTICO. As áreas urbanas
##        classificadas como de suscetibilidade "Alto" e "Médio" não
##        variam um único hectare em quarenta anos em NENHUM dos 34
##        municípios cobertos; só a faixa "Muito Alto" tem variação
##        (em 27 dos 34), e no conjunto do litoral ela cresce de
##        4.939 ha para 6.935 ha (+40%). O tema é o cruzamento de um
##        mapa FIXO de suscetibilidade com a mancha urbana, de modo que
##        sua dinâmica é a dinâmica da urbanização, e não a de um risco
##        que mudou: dentro de cada município, a correlação temporal
##        entre área suscetível e área urbanizada tem mediana de 0,95.
##        A Etapa 08 documenta isso e mede também a associação entre
##        municípios (r = 0,54 em nível, 0,60 em log), bem mais fraca -
##        municípios com manchas urbanas parecidas podem ter exposições
##        muito diferentes. O tema não cobre São João do Sul;
##
## (viii) O TEMA ÁGUA MENSAL NÃO É UM PAINEL COMPARÁVEL. Duas razões
##        independentes o descartam como série: (a) o número de
##        municípios com registro CRESCE ao longo do tempo - um em 1992,
##        seis em 1995, treze em 1999, e só a partir de 2005 estabiliza
##        em 23 ou 24 dos 25 -, de modo que qualquer agregado do litoral
##        confundiria entrada de município com mudança real na
##        superfície de água; e (b) suas classes não são estados da
##        paisagem, mas FAIXAS DE TENDÊNCIA ("≤ -0,66 - Forte
##        decréscimo", "0 a 0,33 - Leve acréscimo"), que não fecham a
##        área do município (as somas variam de 0,03% a 78,5%). A Etapa
##        09 documenta o problema e o tema fica fora das análises de
##        série; o que dele se aproveita é o retrato do sentido da
##        mudança hídrica, e ainda assim nos 25 municípios cobertos.
##
## Quatro escolhas metodológicas adicionais:
##
##   - Camboriú e Paulo Lopes não têm dados no MapBiomas (35 municípios
##     de 37). Permanecem na base cartográfica, para que apareçam nos
##     mapas como "sem dados" em vez de virarem um buraco no litoral,
##     mas ficam FORA de todas as estatísticas. É a mesma decisão
##     adotada na AED do Atlas Digital;
##
##   - a composição é lida em area_pct (percentual da área total do
##     município segundo o MapBiomas), e não em area_pct_terrestre. As
##     duas correlacionam-se a 0,988 e diferem em média 2,1 pontos
##     percentuais, mas apenas a primeira fecha exatamente 100% no
##     nível 1, que é o requisito da leitura composicional. A versão
##     terrestre é preservada nas tabelas por ser a métrica adequada
##     quando o objetivo é comparar municípios com muita área de água;
##
##   - a série tem 40 observações anuais e nenhuma sazonalidade
##     (o MapBiomas produz um mosaico por ano). Isso limita a
##     defasagem máxima examinada a 13 anos (um terço da série),
##     dispensa a decomposição STL - substituída por decomposição em
##     tendência (loess) e resíduo - e recomenda cautela com os testes
##     de raiz unitária, cujo poder é baixo nesse tamanho de amostra;
##
##   - as taxas de transformação são reportadas em ha/ano (declividade
##     de Sen) e também em pontos percentuais por década, para que
##     municípios de tamanhos muito diferentes - Joinville tem 1.130 km²
##     e Bombinhas 34 km² - possam ser comparados.
##
## Fluxo geral da análise:
##
##   01) Leitura da base e preparação dos objetos de trabalho;
##   02) Panorama, completude e triagem do que é série temporal;
##   03) Composição da paisagem e estrutura hierárquica das classes;
##   04) Trajetórias temporais do litoral e dos municípios;
##   05) Mudança líquida 1985-2024 e a restrição de fechamento;
##   06) Padrões municipais e gradiente espacial;
##   07) Urbanização e vegetação urbana;
##   08) Risco climático: áreas urbanas suscetíveis a inundação;
##   09) Água: diagnóstico de por que não é série comparável;
##   10) Painéis diagnósticos por município;
##   11) Dependência temporal: estoque x fluxo, ACF, PACF, Ljung-Box,
##       estacionariedade e decomposição em tendência;
##   12) Tendência: Mann-Kendall e declividade de Sen;
##   13) Estrutura entre classes (CLR) e redundância espacial;
##   14) Padrões espaciais: mapas e autocorrelação espacial (Moran);
##   15) Agrupamento de municípios por trajetória da paisagem;
##   16) Exportação das tabelas e relatório de síntese.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Dados vetoriais e mapas
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem e grades
library(purrr)          ## Programação funcional
library(stringi)        ## Transliteração de acentos
library(ggplot2)        ## Gráficos
library(patchwork)      ## Composição de painéis
library(scales)         ## Escalas e formatação de eixos
library(tseries)        ## Testes de estacionariedade (ADF, KPSS)
library(spdep)          ## Autocorrelação espacial (Moran)
library(writexl)        ## Exportação consolidada em XLSX

######@> Resolução de conflitos de nomes...
## Mantida a mesma fixação explícita adotada nos demais scripts do
## projeto: evita erros silenciosos de seleção de colunas caso algum
## pacote carregado adiante mascare os verbos do dplyr.
select <- dplyr::select
filter <- dplyr::filter

######@> Opções globais...
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente...
## Fixada porque a escolha do número de perfis avalia partições sobre
## uma matriz padronizada, e a reprodutibilidade do agrupamento é
## requisito para que a tipologia possa ser citada no texto.
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
dir_dados <- "../Dados"
dir_out_mapb <- file.path(dir_dados, "Outputs", "MapBiomas")
dir_shape <- file.path(dir_dados, "Shapefiles")

arq_base <- file.path(dir_out_mapb, "RData", "MapBiomas_SC_completo.RData")
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Diretórios de saída...
## A AED gera três famílias de produto, que ficam em subpastas próprias
## para que o material possa ser localizado pelo tipo: tabelas (insumo
## de texto e de análises posteriores), figuras (séries e diagnósticos)
## e mapas (recorte espacial).
dir_res <- "../Results/AED_MapBiomas"
dir_tab <- file.path(dir_res, "Tabelas")
dir_fig <- file.path(dir_res, "Figuras")
dir_fig_mun <- file.path(dir_fig, "Municipios")
dir_mapa <- file.path(dir_res, "Mapas")

for(d in c(dir_res, dir_tab, dir_fig, dir_fig_mun, dir_mapa)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> CRS de referência...
crs_projeto <- 4326      ## WGS84, mesmo das demais bases
crs_area <- 5880         ## SIRGAS 2000 / Brazil Polyconic (distâncias)

######@> Parâmetros da análise...
## ano_ini/ano_fim  : janela comum aos temas anuais do MapBiomas. O tema
##                    Água vai até 2025, mas é descartado como série
##                    (Etapa 09), de modo que a janela efetiva da
##                    análise é a da Cobertura;
## lag_max_anual    : 13 anos, um terço das 40 observações - além disso
##                    a estimativa da autocorrelação perde precisão
##                    útil;
## alfa             : nível de significância adotado nos testes;
## limiar_ocorrencia: percentual mínimo de área para que uma classe seja
##                    considerada presente em um município; abaixo dele
##                    a série é ruído de classificação de poucos pixels;
## tolerancia_fecha : folga aceita na conferência de fechamento da
##                    composição, em pontos percentuais.
ano_ini <- 1985
ano_fim <- 2024
lag_max_anual <- 13
alfa <- 0.05
limiar_ocorrencia <- 0.01
tolerancia_fecha <- 0.01

######@> Paleta das classes de nível 1 da Cobertura...
## Paleta Okabe-Ito, segura para daltonismo, atribuída com apoio
## semântico e mantida fixa em todas as figuras: verde para floresta,
## laranja para agropecuária, amarelo para a vegetação herbácea, azul
## para água e vermelho-alaranjado para a área não vegetada - que é,
## neste litoral, majoritariamente área urbanizada.
cores_classe <- c("Floresta"                       = "#009E73",
                  "Agropecuária"                   = "#E69F00",
                  "Vegetação Herbácea e Arbustiva" = "#F0E442",
                  "Água e Ambiente Marinho"        = "#0072B2",
                  "Área Não Vegetada"              = "#D55E00")

######@> Ordem de exibição das classes de nível 1...
## Fixada para que todas as barras empilhadas e todas as legendas
## tenham a mesma ordem, requisito para comparação visual entre
## figuras.
ordem_classes_n1 <- c("Floresta", "Agropecuária",
                      "Vegetação Herbácea e Arbustiva",
                      "Água e Ambiente Marinho", "Área Não Vegetada")

######@> Paleta das classes de risco climático...
cores_risco <- c("Médio" = "#F0E442", "Alto" = "#E69F00",
                 "Muito Alto" = "#D55E00")

######@> Décadas usadas nos recortes...
quebras_decada <- c(1985, 1995, 2005, 2015, 2024)

########################################################################
######@> Funções auxiliares...

######@> Tema gráfico do documento...
## Centralizar o tema garante que as dezenas de figuras produzidas
## tenham a mesma aparência, o que é requisito para que possam ser
## usadas lado a lado no texto da dissertação.
tema_aed <- function(base = 11) {
    theme_bw(base_size = base) +
        theme(panel.grid.minor = element_blank(),
              panel.grid.major = element_line(linewidth = 0.25,
                                              colour = "grey88"),
              strip.background = element_rect(fill = "grey92",
                                              colour = "grey70"),
              strip.text = element_text(face = "bold", size = base - 1),
              plot.title = element_text(face = "bold", size = base + 2),
              plot.subtitle = element_text(colour = "grey30",
                                           size = base - 1),
              plot.caption = element_text(colour = "grey45",
                                          size = base - 3, hjust = 0),
              legend.position = "bottom",
              legend.title = element_text(face = "bold", size = base - 1))
}

theme_set(tema_aed())

######@> Quebra de linha em legendas longas...
## O ggplot NÃO quebra automaticamente o texto de caption: legendas
## longas são simplesmente cortadas na borda direita da figura. Esta
## função insere as quebras antes da plotagem, mantendo as notas de
## rodapé legíveis independentemente da largura do arquivo gerado.
quebrar <- function(texto, largura = 105) {
    paste(strwrap(paste(texto, collapse = " "), width = largura),
          collapse = "\n")
}

######@> Quebra de linha para legendas de mapa...
## Os mapas são gravados com 8 polegadas de largura, contra 10 a 14 das
## demais figuras. A quebra padrão, calibrada para as figuras largas,
## deixaria o texto das legendas ultrapassar a borda direita do
## arquivo. Esta variante estreita é usada em todos os mapas.
quebrar_mapa <- function(texto) {
    quebrar(texto, largura = 78)
}

######@> Quebra de rótulos de eixo em várias linhas...
## Os nomes das classes do MapBiomas são longos ("Vegetação Herbácea e
## Arbustiva") e não cabem em um eixo com cinco categorias. Substituir
## todo espaço por quebra de linha empilharia uma palavra por linha e
## desperdiçaria altura; esta função quebra apenas o necessário para
## caber na largura pedida.
quebrar_rotulo <- function(x, largura = 16) {
    vapply(as.character(x), function(z)
        paste(strwrap(z, width = largura), collapse = "\n"),
        character(1), USE.NAMES = FALSE)
}

######@> Função de gravação de figuras...
## Padroniza formato, resolução e diretório. dpi = 300 atende a
## requisitos de impressão de dissertação.
salvar_fig <- function(plot, arquivo, largura = 10, altura = 6,
                       diretorio = dir_fig) {
    ggsave(filename = file.path(diretorio, paste0(arquivo, ".png")),
           plot = plot, width = largura, height = altura, dpi = 300,
           bg = "white")
    invisible(NULL)
}

######@> Função de gravação de tabelas...
## Grava em CSV com separador ";" e decimal "," (padrão brasileiro,
## abre corretamente no Excel em português) e devolve a tabela para que
## também seja acumulada no XLSX consolidado.
salvar_tab <- function(dados, arquivo) {
    write.table(dados, file.path(dir_tab, paste0(arquivo, ".csv")),
                sep = ";", dec = ",", row.names = FALSE,
                fileEncoding = "UTF-8")
    invisible(dados)
}

######@> Formatação de inteiros com separador de milhar...
## big.mark = "." sozinho dispara aviso, porque no locale padrão do R o
## separador DECIMAL também é "."; declarar decimal.mark = "," (a
## convenção brasileira) elimina a ambiguidade.
fmt_int <- function(x) {
    formatC(x, format = "f", digits = 0, big.mark = ".",
            decimal.mark = ",")
}

######@> Função para transliterar nomes em nomes seguros de arquivo...
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Abreviação de rótulos longos de classe...
## Vários caminhos de classe do MapBiomas têm mais de 40 caracteres
## ("Área não Urbanizada > Vegetação Herbácea e Arbustiva > Campo
## Alagado e Área Pantanosa") e inutilizariam os eixos das figuras. A
## abreviação mantém o último elo do caminho, que é o nome da classe.
rotulo_curto <- function(x, largura = 28) {
    x <- ifelse(nchar(x) > largura,
                paste0(substr(x, 1, largura - 1), "..."), x)
    return(x)
}

######@> Máximo e mínimo tolerantes a séries inteiramente ausentes...
## max(x, na.rm = TRUE) sobre um vetor só de NA devolve -Inf com aviso,
## o que aconteceria nas classes identicamente nulas (a Lavoura Perene,
## por exemplo, tem área zero e portanto resíduo relativo indefinido em
## todos os municípios). Estas variantes devolvem NA, que é o que a
## tabela deve mostrar.
max_seguro <- function(x) {
    if(all(is.na(x))) return(NA_real_)
    max(x, na.rm = TRUE)
}

min_seguro <- function(x) {
    if(all(is.na(x))) return(NA_real_)
    min(x, na.rm = TRUE)
}

######@> Teste de tendência de Mann-Kendall...
## Implementado no próprio script, e não importado de pacote, por duas
## razões: (a) mantém o script executável sem dependências além das já
## utilizadas no projeto; (b) torna explícita a correção para empates -
## que aqui NÃO é detalhe: várias séries de classe rara têm dezenas de
## anos com o mesmo valor, e a variância sem correção seria inflada.
##
## O teste é não-paramétrico e avalia a hipótese de tendência monotônica
## (não necessariamente linear). Nas séries de cobertura isso é
## preferível à regressão linear porque a transformação da paisagem
## costuma ocorrer em surtos - um loteamento, uma safra de silvicultura
## -, e não a taxa constante.
mann_kendall <- function(x) {
    x <- as.numeric(x[!is.na(x)])
    n <- length(x)
    if(n < 4) {
        return(tibble(S = NA_real_, tau = NA_real_, z = NA_real_,
                      p_valor = NA_real_))
    }
    ## Estatística S: soma dos sinais de todas as diferenças aos pares
    dif <- outer(x, x, "-")
    S <- sum(sign(dif[lower.tri(dif)]))
    ## Variância com correção para empates
    empates <- as.numeric(table(x))
    var_S <- (n * (n - 1) * (2 * n + 5) -
              sum(empates * (empates - 1) * (2 * empates + 5))) / 18
    if(var_S <= 0) {
        return(tibble(S = S, tau = NA_real_, z = NA_real_,
                      p_valor = NA_real_))
    }
    ## Correção de continuidade no cálculo de z
    z <- if(S > 0) (S - 1) / sqrt(var_S) else
         if(S < 0) (S + 1) / sqrt(var_S) else 0
    tau <- S / (n * (n - 1) / 2)
    tibble(S = S, tau = tau, z = z, p_valor = 2 * pnorm(-abs(z)))
}

######@> Declividade de Sen (Theil-Sen)...
## Mediana das declividades entre todos os pares de pontos. É o
## estimador de magnitude que acompanha o Mann-Kendall: robusto a
## valores extremos, e por isso preferível à regressão linear em séries
## com saltos de conversão.
declividade_sen <- function(y, x) {
    ok <- !is.na(y) & !is.na(x)
    y <- y[ok]; x <- x[ok]
    if(length(y) < 4) return(NA_real_)
    dy <- outer(y, y, "-")
    dx <- outer(x, x, "-")
    decl <- (dy / dx)[lower.tri(dy)]
    return(median(decl[is.finite(decl)], na.rm = TRUE))
}

######@> Cálculo de ACF/PACF em formato de tabela...
## Devolve um data.frame com o lag, o valor e o limite do intervalo de
## confiança, permitindo tanto a plotagem em ggplot quanto a exportação
## da autocorrelação como tabela.
calcular_correlograma <- function(x, lag_max = lag_max_anual,
                                  tipo = c("ACF", "PACF")) {
    tipo <- match.arg(tipo)
    x <- as.numeric(x)
    x <- x[!is.na(x)]
    n <- length(x)
    ## Série constante - caso das onze classes identicamente nulas no
    ## litoral - não admite autocorrelação: devolve tabela vazia em vez
    ## de propagar NaN para dentro dos gráficos.
    if(n < 8 || var(x) == 0) {
        return(tibble(lag = integer(), valor = numeric(),
                      ic = numeric(), tipo = character()))
    }
    lag_max <- min(lag_max, floor(n / 3))
    if(tipo == "ACF") {
        obj <- acf(x, lag.max = lag_max, plot = FALSE,
                   na.action = na.pass)
        valores <- as.numeric(obj$acf)[-1]
    } else {
        obj <- pacf(x, lag.max = lag_max, plot = FALSE,
                    na.action = na.pass)
        valores <- as.numeric(obj$acf)
    }
    tibble(lag = seq_along(valores), valor = valores,
           ic = qnorm(1 - alfa / 2) / sqrt(n), tipo = tipo)
}

######@> Gráfico de correlograma em ggplot...
## Reimplementado em ggplot (em vez de usar o plot base de acf()) para
## que os correlogramas possam ser combinados com as demais figuras em
## painéis e sigam o mesmo tema visual.
grafico_correlograma <- function(tabela, titulo = NULL,
                                 subtitulo = NULL) {
    if(nrow(tabela) == 0) {
        return(ggplot() +
               annotate("text", x = 0, y = 0,
                        label = paste("Série sem variabilidade",
                                      "\n(correlograma não definido)"),
                        size = 3, colour = "grey40") +
               labs(title = titulo, subtitle = subtitulo) +
               theme_void())
    }
    ic <- tabela$ic[1]
    ggplot(tabela, aes(x = lag, y = valor)) +
        geom_hline(yintercept = 0, colour = "grey40") +
        geom_hline(yintercept = c(-ic, ic), linetype = "dashed",
                   colour = "#0072B2", linewidth = 0.4) +
        geom_segment(aes(xend = lag, yend = 0), linewidth = 0.6,
                     colour = "grey25") +
        geom_point(size = 1.1, colour = "grey15") +
        scale_x_continuous(breaks = pretty_breaks(6)) +
        labs(title = titulo, subtitle = subtitulo,
             x = "Defasagem (anos)", y = tabela$tipo[1])
}

######@> Bateria de diagnósticos de uma série temporal anual...
## Reúne, em uma linha, tudo o que se costuma olhar antes de modelar:
## autocorrelação de 1ª ordem, teste global de ruído branco
## (Ljung-Box), os dois testes de estacionariedade e o coeficiente de
## variação.
##
## ADF e KPSS têm hipóteses nulas OPOSTAS - o ADF testa H0: raiz
## unitária (não estacionária) e o KPSS testa H0: estacionariedade -, e
## por isso são reportados juntos: concordância entre eles é evidência
## forte; discordância indica série com tendência determinística, que é
## o caso esperado das séries de cobertura em nível.
##
## Ressalva de tamanho de amostra: com 40 observações anuais o poder de
## ambos os testes é baixo, e a classificação abaixo deve ser lida como
## indicação, não como veredito.
diagnosticar_serie <- function(x, lag_teste = 10) {
    x <- as.numeric(x)
    x <- x[!is.na(x)]
    n <- length(x)
    res <- tibble(n = n,
                  media = mean(x),
                  dp = sd(x),
                  cv = NA_real_,
                  acf1 = NA_real_,
                  ljung_box_p = NA_real_,
                  adf_p = NA_real_,
                  kpss_p = NA_real_,
                  estacionaria = NA_character_)
    if(n < 8) return(res)
    res$cv <- ifelse(abs(res$media) > 0, res$dp / abs(res$media),
                     NA_real_)
    if(var(x) == 0) return(res)
    res$acf1 <- as.numeric(acf(x, lag.max = 1, plot = FALSE)$acf[2])
    lag_teste <- min(lag_teste, floor(n / 4))
    res$ljung_box_p <- tryCatch(
        Box.test(x, lag = lag_teste, type = "Ljung-Box")$p.value,
        error = function(e) NA_real_)
    res$adf_p <- tryCatch(suppressWarnings(adf.test(x)$p.value),
                          error = function(e) NA_real_)
    res$kpss_p <- tryCatch(suppressWarnings(kpss.test(x)$p.value),
                           error = function(e) NA_real_)
    ## Leitura conjunta dos dois testes. Os p-valores de adf.test() e
    ## kpss.test() são truncados nos extremos da tabela (0,01 e 0,10),
    ## o que não afeta a classificação abaixo.
    res$estacionaria <- dplyr::case_when(
        is.na(res$adf_p) | is.na(res$kpss_p) ~ NA_character_,
        res$adf_p < alfa & res$kpss_p > alfa ~ "Estacionária",
        res$adf_p >= alfa & res$kpss_p <= alfa ~ "Não estacionária",
        res$adf_p < alfa & res$kpss_p <= alfa ~
            "Tendência determinística",
        TRUE ~ "Indefinida")
    return(res)
}

######@> Decomposição de série anual em tendência e resíduo...
## A decomposição STL usada na AED do ERA5 não se aplica aqui: ela
## exige componente sazonal, e a série do MapBiomas é anual - há um
## mosaico por ano, sem ciclo interno. A alternativa adotada é o
## alisamento por loess, que estima a tendência sem impor forma
## funcional, e a força da tendência é calculada pela mesma medida de
## Wang, Smith e Hyndman: 1 menos a razão entre a variância do resíduo
## e a variância do resíduo somado à tendência. Vale 0 quando a
## tendência não acrescenta nada e tende a 1 quando ela domina.
decompor_tendencia <- function(y, x, span = 0.5) {
    ok <- !is.na(y) & !is.na(x)
    y <- y[ok]; x <- x[ok]
    if(length(y) < 8 || var(y) == 0) {
        return(tibble(forca_tendencia = NA_real_,
                      var_residual = NA_real_,
                      dp_residual = NA_real_))
    }
    ajuste <- loess(y ~ x, span = span, degree = 1)
    tend <- predict(ajuste)
    r <- y - tend
    tibble(forca_tendencia = max(0, 1 - var(r) / var(tend + r)),
           var_residual = var(r),
           dp_residual = sd(r))
}

######@> Transformação log-razão centrada (CLR)...
## Dados composicionais vivem no simplex: as proporções somam uma
## constante, e por isso a correlação usual entre duas classes é
## ESPÚRIA - ao crescer uma, as demais precisam encolher, ainda que
## nada as ligue substantivamente. A transformação CLR leva a
## composição para o espaço real, onde correlação e PCA voltam a ter a
## interpretação de sempre.
##
## Zeros exigem tratamento porque o logaritmo não os admite. Adota-se a
## substituição multiplicativa simples: os zeros recebem um valor
## pequeno (66% do menor valor positivo observado na matriz, limitado a
## um piso absoluto) e as demais partes são reescalonadas para que a
## soma se mantenha. Classes identicamente nulas devem ser removidas
## ANTES desta chamada - substituí-las apenas criaria uma constante.
transformar_clr <- function(mat, piso = 0.001) {
    mat <- as.matrix(mat)
    positivos <- mat[mat > 0]
    delta <- min(piso, 0.66 * min(positivos))
    mat_ok <- mat
    mat_ok[mat_ok <= 0] <- delta
    ## Reescalonamento das partes positivas para preservar a soma
    soma_orig <- rowSums(mat)
    soma_nova <- rowSums(mat_ok)
    mat_ok <- mat_ok * (soma_orig / soma_nova)
    log_mat <- log(mat_ok)
    return(log_mat - rowMeans(log_mat))
}

######@> Silhueta média de uma partição...
## A silhueta de cada município compara sua distância média aos
## companheiros de grupo com a distância média ao grupo vizinho mais
## próximo; varia de -1 a 1, e valores altos indicam agrupamento bem
## separado. É calculada no próprio script para não acrescentar
## dependência de pacote apenas por esta métrica.
silhueta_media <- function(matriz_dist, grupos) {
    m <- as.matrix(matriz_dist)
    unicos <- unique(grupos)
    if(length(unicos) < 2) return(NA_real_)
    valores <- vapply(seq_along(grupos), function(i) {
        proprio <- grupos == grupos[i]
        proprio[i] <- FALSE
        if(!any(proprio)) return(0)
        a <- mean(m[i, proprio])
        b <- min(vapply(setdiff(unicos, grupos[i]), function(g)
            mean(m[i, grupos == g]), numeric(1)))
        (b - a) / max(a, b)
    }, numeric(1))
    mean(valores)
}

######@> Extração dos segmentos do dendrograma...
## Feita manualmente para desenhar a árvore em ggplot sem acrescentar
## dependência de pacote apenas para isso, mantendo o tema visual do
## documento.
segmentos_dendrograma <- function(h) {
    posicoes <- order(order(h$order))
    coord_x <- numeric(nrow(h$merge))
    coord_y <- numeric(nrow(h$merge))
    segs <- list()
    for(k in seq_len(nrow(h$merge))) {
        filhos <- h$merge[k, ]
        xs <- numeric(2); ys <- numeric(2)
        for(j in 1:2) {
            if(filhos[j] < 0) {
                xs[j] <- posicoes[-filhos[j]]
                ys[j] <- 0
            } else {
                xs[j] <- coord_x[filhos[j]]
                ys[j] <- coord_y[filhos[j]]
            }
        }
        coord_x[k] <- mean(xs)
        coord_y[k] <- h$height[k]
        segs[[k]] <- data.frame(
            x = c(xs[1], xs[1], xs[2]),
            y = c(ys[1], h$height[k], h$height[k]),
            xend = c(xs[1], xs[2], xs[2]),
            yend = c(h$height[k], h$height[k], ys[2]))
    }
    do.call(rbind, segs)
}

########################################################################
######@> Etapa 01 - Leitura da base e preparação...

message("=== AED MapBiomas - início ===")
message("Lendo base padronizada...")

if(!file.exists(arq_base)) {
    stop("Base não encontrada. Execute antes ",
         "script_MapBiomas_extracao_municipios_ver00.R")
}

load(arq_base)

######@> Objeto focal da análise...
## series_anuais é a base pedida: tudo o que o MapBiomas entrega como
## série ano a ano, em formato longo canônico (uma linha por município,
## tema, relatório, classe e ano). Os demais objetos do RData são
## usados como apoio - hierarquia e dicionário para a triagem,
## resumo_municipios para as áreas, agregados_periodo para os recortes
## que não são série.
series <- series_anuais

######@> Conferência de integridade antes de analisar...
## Três conferências que, se falharem, invalidam tudo o que vem depois:
## a base precisa ter as colunas esperadas, o percentual de área
## precisa ser coerente com a área em hectares, e a chave
## município-tema-relatório-classe-ano precisa ser única.
colunas_esperadas <- c("geocodigo", "municipio", "tema", "relatorio",
                       "exportado_como_serie", "classe_caminho",
                       "classe", "nivel_profundidade", "ano",
                       "area_ha", "area_pct")
stopifnot(all(colunas_esperadas %in% names(series)))

chave <- series %>%
    count(geocodigo, tema, relatorio, exportado_como_serie,
          classe_caminho, ano)
stopifnot(max(chave$n) == 1)
rm(chave)

message("Linhas lidas           : ", fmt_int(nrow(series)))
message("Temas                  : ", n_distinct(series$tema))
message("Relatórios             : ", n_distinct(series$relatorio))

######@> Separação dos temas em objetos de trabalho...
## A base mistura quatro temas cuja semântica NÃO é comparável, e
## tratá-los como uma tabela única seria o erro mais fácil de cometer.
## Cada um passa a ter seu objeto, e a Etapa 02 documenta por que.
##
## Filtra-se sempre por exportado_como_serie: a base guarda, para
## alguns relatórios, uma versão não-série do mesmo conteúdo (o retrato
## de 2024 isolado, por exemplo), que duplicaria as observações do
## último ano se não fosse excluída.
cob <- series %>%
    filter(tema == "Cobertura 30m", exportado_como_serie,
           ano >= ano_ini, ano <= ano_fim)

urb <- series %>%
    filter(grepl("Urbanização anual", relatorio), exportado_como_serie,
           ano >= ano_ini, ano <= ano_fim)

vurb <- series %>%
    filter(grepl("Vegetação urbana", relatorio), exportado_como_serie,
           ano >= ano_ini, ano <= ano_fim)

risco <- series %>%
    filter(tema == "Risco Climático", exportado_como_serie,
           ano >= ano_ini, ano <= ano_fim)

agua <- series %>%
    filter(tema == "Água Mensal")

######@> Níveis da hierarquia de cobertura...
## O nível 1 é a leitura composicional do município (cinco classes que
## fecham 100%); o nível 2 é o detalhamento que interessa
## substantivamente (mangue, restinga, silvicultura, área urbanizada);
## os níveis 3 e 4 existem apenas dentro da agricultura e, neste
## litoral, quase todos são nulos.
cob_n1 <- cob %>%
    filter(nivel_profundidade == 1) %>%
    mutate(classe = factor(classe, levels = ordem_classes_n1))

## O rótulo do pai vira fator com a MESMA ordem usada no nível 1: sem
## isso, as legendas de nível 1 e de nível 2 sairiam em ordens
## diferentes e o patchwork não conseguiria fundi-las em uma única
## legenda nos painéis compostos.
cob_n2 <- cob %>%
    filter(nivel_profundidade == 2) %>%
    mutate(classe_pai = factor(sub(" > .*$", "", classe_caminho),
                               levels = ordem_classes_n1))

######@> Vetores de referência...
municipios_nomes <- sort(unique(cob$municipio))
geocodigos <- sort(unique(cob$geocodigo))
anos <- sort(unique(cob$ano))
n_municipios <- length(municipios_nomes)
n_anos <- length(anos)

mun_ref <- cob %>%
    distinct(geocodigo, municipio) %>%
    arrange(municipio)

message("Municípios com dados   : ", n_municipios,
        " | anos: ", min(anos), "-", max(anos))

######@> Conferência da grade da cobertura...
## A cobertura precisa ser um painel COMPLETO - 35 municípios x 40 anos
## x 37 classes -, sem o qual as comparações entre anos ficariam
## contaminadas por ausência de município. Diferentemente do tema Água
## (Etapa 09), aqui a grade fecha.
grade_esperada <- n_municipios * n_anos * n_distinct(cob$classe_caminho)
grade_completa <- nrow(cob) == grade_esperada

message("Grade da cobertura     : ", fmt_int(nrow(cob)), " linhas de ",
        fmt_int(grade_esperada), " esperadas",
        ifelse(grade_completa, " (completa)", " (INCOMPLETA)"))

######@> Séries agregadas para o conjunto do litoral...
## Somam os 35 municípios. É a escala em que a trajetória da paisagem
## aparece com menos ruído de classificação, e a base das figuras de
## trajetória da Etapa 04.
##
## O percentual é recalculado sobre o total do litoral, e não obtido
## pela média dos percentuais municipais: a média de percentuais daria
## a cada município o mesmo peso, independentemente do tamanho, o que
## não é o que se quer ao descrever a paisagem regional.
litoral_n1 <- cob_n1 %>%
    group_by(ano, classe) %>%
    summarise(area_ha = sum(area_ha), .groups = "drop") %>%
    group_by(ano) %>%
    mutate(area_pct = 100 * area_ha / sum(area_ha)) %>%
    ungroup()

litoral_n2 <- cob_n2 %>%
    group_by(ano, classe_pai, classe, classe_caminho) %>%
    summarise(area_ha = sum(area_ha), .groups = "drop") %>%
    group_by(ano) %>%
    mutate(area_pct = 100 * area_ha / sum(area_ha)) %>%
    ungroup()

######@> Séries municipais em formato de trabalho...
mun_n1 <- cob_n1 %>%
    select(geocodigo, municipio, ano, classe, area_ha, area_pct,
           area_pct_terrestre, area_ha_mapbiomas, area_ha_terrestre) %>%
    arrange(geocodigo, classe, ano)

mun_n2 <- cob_n2 %>%
    select(geocodigo, municipio, ano, classe_pai, classe,
           classe_caminho, area_ha, area_pct) %>%
    arrange(geocodigo, classe_caminho, ano)

######@> Série de área urbanizada por município...
## O relatório "Urbanização anual" tem uma única classe (Área
## Urbanizada) e é, por isso, a série mais simples e mais diretamente
## interpretável da base: a mancha urbana do município, ano a ano.
urb_mun <- urb %>%
    select(geocodigo, municipio, ano, area_ha, area_pct) %>%
    arrange(geocodigo, ano)

urb_litoral <- urb_mun %>%
    group_by(ano) %>%
    summarise(area_ha = sum(area_ha), .groups = "drop")

######@> Leitura e preparo do shapefile para os mapas...
message("Lendo shapefile...")
shape_bruto <- st_read(arq_shape, quiet = TRUE) %>% st_make_valid()
shape_bruto <- st_transform(shape_bruto, crs_projeto)

atributos <- st_drop_geometry(shape_bruto)
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))

municipios_sf <- shape_bruto %>%
    group_by(geocodigo, municipio) %>%
    summarise(.groups = "drop") %>%
    st_make_valid()

######@> Recorte espacial da análise...
## Camboriú e Paulo Lopes não têm dados no MapBiomas. Permanecem na
## base cartográfica, para que apareçam nos mapas como "sem dados" em
## vez de virarem um buraco no litoral, mas ficam FORA de todas as
## estatísticas.
municipios_sf <- municipios_sf %>%
    mutate(tem_dados = geocodigo %in% geocodigos)

municipios_sem_dados <- municipios_sf %>%
    st_drop_geometry() %>%
    filter(!tem_dados) %>%
    arrange(municipio)

######@> Centroides e posição ao longo do litoral...
## A latitude do centroide ordena os municípios de norte a sul e é o
## eixo natural para examinar gradientes espaciais. As distâncias entre
## centroides são calculadas em projeção métrica (SIRGAS 2000 /
## Polyconic), e não em graus, para que sejam comparáveis.
centroides <- suppressWarnings(st_centroid(municipios_sf))
coords_geo <- st_coordinates(centroides)

geografia_mun <- centroides %>%
    st_drop_geometry() %>%
    mutate(longitude = coords_geo[, 1],
           latitude = coords_geo[, 2]) %>%
    select(geocodigo, municipio, longitude, latitude, tem_dados)

centroides_metricos <- st_transform(centroides, crs_area)
dist_matriz <- st_distance(centroides_metricos)
dimnames(dist_matriz) <- list(centroides$geocodigo,
                              centroides$geocodigo)

message("Municípios analisados  : ", n_municipios,
        " | no mapa: ", nrow(municipios_sf),
        " | sem dados: ", nrow(municipios_sem_dados))

######@> Áreas de referência de cada município...
## area_ha_mapbiomas é a área total reconhecida pelo MapBiomas e
## area_ha_terrestre exclui a lâmina d'água. A razão entre elas separa
## os municípios de recorte lagunar (Imaruí, Laguna) dos demais, e é
## usada como ressalva nas comparações de percentual.
areas_mun <- resumo_municipios %>%
    filter(tem_mapbiomas) %>%
    select(geocodigo, municipio, area_km2_shape, area_ha_mapbiomas,
           area_ha_terrestre, area_ha_agua, pct_area_agua,
           razao_area_mapb_shape)

######@> Lista acumuladora das tabelas exportadas...
## Cada tabela produzida é registrada aqui e, ao final, todas são
## gravadas também em um único arquivo XLSX com uma aba por tabela.
tabelas <- list()

########################################################################
######@> Etapa 02 - Panorama, completude e triagem do que é série...

######@> Ficha da base analisada...
panorama <- tibble(
    Indicador = c("Período coberto (cobertura)",
                  "Municípios com dados",
                  "Municípios sem dados no MapBiomas",
                  "Temas do MapBiomas",
                  "Relatórios inventariados",
                  "Relatórios que são série anual",
                  "Linhas em series_anuais",
                  "Linhas na cobertura (série analisada)",
                  "Classes distintas na cobertura",
                  "Níveis da hierarquia de cobertura",
                  "Linhas em agregados_periodo",
                  "Área total do litoral (ha)",
                  "Área terrestre do litoral (ha)"),
    Valor = c(paste0(min(anos), "-", max(anos), " (", n_anos, " anos)"),
              as.character(n_municipios),
              paste0(nrow(municipios_sem_dados), " (",
                     paste(municipios_sem_dados$municipio,
                           collapse = ", "), ")"),
              as.character(n_distinct(series$tema)),
              as.character(nrow(dicionario_relatorios)),
              as.character(sum(dicionario_relatorios$exportado_como_serie &
                               dicionario_relatorios$tipo_temporal ==
                               "ano")),
              fmt_int(nrow(series)),
              fmt_int(nrow(cob)),
              as.character(n_distinct(cob$classe_caminho)),
              paste(sort(unique(cob$nivel_profundidade)),
                    collapse = ", "),
              fmt_int(nrow(agregados_periodo)),
              fmt_int(sum(areas_mun$area_ha_mapbiomas)),
              fmt_int(sum(areas_mun$area_ha_terrestre))))

tabelas[["Tab_01_panorama"]] <- salvar_tab(panorama,
                                           "Tab_01_panorama_da_base")

message("\n--- Panorama da base ---")
print(as.data.frame(panorama), right = FALSE)

######@> Triagem: o que é série temporal e o que não é...
## Esta é a decisão que estrutura todo o script. A base inventaria 14
## relatórios, mas nem todos descrevem a evolução ano a ano: alguns
## resumem o período inteiro em uma linha (quantas vezes cada pixel
## mudou de classe entre 1985 e 2024), outros descrevem coortes (em que
## quinquênio cada mancha urbana surgiu). Nenhum dos dois admite ACF,
## Mann-Kendall ou decomposição - e submetê-los a essas ferramentas
## produziria resultado formalmente calculável e substantivamente
## vazio.
##
## A regra aplicada: é série o que tem tipo_temporal == "ano" E está
## marcado como exportado_como_serie. As duas condições são
## necessárias, porque a base guarda também versões não-série de
## relatórios anuais (o retrato de 2024 isolado), que duplicariam o
## último ano.
triagem_relatorios <- dicionario_relatorios %>%
    mutate(
        situacao = case_when(
            exportado_como_serie & tipo_temporal == "ano" ~
                "Série anual analisável",
            !exportado_como_serie & tipo_temporal == "ano" ~
                "Retrato de um ano (duplicata do último ano)",
            tipo_temporal == "periodo" ~
                "Agregado do período 1985-2024 (não é série)",
            tipo_temporal == "coorte" ~
                "Coorte de urbanização (não é série)",
            TRUE ~ "Outro"),
        uso_no_script = case_when(
            grepl("Cobertura por classe", relatorio) &
            exportado_como_serie ~ "Etapas 03 a 07 e 10 a 15",
            grepl("Urbanização anual", relatorio) &
            exportado_como_serie ~ "Etapa 07 (urbanização)",
            grepl("Vegetação urbana", relatorio) &
            exportado_como_serie ~ "Etapa 07 (vegetação urbana)",
            grepl("Risco climático", relatorio) &
            exportado_como_serie ~ "Etapa 08 (risco)",
            grepl("Tendência da superfície", relatorio) ~
                "Etapa 09 (diagnóstico; descartado como série)",
            tipo_temporal %in% c("periodo", "coorte") ~
                "Etapas 05 e 07 (descrição do período)",
            TRUE ~ "Não utilizado (duplicata)")) %>%
    select(tema, relatorio, tipo_temporal, exportado_como_serie,
           n_municipios, n_classes, niveis, ano_min, ano_max,
           n_registros, situacao, uso_no_script)

tabelas[["Tab_02_triagem_relatorios"]] <- salvar_tab(
    triagem_relatorios, "Tab_02_triagem_dos_relatorios")

n_series_reais <- sum(triagem_relatorios$situacao ==
                      "Série anual analisável")

message("\nRelatórios que são série anual: ", n_series_reais,
        " de ", nrow(triagem_relatorios))

######@> Figura 01 - o que é série e o que não é...
dados_f01 <- triagem_relatorios %>%
    mutate(rotulo = paste0(sub("^[^•]*• ", "", relatorio),
                           " (", tema, ")"),
           rotulo = ifelse(!exportado_como_serie,
                           paste0(rotulo, " [não exportado]"), rotulo),
           rotulo = factor(rotulo, levels = rev(unique(rotulo))))

f01 <- ggplot(dados_f01, aes(x = n_registros, y = rotulo,
                             fill = situacao)) +
    geom_col(width = 0.7) +
    geom_text(aes(label = fmt_int(n_registros)), hjust = -0.1,
              size = 2.8, colour = "grey25") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.25)),
                       labels = fmt_int) +
    scale_fill_manual(values = c(
        "Série anual analisável" = "#009E73",
        "Retrato de um ano (duplicata do último ano)" = "#F0E442",
        "Agregado do período 1985-2024 (não é série)" = "#E69F00",
        "Coorte de urbanização (não é série)" = "#D55E00"),
        name = NULL) +
    guides(fill = guide_legend(ncol = 2)) +
    labs(title = "Nem toda linha da base é uma série temporal",
         subtitle = paste0("Triagem dos ", nrow(triagem_relatorios),
                           " relatórios inventariados pelo MapBiomas ",
                           "no litoral catarinense"),
         x = "Registros na base", y = NULL,
         caption = quebrar(paste(
             "Apenas os relatórios em verde admitem ACF, teste de",
             "tendência ou decomposição. Os agregados de período",
             "resumem 1985-2024 em uma linha por município (número de",
             "mudanças, número de classes, transições) e as coortes",
             "informam em que quinquênio cada mancha urbana surgiu:",
             "descrevem o intervalo, não sua evolução. Os retratos de",
             "um ano repetem o último ano da série correspondente e",
             "são descartados para não duplicar 2024."))) +
    theme(axis.text.y = element_text(size = 8))

salvar_fig(f01, "Fig_01_triagem_dos_relatorios", 12, 7)

######@> Completude por município e relatório...
## O objeto diagnostico, produzido na padronização, informa quantos
## anos cada município tem em cada relatório. É o mapa das lacunas -
## e elas não são uniformes: o tema Água cobre 25 municípios, o Risco
## cobre 34 e a Cobertura cobre todos os 35.
completude <- diagnostico %>%
    filter(exportado_como_serie) %>%
    left_join(mun_ref, by = c("geocodigo", "municipio")) %>%
    mutate(rotulo_rel = sub("^[^•]*• ", "", relatorio),
           rotulo_rel = rotulo_curto(rotulo_rel, 34))

tabelas[["Tab_03_completude"]] <- salvar_tab(
    completude %>%
        select(geocodigo, municipio, tema, relatorio, n_registros,
               n_anos, tem_dados),
    "Tab_03_completude_por_municipio")

resumo_completude <- completude %>%
    group_by(tema, rotulo_rel) %>%
    summarise(municipios_com_dados = sum(tem_dados),
              municipios_sem_dados = sum(!tem_dados),
              anos_medianos = median(n_anos[tem_dados]),
              .groups = "drop")

tabelas[["Tab_04_cobertura_temas"]] <- salvar_tab(
    resumo_completude, "Tab_04_cobertura_por_tema")

######@> Figura 02 - mapa das lacunas...
ordem_mun_f02 <- geografia_mun %>%
    filter(tem_dados) %>%
    arrange(desc(latitude)) %>%
    pull(municipio)

dados_f02 <- completude %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_mun_f02)),
           faixa = case_when(!tem_dados ~ "Sem dados",
                             n_anos >= 40 ~ "40 anos (série completa)",
                             n_anos >= 30 ~ "30 a 39 anos",
                             n_anos >= 10 ~ "10 a 29 anos",
                             n_anos > 0 ~ "Menos de 10 anos",
                             TRUE ~ "Sem série anual"),
           faixa = factor(faixa,
                          levels = c("40 anos (série completa)",
                                     "30 a 39 anos", "10 a 29 anos",
                                     "Menos de 10 anos",
                                     "Sem série anual", "Sem dados")))

f02 <- ggplot(dados_f02, aes(x = rotulo_rel, y = municipio,
                             fill = faixa)) +
    geom_tile(colour = "white", linewidth = 0.4) +
    scale_fill_manual(values = c("40 anos (série completa)" = "#009E73",
                                 "30 a 39 anos" = "#56B4E9",
                                 "10 a 29 anos" = "#F0E442",
                                 "Menos de 10 anos" = "#E69F00",
                                 "Sem série anual" = "#CC79A7",
                                 "Sem dados" = "grey80"),
                      name = NULL, drop = FALSE) +
    guides(fill = guide_legend(nrow = 1)) +
    labs(title = "Cobertura desigual entre os temas do MapBiomas",
         subtitle = paste("Anos disponíveis por município em cada",
                          "relatório exportado como série"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Municípios ordenados de norte (topo) a sul. A cobertura",
             "de 30 m é completa nos 35 municípios; o risco climático",
             "não cobre São João do Sul; o tema Água cobre 25",
             "municípios e, mesmo neles, o número de anos varia -",
             "razão pela qual é descartado como série na Etapa 09."))) +
    theme(axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
          axis.text.y = element_text(size = 7))

salvar_fig(f02, "Fig_02_completude_por_tema", 11, 9)

######@> Classes sem nenhuma ocorrência no litoral...
## O dicionário do MapBiomas é NACIONAL: traz café, dendê, algodão e
## cana porque existem no Brasil, não porque existam no litoral
## catarinense. Uma classe identicamente nula em 35 municípios e 40
## anos não é uma série com valor baixo - é a ausência da classe, e
## deve ser removida antes de qualquer análise que pressuponha
## variabilidade.
ocorrencia_classes <- cob %>%
    group_by(nivel_profundidade, classe_caminho, classe) %>%
    summarise(area_max_ha = max(area_ha),
              area_media_pct = mean(area_pct),
              area_max_pct = max(area_pct),
              municipios_com_ocorrencia =
                  n_distinct(geocodigo[area_pct > limiar_ocorrencia]),
              anos_com_ocorrencia =
                  n_distinct(ano[area_pct > limiar_ocorrencia]),
              .groups = "drop") %>%
    mutate(situacao = case_when(
               area_max_ha == 0 ~ "Nula em todo o litoral",
               municipios_com_ocorrencia <= 3 ~
                   "Presente em até 3 municípios",
               TRUE ~ "Com ocorrência")) %>%
    arrange(nivel_profundidade, desc(area_media_pct))

tabelas[["Tab_05_ocorrencia_classes"]] <- salvar_tab(
    ocorrencia_classes, "Tab_05_ocorrencia_das_classes")

classes_nulas <- ocorrencia_classes %>%
    filter(situacao == "Nula em todo o litoral")

classes_ativas <- ocorrencia_classes %>%
    filter(situacao != "Nula em todo o litoral") %>%
    pull(classe_caminho)

message("\nClasses da cobertura   : ", nrow(ocorrencia_classes))
message("  identicamente nulas  : ", nrow(classes_nulas))
message("  presentes em <= 3 mun: ",
        sum(ocorrencia_classes$situacao == "Presente em até 3 municípios"))

######@> Conferência do fechamento da composição...
## O nível 1 precisa somar exatamente 100% em todos os pares
## município-ano. Se não somar, a leitura composicional das Etapas 03,
## 05 e 13 não se sustenta e é preciso saber disso ANTES, e não depois
## de interpretar uma correlação.
fechamento_n1 <- cob_n1 %>%
    group_by(geocodigo, municipio, ano) %>%
    summarise(soma_pct = sum(area_pct),
              soma_ha = sum(area_ha),
              area_referencia = first(area_ha_mapbiomas),
              .groups = "drop") %>%
    mutate(desvio_pct = soma_pct - 100,
           desvio_ha_rel = 100 * (soma_ha - area_referencia) /
               area_referencia)

fecha_ok <- max(abs(fechamento_n1$desvio_pct)) < tolerancia_fecha

tabelas[["Tab_06_fechamento"]] <- salvar_tab(
    fechamento_n1 %>%
        group_by(municipio) %>%
        summarise(desvio_pct_max = max(abs(desvio_pct)),
                  desvio_ha_rel_max = max(abs(desvio_ha_rel)),
                  .groups = "drop") %>%
        arrange(desc(desvio_pct_max)),
    "Tab_06_fechamento_da_composicao")

message("Fechamento do nível 1  : desvio máximo de ",
        sprintf("%.6f", max(abs(fechamento_n1$desvio_pct))),
        " pontos percentuais",
        ifelse(fecha_ok, " (fecha)", " (NÃO fecha)"))

######@> Conferência do aninhamento entre níveis...
## Cada classe de nível k+1 é parte de uma classe de nível k. A soma
## dos filhos deve ser menor ou igual ao pai - igual quando o
## detalhamento é exaustivo, menor quando o MapBiomas mantém no pai uma
## parcela não desagregada. Distinguir os dois casos importa: onde o
## detalhamento é exaustivo, é indiferente analisar o pai ou a soma dos
## filhos; onde não é, trocar um pelo outro perde área.
aninhamento <- cob %>%
    mutate(pai = ifelse(nivel_profundidade > 1,
                        sub(" > [^>]+$", "", classe_caminho),
                        NA_character_)) %>%
    filter(!is.na(pai)) %>%
    group_by(geocodigo, ano, nivel_profundidade, pai) %>%
    summarise(soma_filhos = sum(area_ha), .groups = "drop") %>%
    left_join(cob %>%
                  select(geocodigo, ano, pai = classe_caminho,
                         area_pai = area_ha),
              by = c("geocodigo", "ano", "pai")) %>%
    filter(!is.na(area_pai)) %>%
    mutate(residuo_ha = area_pai - soma_filhos,
           residuo_rel = ifelse(area_pai > 0,
                                100 * residuo_ha / area_pai, NA_real_))

resumo_aninhamento <- aninhamento %>%
    group_by(nivel_filho = nivel_profundidade, pai) %>%
    summarise(area_pai_media_ha = mean(area_pai),
              residuo_medio_pct = mean(residuo_rel, na.rm = TRUE),
              residuo_max_pct = max_seguro(residuo_rel),
              exaustivo = isTRUE(max_seguro(abs(residuo_rel)) <
                                 tolerancia_fecha),
              .groups = "drop") %>%
    arrange(nivel_filho, desc(area_pai_media_ha))

tabelas[["Tab_07_aninhamento"]] <- salvar_tab(
    resumo_aninhamento, "Tab_07_aninhamento_das_classes")

message("Aninhamento conferido  : ", nrow(resumo_aninhamento),
        " relações pai-filho, ",
        sum(resumo_aninhamento$exaustivo), " exaustivas")

########################################################################
######@> Etapa 03 - Composição da paisagem e hierarquia das classes...

######@> Composição do litoral nos extremos da série...
## O primeiro retrato: do que é feita a paisagem costeira catarinense e
## como isso mudou em quarenta anos. A leitura é composicional - as
## cinco classes de nível 1 somam 100% -, e por isso os ganhos e perdas
## se compensam por construção. O que a tabela mostra NÃO é, portanto,
## um conjunto de cinco resultados independentes: é uma redistribuição.
composicao_extremos <- litoral_n1 %>%
    filter(ano %in% c(ano_ini, ano_fim)) %>%
    select(ano, classe, area_ha, area_pct) %>%
    pivot_wider(names_from = ano,
                values_from = c(area_ha, area_pct)) %>%
    rename(ha_ini = paste0("area_ha_", ano_ini),
           ha_fim = paste0("area_ha_", ano_fim),
           pct_ini = paste0("area_pct_", ano_ini),
           pct_fim = paste0("area_pct_", ano_fim)) %>%
    mutate(variacao_ha = ha_fim - ha_ini,
           variacao_pct_relativa = 100 * variacao_ha / ha_ini,
           variacao_pontos_pct = pct_fim - pct_ini) %>%
    arrange(desc(ha_fim))

tabelas[["Tab_08_composicao_litoral"]] <- salvar_tab(
    composicao_extremos, "Tab_08_composicao_do_litoral")

message("\n--- Composição do litoral (nível 1) ---")
print(as.data.frame(composicao_extremos %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 2)))), right = FALSE)

######@> Figura 03 - composição do litoral ao longo do tempo...
f03 <- ggplot(litoral_n1, aes(x = ano, y = area_pct, fill = classe)) +
    geom_area(colour = "white", linewidth = 0.15) +
    scale_fill_manual(values = cores_classe, name = NULL) +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 5),
                       expand = c(0, 0)) +
    scale_y_continuous(expand = c(0, 0)) +
    guides(fill = guide_legend(nrow = 2)) +
    labs(title = "Composição da paisagem costeira catarinense",
         subtitle = paste0("Percentual da área dos ", n_municipios,
                           " municípios, classes de nível 1 do ",
                           "MapBiomas, ", ano_ini, "-", ano_fim),
         x = NULL, y = "Percentual da área (%)",
         caption = quebrar(paste(
             "As cinco classes somam exatamente 100% em todos os anos e",
             "em todos os municípios: a figura descreve uma",
             "REDISTRIBUIÇÃO, não cinco trajetórias independentes. O",
             "avanço da área não vegetada - majoritariamente área",
             "urbanizada neste litoral - ocorre principalmente sobre a",
             "floresta, e é o movimento que domina o período."))) 

salvar_fig(f03, "Fig_03_composicao_do_litoral", 11, 6)

######@> Composição em nível 2...
## O nível 2 é onde as classes ganham significado para a discussão de
## desastres: mangue e restinga (proteção costeira), silvicultura
## (uso econômico em expansão), área urbanizada (exposição).
composicao_n2 <- litoral_n2 %>%
    filter(ano %in% c(ano_ini, ano_fim)) %>%
    select(ano, classe_pai, classe, area_ha, area_pct) %>%
    pivot_wider(names_from = ano,
                values_from = c(area_ha, area_pct)) %>%
    rename(ha_ini = paste0("area_ha_", ano_ini),
           ha_fim = paste0("area_ha_", ano_fim),
           pct_ini = paste0("area_pct_", ano_ini),
           pct_fim = paste0("area_pct_", ano_fim)) %>%
    mutate(variacao_ha = ha_fim - ha_ini,
           variacao_pct_relativa = ifelse(ha_ini > 0,
                                          100 * variacao_ha / ha_ini,
                                          NA_real_)) %>%
    filter(ha_fim > 0 | ha_ini > 0) %>%
    arrange(desc(ha_fim))

tabelas[["Tab_09_composicao_nivel2"]] <- salvar_tab(
    composicao_n2, "Tab_09_composicao_nivel_2")

######@> Figura 04 - as classes de nível 2 e sua mudança...
dados_f04 <- composicao_n2 %>%
    mutate(classe = factor(classe, levels = rev(classe))) %>%
    select(classe_pai, classe, ha_ini, ha_fim) %>%
    pivot_longer(c(ha_ini, ha_fim), names_to = "momento",
                 values_to = "area_ha") %>%
    mutate(momento = ifelse(momento == "ha_ini",
                            as.character(ano_ini),
                            as.character(ano_fim)),
           momento = factor(momento, levels = c(as.character(ano_ini),
                                                as.character(ano_fim))))

f04 <- ggplot(dados_f04, aes(x = area_ha, y = classe,
                             colour = classe_pai, shape = momento)) +
    geom_line(aes(group = classe), colour = "grey70", linewidth = 0.5) +
    geom_point(size = 2.4) +
    scale_colour_manual(values = cores_classe, name = "Classe de nível 1") +
    scale_shape_manual(values = c(1, 16), name = NULL) +
    scale_x_continuous(labels = fmt_int,
                       trans = "sqrt",
                       breaks = c(0, 1000, 10000, 50000,
                                  1e5, 2e5, 3e5)) +
    guides(colour = guide_legend(nrow = 2, order = 1),
           shape = guide_legend(order = 2)) +
    labs(title = "Classes de nível 2: onde estava e onde está a área",
         subtitle = paste0("Área total dos ", n_municipios,
                           " municípios em ", ano_ini, " e ", ano_fim,
                           "; eixo em raiz quadrada"),
         x = "Área (ha)", y = NULL,
         caption = quebrar(paste(
             "O eixo é comprimido em raiz quadrada porque as classes",
             "diferem em quatro ordens de grandeza - Rio, Lago e Oceano",
             "ocupa dezenas de milhares de hectares e a Mineração,",
             "dezenas. As classes identicamente nulas no litoral",
             "(café, citrus, dendê, algodão, cana e afloramento",
             "rochoso, entre outras) foram omitidas."))) +
    theme(axis.text.y = element_text(size = 8))

salvar_fig(f04, "Fig_04_classes_nivel_2", 11, 8)

######@> Composição municipal no último ano...
composicao_municipal <- mun_n1 %>%
    filter(ano == ano_fim) %>%
    select(geocodigo, municipio, classe, area_pct) %>%
    pivot_wider(names_from = classe, values_from = area_pct) %>%
    left_join(areas_mun %>% select(geocodigo, area_km2_shape,
                                   pct_area_agua),
              by = "geocodigo") %>%
    left_join(geografia_mun %>% select(geocodigo, latitude),
              by = "geocodigo") %>%
    arrange(desc(latitude))

tabelas[["Tab_10_composicao_municipal"]] <- salvar_tab(
    composicao_municipal, "Tab_10_composicao_municipal_2024")

######@> Figura 05 - composição de cada município...
dados_f05 <- mun_n1 %>%
    filter(ano == ano_fim) %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_mun_f02)))

f05 <- ggplot(dados_f05, aes(x = area_pct, y = municipio,
                             fill = classe)) +
    geom_col(width = 0.8) +
    scale_fill_manual(values = cores_classe, name = NULL) +
    scale_x_continuous(expand = c(0, 0)) +
    guides(fill = guide_legend(nrow = 2)) +
    labs(title = paste("Composição da paisagem de cada município em",
                       ano_fim),
         subtitle = "Municípios ordenados de norte (topo) a sul",
         x = "Percentual da área do município (%)", y = NULL,
         caption = quebrar(paste(
             "A fração de água varia muito entre municípios - de menos",
             "de 2% em Garuva a mais de 30% em municípios lagunares",
             "como Imaruí e Laguna -, o que comprime as demais classes",
             "e precisa ser considerado ao comparar percentuais. A",
             "coluna area_pct_terrestre das tabelas oferece a",
             "alternativa com denominador apenas terrestre."))) +
    theme(axis.text.y = element_text(size = 8))

salvar_fig(f05, "Fig_05_composicao_por_municipio", 10, 9)

########################################################################
######@> Etapa 04 - Trajetórias temporais do litoral e dos municípios...

######@> Figura 06 - séries anuais de nível 1 do litoral...
## Cada classe em seu próprio painel e em sua própria escala: o
## objetivo aqui é a FORMA da trajetória (linear, em surto, estável),
## não a comparação de magnitude - que a Figura 03 já dá.
f06 <- ggplot(litoral_n1, aes(x = ano, y = area_ha, colour = classe)) +
    geom_line(linewidth = 0.8) +
    geom_point(size = 0.8) +
    facet_wrap(~ classe, scales = "free_y", ncol = 3) +
    scale_colour_manual(values = cores_classe, guide = "none") +
    scale_y_continuous(labels = fmt_int) +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 10)) +
    labs(title = "Trajetória de cada classe no conjunto do litoral",
         subtitle = paste0("Área total dos ", n_municipios,
                           " municípios, ", ano_ini, "-", ano_fim,
                           "; escalas verticais independentes"),
         x = NULL, y = "Área (ha)",
         caption = quebrar(paste(
             "As escalas verticais são independentes: a figura compara",
             "FORMAS de trajetória, não magnitudes. A floresta cai de",
             "modo contínuo até meados dos anos 2000 e depois",
             "estabiliza; a área não vegetada cresce sem interrupção; a",
             "agropecuária oscila em torno de um patamar, o que a",
             "análise de tendência da Etapa 12 confirma.")))

salvar_fig(f06, "Fig_06_series_nivel_1_litoral", 12, 7)

######@> Figura 07 - séries anuais de nível 2 com área relevante...
classes_n2_relevantes <- composicao_n2 %>%
    filter(ha_fim >= 500) %>%
    pull(classe)

dados_f07 <- litoral_n2 %>%
    filter(classe %in% classes_n2_relevantes) %>%
    mutate(classe = factor(classe, levels = classes_n2_relevantes))

f07 <- ggplot(dados_f07, aes(x = ano, y = area_ha,
                             colour = classe_pai)) +
    geom_line(linewidth = 0.8) +
    facet_wrap(~ classe, scales = "free_y", ncol = 4) +
    scale_colour_manual(values = cores_classe,
                        name = "Classe de nível 1") +
    scale_y_continuous(labels = fmt_int) +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 10)) +
    guides(colour = guide_legend(nrow = 2)) +
    labs(title = "Trajetórias das classes de nível 2",
         subtitle = paste("Classes com pelo menos 500 ha no litoral em",
                          ano_fim),
         x = NULL, y = "Área (ha)",
         caption = quebrar(paste(
             "Duas trajetórias merecem destaque para a discussão de",
             "desastres: a área urbanizada, que multiplica sua extensão",
             "no período, e o mangue e as restingas, que respondem pela",
             "proteção da linha de costa e cujo comportamento é bem",
             "mais estável. A silvicultura é a classe agropecuária que",
             "mais cresce.")))

salvar_fig(f07, "Fig_07_series_nivel_2_litoral", 13, 8)

######@> Figura 08 - séries municipais das classes de nível 1...
## O feixe de 35 linhas mostra o que a média do litoral esconde: se
## todos os municípios seguem a mesma trajetória (feixe estreito e
## paralelo) ou se cada um segue a sua (feixe embaralhado). A resposta
## é decisiva para a Etapa 13, e é a segunda.
f08 <- ggplot(mun_n1, aes(x = ano, y = area_pct, group = municipio)) +
    geom_line(alpha = 0.35, linewidth = 0.4, colour = "grey30") +
    geom_line(data = litoral_n1, aes(x = ano, y = area_pct,
                                     colour = classe),
              inherit.aes = FALSE, linewidth = 1.2) +
    facet_wrap(~ classe, scales = "free_y", ncol = 3) +
    scale_colour_manual(values = cores_classe, guide = "none") +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 10)) +
    labs(title = "Cada município tem sua própria trajetória",
         subtitle = paste("Linhas finas: municípios. Linha grossa:",
                          "conjunto do litoral"),
         x = NULL, y = "Percentual da área do município (%)",
         caption = quebrar(paste(
             "O feixe municipal é largo e não paralelo: a linha do",
             "litoral é um resumo, não um retrato do município típico.",
             "É o oposto do que se observa nas séries climáticas do",
             "ERA5, em que as anomalias municipais são quase",
             "indistinguíveis entre si - e a razão pela qual, aqui,",
             "efeitos municipais livres se justificam (Etapa 13). O",
             "sentido do movimento, porém, tem organização regional:",
             "ver o Mapa 02.")))

salvar_fig(f08, "Fig_08_series_municipais_nivel_1", 12, 7)

######@> Variação acumulada desde o início da série...
## Expressa em pontos percentuais de área do município, e não em
## hectares, para que Joinville (1.130 km²) e Bombinhas (34 km²)
## possam aparecer no mesmo painel.
variacao_acumulada <- mun_n1 %>%
    group_by(geocodigo, municipio, classe) %>%
    arrange(ano) %>%
    mutate(delta_pp = area_pct - first(area_pct)) %>%
    ungroup()

######@> Figura 09 - mapa de calor da transformação...
dados_f09 <- variacao_acumulada %>%
    filter(classe %in% c("Floresta", "Área Não Vegetada")) %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_mun_f02)))

limite_f09 <- max(abs(dados_f09$delta_pp))

f09 <- ggplot(dados_f09, aes(x = ano, y = municipio, fill = delta_pp)) +
    geom_tile() +
    facet_wrap(~ classe, ncol = 2) +
    scale_fill_gradient2(low = "#8C510A", mid = "grey96",
                         high = "#01665E", midpoint = 0,
                         limits = c(-limite_f09, limite_f09),
                         name = "Variação acumulada (p.p.)") +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 10),
                       expand = c(0, 0)) +
    labs(title = "Quando cada município se transformou",
         subtitle = paste0("Variação acumulada desde ", ano_ini,
                           ", em pontos percentuais da área municipal"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "A escala é divergente e centrada em zero: verde indica",
             "ganho e marrom, perda. A leitura horizontal mostra QUANDO",
             "cada município mudou - e os padrões não são simultâneos,",
             "o que já antecipa a baixa correlação entre municípios",
             "documentada na Etapa 13."))) +
    theme(axis.text.y = element_text(size = 7),
          legend.key.width = unit(1.4, "cm"))

salvar_fig(f09, "Fig_09_heatmap_transformacao", 12, 8)

########################################################################
######@> Etapa 05 - Mudança líquida e a restrição de fechamento...

######@> Variação municipal por classe de nível 1...
variacao_municipal <- mun_n1 %>%
    filter(ano %in% c(ano_ini, ano_fim)) %>%
    select(geocodigo, municipio, classe, ano, area_ha, area_pct) %>%
    pivot_wider(names_from = ano,
                values_from = c(area_ha, area_pct)) %>%
    rename(ha_ini = paste0("area_ha_", ano_ini),
           ha_fim = paste0("area_ha_", ano_fim),
           pct_ini = paste0("area_pct_", ano_ini),
           pct_fim = paste0("area_pct_", ano_fim)) %>%
    mutate(variacao_ha = ha_fim - ha_ini,
           variacao_pp = pct_fim - pct_ini,
           variacao_relativa = ifelse(ha_ini > 0,
                                      100 * variacao_ha / ha_ini,
                                      NA_real_))

tabelas[["Tab_11_variacao_municipal"]] <- salvar_tab(
    variacao_municipal %>% arrange(municipio, classe),
    "Tab_11_variacao_municipal_nivel_1")

######@> A restrição de fechamento, medida...
## Se a composição fecha 100%, a soma das variações em pontos
## percentuais é EXATAMENTE zero em cada município. A consequência
## prática: a perda de floresta e o ganho de área não vegetada não são
## dois achados, são um só, visto de dois ângulos. Esta tabela mede o
## quanto de cada perda foi absorvido por cada ganho.
balanco_fechamento <- variacao_municipal %>%
    group_by(geocodigo, municipio) %>%
    summarise(soma_variacao_pp = sum(variacao_pp),
              perda_total_pp = -sum(variacao_pp[variacao_pp < 0]),
              ganho_total_pp = sum(variacao_pp[variacao_pp > 0]),
              .groups = "drop") %>%
    mutate(desvio = abs(soma_variacao_pp))

compensacao <- variacao_municipal %>%
    select(geocodigo, municipio, classe, variacao_ha) %>%
    pivot_wider(names_from = classe, values_from = variacao_ha) %>%
    mutate(perda_floresta_ha = -Floresta,
           ganho_nao_vegetada_ha = `Área Não Vegetada`,
           razao = ifelse(perda_floresta_ha > 0,
                          ganho_nao_vegetada_ha / perda_floresta_ha,
                          NA_real_))

cor_compensacao <- cor(compensacao$perda_floresta_ha,
                       compensacao$ganho_nao_vegetada_ha,
                       use = "complete.obs")

tabelas[["Tab_12_balanco_fechamento"]] <- salvar_tab(
    balanco_fechamento %>%
        left_join(compensacao %>%
                      select(geocodigo, perda_floresta_ha,
                             ganho_nao_vegetada_ha, razao),
                  by = "geocodigo") %>%
        arrange(desc(perda_total_pp)),
    "Tab_12_balanco_de_fechamento")

message("\nFechamento das variações: soma máxima em módulo = ",
        sprintf("%.6f", max(balanco_fechamento$desvio)),
        " p.p. | correlação perda de floresta x ganho de área não ",
        "vegetada = ", sprintf("%.3f", cor_compensacao))

######@> Figura 10 - a mudança líquida de cada classe...
dados_f10 <- composicao_n2 %>%
    filter(abs(variacao_ha) > 100) %>%
    mutate(classe = factor(classe, levels = classe[order(variacao_ha)]),
           sentido = ifelse(variacao_ha > 0, "Ganho", "Perda"))

f10 <- ggplot(dados_f10, aes(x = variacao_ha, y = classe,
                             fill = classe_pai)) +
    geom_col(width = 0.75) +
    geom_vline(xintercept = 0, colour = "grey30") +
    scale_fill_manual(values = cores_classe,
                      name = "Classe de nível 1") +
    scale_x_continuous(labels = fmt_int) +
    guides(fill = guide_legend(nrow = 2)) +
    labs(title = paste0("Mudança líquida por classe, ", ano_ini,
                        "-", ano_fim),
         subtitle = paste("Classes com variação superior a 100 ha no",
                          "conjunto do litoral"),
         x = "Variação da área (ha)", y = NULL,
         caption = quebrar(paste(
             "A soma de todas as barras é zero por construção: a",
             "composição fecha 100% e o que uma classe ganha, outra",
             "perde. A leitura correta não é 'a área urbanizada",
             "cresceu X e a formação florestal caiu Y', e sim 'X",
             "hectares foram convertidos de floresta em área",
             "urbanizada'."))) +
    theme(axis.text.y = element_text(size = 8))

salvar_fig(f10, "Fig_10_mudanca_liquida_por_classe", 11, 7)

######@> Figura 11 - a compensação, município a município...
f11 <- ggplot(compensacao, aes(x = perda_floresta_ha,
                               y = ganho_nao_vegetada_ha)) +
    geom_abline(slope = 1, intercept = 0, linetype = "dashed",
                colour = "#D55E00") +
    geom_hline(yintercept = 0, colour = "grey70", linewidth = 0.3) +
    geom_vline(xintercept = 0, colour = "grey70", linewidth = 0.3) +
    geom_point(size = 2.2, colour = "#0072B2", alpha = 0.8) +
    geom_text(aes(label = municipio), size = 2.4, vjust = -0.9,
              colour = "grey30", check_overlap = TRUE) +
    scale_x_continuous(labels = fmt_int) +
    scale_y_continuous(labels = fmt_int) +
    labs(title = "A perda de floresta e o ganho de área não vegetada",
         subtitle = paste0("Variação entre ", ano_ini, " e ", ano_fim,
                           ", por município; linha tracejada: ",
                           "compensação exata (1:1)"),
         x = "Perda de floresta (ha)",
         y = "Ganho de área não vegetada (ha)",
         caption = quebrar(paste0(
             "No conjunto do litoral os dois números quase coincidem ",
             "(-44.190 ha de floresta contra +45.249 ha de área não ",
             "vegetada), mas essa coincidência é AGREGADA: município a ",
             "município a correlação é de apenas ",
             sprintf("%.2f", cor_compensacao),
             ". Acima da linha, o ganho de área não vegetada excede a ",
             "perda de floresta e o excedente veio da agropecuária ou ",
             "da vegetação herbácea; abaixo dela, parte da floresta ",
             "perdida foi para outros usos. A soma nacional fechar não ",
             "implica que cada município tenha seguido o mesmo ",
             "caminho.")))

salvar_fig(f11, "Fig_11_compensacao_floresta_urbano", 10, 8)

######@> Agregados de período: o que mudou, quantas vezes...
## Estes relatórios não são série, mas respondem a uma pergunta que a
## série não responde: quantas VEZES cada pixel mudou de classe no
## período, e quais transições dominaram. É a medida de instabilidade
## da paisagem, complementar à medida de mudança líquida.
mudancas_periodo <- agregados_periodo %>%
    filter(grepl("Número de mudanças", relatorio)) %>%
    select(geocodigo, municipio, classe, area_ha) %>%
    group_by(geocodigo, municipio) %>%
    mutate(pct_do_municipio = 100 * area_ha / sum(area_ha)) %>%
    ungroup()

transicoes_periodo <- agregados_periodo %>%
    filter(grepl("Transições", relatorio)) %>%
    distinct(geocodigo, municipio, classe, area_ha) %>%
    mutate(classe_curta = case_when(
               grepl("ganho de áreas de silvicultura", classe) ~
                   "Ganho de silvicultura",
               grepl("para cobertura florestal", classe) ~
                   "Regeneração (uso -> natural)",
               grepl("para pastagem, agricultura", classe) ~
                   "Conversão (natural -> uso)",
               grepl("adicionam superfície", classe) ~
                   "Ganho de água",
               grepl("reduzem a superfície", classe) ~
                   "Perda de água",
               TRUE ~ classe))

tabelas[["Tab_13_mudancas_por_pixel"]] <- salvar_tab(
    mudancas_periodo %>% arrange(municipio, classe),
    "Tab_13_numero_de_mudancas_por_pixel")

tabelas[["Tab_14_transicoes"]] <- salvar_tab(
    transicoes_periodo %>%
        select(geocodigo, municipio, transicao = classe_curta,
               area_ha) %>%
        arrange(municipio, transicao),
    "Tab_14_transicoes_do_periodo")

######@> Figura 12 - instabilidade da paisagem e transições...
estabilidade_litoral <- mudancas_periodo %>%
    group_by(classe) %>%
    summarise(area_ha = sum(area_ha), .groups = "drop") %>%
    mutate(pct = 100 * area_ha / sum(area_ha),
           classe = factor(classe, levels = classe))

g12a <- ggplot(estabilidade_litoral, aes(x = classe, y = pct)) +
    geom_col(fill = "#0072B2", width = 0.75) +
    geom_text(aes(label = sprintf("%.1f%%", pct)), vjust = -0.4,
              size = 2.9, colour = "grey25") +
    scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
    labs(subtitle = "Quantas vezes cada pixel mudou de classe",
         x = NULL, y = "Percentual da área (%)") +
    theme(axis.text.x = element_text(angle = 25, hjust = 1, size = 8))

transicoes_litoral <- transicoes_periodo %>%
    group_by(classe_curta) %>%
    summarise(area_ha = sum(area_ha), .groups = "drop") %>%
    arrange(area_ha) %>%
    mutate(classe_curta = factor(classe_curta, levels = classe_curta))

g12b <- ggplot(transicoes_litoral, aes(x = area_ha, y = classe_curta)) +
    geom_col(fill = "#E69F00", width = 0.7) +
    geom_text(aes(label = fmt_int(area_ha)), hjust = -0.1, size = 2.9,
              colour = "grey25") +
    scale_x_continuous(labels = fmt_int,
                       expand = expansion(mult = c(0, 0.2))) +
    labs(subtitle = paste0("Área por tipo de transição, ", ano_ini,
                           "-", ano_fim),
         x = "Área (ha)", y = NULL) +
    theme(axis.text.y = element_text(size = 8))

f12 <- (g12a | g12b) +
    plot_annotation(
        title = "A paisagem muda mais do que a mudança líquida sugere",
        subtitle = paste("Agregados do período inteiro - não são séries",
                         "temporais"),
        caption = quebrar(paste(
            "À esquerda, a instabilidade: a maior parte do território",
            "nunca mudou de classe em quarenta anos, mas uma fração",
            "relevante mudou três vezes ou mais - reversões que a",
            "diferença entre 1985 e 2024 não registra. À direita, o",
            "balanço entre conversão e regeneração: a conversão de",
            "áreas naturais para uso supera a regeneração em cerca de",
            "duas vezes.")))

salvar_fig(f12, "Fig_12_instabilidade_e_transicoes", 13, 6)

########################################################################
######@> Etapa 06 - Padrões municipais e gradiente espacial...

######@> Perfil de cada município...
## Reúne em uma linha o que descreve o município: sua composição atual,
## quanto se transformou, quão instável é sua paisagem e qual sua
## posição no litoral. É a tabela que alimenta os mapas (Etapa 14) e o
## agrupamento (Etapa 15).
perfil_municipio <- mun_n1 %>%
    filter(ano == ano_fim) %>%
    select(geocodigo, municipio, classe, pct_atual = area_pct) %>%
    pivot_wider(names_from = classe, values_from = pct_atual,
                names_prefix = "pct_") %>%
    left_join(variacao_municipal %>%
                  select(geocodigo, classe, variacao_pp) %>%
                  pivot_wider(names_from = classe,
                              values_from = variacao_pp,
                              names_prefix = "delta_"),
              by = "geocodigo") %>%
    left_join(urb_mun %>%
                  filter(ano %in% c(ano_ini, ano_fim)) %>%
                  select(geocodigo, ano, area_ha) %>%
                  pivot_wider(names_from = ano, values_from = area_ha,
                              names_prefix = "urb_") %>%
                  rename(urb_ini = paste0("urb_", ano_ini),
                         urb_fim = paste0("urb_", ano_fim)) %>%
                  mutate(urb_variacao_ha = urb_fim - urb_ini,
                         urb_multiplicador = ifelse(urb_ini > 0,
                                                    urb_fim / urb_ini,
                                                    NA_real_)),
              by = "geocodigo") %>%
    left_join(mudancas_periodo %>%
                  group_by(geocodigo) %>%
                  summarise(pct_sem_mudanca =
                                sum(pct_do_municipio[
                                    classe == "Nenhuma Mudança"]),
                            pct_tres_ou_mais =
                                sum(pct_do_municipio[
                                    classe %in% c("3 Mudanças",
                                                  "4 Mudanças",
                                                  "5 Mudanças",
                                                  "6 Mudanças ou mais")]),
                            .groups = "drop"),
              by = "geocodigo") %>%
    left_join(areas_mun %>%
                  select(geocodigo, area_km2_shape, area_ha_mapbiomas,
                         pct_area_agua),
              by = "geocodigo") %>%
    left_join(geografia_mun %>%
                  select(geocodigo, longitude, latitude),
              by = "geocodigo") %>%
    mutate(urb_pct_area = 100 * urb_fim / area_ha_mapbiomas,
           urb_taxa_ha_ano = urb_variacao_ha / (ano_fim - ano_ini))

tabelas[["Tab_15_perfil_municipal"]] <- salvar_tab(
    perfil_municipio %>% arrange(desc(latitude)),
    "Tab_15_perfil_municipal")

######@> Lacuna do agregado de instabilidade...
## O relatório "Número de mudanças" cobre 34 dos 35 municípios - Penha
## não foi exportado pela plataforma. A coluna pct_sem_mudanca fica NA
## para ele, e as figuras que a usam deixam de exibir um ponto. É
## registrado aqui para que a ausência não seja confundida com valor
## zero.
sem_instabilidade <- perfil_municipio %>%
    filter(is.na(pct_sem_mudanca)) %>%
    pull(municipio)

if(length(sem_instabilidade) > 0) {
    message("Sem agregado de mudanças: ",
            paste(sem_instabilidade, collapse = ", "),
            " (NA nas colunas de instabilidade)")
}

######@> Gradiente latitudinal...
## A pergunta: a posição no litoral organiza a paisagem? Um gradiente
## forte significaria que a latitude é um bom resumo espacial e que
## municípios vizinhos podem ser tratados como semelhantes; a ausência
## de gradiente significa que a variação é local e que cada município
## precisa entrar por si.
vars_gradiente <- c("pct_Floresta" = "Floresta (%)",
                    "pct_Agropecuária" = "Agropecuária (%)",
                    "pct_Área Não Vegetada" = "Área não vegetada (%)",
                    "urb_pct_area" = "Área urbanizada (%)",
                    "delta_Floresta" = "Variação da floresta (p.p.)",
                    "pct_sem_mudanca" = "Área que nunca mudou (%)")

gradiente <- map_dfr(names(vars_gradiente), function(v) {
    x <- perfil_municipio[[v]]
    y <- perfil_municipio$latitude
    ok <- !is.na(x) & !is.na(y)
    teste <- suppressWarnings(cor.test(x[ok], y[ok],
                                       method = "spearman"))
    tibble(variavel = vars_gradiente[[v]],
           coluna = v,
           rho_latitude = as.numeric(teste$estimate),
           p_valor = teste$p.value,
           relacao = case_when(teste$p.value >= alfa ~
                                   "Sem gradiente detectado",
                               teste$estimate > 0 ~
                                   "Cresce para o norte",
                               TRUE ~ "Cresce para o sul"))
})

tabelas[["Tab_16_gradiente_latitudinal"]] <- salvar_tab(
    gradiente, "Tab_16_gradiente_latitudinal")

message("\nGradiente latitudinal   : ",
        sum(gradiente$relacao != "Sem gradiente detectado"), " de ",
        nrow(gradiente), " indicadores com gradiente significativo")

######@> Figura 13 - indicadores contra a latitude...
dados_f13 <- perfil_municipio %>%
    select(municipio, latitude, all_of(names(vars_gradiente))) %>%
    pivot_longer(-c(municipio, latitude), names_to = "coluna",
                 values_to = "valor") %>%
    left_join(gradiente %>% select(coluna, variavel, rho_latitude,
                                   p_valor),
              by = "coluna") %>%
    mutate(painel = paste0(variavel, "\n(rho = ",
                           sprintf("%.2f", rho_latitude),
                           ifelse(p_valor < alfa, "*", ""), ")"))

f13 <- ggplot(dados_f13, aes(x = latitude, y = valor)) +
    geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
                colour = "#D55E00", fill = "#D55E00", alpha = 0.12,
                linewidth = 0.6) +
    geom_point(size = 1.8, colour = "#0072B2", alpha = 0.85) +
    facet_wrap(~ painel, scales = "free_y", ncol = 3) +
    labs(title = "A latitude organiza a composição, não a urbanização",
         subtitle = paste("Correlação de Spearman com a latitude do",
                          "centroide; * indica p < 0,05"),
         x = "Latitude do centroide (graus)", y = NULL,
         caption = quebrar(paste(
             "A latitude cresce para o norte. Há um gradiente CLARO nas",
             "classes naturais e agrícolas - mais floresta ao norte,",
             "mais agropecuária ao sul, e a perda florestal concentrada",
             "no norte -, e nenhum gradiente nos indicadores urbanos: a",
             "fração urbanizada não depende da posição no litoral. As",
             "duas leituras convivem porque descrevem coisas",
             "diferentes: a composição herda a geografia física,",
             "enquanto a urbanização segue a dinâmica de cada",
             "município.")))

salvar_fig(f13, "Fig_13_gradiente_latitudinal", 12, 7)

######@> Figura 14 - quem mais se transformou...
dados_f14 <- perfil_municipio %>%
    select(municipio, delta_Floresta, `delta_Área Não Vegetada`,
           urb_multiplicador) %>%
    rename(delta_nao_vegetada = `delta_Área Não Vegetada`)

ordem_f14 <- dados_f14 %>%
    arrange(delta_Floresta) %>%
    pull(municipio)

g14a <- dados_f14 %>%
    mutate(municipio = factor(municipio, levels = ordem_f14)) %>%
    ggplot(aes(x = delta_Floresta, y = municipio,
               fill = delta_Floresta > 0)) +
    geom_col(width = 0.75) +
    geom_vline(xintercept = 0, colour = "grey30") +
    scale_fill_manual(values = c("FALSE" = "#8C510A",
                                 "TRUE" = "#01665E"),
                      guide = "none") +
    labs(subtitle = paste0("Variação da floresta, ", ano_ini, "-",
                           ano_fim),
         x = "Pontos percentuais da área municipal", y = NULL) +
    theme(axis.text.y = element_text(size = 7))

g14b <- dados_f14 %>%
    mutate(municipio = factor(municipio, levels = ordem_f14)) %>%
    ggplot(aes(x = urb_multiplicador, y = municipio)) +
    geom_vline(xintercept = 1, linetype = "dashed", colour = "grey40") +
    geom_segment(aes(xend = 1, yend = municipio), colour = "grey70",
                 linewidth = 0.4) +
    geom_point(size = 2, colour = "#D55E00") +
    scale_x_continuous(trans = "log10",
                       breaks = c(1, 2, 5, 10, 25, 50)) +
    labs(subtitle = paste0("Multiplicação da área urbanizada, ",
                           ano_ini, "-", ano_fim),
         x = "Vezes (escala logarítmica)", y = NULL) +
    theme(axis.text.y = element_blank(),
          axis.ticks.y = element_blank())

f14 <- (g14a | g14b) +
    plot_layout(widths = c(1, 0.85)) +
    plot_annotation(
        title = "Municípios ordenados pela perda de floresta",
        subtitle = paste("Os dois painéis compartilham a ordenação do",
                         "eixo vertical"),
        caption = quebrar(paste(
            "A ordenação por perda de floresta NÃO reproduz a ordenação",
            "por crescimento urbano: há municípios que perderam muita",
            "floresta sem urbanizar (conversão para silvicultura ou",
            "agricultura) e municípios que multiplicaram sua mancha",
            "urbana partindo de uma base pequena, sem que isso",
            "aparecesse como perda florestal expressiva. São dois",
            "processos distintos, e a Etapa 15 os usa como eixos da",
            "tipologia.")))

salvar_fig(f14, "Fig_14_ranking_transformacao", 12, 9)

########################################################################
######@> Etapa 07 - Urbanização e vegetação urbana...

######@> Trajetória da mancha urbana do litoral...
## O relatório de urbanização anual traz uma única classe por
## município, o que o torna a série mais limpa da base - e a mais
## diretamente ligada à exposição a desastres: onde há mancha urbana,
## há população e patrimônio expostos.
urb_litoral <- urb_litoral %>%
    arrange(ano) %>%
    mutate(variacao_ha = area_ha - lag(area_ha),
           indice = 100 * area_ha / first(area_ha))

taxa_decada <- urb_mun %>%
    mutate(decada = cut(ano, breaks = c(head(quebras_decada, -1), Inf),
                        labels = c("1985-1994", "1995-2004",
                                   "2005-2014", "2015-2024"),
                        right = FALSE)) %>%
    filter(!is.na(decada)) %>%
    group_by(decada, ano) %>%
    summarise(area_ha = sum(area_ha), .groups = "drop") %>%
    group_by(decada) %>%
    summarise(area_inicial = first(area_ha),
              area_final = last(area_ha),
              crescimento_ha = last(area_ha) - first(area_ha),
              crescimento_ha_ano = (last(area_ha) - first(area_ha)) /
                  (n() - 1),
              crescimento_pct = 100 * (last(area_ha) - first(area_ha)) /
                  first(area_ha),
              .groups = "drop")

tabelas[["Tab_17_urbanizacao_decada"]] <- salvar_tab(
    taxa_decada, "Tab_17_urbanizacao_por_decada")

message("\nÁrea urbanizada do litoral: ",
        fmt_int(urb_litoral$area_ha[urb_litoral$ano == ano_ini]),
        " ha em ", ano_ini, " -> ",
        fmt_int(urb_litoral$area_ha[urb_litoral$ano == ano_fim]),
        " ha em ", ano_fim, " (",
        sprintf("%.1f", 100 * (urb_litoral$area_ha[urb_litoral$ano ==
                                                   ano_fim] /
                               urb_litoral$area_ha[urb_litoral$ano ==
                                                   ano_ini] - 1)),
        "%)")

######@> Figura 15 - a expansão urbana do litoral...
g15a <- ggplot(urb_litoral, aes(x = ano, y = area_ha)) +
    geom_line(linewidth = 0.9, colour = "#D55E00") +
    geom_point(size = 1, colour = "#D55E00") +
    scale_y_continuous(labels = fmt_int) +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 5)) +
    labs(subtitle = "Área urbanizada acumulada", x = NULL,
         y = "Área (ha)")

g15b <- ggplot(urb_litoral %>% filter(!is.na(variacao_ha)),
               aes(x = ano, y = variacao_ha)) +
    geom_col(fill = "#0072B2", width = 0.8) +
    geom_smooth(method = "loess", formula = y ~ x, se = FALSE,
                colour = "grey25", linewidth = 0.6, span = 0.5) +
    scale_y_continuous(labels = fmt_int) +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 5)) +
    labs(subtitle = "Incremento anual (a série de fluxo)", x = NULL,
         y = "Variação da área (ha/ano)")

f15 <- (g15a / g15b) +
    plot_annotation(
        title = "Expansão da mancha urbana no litoral catarinense",
        subtitle = paste0("Conjunto dos ", n_municipios,
                          " municípios, ", ano_ini, "-", ano_fim),
        caption = quebrar(paste(
            "Os dois painéis mostram a MESMA informação em escalas",
            "diferentes: acima o estoque (área acumulada), abaixo o",
            "fluxo (quanto se acrescentou em cada ano). A distinção",
            "atravessa todo este script: a série de estoque é",
            "fortemente autocorrelacionada por construção, e é a série",
            "de fluxo que informa sobre o processo de urbanização.")))

salvar_fig(f15, "Fig_15_expansao_urbana_litoral", 11, 8)

######@> Figura 16 - expansão urbana município a município...
## Atenção ao uso de first(): a base de comparação precisa ser
## materializada como coluna ANTES do ifelse. Um ifelse cuja condição
## tem comprimento 1 devolve um vetor de comprimento 1, que o dplyr
## recicla silenciosamente - e a série inteira sairia igual a 1.
dados_f16 <- urb_mun %>%
    arrange(geocodigo, ano) %>%
    group_by(geocodigo, municipio) %>%
    mutate(area_base = first(area_ha),
           indice = ifelse(area_base > 0, area_ha / area_base,
                           NA_real_)) %>%
    ungroup() %>%
    filter(!is.na(indice))

destaques_f16 <- dados_f16 %>%
    filter(ano == ano_fim) %>%
    slice_max(indice, n = 5) %>%
    pull(municipio)

f16 <- ggplot(dados_f16, aes(x = ano, y = indice, group = municipio)) +
    geom_line(colour = "grey75", linewidth = 0.4) +
    geom_line(data = dados_f16 %>% filter(municipio %in% destaques_f16),
              aes(colour = municipio), linewidth = 0.9) +
    scale_y_continuous(trans = "log10",
                       breaks = c(1, 2, 5, 10, 25, 50, 100)) +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 5)) +
    scale_colour_brewer(palette = "Dark2", name = "Maior expansão") +
    guides(colour = guide_legend(nrow = 2)) +
    labs(title = "Cada município parte de uma base diferente",
         subtitle = paste0("Área urbanizada relativa a ", ano_ini,
                           " (= 1); escala logarítmica"),
         x = NULL, y = paste0("Área urbanizada / área em ", ano_ini),
         caption = quebrar(paste(
             "A escala logarítmica é necessária porque as trajetórias",
             "diferem em uma ordem de grandeza: municípios que já eram",
             "urbanos em 1985 crescem pouco em termos relativos, e",
             "municípios que partiram de dezenas de hectares",
             "multiplicam sua mancha urbana dezenas de vezes. Em",
             "hectares absolutos a ordenação é outra - ver Fig_14.")))

salvar_fig(f16, "Fig_16_expansao_urbana_municipios", 11, 7)

######@> Vegetação dentro da mancha urbana...
## O relatório de vegetação urbana reparte a área urbanizada em
## vegetada e não vegetada. A fração vegetada é um indicador de
## qualidade ambiental urbana com consequência direta para desastres:
## superfície impermeável concentra escoamento.
veg_urbana <- vurb %>%
    filter(classe_caminho %in%
           c("Área Urbanizada > Área Urbana Vegetada",
             "Área Urbanizada > Área Urbanizada não Vegetada")) %>%
    mutate(tipo = ifelse(grepl("não Vegetada", classe_caminho),
                         "nao_vegetada", "vegetada")) %>%
    select(geocodigo, municipio, ano, tipo, area_ha) %>%
    pivot_wider(names_from = tipo, values_from = area_ha,
                values_fill = 0) %>%
    mutate(total_urbano = vegetada + nao_vegetada,
           pct_vegetada = ifelse(total_urbano > 0,
                                 100 * vegetada / total_urbano,
                                 NA_real_))

veg_urbana_litoral <- veg_urbana %>%
    group_by(ano) %>%
    summarise(vegetada = sum(vegetada),
              nao_vegetada = sum(nao_vegetada),
              .groups = "drop") %>%
    mutate(total_urbano = vegetada + nao_vegetada,
           pct_vegetada = 100 * vegetada / total_urbano)

tabelas[["Tab_18_vegetacao_urbana"]] <- salvar_tab(
    veg_urbana %>% arrange(municipio, ano),
    "Tab_18_vegetacao_urbana_municipal")

######@> Figura 17 - a fração vegetada da mancha urbana...
ordem_f17 <- veg_urbana %>%
    filter(ano == ano_fim) %>%
    arrange(desc(pct_vegetada)) %>%
    pull(municipio)

g17a <- ggplot(veg_urbana, aes(x = ano, y = pct_vegetada,
                               group = municipio)) +
    geom_line(colour = "grey75", linewidth = 0.4) +
    geom_line(data = veg_urbana_litoral, aes(x = ano, y = pct_vegetada),
              inherit.aes = FALSE, colour = "#009E73",
              linewidth = 1.2) +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 10)) +
    labs(subtitle = paste("Trajetória (linha grossa: conjunto do",
                          "litoral)"),
         x = NULL, y = "Vegetação urbana (% da mancha urbana)")

g17b <- veg_urbana %>%
    filter(ano == ano_fim) %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_f17))) %>%
    ggplot(aes(x = pct_vegetada, y = municipio)) +
    geom_col(fill = "#009E73", width = 0.75) +
    geom_vline(xintercept = veg_urbana_litoral$pct_vegetada[
                   veg_urbana_litoral$ano == ano_fim],
               linetype = "dashed", colour = "#D55E00") +
    labs(subtitle = paste("Situação em", ano_fim), x = "%", y = NULL) +
    theme(axis.text.y = element_text(size = 7))

f17 <- (g17a | g17b) +
    plot_layout(widths = c(1.1, 1)) +
    plot_annotation(
        title = "Vegetação dentro da mancha urbana",
        subtitle = paste("Percentual da área urbanizada classificada",
                         "como vegetada"),
        caption = quebrar(paste(
            "A linha tracejada marca o valor do conjunto do litoral. A",
            "fração vegetada da mancha urbana é baixa e relativamente",
            "estável ao longo do período, ainda que a área urbana",
            "vegetada cresça em hectares - ela cresce porque a mancha",
            "urbana inteira cresce. Superfície impermeável concentra",
            "escoamento, e esta é a variável da base mais diretamente",
            "ligada a enxurradas urbanas.")))

salvar_fig(f17, "Fig_17_vegetacao_urbana", 13, 7)

######@> Coortes de urbanização...
## Quando cada pedaço da mancha urbana atual surgiu. A base guarda esse
## agregado em duplicata, sob dois rótulos temporais diferentes
## ("...2" e "undefined") com valores idênticos - resíduo do formato de
## exportação da plataforma. A deduplicação é obrigatória, sob pena de
## dobrar todas as áreas.
coortes_urbanizacao <- agregados_periodo %>%
    filter(grepl("Períodos de urbanização", relatorio)) %>%
    distinct(geocodigo, municipio, classe, area_ha) %>%
    mutate(coorte = sub("^Urbanizado ", "", classe))

coortes_litoral <- coortes_urbanizacao %>%
    group_by(coorte) %>%
    summarise(area_ha = sum(area_ha), .groups = "drop") %>%
    mutate(pct = 100 * area_ha / sum(area_ha))

tabelas[["Tab_19_coortes_urbanizacao"]] <- salvar_tab(
    coortes_urbanizacao %>% arrange(municipio, coorte),
    "Tab_19_coortes_de_urbanizacao")

######@> Figura 18 - de que época é a mancha urbana atual...
paleta_coortes <- colorRampPalette(c("#023858", "#0570B0", "#74A9CF",
                                     "#FDBB84", "#D7301F"))(
                                         nrow(coortes_litoral))

dados_f18 <- coortes_urbanizacao %>%
    group_by(geocodigo, municipio) %>%
    mutate(pct = 100 * area_ha / sum(area_ha)) %>%
    ungroup() %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_mun_f02)),
           coorte = factor(coorte, levels = coortes_litoral$coorte))

f18 <- ggplot(dados_f18, aes(x = pct, y = municipio, fill = coorte)) +
    geom_col(width = 0.8) +
    scale_fill_manual(values = paleta_coortes, name = NULL) +
    scale_x_continuous(expand = c(0, 0)) +
    guides(fill = guide_legend(nrow = 3)) +
    labs(title = "Idade da mancha urbana de cada município",
         subtitle = paste("Percentual da área urbanizada atual por",
                          "período de surgimento"),
         x = "Percentual da mancha urbana atual (%)", y = NULL,
         caption = quebrar(paste0(
             "Municípios ordenados de norte (topo) a sul. ",
             sprintf("%.0f%%", coortes_litoral$pct[
                 coortes_litoral$coorte == "até 1985"]),
             " da mancha urbana atual do litoral já existia em 1985: o ",
             "que a série de 40 anos registra é a expansão de uma ",
             "ocupação que já estava consolidada. Municípios com ",
             "predominância de coortes recentes são os que urbanizaram ",
             "dentro da janela observada, e é neles que a série tem ",
             "poder de explicar mudanças na exposição a desastres.")))

salvar_fig(f18, "Fig_18_coortes_de_urbanizacao", 11, 9)

########################################################################
######@> Etapa 08 - Risco climático: áreas urbanas suscetíveis...

######@> O que este tema mede - e o que ele não mede...
## O relatório cruza um mapa de SUSCETIBILIDADE a inundação, alagamento
## e enxurrada com a mancha urbana de cada ano, e devolve quanta área
## urbana está em cada faixa de suscetibilidade. A suscetibilidade é um
## atributo do terreno e NÃO muda ano a ano; o que muda é a mancha
## urbana que a ocupa. Logo, a dinâmica deste tema é a dinâmica da
## urbanização - conclusão que a análise abaixo verifica em vez de
## pressupor.
risco_mun <- risco %>%
    select(geocodigo, municipio, ano, classe, area_ha, area_pct) %>%
    mutate(classe = factor(classe, levels = names(cores_risco))) %>%
    arrange(geocodigo, classe, ano)

risco_litoral <- risco_mun %>%
    group_by(ano, classe) %>%
    summarise(area_ha = sum(area_ha), n_municipios = n_distinct(geocodigo),
              .groups = "drop")

######@> Constância temporal de cada faixa de risco...
## A medida decisiva: em quantos municípios a área de cada faixa é
## literalmente a mesma nos 40 anos. Uma série constante não tem
## tendência, não tem autocorrelação interpretável e não pode servir de
## preditora dinâmica - mas é um descritor válido do município.
constancia_risco <- risco_mun %>%
    group_by(geocodigo, municipio, classe) %>%
    summarise(n_anos = n(),
              media_ha = mean(area_ha),
              dp_ha = sd(area_ha),
              amplitude_ha = max(area_ha) - min(area_ha),
              variacao_relativa = ifelse(min(area_ha) > 0,
                                         100 * (max(area_ha) -
                                                min(area_ha)) /
                                         min(area_ha), NA_real_),
              .groups = "drop") %>%
    mutate(constante = amplitude_ha < 1)

resumo_constancia <- constancia_risco %>%
    group_by(classe) %>%
    summarise(municipios = n(),
              constantes = sum(constante),
              pct_constantes = 100 * sum(constante) / n(),
              amplitude_mediana_ha = median(amplitude_ha),
              .groups = "drop")

tabelas[["Tab_20_constancia_risco"]] <- salvar_tab(
    constancia_risco %>% arrange(classe, desc(amplitude_ha)),
    "Tab_20_constancia_do_risco")

message("\n--- Risco climático: constância das faixas ---")
print(as.data.frame(resumo_constancia %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 2)))), right = FALSE)

######@> Figura 19 - o tema é quase estático...
g19a <- ggplot(risco_litoral, aes(x = ano, y = area_ha,
                                  colour = classe)) +
    geom_line(linewidth = 0.9) +
    scale_colour_manual(values = cores_risco, name = "Suscetibilidade") +
    scale_y_continuous(labels = fmt_int) +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 5)) +
    labs(subtitle = "Área urbana suscetível no conjunto do litoral",
         x = NULL, y = "Área (ha)")

g19b <- ggplot(resumo_constancia, aes(x = classe, y = pct_constantes,
                                      fill = classe)) +
    geom_col(width = 0.7) +
    geom_text(aes(label = paste0(constantes, " de ", municipios)),
              vjust = -0.4, size = 3, colour = "grey25") +
    scale_fill_manual(values = cores_risco, guide = "none") +
    scale_y_continuous(limits = c(0, 105),
                       expand = expansion(mult = c(0, 0.05))) +
    labs(subtitle = "Municípios em que a área é constante nos 40 anos",
         x = NULL, y = "% dos municípios")

f19 <- (g19a | g19b) +
    plot_layout(widths = c(1.4, 1)) +
    plot_annotation(
        title = "Risco climático: um mapa fixo visto através da mancha urbana",
        subtitle = paste("Áreas urbanas suscetíveis a inundação,",
                         "alagamento ou enxurrada"),
        caption = quebrar(paste(
            "As faixas Médio e Alto são literalmente constantes na",
            "grande maioria dos municípios: a suscetibilidade é um",
            "atributo do terreno, e onde a mancha urbana já ocupava",
            "toda a área suscetível em 1985 nada mais muda. Só a faixa",
            "Muito Alto cresce de modo apreciável, e cresce porque a",
            "cidade avançou sobre ela. O tema NÃO deve ser lido como",
            "'o risco aumentou', e sim como 'a exposição aumentou'.")))

salvar_fig(f19, "Fig_19_risco_climatico_constancia", 13, 6)

######@> A dinâmica do risco é a dinâmica da urbanização...
## Teste direto da afirmação: se a área suscetível cresce porque a
## mancha urbana cresce, as duas séries devem andar juntas dentro de
## cada município.
risco_total_mun <- risco_mun %>%
    group_by(geocodigo, municipio, ano) %>%
    summarise(risco_ha = sum(area_ha), .groups = "drop")

risco_versus_urbano <- risco_total_mun %>%
    inner_join(urb_mun %>% select(geocodigo, ano, urb_ha = area_ha),
               by = c("geocodigo", "ano")) %>%
    mutate(pct_urbano_suscetivel = ifelse(urb_ha > 0,
                                          100 * risco_ha / urb_ha,
                                          NA_real_))

cor_risco_urbano <- cor(risco_versus_urbano$risco_ha,
                        risco_versus_urbano$urb_ha)
cor_risco_urbano_log <- cor(log1p(risco_versus_urbano$risco_ha),
                            log1p(risco_versus_urbano$urb_ha))

correlacao_intra <- risco_versus_urbano %>%
    group_by(geocodigo, municipio) %>%
    summarise(cor_temporal = ifelse(sd(risco_ha) > 0 & sd(urb_ha) > 0,
                                    cor(risco_ha, urb_ha), NA_real_),
              pct_suscetivel_fim = pct_urbano_suscetivel[
                  which.max(ano)],
              .groups = "drop")

tabelas[["Tab_21_risco_versus_urbano"]] <- salvar_tab(
    correlacao_intra %>% arrange(desc(pct_suscetivel_fim)),
    "Tab_21_risco_versus_urbanizacao")

message("Risco x urbanização    : r = ",
        sprintf("%.3f", cor_risco_urbano), " (nível), ",
        sprintf("%.3f", cor_risco_urbano_log), " (log); ",
        "correlação temporal interna mediana = ",
        sprintf("%.3f", median(correlacao_intra$cor_temporal,
                               na.rm = TRUE)))

######@> Figura 20 - exposição urbana ao risco...
g20a <- ggplot(risco_versus_urbano, aes(x = urb_ha, y = risco_ha)) +
    geom_point(aes(colour = ano), size = 1.4, alpha = 0.7) +
    scale_x_continuous(trans = "log10", labels = fmt_int) +
    scale_y_continuous(trans = "log10", labels = fmt_int) +
    scale_colour_viridis_c(option = "viridis", name = "Ano") +
    labs(subtitle = paste0("Área suscetível x mancha urbana (r = ",
                           sprintf("%.2f", cor_risco_urbano_log),
                           " em log)"),
         x = "Área urbanizada (ha)", y = "Área urbana suscetível (ha)")

ordem_f20 <- correlacao_intra %>%
    arrange(desc(pct_suscetivel_fim)) %>%
    pull(municipio)

g20b <- correlacao_intra %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_f20))) %>%
    ggplot(aes(x = pct_suscetivel_fim, y = municipio)) +
    geom_col(fill = "#D55E00", width = 0.75) +
    labs(subtitle = paste("Fração da mancha urbana em área suscetível,",
                          ano_fim),
         x = "% da área urbanizada", y = NULL) +
    theme(axis.text.y = element_text(size = 7))

f20 <- (g20a | g20b) +
    plot_layout(widths = c(1.1, 1)) +
    plot_annotation(
        title = "Exposição urbana à suscetibilidade a inundação",
        subtitle = paste0("Todos os pares município-ano, ", ano_ini,
                          "-", ano_fim),
        caption = quebrar(paste(
            "Os eixos do painel da esquerda são logarítmicos porque as",
            "manchas urbanas diferem em duas ordens de grandeza. A",
            "associação existe mas está longe de ser perfeita: há",
            "municípios com mancha urbana grande e pouca área",
            "suscetível, e o inverso. A fração exposta, à direita, é a",
            "variável mais útil para acoplar às séries de desastre,",
            "porque normaliza o tamanho do município.")))

salvar_fig(f20, "Fig_20_exposicao_urbana_ao_risco", 13, 7)

########################################################################
######@> Etapa 09 - Água: diagnóstico de por que não é série...

######@> O problema, medido...
## Duas razões independentes descartam o tema Água como série. A
## primeira é de COBERTURA: o número de municípios com registro cresce
## ao longo do tempo, de modo que qualquer soma do litoral confunde
## entrada de município com mudança real. A segunda é de SEMÂNTICA: as
## classes não são estados da paisagem, mas faixas de TENDÊNCIA da
## superfície de água, e não fecham a área do município.
agua_cobertura <- agua %>%
    group_by(ano) %>%
    summarise(municipios = n_distinct(geocodigo),
              registros = n(),
              area_ha = sum(area_ha),
              .groups = "drop")

agua_fechamento <- agua %>%
    group_by(geocodigo, municipio, ano) %>%
    summarise(soma_pct = sum(area_pct), .groups = "drop")

agua_municipios <- agua %>%
    group_by(geocodigo, municipio) %>%
    summarise(primeiro_ano = min(ano),
              ultimo_ano = max(ano),
              n_anos = n_distinct(ano),
              area_media_ha = mean(area_ha),
              .groups = "drop") %>%
    arrange(primeiro_ano)

agua_classes <- agua %>%
    group_by(classe) %>%
    summarise(area_media_ha = mean(area_ha),
              area_max_ha = max(area_ha),
              registros = n(),
              .groups = "drop") %>%
    arrange(desc(area_media_ha))

tabelas[["Tab_22_agua_cobertura"]] <- salvar_tab(
    agua_cobertura, "Tab_22_agua_cobertura_por_ano")
tabelas[["Tab_23_agua_municipios"]] <- salvar_tab(
    agua_municipios, "Tab_23_agua_por_municipio")

message("\n--- Tema Água: diagnóstico ---")
message("Municípios cobertos    : ", nrow(agua_municipios), " de ",
        n_municipios)
message("Municípios em ", min(agua$ano), "     : ",
        agua_cobertura$municipios[1],
        " | em 2005: ",
        agua_cobertura$municipios[agua_cobertura$ano == 2005])
message("Soma de area_pct       : de ",
        sprintf("%.2f", min(agua_fechamento$soma_pct)), "% a ",
        sprintf("%.2f", max(agua_fechamento$soma_pct)),
        "% (não fecha)")

######@> Figura 21 - por que o tema Água não entra nas séries...
g21a <- ggplot(agua_cobertura, aes(x = ano, y = municipios)) +
    geom_col(fill = "#0072B2", width = 0.8) +
    geom_hline(yintercept = nrow(agua_municipios), linetype = "dashed",
               colour = "#D55E00") +
    annotate("text", x = min(agua$ano) + 2,
             y = nrow(agua_municipios) + 1.2,
             label = paste(nrow(agua_municipios),
                           "municípios com o tema"),
             size = 3, colour = "#D55E00", hjust = 0) +
    scale_x_continuous(breaks = seq(1990, 2025, 5)) +
    labs(subtitle = "Municípios com registro em cada ano",
         x = NULL, y = "Municípios")

g21b <- ggplot(agua_fechamento, aes(x = factor(ano), y = soma_pct)) +
    geom_boxplot(outlier.size = 0.6, fill = "#56B4E9", alpha = 0.6,
                 linewidth = 0.3) +
    geom_hline(yintercept = 100, linetype = "dashed",
               colour = "#D55E00") +
    scale_x_discrete(breaks = seq(1995, 2025, 5)) +
    labs(subtitle = "Soma das classes por município-ano",
         x = NULL, y = "Soma de area_pct (%)")

f21 <- (g21a / g21b) +
    plot_annotation(
        title = "O tema Água não constitui um painel comparável",
        subtitle = paste("Tendência da superfície de água por classe,",
                         paste0(min(agua$ano), "-", max(agua$ano))),
        caption = quebrar(paste(
            "Acima: a cobertura CRESCE ao longo do tempo, de um",
            "município em 1992 a mais de vinte a partir de 2005. Um",
            "agregado do litoral somaria municípios que entram, e o",
            "crescimento resultante não seria mudança da superfície de",
            "água. Abaixo: as classes são faixas de tendência, não",
            "estados da paisagem, e por isso não fecham a área do",
            "município - a linha tracejada em 100% nunca é atingida.",
            "O tema é mantido como retrato do SENTIDO da mudança",
            "hídrica nos municípios cobertos, e fica fora de todas as",
            "análises de série deste script.")))

salvar_fig(f21, "Fig_21_agua_diagnostico", 12, 8)

######@> O que o tema Água ainda informa...
## Descartado como série, ele continua respondendo a uma pergunta
## descritiva: no período coberto, a superfície de água do município
## esteve predominantemente em acréscimo ou em decréscimo? A resposta é
## o balanço entre as faixas, calculado apenas nos municípios com
## cobertura razoável.
agua_balanco <- agua %>%
    filter(geocodigo %in% agua_municipios$geocodigo[
               agua_municipios$n_anos >= 20]) %>%
    mutate(sentido = case_when(grepl("acréscimo", classe) ~ "Acréscimo",
                               grepl("decréscimo", classe) ~
                                   "Decréscimo",
                               TRUE ~ "Outro")) %>%
    group_by(geocodigo, municipio, sentido) %>%
    summarise(area_ha = sum(area_ha), .groups = "drop") %>%
    pivot_wider(names_from = sentido, values_from = area_ha,
                values_fill = 0) %>%
    mutate(balanco_ha = Acréscimo - Decréscimo,
           sentido_predominante = ifelse(balanco_ha > 0,
                                         "Acréscimo", "Decréscimo"))

tabelas[["Tab_24_agua_balanco"]] <- salvar_tab(
    agua_balanco %>% arrange(balanco_ha),
    "Tab_24_agua_balanco_do_sentido")

message("Balanço hídrico        : ",
        sum(agua_balanco$sentido_predominante == "Decréscimo"), " de ",
        nrow(agua_balanco),
        " municípios com predomínio de decréscimo")

########################################################################
######@> Etapa 10 - Painéis diagnósticos por município...

######@> Séries municipais de trabalho para os diagnósticos...
## Três séries por município resumem o que interessa: a floresta (o que
## se perde), a área não vegetada (o que avança) e a área urbanizada (a
## exposição). As duas primeiras em percentual da área municipal, para
## comparabilidade entre municípios de tamanhos muito diferentes; a
## terceira em hectares, porque é a grandeza em que a expansão urbana é
## usualmente relatada.
series_chave <- bind_rows(
    mun_n1 %>%
        filter(classe == "Floresta") %>%
        transmute(geocodigo, municipio, ano, serie = "Floresta (%)",
                  valor = area_pct),
    mun_n1 %>%
        filter(classe == "Área Não Vegetada") %>%
        transmute(geocodigo, municipio, ano,
                  serie = "Área não vegetada (%)", valor = area_pct),
    urb_mun %>%
        transmute(geocodigo, municipio, ano,
                  serie = "Área urbanizada (ha)", valor = area_ha)) %>%
    arrange(geocodigo, serie, ano)

######@> Construção de um painel por município...
## Cada arquivo reúne, para um município: (a) a composição da paisagem
## ao longo do período; (b) a trajetória da área urbanizada; (c) a
## mudança líquida por classe de nível 2; e (d, e) os correlogramas da
## série de floresta em PRIMEIRA DIFERENÇA - isto é, da taxa anual de
## conversão, e não do estoque, cuja autocorrelação seria alta por
## construção e nada diria sobre o processo.
message("\nGerando painéis por município...")

diagnostico_municipal <- vector("list", n_municipios)

for(i in seq_along(municipios_nomes)) {
    mun <- municipios_nomes[i]
    geo <- mun_ref$geocodigo[mun_ref$municipio == mun]

    dados_comp <- mun_n1 %>% filter(municipio == mun)
    dados_urb <- urb_mun %>% filter(municipio == mun) %>% arrange(ano)
    dados_flor <- dados_comp %>%
        filter(classe == "Floresta") %>%
        arrange(ano)
    dados_nv <- dados_comp %>%
        filter(classe == "Área Não Vegetada") %>%
        arrange(ano)

    ## (a) Composição da paisagem ao longo do período
    g1 <- ggplot(dados_comp, aes(x = ano, y = area_pct,
                                 fill = classe)) +
        geom_area(colour = "white", linewidth = 0.1) +
        scale_fill_manual(values = cores_classe, name = NULL,
                          drop = FALSE, limits = ordem_classes_n1) +
        scale_x_continuous(breaks = seq(ano_ini, ano_fim, 5),
                           expand = c(0, 0)) +
        scale_y_continuous(expand = c(0, 0)) +
        labs(subtitle = "Composição da paisagem", x = NULL,
             y = "% da área")

    ## (b) Trajetória da mancha urbana
    g2 <- ggplot(dados_urb, aes(x = ano, y = area_ha)) +
        geom_line(colour = "#D55E00", linewidth = 0.8) +
        geom_point(size = 0.8, colour = "#D55E00") +
        scale_x_continuous(breaks = seq(ano_ini, ano_fim, 5)) +
        scale_y_continuous(labels = fmt_int) +
        labs(subtitle = "Área urbanizada", x = NULL, y = "ha")

    ## (c) Mudança líquida por classe de nível 2
    variacao_mun_n2 <- mun_n2 %>%
        filter(municipio == mun, ano %in% c(ano_ini, ano_fim)) %>%
        select(classe_pai, classe, ano, area_ha) %>%
        pivot_wider(names_from = ano, values_from = area_ha) %>%
        rename(ha_ini = as.character(ano_ini),
               ha_fim = as.character(ano_fim)) %>%
        mutate(variacao_ha = ha_fim - ha_ini,
               classe_pai = factor(classe_pai,
                                   levels = ordem_classes_n1)) %>%
        filter(abs(variacao_ha) > 1) %>%
        arrange(variacao_ha) %>%
        mutate(classe = factor(classe, levels = classe))

    if(nrow(variacao_mun_n2) > 0) {
        g3 <- ggplot(variacao_mun_n2, aes(x = variacao_ha, y = classe,
                                          fill = classe_pai)) +
            geom_col(width = 0.7) +
            geom_vline(xintercept = 0, colour = "grey30") +
            ## A legenda é suprimida aqui porque o painel (a) já
            ## exibe a mesma correspondência de cores; duas legendas
            ## idênticas ocupariam o rodapé do painel sem acrescentar
            ## informação.
            scale_fill_manual(values = cores_classe, guide = "none",
                              drop = FALSE, limits = ordem_classes_n1) +
            scale_x_continuous(labels = fmt_int) +
            labs(subtitle = paste0("Mudança líquida por classe (",
                                   ano_ini, "-", ano_fim, ")"),
                 x = "ha", y = NULL) +
            theme(axis.text.y = element_text(size = 7))
    } else {
        g3 <- ggplot() +
            annotate("text", x = 0, y = 0, size = 3, colour = "grey40",
                     label = "Sem classe com variação superior a 1 ha") +
            theme_void()
    }

    ## (d) e (e) Correlogramas da série de floresta em 1ª diferença
    dif_flor <- diff(dados_flor$area_pct)
    acf_flor <- calcular_correlograma(dif_flor, lag_max_anual, "ACF")
    pacf_flor <- calcular_correlograma(dif_flor, lag_max_anual, "PACF")
    g4 <- grafico_correlograma(
        acf_flor, subtitulo = "ACF da variação anual da floresta")
    g5 <- grafico_correlograma(
        pacf_flor, subtitulo = "PACF da variação anual da floresta")

    ## Composição do painel
    painel <- (g1 / g2 / g3 / (g4 | g5)) +
        plot_layout(heights = c(1, 0.8, 1.1, 1), guides = "collect") +
        plot_annotation(
            title = paste0(mun, " (", geo, ")"),
            subtitle = sprintf(paste("Floresta: %.1f%% -> %.1f%% |",
                                     "Área urbanizada: %s -> %s ha",
                                     "(x%.1f) | Área: %s km²"),
                               first(dados_flor$area_pct),
                               last(dados_flor$area_pct),
                               fmt_int(first(dados_urb$area_ha)),
                               fmt_int(last(dados_urb$area_ha)),
                               last(dados_urb$area_ha) /
                               first(dados_urb$area_ha),
                               fmt_int(perfil_municipio$area_km2_shape[
                                   perfil_municipio$geocodigo == geo])),
            caption = quebrar(paste(
                "AED MapBiomas | Os correlogramas são da PRIMEIRA",
                "DIFERENÇA (taxa anual de conversão), não do estoque.",
                "Linhas tracejadas: limite de significância a 5%"))) &
        theme(legend.position = "bottom")

    salvar_fig(painel, paste0("Painel_", geo, "_", limpar_nome(mun)),
               10, 14, diretorio = dir_fig_mun)

    ## Diagnóstico numérico do município, acumulado para a tabela final
    diag_flor_nivel <- diagnosticar_serie(dados_flor$area_pct)
    diag_flor_dif <- diagnosticar_serie(dif_flor)
    diag_urb_nivel <- diagnosticar_serie(dados_urb$area_ha)
    diag_urb_dif <- diagnosticar_serie(diff(dados_urb$area_ha))
    mk_flor <- mann_kendall(dados_flor$area_pct)
    mk_urb <- mann_kendall(dados_urb$area_ha)

    diagnostico_municipal[[i]] <- tibble(
        geocodigo = geo, municipio = mun,
        ## Floresta - estoque e fluxo
        flor_pct_ini = first(dados_flor$area_pct),
        flor_pct_fim = last(dados_flor$area_pct),
        flor_acf1_nivel = diag_flor_nivel$acf1,
        flor_acf1_dif = diag_flor_dif$acf1,
        flor_ljung_dif_p = diag_flor_dif$ljung_box_p,
        flor_estacionaria = diag_flor_nivel$estacionaria,
        flor_mk_tau = mk_flor$tau, flor_mk_p = mk_flor$p_valor,
        flor_sen_pp_decada = 10 * declividade_sen(dados_flor$area_pct,
                                                  dados_flor$ano),
        ## Área não vegetada
        nv_pct_ini = first(dados_nv$area_pct),
        nv_pct_fim = last(dados_nv$area_pct),
        nv_sen_pp_decada = 10 * declividade_sen(dados_nv$area_pct,
                                                dados_nv$ano),
        ## Área urbanizada - estoque e fluxo
        urb_ha_ini = first(dados_urb$area_ha),
        urb_ha_fim = last(dados_urb$area_ha),
        urb_acf1_nivel = diag_urb_nivel$acf1,
        urb_acf1_dif = diag_urb_dif$acf1,
        urb_mk_tau = mk_urb$tau, urb_mk_p = mk_urb$p_valor,
        urb_sen_ha_ano = declividade_sen(dados_urb$area_ha,
                                         dados_urb$ano))
}

diagnostico_municipal <- bind_rows(diagnostico_municipal) %>%
    mutate(memoria_no_fluxo = ifelse(flor_ljung_dif_p < alfa,
                                     "Sim", "Não"),
           tendencia_floresta = case_when(
               is.na(flor_mk_p) ~ "Indefinida",
               flor_mk_p >= alfa ~ "Sem tendência",
               flor_mk_tau > 0 ~ "Ganho de floresta",
               TRUE ~ "Perda de floresta"),
           tendencia_urbana = case_when(
               is.na(urb_mk_p) ~ "Indefinida",
               urb_mk_p >= alfa ~ "Sem tendência",
               urb_mk_tau > 0 ~ "Expansão",
               TRUE ~ "Retração")) %>%
    arrange(flor_sen_pp_decada)

tabelas[["Tab_25_diag_municipal"]] <- salvar_tab(
    diagnostico_municipal, "Tab_25_diagnostico_series_municipais")

message("Painéis gerados        : ", n_municipios)
message("Municípios com perda de floresta significativa: ",
        sum(diagnostico_municipal$tendencia_floresta ==
            "Perda de floresta"), " de ", n_municipios)
message("Municípios com expansão urbana significativa  : ",
        sum(diagnostico_municipal$tendencia_urbana == "Expansão"),
        " de ", n_municipios)
message("Municípios com memória no fluxo (Ljung-Box)   : ",
        sum(diagnostico_municipal$memoria_no_fluxo == "Sim"),
        " de ", n_municipios)

########################################################################
######@> Etapa 11 - Dependência temporal: estoque e fluxo...

######@> Séries do litoral em formato de lista...
## Seis séries resumem o litoral: as cinco classes de nível 1, em
## percentual da área, e a área urbanizada, em hectares. Cada uma é
## examinada em DUAS versões - o nível (estoque) e a primeira diferença
## (fluxo) -, e a comparação entre as duas é o resultado central desta
## etapa.
series_litoral <- bind_rows(
    litoral_n1 %>%
        transmute(serie = as.character(classe), ano, valor = area_pct),
    urb_litoral %>%
        transmute(serie = "Área urbanizada (ha)", ano,
                  valor = area_ha)) %>%
    arrange(serie, ano)

ordem_series <- c(ordem_classes_n1, "Área urbanizada (ha)")

######@> Diagnóstico das séries do litoral, em nível e em diferença...
diagnostico_litoral <- map_dfr(ordem_series, function(s) {
    x <- series_litoral$valor[series_litoral$serie == s]
    bind_rows(
        diagnosticar_serie(x) %>% mutate(versao = "Nível (estoque)"),
        diagnosticar_serie(diff(x)) %>%
            mutate(versao = "1ª diferença (fluxo)")) %>%
        mutate(serie = s, .before = 1)
}) %>%
    select(serie, versao, everything())

tabelas[["Tab_26_diag_litoral"]] <- salvar_tab(
    diagnostico_litoral, "Tab_26_diagnostico_series_do_litoral")

message("\n--- Dependência temporal: estoque x fluxo (litoral) ---")
print(as.data.frame(diagnostico_litoral %>%
                    select(serie, versao, acf1, ljung_box_p,
                           estacionaria) %>%
                    mutate(acf1 = round(acf1, 3),
                           ljung_box_p = round(ljung_box_p, 4))),
      right = FALSE)

######@> Correlogramas das séries do litoral...
## Calculados nas duas versões e reunidos em uma tabela única, o que
## permite tanto a figura em facetas quanto a exportação dos
## coeficientes.
correlogramas_litoral <- map_dfr(ordem_series, function(s) {
    x <- series_litoral$valor[series_litoral$serie == s]
    bind_rows(
        calcular_correlograma(x, lag_max_anual, "ACF") %>%
            mutate(versao = "Nível (estoque)"),
        calcular_correlograma(x, lag_max_anual, "PACF") %>%
            mutate(versao = "Nível (estoque)"),
        calcular_correlograma(diff(x), lag_max_anual, "ACF") %>%
            mutate(versao = "1ª diferença (fluxo)"),
        calcular_correlograma(diff(x), lag_max_anual, "PACF") %>%
            mutate(versao = "1ª diferença (fluxo)")) %>%
        mutate(serie = s, .before = 1)
}) %>%
    mutate(serie = factor(serie, levels = ordem_series),
           versao = factor(versao, levels = c("Nível (estoque)",
                                              "1ª diferença (fluxo)")))

tabelas[["Tab_27_correlogramas"]] <- salvar_tab(
    correlogramas_litoral %>%
        select(serie, versao, tipo, lag, valor, ic),
    "Tab_27_correlogramas_do_litoral")

######@> Figura 22 - a autocorrelação do estoque é artefato...
dados_f22 <- correlogramas_litoral %>% filter(tipo == "ACF")

f22 <- ggplot(dados_f22, aes(x = lag, y = valor)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_hline(aes(yintercept = ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_hline(aes(yintercept = -ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_segment(aes(xend = lag, yend = 0, colour = versao),
                 linewidth = 0.6) +
    geom_point(aes(colour = versao), size = 1) +
    facet_grid(serie ~ versao, switch = "y") +
    scale_colour_manual(values = c("Nível (estoque)" = "#D55E00",
                                   "1ª diferença (fluxo)" = "#0072B2"),
                        guide = "none") +
    labs(title = "Estoque e fluxo: a mesma série, duas leituras",
         subtitle = paste("Função de autocorrelação das séries do",
                          "litoral, em nível e em primeira diferença"),
         x = "Defasagem (anos)", y = "ACF",
         caption = quebrar(paste(
             "À esquerda, a ACF do ESTOQUE decai lentamente em todas as",
             "séries: a área de floresta de um ano é a do ano anterior",
             "mais o saldo, e a autocorrelação alta é consequência",
             "aritmética disso, não evidência de memória no processo. À",
             "direita, a ACF do FLUXO - quanto a conversão de um ano",
             "informa sobre a do ano seguinte. É a segunda coluna que",
             "responde à pergunta de interesse, e nela a dependência é",
             "bem mais modesta."))) +
    theme(strip.text.y.left = element_text(angle = 0, size = 8),
          strip.placement = "outside")

salvar_fig(f22, "Fig_22_acf_estoque_e_fluxo", 10, 11)

######@> Figura 23 - PACF das séries em primeira diferença...
dados_f23 <- correlogramas_litoral %>%
    filter(tipo == "PACF", versao == "1ª diferença (fluxo)")

f23 <- ggplot(dados_f23, aes(x = lag, y = valor)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_hline(aes(yintercept = ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_hline(aes(yintercept = -ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_segment(aes(xend = lag, yend = 0), linewidth = 0.6,
                 colour = "grey25") +
    geom_point(size = 1.1, colour = "grey15") +
    facet_wrap(~ serie, ncol = 3) +
    labs(title = "Autocorrelação parcial da taxa anual de conversão",
         subtitle = "Séries do litoral em primeira diferença",
         x = "Defasagem (anos)", y = "PACF",
         caption = quebrar(paste(
             "A PACF isola a contribuição de cada defasagem, descontado",
             "o efeito das anteriores. Onde apenas o primeiro bastão",
             "ultrapassa o limite de significância, um termo",
             "autorregressivo de ordem 1 sobre a série de fluxo é",
             "suficiente - estruturas mais elaboradas não encontram",
             "respaldo em 39 diferenças anuais.")))

salvar_fig(f23, "Fig_23_pacf_do_fluxo", 12, 7)

######@> A mesma comparação, município a município...
## O que vale para o agregado precisa valer para as unidades, sob pena
## de a conclusão ser um artefato da agregação.
acf_municipal <- mun_n1 %>%
    group_by(geocodigo, municipio, classe) %>%
    arrange(ano) %>%
    summarise(acf1_nivel = if(sd(area_pct) > 0)
                  as.numeric(acf(area_pct, lag.max = 1,
                                 plot = FALSE)$acf[2]) else NA_real_,
              acf1_dif = if(sd(diff(area_pct)) > 0)
                  as.numeric(acf(diff(area_pct), lag.max = 1,
                                 plot = FALSE)$acf[2]) else NA_real_,
              .groups = "drop")

resumo_acf <- acf_municipal %>%
    group_by(classe) %>%
    summarise(acf1_nivel_medio = mean(acf1_nivel, na.rm = TRUE),
              acf1_dif_medio = mean(acf1_dif, na.rm = TRUE),
              queda = mean(acf1_nivel, na.rm = TRUE) -
                  mean(acf1_dif, na.rm = TRUE),
              .groups = "drop")

tabelas[["Tab_28_acf_municipal"]] <- salvar_tab(
    acf_municipal %>% arrange(classe, desc(acf1_nivel)),
    "Tab_28_autocorrelacao_municipal")

message("\nACF(1) média por classe (nível -> 1ª diferença):")
print(as.data.frame(resumo_acf %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 3)))), right = FALSE)

######@> Figura 24 - a queda da autocorrelação ao diferenciar...
## Séries municipais sem variabilidade alguma (uma classe ausente do
## município nos 40 anos) não têm ACF definida. São removidas aqui, e
## não silenciosamente descartadas pelo ggplot, para que a contagem
## apareça na legenda da figura.
n_acf_indefinida <- sum(is.na(acf_municipal$acf1_nivel) |
                        is.na(acf_municipal$acf1_dif))

dados_f24 <- acf_municipal %>%
    filter(!is.na(acf1_nivel), !is.na(acf1_dif)) %>%
    pivot_longer(c(acf1_nivel, acf1_dif), names_to = "versao",
                 values_to = "acf1") %>%
    mutate(versao = ifelse(versao == "acf1_nivel", "Nível (estoque)",
                           "1ª diferença (fluxo)"),
           versao = factor(versao, levels = c("Nível (estoque)",
                                              "1ª diferença (fluxo)")))

f24 <- ggplot(dados_f24, aes(x = versao, y = acf1, fill = versao)) +
    geom_hline(yintercept = 0, colour = "grey60") +
    geom_boxplot(width = 0.55, outlier.size = 0.7, alpha = 0.75,
                 linewidth = 0.35) +
    geom_line(aes(group = interaction(geocodigo, classe)),
              colour = "grey60", alpha = 0.3, linewidth = 0.25) +
    facet_wrap(~ classe, ncol = 5) +
    scale_fill_manual(values = c("Nível (estoque)" = "#D55E00",
                                 "1ª diferença (fluxo)" = "#0072B2"),
                      guide = "none") +
    labs(title = "Diferenciar remove a autocorrelação de construção",
         subtitle = paste("Autocorrelação de defasagem 1 das séries",
                          "municipais, por classe de nível 1"),
         x = NULL, y = "ACF(1)",
         caption = quebrar(paste(
             "Cada linha cinza é um município. A queda é sistemática e",
             "vale em todas as classes: o que resta depois de",
             "diferenciar é a dependência real do processo de",
             "conversão, e ela é pequena - compatível com um termo",
             "autorregressivo de ordem baixa, e não com memória",
             "longa.",
             ifelse(n_acf_indefinida > 0,
                    paste(n_acf_indefinida, "séries municipais sem",
                          "variabilidade foram omitidas."), "")))) +
    theme(axis.text.x = element_text(angle = 20, hjust = 1, size = 8))

salvar_fig(f24, "Fig_24_queda_da_autocorrelacao", 13, 6)

######@> Decomposição em tendência e resíduo...
## Sem componente sazonal a decompor, a pergunta que resta é quanto da
## variância de cada série é explicada por sua tendência de longo
## prazo. Força próxima de 1 indica série dominada pela tendência -
## caso da área urbanizada; força baixa indica série dominada por
## flutuação de curto prazo.
forca_litoral <- map_dfr(ordem_series, function(s) {
    d <- series_litoral %>% filter(serie == s)
    decompor_tendencia(d$valor, d$ano) %>% mutate(serie = s, .before = 1)
})

forca_municipal <- mun_n1 %>%
    group_by(geocodigo, municipio, classe) %>%
    group_modify(~ decompor_tendencia(.x$area_pct, .x$ano)) %>%
    ungroup()

tabelas[["Tab_29_forca_tendencia"]] <- salvar_tab(
    forca_municipal %>% arrange(classe, desc(forca_tendencia)),
    "Tab_29_forca_da_tendencia_municipal")

######@> Figura 25 - quanta da variância é tendência...
dados_f25a <- series_litoral %>%
    filter(serie %in% ordem_classes_n1) %>%
    mutate(serie = factor(serie, levels = ordem_classes_n1))

tendencias_loess <- dados_f25a %>%
    group_by(serie) %>%
    group_modify(~ tibble(ano = .x$ano,
                          ajuste = predict(loess(valor ~ ano,
                                                 data = .x,
                                                 span = 0.5,
                                                 degree = 1)))) %>%
    ungroup()

g25a <- ggplot(dados_f25a, aes(x = ano, y = valor)) +
    geom_line(colour = "grey55", linewidth = 0.5) +
    geom_line(data = tendencias_loess, aes(x = ano, y = ajuste,
                                           colour = serie),
              linewidth = 1) +
    facet_wrap(~ serie, scales = "free_y", ncol = 5) +
    scale_colour_manual(values = cores_classe, guide = "none") +
    scale_x_continuous(breaks = seq(ano_ini, ano_fim, 15)) +
    labs(subtitle = "Série do litoral e sua tendência (loess)",
         x = NULL, y = "% da área")

g25b <- forca_municipal %>%
    filter(!is.na(forca_tendencia)) %>%
    ggplot(aes(x = classe, y = forca_tendencia, fill = classe)) +
    geom_boxplot(width = 0.6, outlier.size = 0.7, alpha = 0.8,
                 linewidth = 0.35) +
    geom_point(data = forca_litoral %>%
                   filter(serie %in% ordem_classes_n1) %>%
                   mutate(classe = factor(serie,
                                          levels = ordem_classes_n1)),
               aes(x = classe, y = forca_tendencia), inherit.aes = FALSE,
               shape = 23, size = 2.6, fill = "white",
               colour = "grey15") +
    scale_fill_manual(values = cores_classe, guide = "none") +
    scale_x_discrete(labels = quebrar_rotulo) +
    labs(subtitle = paste("Força da tendência por município",
                          "(losango: conjunto do litoral)"),
         x = NULL, y = "Força da tendência")

f25 <- (g25a / g25b) +
    plot_annotation(
        title = "Quanto de cada série é tendência de longo prazo",
        subtitle = paste("Decomposição em tendência (loess) e resíduo;",
                         "medida de Wang, Smith e Hyndman"),
        caption = quebrar(paste(
            "A força vale 0 quando a tendência não explica nada da",
            "variância e tende a 1 quando ela domina. Séries dominadas",
            "pela tendência são bem resumidas por um termo de",
            "inclinação; séries de força baixa exigem que a flutuação",
            "de curto prazo seja modelada, e não apenas descontada. O",
            "losango marca o valor do agregado do litoral, quase sempre",
            "maior que o do município típico - a agregação cancela",
            "flutuações locais e realça a tendência comum.")))

salvar_fig(f25, "Fig_25_forca_da_tendencia", 13, 9)

########################################################################
######@> Etapa 12 - Tendência: Mann-Kendall e declividade de Sen...

######@> Tendência das séries do litoral...
tendencia_litoral <- map_dfr(ordem_series, function(s) {
    d <- series_litoral %>% filter(serie == s) %>% arrange(ano)
    mk <- mann_kendall(d$valor)
    sen <- declividade_sen(d$valor, d$ano)
    tibble(serie = s,
           unidade = ifelse(grepl("ha", s), "ha", "% da área"),
           valor_ini = first(d$valor),
           valor_fim = last(d$valor),
           tau = mk$tau, p_valor = mk$p_valor,
           sen_por_ano = sen,
           sen_por_decada = 10 * sen,
           variacao_periodo = sen * (ano_fim - ano_ini))
}) %>%
    mutate(resultado = case_when(
               is.na(p_valor) ~ "Indefinido",
               p_valor >= alfa ~ "Sem tendência detectada",
               tau > 0 ~ "Crescente",
               TRUE ~ "Decrescente"))

######@> Tendência das classes de nível 2 com área relevante...
tendencia_n2 <- litoral_n2 %>%
    filter(classe %in% classes_n2_relevantes) %>%
    group_by(classe_pai, classe) %>%
    group_modify(~ {
        mk <- mann_kendall(.x$area_ha)
        tibble(tau = mk$tau, p_valor = mk$p_valor,
               sen_ha_ano = declividade_sen(.x$area_ha, .x$ano),
               area_ini = .x$area_ha[which.min(.x$ano)],
               area_fim = .x$area_ha[which.max(.x$ano)])
    }) %>%
    ungroup() %>%
    mutate(variacao_pct = 100 * (area_fim - area_ini) / area_ini,
           resultado = case_when(
               is.na(p_valor) ~ "Indefinido",
               p_valor >= alfa ~ "Sem tendência detectada",
               tau > 0 ~ "Crescente",
               TRUE ~ "Decrescente")) %>%
    arrange(desc(abs(sen_ha_ano)))

tabelas[["Tab_30_tendencia_litoral"]] <- salvar_tab(
    tendencia_litoral, "Tab_30_tendencia_do_litoral")
tabelas[["Tab_31_tendencia_nivel2"]] <- salvar_tab(
    tendencia_n2, "Tab_31_tendencia_classes_nivel_2")

message("\n--- Tendência no conjunto do litoral ---")
print(as.data.frame(tendencia_litoral %>%
                    select(serie, tau, p_valor, sen_por_decada,
                           resultado) %>%
                    mutate(tau = round(tau, 3),
                           p_valor = signif(p_valor, 3),
                           sen_por_decada = round(sen_por_decada, 3))),
      right = FALSE)

######@> Tendência município a município...
tendencia_municipal <- mun_n1 %>%
    group_by(geocodigo, municipio, classe) %>%
    group_modify(~ {
        mk <- mann_kendall(.x$area_pct)
        tibble(tau = mk$tau, p_valor = mk$p_valor,
               sen_pp_decada = 10 * declividade_sen(.x$area_pct,
                                                    .x$ano))
    }) %>%
    ungroup() %>%
    mutate(significativa = !is.na(p_valor) & p_valor < alfa,
           resultado = case_when(
               is.na(p_valor) ~ "Indefinido",
               p_valor >= alfa ~ "Sem tendência detectada",
               tau > 0 ~ "Crescente",
               TRUE ~ "Decrescente"))

tabelas[["Tab_32_tendencia_municipal"]] <- salvar_tab(
    tendencia_municipal %>% arrange(classe, sen_pp_decada),
    "Tab_32_tendencia_municipal")

resumo_tendencia <- tendencia_municipal %>%
    group_by(classe) %>%
    summarise(crescentes = sum(resultado == "Crescente"),
              decrescentes = sum(resultado == "Decrescente"),
              sem_tendencia = sum(resultado == "Sem tendência detectada"),
              .groups = "drop")

message("\nTendência municipal por classe:")
print(as.data.frame(resumo_tendencia), right = FALSE)

######@> Figura 26 - tendência de cada série do litoral...
dados_f26 <- tendencia_litoral %>%
    mutate(rotulo = factor(serie, levels = rev(ordem_series)),
           destaque = resultado != "Sem tendência detectada")

## O eixo é o TAU de Kendall, e não a declividade de Sen: as séries
## estão em unidades diferentes (pontos percentuais da área para as
## classes, hectares para a mancha urbana) e o comprimento das barras
## de Sen não seria comparável - a urbanização, medida em hectares,
## reduziria todas as demais a um traço. A magnitude com sua unidade
## aparece como rótulo ao lado de cada barra.
f26 <- ggplot(dados_f26, aes(x = tau, y = rotulo, fill = resultado)) +
    geom_col(width = 0.7) +
    geom_vline(xintercept = 0, colour = "grey30") +
    geom_text(aes(label = paste0(ifelse(sen_por_decada > 0, "+", ""),
                                 ifelse(abs(sen_por_decada) >= 100,
                                        fmt_int(sen_por_decada),
                                        sprintf("%.2f", sen_por_decada)),
                                 " ", unidade, "/década",
                                 ifelse(p_valor < alfa, " *", ""))),
              hjust = ifelse(dados_f26$tau > 0, -0.08, 1.08),
              size = 3, colour = "grey25") +
    scale_fill_manual(values = c("Crescente" = "#D55E00",
                                 "Decrescente" = "#0072B2",
                                 "Sem tendência detectada" = "grey70"),
                      name = NULL) +
    scale_x_continuous(limits = c(-1.9, 1.9),
                       breaks = seq(-1, 1, 0.5)) +
    labs(title = "Tendência das séries do litoral",
         subtitle = paste("Tau de Mann-Kendall; o rótulo traz a",
                          "declividade de Sen na unidade da série"),
         x = "Tau de Kendall", y = NULL,
         caption = quebrar(paste(
             "O tau mede a consistência da tendência (de -1 a +1) e é",
             "comparável entre séries de unidades diferentes; a",
             "declividade de Sen mede sua magnitude e não é - por isso",
             "ela aparece como rótulo, e não como comprimento de barra.",
             "A área urbanizada tem tau = 1: cresceu em TODOS os pares",
             "de anos comparados, sem uma única reversão em quarenta",
             "anos. O asterisco marca significância a 5%.")))

salvar_fig(f26, "Fig_26_tendencia_do_litoral", 11, 6)

######@> Figura 27 - onde cada classe cresce e onde encolhe...
dados_f27 <- tendencia_municipal %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_mun_f02)),
           rotulo = ifelse(significativa, "*", ""))

limite_f27 <- max(abs(dados_f27$sen_pp_decada), na.rm = TRUE)

f27 <- ggplot(dados_f27, aes(x = classe, y = municipio,
                             fill = sen_pp_decada)) +
    geom_tile(colour = "white", linewidth = 0.3) +
    geom_text(aes(label = rotulo), size = 3, colour = "grey15",
              vjust = 0.75) +
    scale_fill_gradient2(low = "#8C510A", mid = "grey96",
                         high = "#01665E", midpoint = 0,
                         limits = c(-limite_f27, limite_f27),
                         name = "Sen (p.p. por década)") +
    scale_x_discrete(labels = quebrar_rotulo) +
    labs(title = "Tendência de cada classe em cada município",
         subtitle = paste("Declividade de Sen em pontos percentuais",
                          "por década; * = Mann-Kendall significativo"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Municípios ordenados de norte (topo) a sul. O SENTIDO da",
             "tendência florestal é regionalmente organizado - perda",
             "concentrada no terço norte, ganho em vários municípios do",
             "sul e do centro -, mas a MAGNITUDE varia muito entre",
             "vizinhos e há reversões de sinal dentro de cada trecho.",
             "Um termo de tendência comum a todos os municípios, como o",
             "que a AED do ERA5 recomendou para a temperatura, seria",
             "aqui uma simplificação grosseira."))) +
    theme(axis.text.y = element_text(size = 7),
          axis.text.x = element_text(size = 8),
          legend.key.width = unit(1.4, "cm"))

salvar_fig(f27, "Fig_27_tendencia_municipal", 10, 9)

########################################################################
######@> Etapa 13 - Estrutura entre classes e redundância espacial...

######@> Matriz composicional...
## Uma linha por município-ano, uma coluna por classe de nível 1. É
## sobre ela que se calculam as duas versões da matriz de correlação: a
## ingênua, sobre os percentuais, e a correta, sobre a transformação
## log-razão centrada.
matriz_composicao <- mun_n1 %>%
    select(geocodigo, ano, classe, area_pct) %>%
    pivot_wider(names_from = classe, values_from = area_pct) %>%
    arrange(geocodigo, ano)

mat_pct <- as.matrix(matriz_composicao[, ordem_classes_n1])
mat_clr <- transformar_clr(mat_pct)

cor_bruta <- cor(mat_pct)
cor_clr <- cor(mat_clr)

######@> Comparação entre as duas leituras...
## A pergunta prática: alguma conclusão muda ao corrigir o fechamento?
## Onde os dois coeficientes têm sinais opostos, a correlação bruta é
## artefato; onde concordam, a associação sobrevive à correção.
comparacao_correlacao <- expand.grid(classe_a = ordem_classes_n1,
                                     classe_b = ordem_classes_n1,
                                     stringsAsFactors = FALSE) %>%
    filter(classe_a < classe_b) %>%
    mutate(cor_bruta = map2_dbl(classe_a, classe_b,
                                ~ cor_bruta[.x, .y]),
           cor_clr = map2_dbl(classe_a, classe_b, ~ cor_clr[.x, .y]),
           diferenca = cor_clr - cor_bruta,
           muda_de_sinal = sign(cor_bruta) != sign(cor_clr)) %>%
    arrange(desc(abs(diferenca)))

tabelas[["Tab_33_correlacao_classes"]] <- salvar_tab(
    comparacao_correlacao, "Tab_33_correlacao_entre_classes")

message("\nCorrelação entre classes: ", sum(comparacao_correlacao$muda_de_sinal),
        " de ", nrow(comparacao_correlacao),
        " pares mudam de sinal ao corrigir o fechamento")

######@> Figura 28 - correlação ingênua e correlação corrigida...
preparar_matriz <- function(m, rotulo) {
    as.data.frame(as.table(m)) %>%
        setNames(c("classe_a", "classe_b", "correlacao")) %>%
        mutate(versao = rotulo)
}

dados_f28 <- bind_rows(
    preparar_matriz(cor_bruta, "Percentuais (composição fechada)"),
    preparar_matriz(cor_clr, "Log-razão centrada (CLR)")) %>%
    mutate(versao = factor(versao,
                           levels = c("Percentuais (composição fechada)",
                                      "Log-razão centrada (CLR)")),
           classe_a = factor(classe_a, levels = ordem_classes_n1),
           classe_b = factor(classe_b, levels = rev(ordem_classes_n1)))

f28 <- ggplot(dados_f28, aes(x = classe_a, y = classe_b,
                             fill = correlacao)) +
    geom_tile(colour = "white", linewidth = 0.4) +
    geom_text(aes(label = sprintf("%.2f", correlacao)), size = 2.7,
              colour = "grey15") +
    facet_wrap(~ versao, ncol = 2) +
    scale_fill_gradient2(low = "#B2182B", mid = "grey96",
                         high = "#2166AC", midpoint = 0,
                         limits = c(-1, 1), name = "Correlação") +
    scale_x_discrete(labels = quebrar_rotulo) +
    scale_y_discrete(labels = quebrar_rotulo) +
    labs(title = "A correlação entre classes precisa ser corrigida",
         subtitle = paste("Todos os pares município-ano;",
                          "à esquerda os percentuais, à direita a",
                          "transformação log-razão centrada"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Como as cinco classes somam 100%, o crescimento de uma",
             "obriga a queda das demais e a correlação bruta é",
             "parcialmente IMPOSTA - não observada. A transformação CLR",
             "leva a composição para o espaço real, onde a correlação",
             "recupera sua interpretação usual. Os pares cujo",
             "coeficiente muda de sinal entre os dois painéis são",
             "aqueles em que a leitura ingênua levaria a conclusão",
             "errada."))) +
    theme(axis.text.x = element_text(size = 7),
          axis.text.y = element_text(size = 7),
          legend.key.width = unit(1.4, "cm"))

salvar_fig(f28, "Fig_28_correlacao_entre_classes", 13, 7)

######@> Dimensionalidade da composição...
## Quantos eixos independentes descrevem a paisagem de um município?
## A PCA é feita sobre o CLR das composições MÉDIAS municipais - ou
## seja, sobre a variação ENTRE municípios, que é a que interessa para
## decidir quantos descritores espaciais o modelo precisa.
composicao_media <- mun_n1 %>%
    group_by(geocodigo, municipio, classe) %>%
    summarise(area_pct = mean(area_pct), .groups = "drop") %>%
    pivot_wider(names_from = classe, values_from = area_pct)

clr_medias <- transformar_clr(
    as.matrix(composicao_media[, ordem_classes_n1]))
rownames(clr_medias) <- composicao_media$municipio

pca_composicao <- prcomp(clr_medias, center = TRUE, scale. = FALSE)
variancia_pca <- 100 * summary(pca_composicao)$importance[2, ]

dimensionalidade_composicao <- tibble(
    componente = names(variancia_pca),
    variancia_explicada = as.numeric(variancia_pca),
    acumulada = cumsum(as.numeric(variancia_pca)))

tabelas[["Tab_34_pca_composicao"]] <- salvar_tab(
    dimensionalidade_composicao, "Tab_34_pca_da_composicao")

message("PCA da composição      : PC1 = ",
        sprintf("%.1f", variancia_pca[1]), "%, PC1+PC2 = ",
        sprintf("%.1f", sum(variancia_pca[1:2])), "%")

######@> Redundância espacial: quantas séries independentes existem?
## A mesma pergunta que a AED do ERA5 fez sobre o clima, feita agora
## sobre a paisagem - e com resposta oposta. Para cada classe, mede-se
## a correlação entre as séries municipais e a dimensionalidade
## efetiva do conjunto, nas duas versões (nível e primeira diferença).
##
## A versão em NÍVEL é enganosa aqui: municípios com composições
## parecidas terão séries parecidas mesmo que suas trajetórias sejam
## independentes. É a versão em DIFERENÇA que responde se os
## municípios se transformam JUNTOS.
calcular_redundancia <- function(dados, coluna_valor, rotulo) {
    largo <- dados %>%
        select(geocodigo, ano, valor = all_of(coluna_valor)) %>%
        pivot_wider(names_from = geocodigo, values_from = valor) %>%
        arrange(ano)
    mat <- as.matrix(largo[, -1])
    mat <- mat[, apply(mat, 2, function(x) sd(x, na.rm = TRUE) > 0),
               drop = FALSE]
    if(ncol(mat) < 3) return(NULL)
    dif <- apply(mat, 2, diff)
    dif <- dif[, apply(dif, 2, function(x) sd(x, na.rm = TRUE) > 0),
               drop = FALSE]
    resumo_versao <- function(m, versao) {
        cm <- cor(m)
        pca <- prcomp(scale(m))
        prop <- summary(pca)$importance[2, ]
        tibble(serie = rotulo, versao = versao,
               n_municipios = ncol(m),
               cor_mediana = median(cm[upper.tri(cm)]),
               cor_maxima = max(cm[upper.tri(cm)]),
               pc1_pct = 100 * prop[1],
               componentes_95 = which(cumsum(prop) >= 0.95)[1])
    }
    bind_rows(resumo_versao(mat, "Nível (estoque)"),
              resumo_versao(dif, "1ª diferença (fluxo)"))
}

redundancia <- bind_rows(
    map_dfr(ordem_classes_n1, function(cl) {
        calcular_redundancia(mun_n1 %>% filter(classe == cl),
                             "area_pct", cl)
    }),
    calcular_redundancia(urb_mun, "area_ha", "Área urbanizada (ha)")) %>%
    mutate(serie = factor(serie, levels = ordem_series),
           versao = factor(versao, levels = c("Nível (estoque)",
                                              "1ª diferença (fluxo)")))

tabelas[["Tab_35_redundancia_espacial"]] <- salvar_tab(
    redundancia, "Tab_35_redundancia_espacial")

message("\n--- Redundância espacial entre municípios ---")
print(as.data.frame(redundancia %>%
                    mutate(cor_mediana = round(cor_mediana, 3),
                           pc1_pct = round(pc1_pct, 1))),
      right = FALSE)

######@> Figura 29 - dimensionalidade efetiva da paisagem...
g29a <- ggplot(redundancia, aes(x = serie, y = pc1_pct,
                                fill = versao)) +
    geom_col(position = position_dodge(width = 0.75), width = 0.7) +
    geom_hline(yintercept = 96.5, linetype = "dashed",
               colour = "#D55E00") +
    annotate("text", x = 0.7, y = 93,
             label = "ERA5: PC1 da temperatura = 96,5%", size = 2.8,
             colour = "#D55E00", hjust = 0) +
    scale_fill_manual(values = c("Nível (estoque)" = "#E69F00",
                                 "1ª diferença (fluxo)" = "#0072B2"),
                      name = NULL) +
    scale_x_discrete(labels = quebrar_rotulo) +
    scale_y_continuous(limits = c(0, 100)) +
    labs(subtitle = "Variância explicada pelo primeiro componente",
         x = NULL, y = "PC1 (%)")

g29b <- ggplot(redundancia, aes(x = serie, y = componentes_95,
                                fill = versao)) +
    geom_col(position = position_dodge(width = 0.75), width = 0.7) +
    geom_hline(yintercept = n_municipios, linetype = "dotted",
               colour = "grey40") +
    annotate("text", x = 0.7, y = n_municipios - 1.6,
             label = paste("máximo possível:", n_municipios,
                           "componentes"),
             size = 2.8, colour = "grey40", hjust = 0) +
    scale_fill_manual(values = c("Nível (estoque)" = "#E69F00",
                                 "1ª diferença (fluxo)" = "#0072B2"),
                      guide = "none") +
    scale_x_discrete(labels = quebrar_rotulo) +
    labs(subtitle = paste("Componentes necessários para 95% da",
                          "variância"),
         x = NULL, y = "Componentes")

f29 <- (g29a / g29b) +
    plot_layout(guides = "collect") +
    plot_annotation(
        title = "Os municípios não são redundantes",
        subtitle = paste0("Dimensionalidade efetiva das ",
                          n_municipios, " séries municipais, por ",
                          "classe"),
        caption = quebrar(paste(
            "A linha tracejada marca o resultado da AED do ERA5, em que",
            "um único componente explicava 96,5% da variância das",
            "anomalias térmicas municipais e efeitos espaciais livres",
            "não se justificavam. A série de área urbanizada em NÍVEL",
            "alcança exatamente o mesmo patamar - e é justamente o",
            "exemplo do engano: todas as manchas urbanas crescem",
            "monotonicamente, e uma tendência comum basta para",
            "sincronizá-las sem que haja qualquer sincronia no processo.",
            "Ao passar para o FLUXO, o mesmo conjunto de séries cai para",
            "21% no primeiro componente e exige 19 componentes para 95%",
            "da variância. A transformação da paisagem é um processo",
            "local, e cada município carrega informação própria."))) &
    theme(legend.position = "bottom")

salvar_fig(f29, "Fig_29_dimensionalidade_efetiva", 12, 9)

######@> Correlação entre municípios contra distância...
## Se a semelhança entre municípios decaísse com a distância,
## haveria estrutura espacial contínua a modelar. O gráfico responde
## se isso ocorre - e para qual das duas versões da série.
pares_municipios <- function(dados, coluna_valor, rotulo) {
    largo <- dados %>%
        select(geocodigo, ano, valor = all_of(coluna_valor)) %>%
        pivot_wider(names_from = geocodigo, values_from = valor) %>%
        arrange(ano)
    mat <- as.matrix(largo[, -1])
    dif <- apply(mat, 2, diff)
    cm_nivel <- cor(mat)
    cm_dif <- cor(dif)
    codigos <- colnames(mat)
    combinacoes <- t(combn(seq_along(codigos), 2))
    tibble(serie = rotulo,
           geo_a = codigos[combinacoes[, 1]],
           geo_b = codigos[combinacoes[, 2]],
           cor_nivel = cm_nivel[combinacoes],
           cor_dif = cm_dif[combinacoes]) %>%
        mutate(distancia_km = as.numeric(
                   dist_matriz[cbind(geo_a, geo_b)]) / 1000)
}

pares_floresta <- pares_municipios(
    mun_n1 %>% filter(classe == "Floresta"), "area_pct", "Floresta")
pares_urbano <- pares_municipios(urb_mun, "area_ha",
                                 "Área urbanizada")

pares <- bind_rows(pares_floresta, pares_urbano) %>%
    pivot_longer(c(cor_nivel, cor_dif), names_to = "versao",
                 values_to = "correlacao") %>%
    mutate(versao = ifelse(versao == "cor_nivel", "Nível (estoque)",
                           "1ª diferença (fluxo)"),
           versao = factor(versao, levels = c("Nível (estoque)",
                                              "1ª diferença (fluxo)")))

decaimento <- pares %>%
    group_by(serie, versao) %>%
    summarise(cor_com_distancia = cor(correlacao, distancia_km,
                                      method = "spearman"),
              correlacao_mediana = median(correlacao),
              .groups = "drop")

tabelas[["Tab_36_correlacao_distancia"]] <- salvar_tab(
    decaimento, "Tab_36_correlacao_contra_distancia")

######@> Figura 30 - a semelhança decai com a distância?
f30 <- ggplot(pares, aes(x = distancia_km, y = correlacao)) +
    geom_hline(yintercept = 0, colour = "grey60", linewidth = 0.3) +
    geom_point(alpha = 0.25, size = 0.8, colour = "#0072B2") +
    geom_smooth(method = "loess", formula = y ~ x, se = TRUE,
                colour = "#D55E00", fill = "#D55E00", alpha = 0.15,
                linewidth = 0.7, span = 0.9) +
    facet_grid(serie ~ versao) +
    labs(title = "Semelhança entre municípios e distância geográfica",
         subtitle = paste("Cada ponto é um par de municípios;",
                          "correlação das séries de 40 anos"),
         x = "Distância entre centroides (km)",
         y = "Correlação entre as séries",
         caption = quebrar(paste(
             "No NÍVEL, pares de municípios próximos tendem a ser mais",
             "parecidos - efeito de composições semelhantes, e não de",
             "trajetórias sincronizadas. No FLUXO, a nuvem se achata em",
             "torno de zero e o decaimento com a distância praticamente",
             "desaparece: a conversão de um ano em um município diz",
             "pouco sobre o que ocorreu no vizinho no mesmo ano. É a",
             "assinatura de um processo governado por decisões locais.")))

salvar_fig(f30, "Fig_30_correlacao_contra_distancia", 11, 8)

########################################################################
######@> Etapa 14 - Padrões espaciais: mapas e autocorrelação...

######@> Classe predominante de cada município...
classe_predominante <- mun_n1 %>%
    filter(ano == ano_fim) %>%
    group_by(geocodigo) %>%
    slice_max(area_pct, n = 1, with_ties = FALSE) %>%
    ungroup() %>%
    select(geocodigo, classe_predominante = classe,
           pct_predominante = area_pct)

######@> Junção dos indicadores ao shapefile...
mapa_dados <- municipios_sf %>%
    left_join(perfil_municipio %>%
                  select(geocodigo, pct_Floresta = `pct_Floresta`,
                         pct_nao_vegetada = `pct_Área Não Vegetada`,
                         delta_floresta = `delta_Floresta`,
                         delta_nao_vegetada = `delta_Área Não Vegetada`,
                         urb_pct_area, urb_multiplicador,
                         urb_taxa_ha_ano, pct_sem_mudanca,
                         pct_area_agua),
              by = "geocodigo") %>%
    left_join(classe_predominante, by = "geocodigo") %>%
    left_join(tendencia_municipal %>%
                  filter(classe == "Floresta") %>%
                  select(geocodigo, tau_floresta = tau,
                         sen_floresta = sen_pp_decada,
                         p_floresta = p_valor),
              by = "geocodigo") %>%
    left_join(correlacao_intra %>%
                  select(geocodigo, pct_suscetivel_fim),
              by = "geocodigo")

######@> Função de mapa coroplético contínuo...
## Centralizada para que todos os mapas compartilhem projeção, tema e
## tratamento dos municípios sem dados.
mapa_base <- function(dados, variavel, titulo, subtitulo, legenda,
                      paleta = "viridis", direcao = -1,
                      caption = NULL, transformacao = "identity") {
    ggplot(dados) +
        geom_sf(aes(fill = .data[[variavel]]), colour = "grey30",
                linewidth = 0.2) +
        scale_fill_viridis_c(option = paleta, direction = direcao,
                             name = legenda, na.value = "grey85",
                             trans = transformacao) +
        labs(title = titulo, subtitle = subtitulo, caption = caption) +
        theme_void(base_size = 11) +
        theme(plot.title = element_text(face = "bold", size = 13),
              plot.subtitle = element_text(colour = "grey30", size = 10),
              plot.caption = element_text(colour = "grey45", size = 8,
                                          hjust = 0),
              legend.position = "right")
}

######@> Função de mapa coroplético divergente...
## Usada nas variáveis de VARIAÇÃO, em que o zero é uma referência
## substantiva (ganhou ou perdeu) e uma escala sequencial esconderia
## justamente essa distinção.
mapa_divergente <- function(dados, variavel, titulo, subtitulo,
                            legenda, caption = NULL) {
    limite <- max(abs(dados[[variavel]]), na.rm = TRUE)
    ggplot(dados) +
        geom_sf(aes(fill = .data[[variavel]]), colour = "grey30",
                linewidth = 0.2) +
        scale_fill_gradient2(low = "#8C510A", mid = "grey96",
                             high = "#01665E", midpoint = 0,
                             limits = c(-limite, limite),
                             name = legenda, na.value = "grey85") +
        labs(title = titulo, subtitle = subtitulo, caption = caption) +
        theme_void(base_size = 11) +
        theme(plot.title = element_text(face = "bold", size = 13),
              plot.subtitle = element_text(colour = "grey30", size = 10),
              plot.caption = element_text(colour = "grey45", size = 8,
                                          hjust = 0),
              legend.position = "right")
}

######@> Mapa 01 - cobertura florestal atual...
m1 <- mapa_base(mapa_dados, "pct_Floresta",
                "Cobertura florestal",
                paste0("Percentual da área do município em ", ano_fim),
                "% da área", paleta = "viridis",
                caption = quebrar_mapa(paste(
                    "Em cinza: Camboriú e Paulo Lopes, sem dados no",
                    "MapBiomas. A cobertura florestal cresce",
                    "sistematicamente para o norte (correlação de",
                    "Spearman de 0,78 com a latitude) e a agropecuária,",
                    "para o sul: em 20 dos 35 municípios a classe",
                    "predominante é a agropecuária, e nos 15 restantes,",
                    "a floresta.")))

salvar_fig(m1, "Mapa_01_cobertura_florestal", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 02 - variação da cobertura florestal...
m2 <- mapa_divergente(mapa_dados, "delta_floresta",
                      "Variação da cobertura florestal",
                      paste0("Pontos percentuais da área municipal, ",
                             ano_ini, "-", ano_fim),
                      "p.p.",
                      caption = quebrar_mapa(paste(
                          "Verde: ganho de floresta; marrom: perda. A",
                          "perda concentra-se no terço NORTE do",
                          "litoral, no entorno da conurbação",
                          "Joinville-Itajaí, e o índice de Moran",
                          "confirma o agrupamento (I = 0,63; p <",
                          "0,001). O resultado de 40 anos é, portanto,",
                          "espacialmente estruturado - o que NÃO",
                          "contradiz a Etapa 13: lá o que se mostra",
                          "independente entre municípios é a conversão",
                          "ANO A ANO, não o saldo do período.")))

salvar_fig(m2, "Mapa_02_variacao_florestal", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 03 - mancha urbana atual...
m3 <- mapa_base(mapa_dados, "urb_pct_area",
                "Mancha urbana",
                paste0("Percentual da área do município urbanizado em ",
                       ano_fim),
                "% da área", paleta = "inferno", direcao = -1,
                caption = quebrar_mapa(paste(
                    "Os municípios de balneário têm as maiores frações",
                    "urbanizadas do litoral, ainda que suas manchas",
                    "urbanas sejam pequenas em hectares: são municípios",
                    "de área reduzida e ocupação concentrada na faixa",
                    "costeira.")))

salvar_fig(m3, "Mapa_03_mancha_urbana", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 04 - intensidade da expansão urbana...
m4 <- mapa_base(mapa_dados, "urb_multiplicador",
                "Expansão da mancha urbana",
                paste0("Quantas vezes a área urbanizada se multiplicou, ",
                       ano_ini, "-", ano_fim),
                "Vezes", paleta = "magma", direcao = -1,
                transformacao = "log10",
                caption = quebrar_mapa(paste(
                    "A escala é logarítmica. O padrão é quase inverso",
                    "ao do Mapa 03: os municípios que mais multiplicaram",
                    "sua mancha urbana são os que partiram de uma base",
                    "pequena, e não os que hoje têm maior fração",
                    "urbanizada.")))

salvar_fig(m4, "Mapa_04_expansao_urbana", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 05 - classe predominante...
m5 <- ggplot(mapa_dados) +
    geom_sf(aes(fill = classe_predominante), colour = "grey30",
            linewidth = 0.2) +
    scale_fill_manual(values = cores_classe, na.value = "grey85",
                      name = "Classe predominante", drop = FALSE) +
    labs(title = "Classe de uso e cobertura predominante",
         subtitle = paste("Classe de nível 1 com maior área em",
                          ano_fim),
         caption = quebrar_mapa(paste(
             "A predominância divide o litoral em dois blocos: 15",
             "municípios em que a floresta ainda responde pela maior",
             "parte da área, concentrados ao norte, e 20 dominados pela",
             "agropecuária. Nenhum município tem a área não vegetada",
             "como classe predominante, apesar de ela ser a classe que",
             "mais cresce - o avanço urbano é grande em taxa e ainda",
             "pequeno em área."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m5, "Mapa_05_classe_predominante", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 06 - exposição urbana à suscetibilidade...
m6 <- mapa_base(mapa_dados, "pct_suscetivel_fim",
                "Exposição urbana a inundação",
                paste0("Percentual da mancha urbana em área suscetível, ",
                       ano_fim),
                "% da mancha urbana", paleta = "rocket", direcao = -1,
                caption = quebrar_mapa(paste(
                    "Em cinza: municípios sem o tema Risco Climático",
                    "(São João do Sul) ou sem dados no MapBiomas. A",
                    "fração exposta normaliza o tamanho do município e",
                    "é, entre os indicadores desta base, o mais",
                    "diretamente comparável às séries de desastre.")))

salvar_fig(m6, "Mapa_06_exposicao_urbana", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Autocorrelação espacial...
## A pergunta: municípios vizinhos se transformam de modo parecido? Uma
## resposta afirmativa significa que as observações NÃO são
## independentes no espaço - o que restringe os modelos possíveis.
##
## A vizinhança é definida por CONTIGUIDADE (critério queen: basta
## compartilhar um ponto de fronteira), natural para municípios. Como o
## litoral é uma FAIXA e não uma malha, a exclusão de Camboriú e Paulo
## Lopes - que existem no território, mas não têm dado - rompe elos da
## cadeia e pode partir o grafo. O índice segue definido, mas passa a
## comparar apenas DENTRO de cada trecho. Por isso o cálculo é repetido
## sob um segundo esquema, de k vizinhos mais próximos, sempre conexo:
## concordância entre os dois indica que o resultado não é artefato dos
## pesos.
mapa_analise <- mapa_dados %>% filter(tem_dados)

vizinhanca <- poly2nb(mapa_analise, queen = TRUE)
componentes <- n.comp.nb(vizinhanca)$nc
sem_vizinho <- sum(card(vizinhanca) == 0)

coords_mun <- suppressWarnings(st_coordinates(st_centroid(mapa_analise)))
vizinhanca_knn <- knn2nb(knearneigh(coords_mun, k = 4))

pesos <- nb2listw(vizinhanca, style = "W", zero.policy = TRUE)
pesos_knn <- nb2listw(vizinhanca_knn, style = "W")

criterio_vizinhanca <- sprintf(
    "Contiguidade (queen): %.2f vizinhos em média, %d componente(s)",
    mean(card(vizinhanca)), componentes)

message("\nVizinhança espacial: ", criterio_vizinhanca)
if(componentes > 1) {
    message("  ATENÇÃO: grafo de contiguidade desconexo (",
            componentes, " trechos), efeito da exclusão de Camboriú e ",
            "Paulo Lopes. Resultados conferidos também com kNN (k = 4).")
}
if(sem_vizinho > 0) {
    warning("Municípios sem vizinho por contiguidade: ", sem_vizinho)
}

######@> Índice de Moran global para vários indicadores...
indicadores_moran <- list(
    c("pct_Floresta", "Cobertura florestal (%)"),
    c("delta_floresta", "Variação da floresta (p.p.)"),
    c("urb_pct_area", "Mancha urbana (% da área)"),
    c("urb_multiplicador", "Multiplicação da mancha urbana"),
    c("pct_sem_mudanca", "Área que nunca mudou (%)"),
    c("pct_suscetivel_fim", "Exposição urbana a inundação (%)"))

testar_moran <- function(x, listw, rotulo, esquema) {
    if(all(is.na(x)) || var(x, na.rm = TRUE) == 0) return(NULL)
    ok <- !is.na(x)
    if(sum(ok) < nrow(mapa_analise)) {
        ## Municípios sem o indicador são substituídos pela média, o
        ## que preserva a estrutura de vizinhança sem inventar padrão
        ## espacial - a alternativa, remover a unidade, quebraria o
        ## grafo em mais trechos ainda.
        x[!ok] <- mean(x, na.rm = TRUE)
    }
    teste <- moran.test(x, listw, zero.policy = TRUE)
    tibble(indicador = rotulo, esquema = esquema,
           moran_i = as.numeric(teste$estimate[1]),
           esperado = as.numeric(teste$estimate[2]),
           p_valor = teste$p.value,
           n_substituidos = sum(!ok))
}

moran_global <- map_dfr(indicadores_moran, function(par) {
    x <- mapa_analise[[par[1]]]
    bind_rows(testar_moran(x, pesos, par[2], "Contiguidade"),
              testar_moran(x, pesos_knn, par[2], "kNN (k = 4)"))
}) %>%
    mutate(resultado = case_when(
               p_valor >= alfa ~ "Sem autocorrelação detectada",
               moran_i > 0 ~ "Agrupamento espacial",
               TRUE ~ "Dispersão espacial"))

concordancia_moran <- moran_global %>%
    select(indicador, esquema, resultado) %>%
    pivot_wider(names_from = esquema, values_from = resultado) %>%
    mutate(concordam = Contiguidade == `kNN (k = 4)`)

tabelas[["Tab_37_moran_global"]] <- salvar_tab(
    moran_global, "Tab_37_moran_global")

message("Moran global           : ",
        sum(moran_global$resultado != "Sem autocorrelação detectada"),
        " de ", nrow(moran_global),
        " testes com autocorrelação significativa | esquemas concordam em ",
        sum(concordancia_moran$concordam), " de ",
        nrow(concordancia_moran), " indicadores")

######@> Moran local (LISA) sobre a variação da floresta...
## O índice global responde "há estrutura espacial?"; o local responde
## "onde". Os agrupamentos são classificados pelo quadrante do diagrama
## de espalhamento de Moran, e apenas os significativos são rotulados.
x_lisa <- mapa_analise$delta_floresta
x_lisa[is.na(x_lisa)] <- mean(x_lisa, na.rm = TRUE)

lisa <- localmoran(x_lisa, pesos, zero.policy = TRUE)
x_padrao <- as.numeric(scale(x_lisa))
defasagem <- lag.listw(pesos, x_padrao, zero.policy = TRUE)

mapa_analise <- mapa_analise %>%
    mutate(lisa_i = lisa[, 1],
           lisa_p = lisa[, ncol(lisa)],
           agrupamento = case_when(
               lisa_p >= alfa ~ "Não significativo",
               x_padrao > 0 & defasagem > 0 ~ "Ganho junto a ganho",
               x_padrao < 0 & defasagem < 0 ~ "Perda junto a perda",
               x_padrao > 0 & defasagem < 0 ~ "Ganho junto a perda",
               TRUE ~ "Perda junto a ganho"))

tabelas[["Tab_38_lisa"]] <- salvar_tab(
    mapa_analise %>%
        st_drop_geometry() %>%
        select(geocodigo, municipio, delta_floresta, lisa_i, lisa_p,
               agrupamento) %>%
        arrange(lisa_p),
    "Tab_38_moran_local_floresta")

######@> Mapa 07 - agrupamentos LISA da variação florestal...
cores_lisa <- c("Ganho junto a ganho" = "#01665E",
                "Perda junto a perda" = "#8C510A",
                "Ganho junto a perda" = "#80CDC1",
                "Perda junto a ganho" = "#DFC27D",
                "Não significativo" = "grey88")

m7 <- ggplot(mapa_dados) +
    geom_sf(fill = "grey85", colour = "grey30", linewidth = 0.2) +
    geom_sf(data = mapa_analise, aes(fill = agrupamento),
            colour = "grey30", linewidth = 0.2) +
    scale_fill_manual(values = cores_lisa, name = "Agrupamento LISA") +
    labs(title = "Agrupamentos espaciais da variação florestal",
         subtitle = paste0("Moran local sobre a variação ", ano_ini,
                           "-", ano_fim, ", significância a 5%"),
         caption = quebrar_mapa(paste(
             "Cinza claro: municípios sem agrupamento significativo ou",
             "sem dados. Há um agrupamento nítido de PERDA JUNTO A",
             "PERDA no litoral norte - Araquari, Barra Velha, Balneário",
             "Piçarras, Penha, Navegantes, São Francisco do Sul e",
             "Balneário Barra do Sul -, a assinatura espacial da",
             "expansão da conurbação Joinville-Itajaí sobre a floresta.",
             "Nenhum agrupamento de ganho atinge significância."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m7, "Mapa_07_lisa_variacao_florestal", largura = 8,
           altura = 9, diretorio = dir_mapa)

########################################################################
######@> Etapa 15 - Agrupamento de municípios por trajetória...

######@> Construção da matriz de perfis...
## As variáveis descrevem o município em quatro dimensões: o que ele é
## hoje (composição), quanto se transformou (variações), quão urbano se
## tornou (mancha e multiplicação) e quão estável é sua paisagem. A
## padronização em escala z é indispensável porque as variáveis têm
## unidades incomparáveis.
##
## O multiplicador da mancha urbana entra em logaritmo: sua
## distribuição é fortemente assimétrica (de menos de duas a mais de
## cinquenta vezes) e, sem a transformação, dois ou três municípios
## dominariam a distância euclidiana.
vars_perfil <- c("pct_Floresta", "pct_Agropecuária",
                 "pct_Área Não Vegetada", "delta_Floresta",
                 "delta_Área Não Vegetada", "urb_pct_area",
                 "log_urb_multiplicador", "pct_sem_mudanca",
                 "pct_area_agua")

perfil_matriz <- perfil_municipio %>%
    mutate(log_urb_multiplicador = log10(urb_multiplicador)) %>%
    select(geocodigo, municipio, all_of(vars_perfil))

######@> Tratamento da lacuna de Penha...
## Penha não tem o agregado de instabilidade. Em vez de excluir o
## município da tipologia - o que abriria um vazio no litoral -, a
## coluna recebe a MEDIANA das demais. A substituição é registrada na
## tabela exportada para que o leitor saiba que aquele valor não é
## observado.
mediana_estabilidade <- median(perfil_matriz$pct_sem_mudanca,
                               na.rm = TRUE)

perfil_matriz <- perfil_matriz %>%
    mutate(estabilidade_imputada = is.na(pct_sem_mudanca),
           pct_sem_mudanca = ifelse(is.na(pct_sem_mudanca),
                                    mediana_estabilidade,
                                    pct_sem_mudanca))

matriz_z <- perfil_matriz %>%
    select(all_of(vars_perfil)) %>%
    scale()

rownames(matriz_z) <- perfil_matriz$municipio

######@> Agrupamento hierárquico...
## Distância euclidiana sobre as variáveis padronizadas e ligação de
## Ward, que tende a formar grupos de tamanho equilibrado - preferível
## aqui, onde o objetivo é descrever tipologias e não isolar valores
## extremos.
distancias <- dist(matriz_z, method = "euclidean")
agrupamento <- hclust(distancias, method = "ward.D2")

######@> Escolha do número de grupos pela silhueta média...
## O critério NÃO é o máximo simples: quando os municípios se
## distribuem ao longo de um gradiente contínuo, a silhueta pode
## crescer até o limite da faixa examinada e o "máximo" seria apenas o
## maior k testado. Adota-se, por isso, uma regra de parcimônia
## declarada: o MENOR k cuja silhueta esteja a menos de uma tolerância
## do melhor valor observado.
tolerancia_silhueta <- 0.02

avaliacao_k <- tibble(k = 2:6) %>%
    mutate(silhueta = vapply(k, function(kk)
        silhueta_media(distancias, cutree(agrupamento, k = kk)),
        numeric(1)),
        distancia_do_melhor = max(silhueta) - silhueta,
        aceitavel = distancia_do_melhor <= tolerancia_silhueta)

n_clusters <- min(avaliacao_k$k[avaliacao_k$aceitavel])

tabelas[["Tab_39_escolha_num_perfis"]] <- salvar_tab(
    avaliacao_k, "Tab_39_escolha_do_numero_de_perfis")

message("\nNúmero de perfis escolhido: ", n_clusters,
        " (silhueta = ",
        sprintf("%.3f", avaliacao_k$silhueta[avaliacao_k$k ==
                                             n_clusters]),
        "; melhor observada = ",
        sprintf("%.3f", max(avaliacao_k$silhueta)),
        ", em k = ", avaliacao_k$k[which.max(avaliacao_k$silhueta)],
        ")")

grupos_cluster <- cutree(agrupamento, k = n_clusters)

perfil_matriz <- perfil_matriz %>%
    mutate(perfil = paste0("Perfil ",
                           grupos_cluster[match(municipio,
                                                names(grupos_cluster))]))

######@> Caracterização dos perfis...
caracterizacao <- perfil_matriz %>%
    group_by(perfil) %>%
    summarise(n_municipios = n(),
              municipios = paste(municipio, collapse = ", "),
              across(all_of(vars_perfil), mean),
              .groups = "drop")

tabelas[["Tab_40_perfis"]] <- salvar_tab(
    perfil_matriz %>% select(geocodigo, municipio, perfil,
                             everything()),
    "Tab_40_perfis_dos_municipios")
tabelas[["Tab_41_caracterizacao"]] <- salvar_tab(
    caracterizacao, "Tab_41_caracterizacao_dos_perfis")

message("Perfis formados        : ",
        paste(caracterizacao$perfil, " (n = ",
              caracterizacao$n_municipios, ")", sep = "",
              collapse = " | "))

######@> Figura 31 - dendrograma dos perfis...
ordem_dend <- agrupamento$labels[agrupamento$order]
altura_corte <- mean(rev(sort(agrupamento$height))[c(n_clusters - 1,
                                                     n_clusters)])

f31 <- ggplot() +
    geom_segment(data = segmentos_dendrograma(agrupamento),
                 aes(x = x, y = y, xend = xend, yend = yend),
                 colour = "grey35", linewidth = 0.4) +
    geom_hline(yintercept = altura_corte, linetype = "dashed",
               colour = "#D55E00") +
    scale_x_continuous(breaks = seq_along(ordem_dend),
                       labels = ordem_dend, expand = c(0.02, 0.02)) +
    labs(title = "Agrupamento dos municípios por trajetória da paisagem",
         subtitle = paste0("Ligação de Ward sobre ", length(vars_perfil),
                           " variáveis padronizadas de composição, ",
                           "transformação e urbanização"),
         x = NULL, y = "Distância",
         caption = quebrar(paste0(
             "Linha tracejada: corte adotado, em ", n_clusters,
             " perfis, escolhido pela regra de parcimônia da silhueta ",
             "média (menor k a menos de ", tolerancia_silhueta,
             " do melhor valor observado na faixa de 2 a 6 grupos; ver ",
             "Tab_39). A tipologia é DESCRITIVA: serve para organizar a ",
             "leitura dos 35 municípios, não para substituir o efeito ",
             "municipal em um modelo."))) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5,
                                     size = 8))

salvar_fig(f31, "Fig_31_dendrograma_perfis", 12, 7)

######@> Figura 32 - assinatura de cada perfil...
## Mostra, para cada perfil, o afastamento médio de cada variável em
## relação ao conjunto - em desvios-padrão. É o que permite NOMEAR os
## perfis.
rotulos_vars <- c("pct_Floresta" = "Floresta (%)",
                  "pct_Agropecuária" = "Agropecuária (%)",
                  "pct_Área Não Vegetada" = "Área não vegetada (%)",
                  "delta_Floresta" = "Variação da floresta",
                  "delta_Área Não Vegetada" = "Variação da não vegetada",
                  "urb_pct_area" = "Mancha urbana (%)",
                  "log_urb_multiplicador" = "Expansão urbana (log)",
                  "pct_sem_mudanca" = "Área que nunca mudou (%)",
                  "pct_area_agua" = "Água (% da área)")

assinatura <- as_tibble(matriz_z) %>%
    mutate(perfil = perfil_matriz$perfil) %>%
    group_by(perfil) %>%
    summarise(across(everything(), mean), .groups = "drop") %>%
    pivot_longer(-perfil, names_to = "variavel", values_to = "z") %>%
    mutate(rotulo = rotulos_vars[variavel],
           rotulo = factor(rotulo, levels = rev(rotulos_vars)))

limite_f32 <- max(abs(assinatura$z))

f32 <- ggplot(assinatura, aes(x = perfil, y = rotulo, fill = z)) +
    geom_tile(colour = "white", linewidth = 0.5) +
    geom_text(aes(label = sprintf("%+.1f", z)), size = 3,
              colour = "grey15") +
    scale_fill_gradient2(low = "#8C510A", mid = "grey96",
                         high = "#01665E", midpoint = 0,
                         limits = c(-limite_f32, limite_f32),
                         name = "Desvios-padrão") +
    labs(title = "Assinatura de cada perfil",
         subtitle = paste("Afastamento médio em relação ao conjunto,",
                          "em desvios-padrão"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Valores positivos indicam que o perfil está acima da",
             "média do litoral naquela variável. A leitura conjunta das",
             "linhas nomeia o perfil: um grupo com floresta alta, perda",
             "florestal e expansão urbana intensa descreve o município",
             "que se transformou dentro da janela observada; um grupo",
             "com agropecuária alta e pouca mudança descreve o",
             "município cuja conversão ocorreu ANTES de 1985 e que a",
             "série, portanto, não registra."))) +
    theme(legend.key.width = unit(1.4, "cm"))

salvar_fig(f32, "Fig_32_assinatura_dos_perfis", 10, 7)

######@> Mapa 08 - distribuição espacial dos perfis...
cores_perfil <- c("#0072B2", "#D55E00", "#009E73", "#CC79A7",
                  "#E69F00", "#56B4E9")[seq_len(n_clusters)]
names(cores_perfil) <- sort(unique(perfil_matriz$perfil))

mapa_perfis <- mapa_dados %>%
    left_join(perfil_matriz %>% select(geocodigo, perfil),
              by = "geocodigo")

m8 <- ggplot(mapa_perfis) +
    geom_sf(aes(fill = perfil), colour = "grey30", linewidth = 0.2) +
    scale_fill_manual(values = cores_perfil, na.value = "grey85",
                      name = "Perfil") +
    labs(title = "Tipologia dos municípios costeiros",
         subtitle = paste(n_clusters,
                          "perfis de trajetória da paisagem"),
         caption = quebrar_mapa(paste(
             "Em cinza: municípios sem dados. Os perfis têm alguma",
             "coerência espacial - reflexo do gradiente de composição",
             "documentado na Etapa 06 -, mas não formam blocos",
             "contíguos: municípios vizinhos podem pertencer a perfis",
             "distintos porque suas trajetórias de urbanização",
             "diferem."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m8, "Mapa_08_perfis_dos_municipios", largura = 8,
           altura = 9, diretorio = dir_mapa)

########################################################################
######@> Etapa 16 - Exportação consolidada e síntese...

######@> Arquivo XLSX com todas as tabelas...
## Nomes de aba limitados a 31 caracteres pela especificação do formato.
nomes_abas <- substr(names(tabelas), 1, 31)
names(tabelas) <- nomes_abas

write_xlsx(map(tabelas, as.data.frame),
           file.path(dir_tab, "AED_MapBiomas_todas_as_tabelas.xlsx"))

######@> Atalhos para os números citados no relatório...
## Extraídos aqui, e não no meio do texto, para que o relatório fique
## legível e para que qualquer mudança de definição tenha um único
## ponto de edição.
pega_serie <- function(tabela, nome, coluna) {
    tabela[[coluna]][tabela$serie == nome]
}

flor_ini <- composicao_extremos$pct_ini[
    composicao_extremos$classe == "Floresta"]
flor_fim <- composicao_extremos$pct_fim[
    composicao_extremos$classe == "Floresta"]
flor_var_ha <- composicao_extremos$variacao_ha[
    composicao_extremos$classe == "Floresta"]
nv_var_ha <- composicao_extremos$variacao_ha[
    composicao_extremos$classe == "Área Não Vegetada"]

urb_ini_ha <- urb_litoral$area_ha[urb_litoral$ano == ano_ini]
urb_fim_ha <- urb_litoral$area_ha[urb_litoral$ano == ano_fim]

acf_flor_nivel <- diagnostico_litoral$acf1[
    diagnostico_litoral$serie == "Floresta" &
    diagnostico_litoral$versao == "Nível (estoque)"]
acf_flor_dif <- diagnostico_litoral$acf1[
    diagnostico_litoral$serie == "Floresta" &
    diagnostico_litoral$versao == "1ª diferença (fluxo)"]

red_flor_nivel <- redundancia %>%
    filter(serie == "Floresta", versao == "Nível (estoque)")
red_flor_dif <- redundancia %>%
    filter(serie == "Floresta", versao == "1ª diferença (fluxo)")
red_urb_nivel <- redundancia %>%
    filter(serie == "Área urbanizada (ha)", versao == "Nível (estoque)")
red_urb_dif <- redundancia %>%
    filter(serie == "Área urbanizada (ha)",
           versao == "1ª diferença (fluxo)")

moran_delta_flor <- moran_global %>%
    filter(indicador == "Variação da floresta (p.p.)",
           esquema == "Contiguidade")

par_extremo <- comparacao_correlacao %>% slice(1)

######@> Relatório de síntese em texto...
## Registra os números que sustentam as afirmações do capítulo, de modo
## que possam ser citados sem reabrir os objetos do R.
linhas_relatorio <- c(
    "########################################################################",
    "## ANÁLISE EXPLORATÓRIA - MAPBIOMAS",
    paste0("## Litoral de Santa Catarina | ", ano_ini, "-", ano_fim),
    paste0("## Gerado em ", format(Sys.time(), "%d/%m/%Y %H:%M")),
    "########################################################################",
    "",
    "1. COBERTURA DA BASE",
    paste0("   Municípios analisados      : ", n_municipios, " de ",
           nrow(municipios_sf)),
    paste0("   Municípios sem dados       : ",
           paste(municipios_sem_dados$municipio, collapse = ", ")),
    paste0("   Período                    : ", ano_ini, " a ", ano_fim,
           " (", n_anos, " anos, um mosaico por ano)"),
    paste0("   Linhas em series_anuais    : ", fmt_int(nrow(series))),
    paste0("   Linhas na cobertura        : ", fmt_int(nrow(cob)),
           " (grade completa: ", ifelse(grade_completa, "sim", "NÃO"),
           ")"),
    paste0("   Área total do litoral      : ",
           fmt_int(sum(areas_mun$area_ha_mapbiomas)), " ha"),
    "",
    "2. TRIAGEM: O QUE É SÉRIE TEMPORAL",
    paste0("   Relatórios inventariados   : ",
           nrow(triagem_relatorios)),
    paste0("   Séries anuais analisáveis  : ", n_series_reais),
    paste0("   Agregados de período/coorte: ",
           sum(triagem_relatorios$tipo_temporal %in%
               c("periodo", "coorte"))),
    paste0("   Classes da cobertura       : ",
           nrow(ocorrencia_classes), ", das quais ",
           nrow(classes_nulas), " identicamente nulas no litoral"),
    paste0("   Fechamento do nível 1      : desvio máximo de ",
           sprintf("%.6f", max(abs(fechamento_n1$desvio_pct))),
           " p.p. (a composição fecha 100%)"),
    "",
    "3. COMPOSIÇÃO E SUA MUDANÇA",
    paste0("   ", format(as.character(composicao_extremos$classe),
                         width = 32),
           sprintf("%6.2f%% -> %6.2f%%", composicao_extremos$pct_ini,
                   composicao_extremos$pct_fim),
           sprintf("  (%9s ha)",
                   paste0(ifelse(composicao_extremos$variacao_ha > 0,
                                 "+", ""),
                          fmt_int(composicao_extremos$variacao_ha)))),
    paste0("   A perda florestal (", fmt_int(flor_var_ha),
           " ha) e o ganho de área não vegetada (+",
           fmt_int(nv_var_ha), " ha) são"),
    paste0("   quase idênticos NO AGREGADO, mas a correlação entre eles ",
           "município a"),
    paste0("   município é de apenas ",
           sprintf("%.2f", cor_compensacao),
           ": a compensação exata é propriedade do fechamento,"),
    "   não uma regularidade local.",
    "",
    "4. URBANIZAÇÃO",
    paste0("   Mancha urbana do litoral   : ", fmt_int(urb_ini_ha),
           " ha -> ", fmt_int(urb_fim_ha), " ha (",
           sprintf("%+.0f%%", 100 * (urb_fim_ha / urb_ini_ha - 1)),
           ")"),
    paste0("   Crescimento por década     : ",
           paste0(taxa_decada$decada, " ",
                  sprintf("%+.0f%%", taxa_decada$crescimento_pct),
                  collapse = " | ")),
    paste0("   Já urbanizado em 1985      : ",
           sprintf("%.0f%%", coortes_litoral$pct[
               coortes_litoral$coorte == "até 1985"]),
           " da mancha urbana atual"),
    paste0("   Vegetação urbana           : ",
           sprintf("%.1f%%", veg_urbana_litoral$pct_vegetada[
               veg_urbana_litoral$ano == ano_ini]),
           " em ", ano_ini, " -> ",
           sprintf("%.1f%%", veg_urbana_litoral$pct_vegetada[
               veg_urbana_litoral$ano == ano_fim]),
           " em ", ano_fim, " da mancha urbana"),
    paste0("   Expansão significativa em  : ",
           sum(diagnostico_municipal$tendencia_urbana == "Expansão"),
           " de ", n_municipios, " municípios"),
    "",
    "5. RISCO CLIMÁTICO (áreas urbanas suscetíveis)",
    paste0("   ", format(as.character(resumo_constancia$classe),
                         width = 12),
           "constante em ",
           sprintf("%2d de %2d", resumo_constancia$constantes,
                   resumo_constancia$municipios),
           " municípios ao longo dos 40 anos"),
    paste0("   Correlação com a mancha urbana: ",
           sprintf("%.2f", cor_risco_urbano), " entre municípios, ",
           sprintf("%.2f", median(correlacao_intra$cor_temporal,
                                  na.rm = TRUE)),
           " dentro de cada um"),
    "   Leitura: a exposição cresceu porque a cidade avançou sobre área",
    "   suscetível; a suscetibilidade em si é um mapa fixo.",
    "",
    "6. ÁGUA (descartado como série)",
    paste0("   Municípios cobertos        : ", nrow(agua_municipios),
           " de ", n_municipios),
    paste0("   Municípios com registro    : ",
           agua_cobertura$municipios[1], " em ", min(agua$ano), ", ",
           agua_cobertura$municipios[agua_cobertura$ano == 2005],
           " em 2005"),
    paste0("   Soma das classes           : de ",
           sprintf("%.2f%%", min(agua_fechamento$soma_pct)), " a ",
           sprintf("%.2f%%", max(agua_fechamento$soma_pct)),
           " da área (não fecha)"),
    paste0("   Balanço do sentido         : ",
           sum(agua_balanco$sentido_predominante == "Decréscimo"),
           " de ", nrow(agua_balanco),
           " municípios com predomínio de decréscimo"),
    "",
    "7. DEPENDÊNCIA TEMPORAL: ESTOQUE E FLUXO",
    paste0("   ACF(1) da floresta         : ",
           sprintf("%.3f", acf_flor_nivel), " em nível -> ",
           sprintf("%.3f", acf_flor_dif), " na 1ª diferença"),
    paste0("   ", format(as.character(resumo_acf$classe), width = 32),
           sprintf("%.3f -> %.3f", resumo_acf$acf1_nivel_medio,
                   resumo_acf$acf1_dif_medio),
           "  (média municipal)"),
    paste0("   Municípios com memória no fluxo (Ljung-Box): ",
           sum(diagnostico_municipal$memoria_no_fluxo == "Sim"),
           " de ", n_municipios),
    "   Leitura: a autocorrelação do estoque é aritmética, não",
    "   informativa. Toda leitura de dependência é feita no fluxo.",
    "",
    "8. TENDÊNCIA (Mann-Kendall e Sen)",
    paste0("   ", format(tendencia_litoral$serie, width = 32),
           sprintf("tau = %+.3f", tendencia_litoral$tau),
           sprintf(" | Sen = %10s %s/década",
                   ifelse(abs(tendencia_litoral$sen_por_decada) >= 100,
                          sprintf("%+.0f",
                                  tendencia_litoral$sen_por_decada),
                          sprintf("%+.2f",
                                  tendencia_litoral$sen_por_decada)),
                   tendencia_litoral$unidade),
           " | ", tendencia_litoral$resultado),
    paste0("   Tendência municipal da floresta: ",
           sum(tendencia_municipal$classe == "Floresta" &
               tendencia_municipal$resultado == "Decrescente"),
           " em queda, ",
           sum(tendencia_municipal$classe == "Floresta" &
               tendencia_municipal$resultado == "Crescente"),
           " em ganho, ",
           sum(tendencia_municipal$classe == "Floresta" &
               tendencia_municipal$resultado ==
               "Sem tendência detectada"), " sem tendência"),
    "",
    "9. ESTRUTURA ENTRE CLASSES (fechamento e CLR)",
    paste0("   Pares que mudam de sinal ao corrigir o fechamento: ",
           sum(comparacao_correlacao$muda_de_sinal), " de ",
           nrow(comparacao_correlacao)),
    paste0("   Maior divergência          : ", par_extremo$classe_a,
           " x ", par_extremo$classe_b, " (",
           sprintf("%.2f", par_extremo$cor_bruta), " bruta -> ",
           sprintf("%.2f", par_extremo$cor_clr), " CLR)"),
    paste0("   PCA da composição (CLR)    : PC1 = ",
           sprintf("%.1f%%", variancia_pca[1]), ", PC1+PC2 = ",
           sprintf("%.1f%%", sum(variancia_pca[1:2]))),
    "",
    "10. REDUNDÂNCIA ESPACIAL E AUTOCORRELAÇÃO",
    paste0("   Floresta - nível           : correlação mediana ",
           sprintf("%.3f", red_flor_nivel$cor_mediana), ", PC1 = ",
           sprintf("%.1f%%", red_flor_nivel$pc1_pct), ", ",
           red_flor_nivel$componentes_95, " componentes para 95%"),
    paste0("   Floresta - 1ª diferença    : correlação mediana ",
           sprintf("%.3f", red_flor_dif$cor_mediana), ", PC1 = ",
           sprintf("%.1f%%", red_flor_dif$pc1_pct), ", ",
           red_flor_dif$componentes_95, " componentes para 95%"),
    paste0("   Área urbanizada - nível    : PC1 = ",
           sprintf("%.1f%%", red_urb_nivel$pc1_pct),
           " (artefato da tendência comum)"),
    paste0("   Área urbanizada - fluxo    : PC1 = ",
           sprintf("%.1f%%", red_urb_dif$pc1_pct), ", ",
           red_urb_dif$componentes_95, " componentes para 95%"),
    paste0("   Moran da variação florestal: I = ",
           sprintf("%.3f", moran_delta_flor$moran_i), ", p = ",
           format.pval(moran_delta_flor$p_valor, digits = 3,
                       eps = 0.001),
           " (agrupamento no litoral norte)"),
    paste0("   Testes de Moran significativos: ",
           sum(moran_global$resultado != "Sem autocorrelação detectada"),
           " de ", nrow(moran_global), ", com os dois esquemas de",
           " vizinhança concordando em ",
           sum(concordancia_moran$concordam), " de ",
           nrow(concordancia_moran), " indicadores"),
    "",
    "11. TIPOLOGIA DOS MUNICÍPIOS",
    paste0("   Perfis adotados            : ", n_clusters,
           " (silhueta ",
           sprintf("%.3f", avaliacao_k$silhueta[avaliacao_k$k ==
                                                n_clusters]), ")"),
    paste0("   ", format(caracterizacao$perfil, width = 12),
           sprintf("n = %2d | ", caracterizacao$n_municipios),
           substr(caracterizacao$municipios, 1, 90)),
    "",
    "########################################################################",
    "## IMPLICAÇÕES PARA A MODELAGEM",
    "########################################################################",
    "",
    "   (a) UNIDADE DE ANÁLISE",
    "       O município é a unidade adequada: a base já vem tabulada",
    "       nele, a grade é completa em 35 dos 37 municípios e - ao",
    "       contrário do ERA5 - não há redundância espacial que",
    "       desaconselhe efeitos municipais livres nas séries de fluxo.",
    "",
    "   (b) ESTOQUE E FLUXO",
    paste0("       A ACF(1) das séries em nível fica entre ",
           sprintf("%.2f", min(resumo_acf$acf1_nivel_medio)), " e ",
           sprintf("%.2f", max(resumo_acf$acf1_nivel_medio)),
           " por"),
    "       construção. Modelar o estoque sem diferenciar produziria",
    "       resíduos autocorrelacionados e erros-padrão otimistas. A",
    "       série de interesse é a taxa anual de conversão.",
    "",
    "   (c) COMPOSIÇÃO",
    "       As cinco classes de nível 1 somam 100%: não podem entrar",
    "       juntas em um modelo como preditoras independentes. As",
    "       alternativas são usar log-razões (CLR ou ILR), escolher um",
    "       subconjunto que não esgote a composição, ou modelar a",
    "       composição inteira com uma resposta multinomial.",
    "",
    "   (d) ESCALA TEMPORAL",
    paste0("       São ", n_anos, " observações anuais, sem sazonalidade. Isso",
           " limita a"),
    paste0("       defasagem examinável a ", lag_max_anual,
           " anos, reduz o poder dos testes de raiz"),
    "       unitária e desaconselha estruturas de memória longa.",
    "",
    "   (e) O QUE NÃO USAR COMO PREDITOR DINÂMICO",
    paste0("       As ", nrow(classes_nulas),
           " classes identicamente nulas; as faixas Médio e Alto do"),
    "       risco climático, constantes em todos os municípios; e o tema",
    "       Água, cuja cobertura cresce ao longo do tempo. As faixas de",
    "       risco continuam válidas como DESCRITORES fixos do município.",
    "",
    "   (f) DUAS ESCALAS ESPACIAIS, DUAS RESPOSTAS",
    paste0("       O saldo de 40 anos é espacialmente estruturado (Moran ",
           sprintf("%.2f", moran_delta_flor$moran_i), "),"),
    "       com perda florestal concentrada no litoral norte; a conversão",
    paste0("       ano a ano não é (correlação mediana ",
           sprintf("%.2f", red_flor_dif$cor_mediana), " entre"),
    "       municípios). Um modelo de longo prazo pode se beneficiar de",
    "       estrutura espacial; um modelo de eventos anuais, não.",
    "",
    "   (g) RESSALVA QUE ATRAVESSA TUDO",
    "       MapBiomas é CLASSIFICAÇÃO DE IMAGEM, não observação direta.",
    "       Mudanças de classe entre anos consecutivos podem refletir",
    "       diferenças de cobertura de nuvens, de sensor ou de versão do",
    "       algoritmo, e não transformação real do território - o que",
    "       afeta sobretudo as classes raras e as reversões de curto",
    "       prazo. A instabilidade medida na Etapa 05 (pixels que mudam",
    "       três vezes ou mais) é o melhor indicador disponível desse",
    "       ruído, e recomenda cautela com qualquer leitura baseada em",
    "       variações de um único ano.",
    "",
    "########################################################################")

writeLines(linhas_relatorio,
           file.path(dir_res, "AED_MapBiomas_relatorio_sintese.txt"))

######@> Resumo final do processamento...
n_figs <- length(list.files(dir_fig, pattern = "\\.png$"))
n_figs_mun <- length(list.files(dir_fig_mun, pattern = "\\.png$"))
n_mapas <- length(list.files(dir_mapa, pattern = "\\.png$"))
n_tabs <- length(list.files(dir_tab, pattern = "\\.csv$"))

message("\n=== AED concluída ===")
message("Figuras gerais         : ", n_figs)
message("Painéis por município  : ", n_figs_mun)
message("Mapas                  : ", n_mapas)
message("Tabelas (CSV)          : ", n_tabs, " + 1 XLSX consolidado")
message("Relatório de síntese   : AED_MapBiomas_relatorio_sintese.txt")
message("Saídas em              : ", normalizePath(dir_res))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
