########################################################################
## Description: Análise exploratória de dados (AED) das séries
##              climáticas do ERA5 por município costeiro de Santa
##              Catarina, com foco nos padrões espaço-temporais das
##              variáveis atmosféricas e de superfície...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: qua ago 19 15:00:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: Base padronizada pelo
##                script_ERA5_extracao_municipios_ver01.R:
##                  - dados_municipio_final : município x ano x mês
##                                            (38.443 linhas, 100 colunas,
##                                             grade completa)
##                  - dados_pixel           : célula x ano x mês
##                  - tabela_pesos          : frações de intersecção
##                                            pixel-município
##                  - dicionario, sufixos   : metadados das colunas
##                  - diagnostico           : cobertura por pixel
##                Complementada pelo shapefile de municípios.
##                Período 1940-2026, 37 municípios, reanálise ERA5
##                (ECMWF), grade de 0,25 graus.
##
### Commentary:
##
## Esta é a análise exploratória que antecede a modelagem. Seu propósito
## não é responder às perguntas da dissertação, e sim estabelecer O QUE
## OS DADOS PERMITEM PERGUNTAR: quais colunas são de fato séries
## temporais, quanta informação independente existe entre os 37
## municípios, qual a estrutura sazonal e tendencial de cada variável,
## que dependência sobra depois de removida a sazonalidade e em que
## escala espacial faz sentido acoplar estes dados às séries de
## desastres.
##
## Cinco achados da sondagem preliminar estruturam o documento e
## precisam ser declarados antes de qualquer resultado, porque cada um
## deles descarta uma análise que pareceria natural:
##
##    (i) NEM TODA COLUNA É UMA SÉRIE TEMPORAL. Das 20 variáveis
##        originais, quatro (cvh, cvl, tvh, tvl) são campos ESTÁTICOS do
##        ERA5: o desvio-padrão temporal dentro de cada município é
##        exatamente zero ao longo dos 86 anos. Outras duas (lai_hv,
##        lai_lv) variam ao longo do ano mas são IDÊNTICAS entre anos
##        para um mesmo mês (desvio-padrão entre anos da ordem de
##        0,00003) - isto é, são uma CLIMATOLOGIA mensal fixa, não uma
##        série observada. Nenhuma das seis pode ser usada como
##        preditora dinâmica, e submetê-las a ACF, teste de tendência ou
##        decomposição produziria resultados formalmente calculáveis e
##        substantivamente vazios. O script faz essa triagem na Etapa 02
##        e conduz as demais etapas apenas sobre as variáveis dinâmicas,
##        mantendo as estáticas como descritores fixos do município;
##
##   (ii) 37 MUNICÍPIOS NÃO SÃO 37 SÉRIES INDEPENDENTES. A grade do ERA5
##        tem 0,25 graus (cerca de 27 km), e os municípios costeiros
##        catarinenses são pequenos: três são cobertos por um ÚNICO
##        pixel e, no conjunto, os 37 municípios têm apenas 21 pixels
##        dominantes distintos - onze células são a principal fonte de
##        dois a quatro municípios simultaneamente. A consequência é
##        direta e mensurável: na temperatura, a correlação mediana
##        entre as anomalias municipais é 0,97 e o primeiro componente
##        principal explica 96,5% da variância conjunta - UM único
##        componente basta para 95% dela. Um modelo com efeito
##        espacial livre por município estaria estimando parâmetros para
##        uma variação que a base não contém. A dimensionalidade efetiva
##        é quantificada por variável na Etapa 10, e não é a mesma para
##        todas: a precipitação (PC1 = 75%, quatro componentes para 95%)
##        e o vento (PC1 = 74%) preservam estrutura espacial que a
##        temperatura não tem. Pares de municípios que compartilham a
##        célula dominante têm correlação acima de 0,99 em TODAS as
##        variáveis, mas a Etapa 10 mostra que isso NÃO é, em sua maior
##        parte, artefato de grade: controlada a distância entre
##        centroides, o excesso de correlação atribuível ao pixel
##        compartilhado fica entre 0,005 e 0,030. A redundância é
##        coerência espacial GENUÍNA de campos atmosféricos em uma faixa
##        costeira estreita - o que torna a conclusão mais forte, e não
##        mais fraca: ela não seria removida por uma fonte de maior
##        resolução, porque não é a fonte que a produz;
##
##  (iii) OS SUFIXOS _dp, _min e _max NÃO SÃO EXTREMOS TEMPORAIS. Eles
##        descrevem a dispersão ENTRE OS PIXELS de um mesmo município no
##        mesmo mês - ou seja, heterogeneidade espacial INTERNA. A
##        confusão seria consequente: para o vento, a amplitude interna
##        média (1,57 m/s) é 4,4 vezes MAIOR que o desvio-padrão
##        temporal da própria série municipal (0,35 m/s), de modo que a
##        média municipal resume mal o que acontece dentro do município -
##        coerente com o fato, verificado na Etapa 02, de que 75% da
##        variância do vento está ENTRE municípios, e não entre meses.
##        Para a temperatura ocorre o inverso (razão 0,37), e a média é
##        um bom resumo. Essa razão é calculada para todas as variáveis
##        na Etapa 06 e informa em quais delas o município é a unidade
##        espacial adequada;
##
##   (iv) SAZONALIDADE E TENDÊNCIA SÃO REMOVIDAS ANTES DE INTERPRETAR A
##        AUTOCORRELAÇÃO. A ACF da temperatura bruta tem 0,906 no lag 12
##        e -0,877 no lag 6: é o ciclo anual, não memória do processo.
##        Depois de convertida em anomalia frente à normal 1991-2020, a
##        ACF de lag 1 cai para 0,352, já abaixo do limiar usual de
##        decorrelação de 1/e - memória curta, de um a dois meses. Com
##        mais de mil observações o limite de significância da ACF é
##        próximo de 0,06, de modo que muitos lags seguem formalmente
##        significativos sendo desprezíveis em magnitude: a leitura deve
##        seguir o tamanho do coeficiente. Todos os correlogramas são
##        apresentados em duas versões, série bruta e anomalia, porque a
##        primeira responde "como é o clima" e apenas a segunda responde
##        "quanto um mês informa sobre o seguinte";
##
##    (v) HÁ DUAS VARIÁVEIS DE VENTO E ELAS MEDEM COISAS DIFERENTES.
##        si10 é a média da VELOCIDADE escalar (média de módulos),
##        enquanto vento_vel_m_s é o MÓDULO DO VENTO MÉDIO, calculado a
##        partir das componentes u10 e v10 já mediadas no mês. Como as
##        direções se cancelam na média vetorial, a segunda é 3,2 vezes
##        menor que a primeira e as duas correlacionam-se apenas 0,57.
##        Para intensidade de vento - que é o que interessa a eventos
##        de desastre - a variável correta é si10; a razão entre as duas
##        é usada aqui como índice de CONSTÂNCIA DIRECIONAL do vento. A
##        direção (vento_dir_graus) é circular e sua média aritmética
##        não tem sentido: as médias direcionais deste script são
##        vetoriais, calculadas a partir de u10 e v10.
##
## Duas escolhas metodológicas adicionais:
##
##   - O ano de 2026 está incompleto na base (sete meses) e é excluído
##     de todas as climatologias, séries anuais e testes de tendência,
##     que passariam a comparar anos de doze meses com um de sete. As
##     linhas permanecem na base lida e são reportadas no panorama;
##
##   - As anomalias usam como referência a normal climatológica
##     1991-2020, período padrão da OMM. A escolha tem uma vantagem
##     adicional neste projeto: 1991-2020 está contido na janela do
##     Atlas Digital de desastres (1991-2025), de modo que as anomalias
##     ficam centradas no mesmo período em que existem registros de
##     desastre para acoplar.
##
## Fluxo geral da análise:
##
##   01) Leitura da base e preparação dos objetos de trabalho;
##   02) Panorama, completude e triagem das variáveis;
##   03) Climatologia e ciclo sazonal;
##   04) Estrutura temporal agregada do litoral e anomalias;
##   05) Padrões municipais: gradiente espacial e rankings;
##   06) Heterogeneidade interna aos municípios (sufixos _dp/_min/_max);
##   07) Painéis diagnósticos por município;
##   08) Dependência temporal: ACF, PACF, Ljung-Box, estacionariedade e
##       decomposição STL;
##   09) Tendência: Mann-Kendall e declividade de Sen;
##   10) Estrutura entre variáveis e redundância espacial (PCA);
##   11) Distribuição, caudas e meses extremos;
##   12) Padrões espaciais: mapas e autocorrelação espacial (Moran);
##   13) Agrupamento de municípios por perfil climático;
##   14) Exportação das tabelas e relatório de síntese.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Dados vetoriais e mapas
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem e grades
library(purrr)          ## Programação funcional
library(stringi)        ## Transliteração de acentos
library(ggplot2)        ## Gráficos
library(patchwork)      ## Composição de painéis
library(scales)         ## Escalas e formatação de eixos
library(forecast)       ## Decomposição STL e utilitários de séries
library(tseries)        ## Testes de estacionariedade (ADF, KPSS)
library(spdep)          ## Autocorrelação espacial (Moran)
library(writexl)        ## Exportação consolidada em XLSX

######@> Resolução de conflitos de nomes...
## Mantida a mesma fixação explícita adotada nos demais scripts do
## projeto: evita erros silenciosos de seleção de colunas caso algum
## pacote carregado adiante mascare os verbos do dplyr.
select <- dplyr::select
filter <- dplyr::filter

######@> Opções globais...
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente...
## Fixada porque a etapa de agrupamento (k-means) é estocástica.
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
dir_dados <- "../Dados"
dir_out_era5 <- file.path(dir_dados, "Outputs", "Copernicus_ERA5")
dir_shape <- file.path(dir_dados, "Shapefiles")

arq_base <- file.path(dir_out_era5, "RData", "ERA5_SC_completo.RData")
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Diretórios de saída...
## A AED gera três famílias de produto, que ficam em subpastas próprias
## para que o material possa ser localizado pelo tipo: tabelas (insumo
## de texto e de análises posteriores), figuras (séries e diagnósticos)
## e mapas (recorte espacial).
dir_res <- "../Results/AED_ERA5"
dir_tab <- file.path(dir_res, "Tabelas")
dir_fig <- file.path(dir_res, "Figuras")
dir_fig_mun <- file.path(dir_fig, "Municipios")
dir_mapa <- file.path(dir_res, "Mapas")

for(d in c(dir_res, dir_tab, dir_fig, dir_fig_mun, dir_mapa)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> CRS de referência...
crs_projeto <- 4326      ## WGS84, mesmo das demais bases
crs_area <- 5880         ## SIRGAS 2000 / Brazil Polyconic (áreas)

######@> Parâmetros da análise...
## ano_fim_completo : 2026 tem apenas sete meses na base; incluí-lo nas
##                    médias anuais compararia anos de doze meses com um
##                    de sete, viesando toda a análise de tendência;
## ref_ini/ref_fim  : normal climatológica de referência para as
##                    anomalias (padrão OMM, e contida na janela do
##                    Atlas Digital de desastres);
## lag_max_mensal   : 36 meses cobrem três ciclos anuais, suficiente
##                    para revelar (ou descartar) periodicidade;
## lag_max_anual    : 20 anos - com 86 observações anuais, a
##                    autocorrelação além disso perde precisão útil;
## alfa             : nível de significância adotado nos testes.
ano_fim_completo <- 2025
ref_ini <- 1991
ref_fim <- 2020
lag_max_mensal <- 36
lag_max_anual <- 20
alfa <- 0.05

######@> Paleta dos domínios climáticos...
## Paleta Okabe-Ito, segura para daltonismo, atribuída com apoio
## semântico: vermelho-alaranjado para o domínio térmico, azul para o
## hídrico, amarelo para o radiativo, verde-azulado para o vento e
## cinza-azulado para a nebulosidade.
cores_dominio <- c("Térmico"     = "#D55E00",
                   "Hídrico"     = "#0072B2",
                   "Radiativo"   = "#E69F00",
                   "Vento"       = "#009E73",
                   "Nebulosidade" = "#56B4E9")

######@> Nomes dos meses (rótulos dos eixos)...
meses_abrev <- c("Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
                 "Jul", "Ago", "Set", "Out", "Nov", "Dez")

######@> Estações do ano (hemisfério sul)...
## Usadas nos recortes sazonais. DJF é verão austral, e a atribuição
## segue a convenção meteorológica (trimestres fixos), não as datas
## astronômicas.
estacao_do_mes <- c("Verão", "Verão", "Outono", "Outono", "Outono",
                    "Inverno", "Inverno", "Inverno", "Primavera",
                    "Primavera", "Primavera", "Verão")
ordem_estacoes <- c("Verão", "Outono", "Inverno", "Primavera")

########################################################################
######@> Funções auxiliares...

######@> Tema gráfico do documento...
## Centralizar o tema garante que as dezenas de figuras produzidas
## tenham a mesma aparência, o que é requisito para que possam ser
## usadas lado a lado no texto da dissertação.
tema_aed <- function(base = 11) {
    theme_bw(base_size = base) +
        theme(panel.grid.minor = element_blank(),
              panel.grid.major = element_line(linewidth = 0.25,
                                              colour = "grey88"),
              strip.background = element_rect(fill = "grey92",
                                              colour = "grey70"),
              strip.text = element_text(face = "bold", size = base - 1),
              plot.title = element_text(face = "bold", size = base + 2),
              plot.subtitle = element_text(colour = "grey30",
                                           size = base - 1),
              plot.caption = element_text(colour = "grey45",
                                          size = base - 3, hjust = 0),
              legend.position = "bottom",
              legend.title = element_text(face = "bold", size = base - 1))
}

theme_set(tema_aed())

######@> Quebra de linha em legendas longas...
## O ggplot NÃO quebra automaticamente o texto de caption: legendas
## longas são simplesmente cortadas na borda direita da figura. Esta
## função insere as quebras antes da plotagem, mantendo as notas de
## rodapé legíveis independentemente da largura do arquivo gerado.
quebrar <- function(texto, largura = 105) {
    paste(strwrap(paste(texto, collapse = " "), width = largura),
          collapse = "\n")
}

######@> Quebra de linha para legendas de mapa...
## Os mapas são gravados com 8 polegadas de largura, contra 10 a 14 das
## demais figuras. A quebra padrão, calibrada para as figuras largas,
## deixaria o texto das legendas ultrapassar a borda direita do
## arquivo. Esta variante estreita é usada em todos os mapas.
quebrar_mapa <- function(texto) {
    quebrar(texto, largura = 78)
}

######@> Função de gravação de figuras...
## Padroniza formato, resolução e diretório. dpi = 300 atende a
## requisitos de impressão de dissertação.
salvar_fig <- function(plot, arquivo, largura = 10, altura = 6,
                       diretorio = dir_fig) {
    ggsave(filename = file.path(diretorio, paste0(arquivo, ".png")),
           plot = plot, width = largura, height = altura, dpi = 300,
           bg = "white")
    invisible(NULL)
}

######@> Função de gravação de tabelas...
## Grava em CSV com separador ";" e decimal "," (padrão brasileiro,
## abre corretamente no Excel em português) e devolve a tabela para que
## também seja acumulada no XLSX consolidado.
salvar_tab <- function(dados, arquivo) {
    write.table(dados, file.path(dir_tab, paste0(arquivo, ".csv")),
                sep = ";", dec = ",", row.names = FALSE,
                fileEncoding = "UTF-8")
    invisible(dados)
}

######@> Formatação de inteiros com separador de milhar...
## big.mark = "." sozinho dispara aviso, porque no locale padrão do R o
## separador DECIMAL também é "."; declarar decimal.mark = "," (a
## convenção brasileira) elimina a ambiguidade.
fmt_int <- function(x) {
    formatC(x, format = "f", digits = 0, big.mark = ".",
            decimal.mark = ",")
}

######@> Função para transliterar nomes em nomes seguros de arquivo...
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Média vetorial de direção do vento...
## A direção é uma variável CIRCULAR: a média aritmética entre 350 e 10
## graus devolveria 180 (sul), quando o resultado correto é 0 (norte).
## A média correta é obtida decompondo em seno e cosseno, mediando as
## componentes e recompondo o ângulo.
##
## Convenção meteorológica: o ângulo indica a direção DE ONDE o vento
## sopra, e por isso o sinal das componentes é invertido antes do
## atan2 - a mesma convenção usada na padronização da base.
direcao_media <- function(u, v) {
    um <- mean(u, na.rm = TRUE)
    vm <- mean(v, na.rm = TRUE)
    ang <- (atan2(-um, -vm) * 180 / pi) %% 360
    return(ang)
}

######@> Comprimento do vetor médio (constância direcional)...
## Razão entre o módulo do vento médio e a média dos módulos. Vale 1
## quando o vento sopra sempre da mesma direção e tende a 0 quando as
## direções se distribuem uniformemente. É a medida que dá sentido à
## diferença entre vento_vel_m_s e si10 (achado (v) do cabeçalho).
constancia_direcional <- function(vel_vetorial, vel_escalar) {
    ifelse(vel_escalar > 0, vel_vetorial / vel_escalar, NA_real_)
}

######@> Teste de tendência de Mann-Kendall...
## Implementado no próprio script, e não importado de pacote, por duas
## razões: (a) mantém o script executável sem dependências além das já
## utilizadas no projeto; (b) torna explícita a correção para empates.
##
## O teste é não-paramétrico e avalia a hipótese de tendência monotônica
## (não necessariamente linear). Nas séries climáticas isso é preferível
## à regressão linear porque não pressupõe forma funcional nem
## normalidade dos resíduos, e é robusto aos anos atípicos que a
## variabilidade interanual produz.
mann_kendall <- function(x) {
    x <- as.numeric(x[!is.na(x)])
    n <- length(x)
    if(n < 4) {
        return(tibble(S = NA_real_, tau = NA_real_, z = NA_real_,
                      p_valor = NA_real_))
    }
    ## Estatística S: soma dos sinais de todas as diferenças aos pares
    dif <- outer(x, x, "-")
    S <- sum(sign(dif[lower.tri(dif)]))
    ## Variância com correção para empates
    empates <- as.numeric(table(x))
    var_S <- (n * (n - 1) * (2 * n + 5) -
              sum(empates * (empates - 1) * (2 * empates + 5))) / 18
    if(var_S <= 0) {
        return(tibble(S = S, tau = NA_real_, z = NA_real_,
                      p_valor = NA_real_))
    }
    ## Correção de continuidade no cálculo de z
    z <- if(S > 0) (S - 1) / sqrt(var_S) else
         if(S < 0) (S + 1) / sqrt(var_S) else 0
    tau <- S / (n * (n - 1) / 2)
    tibble(S = S, tau = tau, z = z, p_valor = 2 * pnorm(-abs(z)))
}

######@> Declividade de Sen (Theil-Sen)...
## Mediana das declividades entre todos os pares de pontos. É o
## estimador de magnitude que acompanha o Mann-Kendall: robusto a
## valores extremos, e por isso preferível à regressão linear em séries
## climáticas com anos atípicos.
declividade_sen <- function(y, x) {
    ok <- !is.na(y) & !is.na(x)
    y <- y[ok]; x <- x[ok]
    if(length(y) < 4) return(NA_real_)
    dy <- outer(y, y, "-")
    dx <- outer(x, x, "-")
    decl <- (dy / dx)[lower.tri(dy)]
    return(median(decl[is.finite(decl)], na.rm = TRUE))
}

######@> Cálculo de ACF/PACF em formato de tabela...
## Devolve um data.frame com o lag, o valor e o limite do intervalo de
## confiança, permitindo tanto a plotagem em ggplot quanto a exportação
## da autocorrelação como tabela.
calcular_correlograma <- function(x, lag_max, tipo = c("ACF", "PACF")) {
    tipo <- match.arg(tipo)
    x <- as.numeric(x)
    n <- length(x)
    ## Série constante - caso dos campos estáticos do ERA5 - não admite
    ## autocorrelação: devolve tabela vazia em vez de propagar NaN para
    ## dentro dos gráficos.
    if(n < 8 || var(x, na.rm = TRUE) == 0) {
        return(tibble(lag = integer(), valor = numeric(),
                      ic = numeric(), tipo = character()))
    }
    lag_max <- min(lag_max, floor(n / 3))
    if(tipo == "ACF") {
        obj <- acf(x, lag.max = lag_max, plot = FALSE,
                   na.action = na.pass)
        valores <- as.numeric(obj$acf)[-1]
    } else {
        obj <- pacf(x, lag.max = lag_max, plot = FALSE,
                    na.action = na.pass)
        valores <- as.numeric(obj$acf)
    }
    tibble(lag = seq_along(valores), valor = valores,
           ic = qnorm(1 - alfa / 2) / sqrt(n), tipo = tipo)
}

######@> Gráfico de correlograma em ggplot...
## Reimplementado em ggplot (em vez de usar o plot base de acf()) para
## que os correlogramas possam ser combinados com as demais figuras em
## painéis e sigam o mesmo tema visual.
grafico_correlograma <- function(tabela, titulo = NULL,
                                 subtitulo = NULL) {
    if(nrow(tabela) == 0) {
        return(ggplot() +
               annotate("text", x = 0, y = 0,
                        label = paste("Série sem variabilidade",
                                      "\n(correlograma não definido)"),
                        size = 3, colour = "grey40") +
               labs(title = titulo) + theme_void())
    }
    ic <- tabela$ic[1]
    ggplot(tabela, aes(x = lag, y = valor)) +
        geom_hline(yintercept = 0, colour = "grey40") +
        geom_hline(yintercept = c(-ic, ic), linetype = "dashed",
                   colour = "#0072B2", linewidth = 0.4) +
        geom_segment(aes(xend = lag, yend = 0), linewidth = 0.6,
                     colour = "grey25") +
        geom_point(size = 1.1, colour = "grey15") +
        labs(title = titulo, subtitle = subtitulo,
             x = "Defasagem (lag)", y = tabela$tipo[1])
}

######@> Bateria de diagnósticos de uma série temporal...
## Reúne, em uma linha, tudo o que se costuma olhar antes de modelar:
## autocorrelação de 1ª ordem e sazonal, teste global de ruído branco
## (Ljung-Box), os dois testes de estacionariedade e o coeficiente de
## variação.
##
## ADF e KPSS têm hipóteses nulas OPOSTAS - o ADF testa H0: raiz
## unitária (não estacionária) e o KPSS testa H0: estacionariedade -, e
## por isso são reportados juntos: concordância entre eles é evidência
## forte; discordância indica série com tendência determinística, que é
## o caso de várias séries climáticas deste conjunto.
diagnosticar_serie <- function(x, lag_teste = 24, sazonal_lag = 12) {
    x <- as.numeric(x)
    n <- length(x)
    res <- tibble(n = n,
                  media = mean(x, na.rm = TRUE),
                  dp = sd(x, na.rm = TRUE),
                  cv = NA_real_,
                  acf1 = NA_real_,
                  acf_sazonal = NA_real_,
                  ljung_box_p = NA_real_,
                  adf_p = NA_real_,
                  kpss_p = NA_real_,
                  estacionaria = NA_character_)
    res$cv <- ifelse(abs(res$media) > 0, res$dp / abs(res$media),
                     NA_real_)
    if(n < 24 || var(x, na.rm = TRUE) == 0) return(res)
    ac <- acf(x, lag.max = max(sazonal_lag, 1), plot = FALSE)$acf
    res$acf1 <- as.numeric(ac[2])
    if(length(ac) > sazonal_lag) {
        res$acf_sazonal <- as.numeric(ac[sazonal_lag + 1])
    }
    lag_teste <- min(lag_teste, floor(n / 4))
    res$ljung_box_p <- tryCatch(
        Box.test(x, lag = lag_teste, type = "Ljung-Box")$p.value,
        error = function(e) NA_real_)
    res$adf_p <- tryCatch(suppressWarnings(adf.test(x)$p.value),
                          error = function(e) NA_real_)
    res$kpss_p <- tryCatch(suppressWarnings(kpss.test(x)$p.value),
                           error = function(e) NA_real_)
    ## Leitura conjunta dos dois testes. Os p-valores de adf.test() e
    ## kpss.test() são truncados nos extremos da tabela (0,01 e 0,10),
    ## o que não afeta a classificação abaixo.
    res$estacionaria <- dplyr::case_when(
        is.na(res$adf_p) | is.na(res$kpss_p) ~ NA_character_,
        res$adf_p < alfa & res$kpss_p > alfa ~ "Estacionária",
        res$adf_p >= alfa & res$kpss_p <= alfa ~ "Não estacionária",
        res$adf_p < alfa & res$kpss_p <= alfa ~
            "Tendência determinística",
        TRUE ~ "Indefinida")
    return(res)
}

######@> Força das componentes de uma decomposição STL...
## Medidas de Wang, Smith e Hyndman: a força da sazonalidade (ou da
## tendência) é 1 menos a razão entre a variância do resíduo e a
## variância do resíduo somado à componente de interesse. Vale 0 quando
## a componente não acrescenta nada e tende a 1 quando ela domina.
##
## É a métrica que permite comparar variáveis medidas em unidades
## diferentes - a temperatura em graus e a precipitação em mm/dia não
## teriam decomposições comparáveis em escala absoluta.
forca_stl <- function(serie_ts, s_window = "periodic") {
    ajuste <- stl(serie_ts, s.window = s_window)
    comp <- as.data.frame(ajuste$time.series)
    r <- comp$remainder
    tibble(forca_sazonal =
               max(0, 1 - var(r) / var(comp$seasonal + r)),
           forca_tendencia =
               max(0, 1 - var(r) / var(comp$trend + r)),
           var_residual = var(r))
}

######@> Conversão de série mensal em objeto ts...
## Centralizada para que todas as séries do script comecem no mesmo
## ponto de origem e tenham a mesma frequência declarada.
como_ts <- function(x, ano_inicio, mes_inicio = 1) {
    ts(as.numeric(x), start = c(ano_inicio, mes_inicio), frequency = 12)
}

########################################################################
######@> Etapa 01 - Leitura da base e preparação...

message("=== AED ERA5 - início ===")
message("Lendo base padronizada...")

if(!file.exists(arq_base)) {
    stop("Base não encontrada. Execute antes ",
         "script_ERA5_extracao_municipios_ver01.R")
}

load(arq_base)

######@> Objeto focal da análise...
## A base pedida. Todas as séries deste script derivam dela, de modo
## que não há caminho alternativo de cálculo que possa divergir dos
## números apresentados.
era5 <- dados_municipio_final

######@> Conferência de integridade antes de analisar...
## A base é uma GRADE COMPLETA: cada município deve ter exatamente uma
## linha por mês do período. Se a contagem não fechar, alguma junção se
## perdeu na padronização e nenhuma conclusão adiante seria confiável.
n_mun_base <- n_distinct(era5$geocodigo)
n_meses_base <- n_distinct(paste(era5$ano, era5$mes))

stopifnot(nrow(era5) == n_mun_base * n_meses_base,
          !any(duplicated(era5[, c("geocodigo", "ano", "mes")])))

message("Grade conferida: ", n_mun_base, " municípios x ",
        n_meses_base, " meses = ", fmt_int(nrow(era5)), " linhas")

######@> Metadados das variáveis analisadas...
## Cada variável recebe rótulo legível, unidade e domínio climático. O
## domínio organiza as figuras e as tabelas: variáveis do mesmo domínio
## contam a mesma história e são apresentadas juntas.
##
## A coluna "origem" separa o que veio do ERA5 do que é derivado neste
## script. As derivadas são três combinações que respondem perguntas
## que nenhuma variável isolada responde: se o município ganha ou perde
## água no mês (balanço hídrico), quanto da chuva é convectiva (regime
## de tempestade x frontal) e quão constante é a direção do vento.
vars_meta <- tribble(
    ~variavel,           ~rotulo,                        ~unidade,     ~dominio,       ~origem,
    "t2m_C",             "Temperatura do ar a 2 m",      "°C",         "Térmico",      "ERA5",
    "tp_mm_dia",         "Precipitação total",           "mm/dia",     "Hídrico",      "ERA5",
    "cp_mm_dia",         "Precipitação convectiva",      "mm/dia",     "Hídrico",      "ERA5",
    "lsrr_mm_dia",       "Chuva de larga escala",        "mm/dia",     "Hídrico",      "ERA5",
    "e_mm_dia",          "Evaporação",                   "mm/dia",     "Hídrico",      "ERA5",
    "pev_mm_dia",        "Evaporação potencial",         "mm/dia",     "Hídrico",      "ERA5",
    "tcrw",              "Água de chuva na coluna",      "kg/m²",      "Hídrico",      "ERA5",
    "ptype",             "Índice de tipo de precip.",    "0-1",        "Hídrico",      "ERA5",
    "slhf_W_m2",         "Fluxo de calor latente",       "W/m²",       "Radiativo",    "ERA5",
    "ssr_W_m2",          "Radiação solar líquida",       "W/m²",       "Radiativo",    "ERA5",
    "tcc_pct",           "Cobertura de nuvens",          "%",          "Nebulosidade", "ERA5",
    "si10",              "Velocidade do vento a 10 m",   "m/s",        "Vento",        "ERA5",
    "vento_vel_m_s",     "Módulo do vento médio",        "m/s",        "Vento",        "ERA5",
    "balanco_hidrico",   "Balanço hídrico (P - E)",      "mm/dia",     "Hídrico",      "Derivada",
    "fracao_convectiva", "Fração convectiva da chuva",   "0-1",        "Hídrico",      "Derivada",
    "constancia_vento",  "Constância direcional",        "0-1",        "Vento",        "Derivada")

######@> Variáveis candidatas a campo estático ou climatológico...
## Submetidas à triagem da Etapa 02 e mantidas fora das análises
## temporais se a triagem confirmar a suspeita.
vars_candidatas_fixas <- c("cvh", "cvl", "tvh", "tvl",
                           "lai_hv", "lai_lv")

######@> Construção das variáveis derivadas...
## balanco_hidrico  : e_mm_dia é NEGATIVO na convenção do ERA5 (perda de
##                    água pela superfície), de modo que a soma com a
##                    precipitação já é o balanço; escrever "tp - e"
##                    duplicaria a evaporação com o sinal trocado;
## fracao_convectiva: participação da chuva convectiva no total. Valores
##                    altos indicam regime de instabilidade (verão,
##                    tempestades locais); baixos, chuva estratiforme de
##                    origem frontal;
## constancia_vento : ver função constancia_direcional().
era5 <- era5 %>%
    mutate(balanco_hidrico = tp_mm_dia + e_mm_dia,
           fracao_convectiva = ifelse(tp_mm_dia > 0,
                                      cp_mm_dia / tp_mm_dia, NA_real_),
           constancia_vento = constancia_direcional(vento_vel_m_s,
                                                    si10),
           estacao = factor(estacao_do_mes[mes],
                            levels = ordem_estacoes),
           mes_nome = factor(meses_abrev[mes], levels = meses_abrev),
           decada = (ano %/% 10) * 10)

######@> Vetores de referência...
municipios_nomes <- sort(unique(era5$municipio))
anos_todos <- sort(unique(era5$ano))
ano_min <- min(anos_todos)
ano_max <- max(anos_todos)
n_municipios <- length(municipios_nomes)

vars_todas <- vars_meta$variavel
vars_dominio <- setNames(vars_meta$dominio, vars_meta$variavel)
vars_rotulo <- setNames(vars_meta$rotulo, vars_meta$variavel)
vars_unidade <- setNames(vars_meta$unidade, vars_meta$variavel)

######@> Rótulo com unidade, usado nos eixos das figuras...
rotular <- function(v) {
    paste0(vars_rotulo[v], " (", vars_unidade[v], ")")
}

######@> Subconjunto de anos completos...
## Todas as climatologias, séries anuais e testes de tendência usam
## este objeto. O ano parcial permanece disponível em era5 e é
## reportado no panorama, mas nunca entra em uma média anual.
meses_ano_parcial <- era5 %>%
    filter(ano > ano_fim_completo) %>%
    summarise(n = n_distinct(mes)) %>%
    pull(n)

dat <- era5 %>% filter(ano <= ano_fim_completo)

anos <- sort(unique(dat$ano))
n_anos <- length(anos)
ano_ini_analise <- min(anos)
ano_fim_analise <- max(anos)

message("Período analisado: ", ano_ini_analise, "-", ano_fim_analise,
        " (", n_anos, " anos completos)")
if(ano_max > ano_fim_completo) {
    message("  Ano parcial excluído das médias: ", ano_max,
            " (", meses_ano_parcial, " meses)")
}

######@> Variáveis-chave para as análises de custo elevado...
## As dezesseis variáveis são analisadas no agregado do litoral. As
## rotinas que se repetem por município (diagnósticos completos,
## painéis, correlogramas individuais) usam este subconjunto de cinco,
## escolhido para cobrir todos os domínios sem redundância: térmico,
## hídrico, radiativo, vento e nebulosidade.
vars_chave <- c("t2m_C", "tp_mm_dia", "si10", "ssr_W_m2", "tcc_pct")

######@> Ponderação espacial das séries do litoral...
## A série regional é a média das séries municipais PONDERADA PELA ÁREA.
## A média simples daria a Bombinhas (36 km²) o mesmo peso que a
## Joinville (1.130 km²), o que distorceria o retrato regional; a
## ponderação pela área faz a série representar o território, e não o
## conjunto de unidades administrativas.
pesos_area <- dat %>%
    distinct(geocodigo, municipio, area_km2, lon_centroide,
             lat_centroide, n_pixels) %>%
    mutate(peso = area_km2 / sum(area_km2))

######@> Formato longo das variáveis dinâmicas...
## Base de trabalho de quase toda a análise. Manter um único objeto
## longo evita repetir, para cada variável, o mesmo bloco de código com
## o nome da coluna trocado - e garante que todas as variáveis recebam
## exatamente o mesmo tratamento.
longo <- dat %>%
    select(geocodigo, municipio, ano, mes, data, estacao, mes_nome,
           decada, all_of(vars_todas)) %>%
    pivot_longer(all_of(vars_todas), names_to = "variavel",
                 values_to = "valor") %>%
    left_join(select(pesos_area, geocodigo, peso), by = "geocodigo") %>%
    mutate(dominio = vars_dominio[variavel])

######@> Série mensal do litoral (média ponderada pela área)...
litoral_mensal <- longo %>%
    group_by(variavel, dominio, ano, mes, data, estacao, mes_nome) %>%
    summarise(valor = sum(valor * peso, na.rm = TRUE) /
                  sum(peso[!is.na(valor)]), .groups = "drop") %>%
    arrange(variavel, ano, mes)

######@> Série anual do litoral...
litoral_anual <- litoral_mensal %>%
    group_by(variavel, dominio, ano) %>%
    summarise(valor = mean(valor), .groups = "drop")

######@> Séries municipais anuais...
mun_anual <- longo %>%
    group_by(geocodigo, municipio, variavel, dominio, ano) %>%
    summarise(valor = mean(valor, na.rm = TRUE), .groups = "drop")

######@> Direção média do vento, calculada vetorialmente...
## Tratada fora do objeto longo porque não admite média aritmética
## (ver função direcao_media). Calculada por município e por mês do
## ano, para descrever o regime direcional sazonal.
vento_direcao <- dat %>%
    group_by(geocodigo, municipio, mes) %>%
    summarise(direcao = direcao_media(u10, v10),
              vel_escalar = mean(si10),
              vel_vetorial = mean(vento_vel_m_s),
              .groups = "drop") %>%
    mutate(constancia = vel_vetorial / vel_escalar,
           mes_nome = factor(meses_abrev[mes], levels = meses_abrev))

######@> Leitura e preparo do shapefile para os mapas...
message("Lendo shapefile...")
shape_bruto <- st_read(arq_shape, quiet = TRUE) %>% st_make_valid()
shape_bruto <- st_transform(shape_bruto, crs_projeto)

######@> Recuperação de código e nome a partir de colunas alternativas...
## O shapefile carrega três gerações de colunas de identificação, cada
## uma com lacunas em feições distintas. O coalesce reconstrói o
## identificador completo - conferido adiante contra a base do ERA5.
atributos <- st_drop_geometry(shape_bruto)
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))

municipios_sf <- shape_bruto %>%
    group_by(geocodigo) %>%
    summarise(.groups = "drop") %>%
    st_make_valid() %>%
    left_join(distinct(pesos_area, geocodigo, municipio, area_km2,
                       n_pixels, lon_centroide, lat_centroide),
              by = "geocodigo")

######@> Conferência da correspondência espacial...
## Diferente do Atlas Digital, aqui NÃO há município sem dado: a
## reanálise cobre todo o território, e os 37 municípios do shapefile
## têm série completa. A verificação é mantida porque uma divergência
## silenciosa inutilizaria todos os mapas.
sem_dado <- setdiff(municipios_sf$geocodigo, unique(dat$geocodigo))
sem_mapa <- setdiff(unique(dat$geocodigo), municipios_sf$geocodigo)

if(length(sem_dado) > 0 || length(sem_mapa) > 0) {
    warning("Divergência entre shapefile e base: ",
            length(sem_dado), " sem dado, ", length(sem_mapa),
            " sem mapa.")
}

message("Municípios analisados: ", n_municipios,
        " | no mapa: ", nrow(municipios_sf))

######@> Lista acumuladora das tabelas exportadas...
## Cada tabela produzida é registrada aqui e, ao final, todas são
## gravadas também em um único arquivo XLSX com uma aba por tabela.
tabelas <- list()

########################################################################
######@> Etapa 02 - Panorama, completude e triagem das variáveis...

message("\n--- Etapa 02: panorama e triagem das variáveis ---")

######@> Ficha da base analisada...
panorama <- tibble(
    Indicador = c("Fonte",
                  "Resolução espacial original",
                  "Período disponível na base",
                  "Período analisado (anos completos)",
                  "Ano parcial excluído",
                  "Municípios",
                  "Meses por município",
                  "Linhas da base",
                  "Colunas da base",
                  "Variáveis originais do ERA5",
                  "Variáveis derivadas neste script",
                  "Pixels ERA5 utilizados",
                  "Pixels por município (mín-máx)",
                  "Municípios cobertos por 1 único pixel",
                  "Pixels dominantes distintos",
                  "Área total do recorte (km²)",
                  "Normal climatológica de referência",
                  "Valores ausentes nas variáveis analisadas"),
    Valor = c(
        "Reanálise ERA5 (ECMWF / Copernicus)",
        "0,25° (~27 km)",
        paste0(ano_min, "-", ano_max),
        paste0(ano_ini_analise, "-", ano_fim_analise, " (", n_anos,
               " anos)"),
        paste0(ano_max, " (", meses_ano_parcial, " meses)"),
        as.character(n_municipios),
        as.character(n_meses_base),
        fmt_int(nrow(era5)),
        as.character(ncol(era5)),
        as.character(sum(vars_meta$origem == "ERA5")),
        as.character(sum(vars_meta$origem == "Derivada")),
        as.character(n_distinct(tabela_pesos$celula)),
        paste0(min(pesos_area$n_pixels), "-", max(pesos_area$n_pixels)),
        as.character(sum(pesos_area$n_pixels == 1)),
        as.character(tabela_pesos %>%
                     group_by(geocodigo) %>%
                     slice_max(fracao_cobertura, n = 1,
                               with_ties = FALSE) %>%
                     ungroup() %>%
                     summarise(n = n_distinct(celula)) %>% pull(n)),
        fmt_int(round(sum(pesos_area$area_km2))),
        paste0(ref_ini, "-", ref_fim),
        fmt_int(sum(is.na(select(dat, all_of(vars_todas)))))))

tabelas[["Tab_01_panorama_geral"]] <-
    salvar_tab(panorama, "Tab_01_panorama_geral")

######@> Triagem: o que é série temporal e o que é campo fixo...
## A pergunta desta seção é a mais elementar possível e, ainda assim,
## decide o restante do script: cada coluna VARIA no tempo?
##
## Três medidas separam os casos:
##
##   dp_temporal   : desvio-padrão da série completa dentro de cada
##                   município. Zero significa campo constante;
##   dp_entre_anos : desvio-padrão entre anos PARA UM MESMO MÊS. Uma
##                   variável com sazonalidade real mas sem
##                   variabilidade interanual tem dp_temporal alto e
##                   dp_entre_anos praticamente nulo - assinatura de
##                   uma climatologia imposta, não de uma observação;
##   dp_entre_mun  : desvio-padrão entre municípios no mesmo mês, que
##                   indica se a variável ao menos discrimina o espaço.
##
## A razão dp_entre_anos / dp_temporal é o critério operacional: abaixo
## de 1% a variável é tratada como climatologia fixa.
triagem_vars <- bind_rows(
    lapply(c(vars_todas, vars_candidatas_fixas), function(v) {
        x <- dat[[v]]
        d_temp <- dat %>%
            group_by(geocodigo) %>%
            summarise(s = sd(.data[[v]], na.rm = TRUE),
                      .groups = "drop") %>%
            pull(s) %>% mean(na.rm = TRUE)
        d_ano <- dat %>%
            group_by(geocodigo, mes) %>%
            summarise(s = sd(.data[[v]], na.rm = TRUE),
                      .groups = "drop") %>%
            pull(s) %>% mean(na.rm = TRUE)
        d_mun <- dat %>%
            group_by(ano, mes) %>%
            summarise(s = sd(.data[[v]], na.rm = TRUE),
                      .groups = "drop") %>%
            pull(s) %>% mean(na.rm = TRUE)
        tibble(variavel = v,
               media = mean(x, na.rm = TRUE),
               dp_temporal = d_temp,
               dp_entre_anos = d_ano,
               dp_entre_mun = d_mun,
               razao_interanual = ifelse(d_temp > 0, d_ano / d_temp,
                                         NA_real_))
    }))

triagem_vars <- triagem_vars %>%
    mutate(classificacao = case_when(
               is.na(dp_temporal) | dp_temporal == 0 ~
                   "Campo estático",
               razao_interanual < 0.01 ~ "Climatologia fixa",
               TRUE ~ "Série dinâmica"),
           usada_nas_series = classificacao == "Série dinâmica",
           rotulo = ifelse(variavel %in% names(vars_rotulo),
                           vars_rotulo[variavel], variavel)) %>%
    arrange(classificacao, desc(razao_interanual))

tabelas[["Tab_02_triagem_variaveis"]] <-
    salvar_tab(triagem_vars, "Tab_02_triagem_variaveis")

######@> Consequência da triagem...
## As variáveis reprovadas são retiradas de tudo o que se segue. O
## script INTERROMPE se alguma variável do conjunto focal for
## reprovada, porque isso significaria que a premissa de desenho da
## análise mudou e o restante do código não faria mais sentido.
vars_estaticas <- triagem_vars %>%
    filter(!usada_nas_series) %>% pull(variavel)

vars_dinamicas <- triagem_vars %>%
    filter(usada_nas_series, variavel %in% vars_todas) %>%
    pull(variavel)

if(!all(vars_todas %in% vars_dinamicas)) {
    stop("Variável do conjunto focal reprovada na triagem: ",
         paste(setdiff(vars_todas, vars_dinamicas), collapse = ", "))
}

message("Variáveis dinâmicas : ", length(vars_dinamicas))
message("Campos fixos        : ", length(vars_estaticas), " (",
        paste(vars_estaticas, collapse = ", "), ")")

######@> Descritores estáticos do município...
## As variáveis reprovadas não desaparecem da análise: elas descrevem a
## SUPERFÍCIE sobre a qual o clima atua (tipo e cobertura de vegetação,
## índice de área foliar) e entram adiante como características fixas
## dos municípios no agrupamento por perfil.
descritores_fixos <- dat %>%
    group_by(geocodigo, municipio) %>%
    summarise(across(all_of(vars_candidatas_fixas),
                     ~mean(.x, na.rm = TRUE)), .groups = "drop") %>%
    left_join(select(pesos_area, geocodigo, area_km2, n_pixels,
                     lat_centroide, lon_centroide), by = "geocodigo")

tabelas[["Tab_03_descritores_fixos"]] <-
    salvar_tab(descritores_fixos, "Tab_03_descritores_fixos")

######@> Figura 01 - resultado da triagem...
## O eixo horizontal em escala logarítmica é indispensável: a razão
## interanual das variáveis dinâmicas fica entre 0,2 e 1, enquanto a
## das climatologias fixas é da ordem de 0,0001 - quatro ordens de
## grandeza abaixo. Em escala linear todas as reprovadas colapsariam
## sobre o zero e o gráfico não mostraria a separação.
dados_triagem <- triagem_vars %>%
    filter(!is.na(razao_interanual), razao_interanual > 0) %>%
    mutate(rotulo = factor(rotulo,
                           levels = rotulo[order(razao_interanual)]))

base_segmento <- min(dados_triagem$razao_interanual) * 0.5

f01 <- ggplot(dados_triagem,
              aes(x = razao_interanual, y = rotulo,
                  colour = classificacao)) +
    geom_vline(xintercept = 0.01, linetype = "dashed",
               colour = "grey40") +
    geom_segment(aes(xend = base_segmento, yend = rotulo),
                 linewidth = 0.5) +
    geom_point(size = 2.6) +
    scale_x_log10(labels = label_number(accuracy = 0.0001)) +
    scale_colour_manual(values = c("Série dinâmica" = "#0072B2",
                                   "Climatologia fixa" = "#D55E00",
                                   "Campo estático" = "#999999"),
                        name = "Classificação") +
    labs(title = "Triagem das variáveis: o que varia entre anos?",
         subtitle = paste0("Razão entre a variabilidade interanual e a ",
                           "variabilidade temporal total, ",
                           ano_ini_analise, "-", ano_fim_analise),
         x = "dp entre anos / dp temporal (escala log)",
         y = NULL,
         caption = quebrar(paste(
             "Linha tracejada: critério de 1% adotado para separar série",
             "de climatologia. Variáveis à esquerda dela repetem o mesmo",
             "valor todos os anos para um dado mês e não são séries",
             "observadas. Campos com desvio-padrão temporal exatamente",
             "zero (cvh, cvl, tvh, tvl) não aparecem, por não terem razão",
             "definida.")))

salvar_fig(f01, "Fig_01_triagem_variaveis", largura = 10, altura = 6.5)

######@> Resumo estatístico das variáveis dinâmicas...
resumo_vars <- longo %>%
    group_by(variavel, dominio) %>%
    summarise(n = sum(!is.na(valor)),
              media = mean(valor, na.rm = TRUE),
              dp = sd(valor, na.rm = TRUE),
              minimo = min(valor, na.rm = TRUE),
              q25 = quantile(valor, 0.25, na.rm = TRUE),
              mediana = median(valor, na.rm = TRUE),
              q75 = quantile(valor, 0.75, na.rm = TRUE),
              maximo = max(valor, na.rm = TRUE),
              assimetria = mean((valor - mean(valor, na.rm = TRUE))^3,
                                na.rm = TRUE) /
                  sd(valor, na.rm = TRUE)^3,
              .groups = "drop") %>%
    mutate(rotulo = vars_rotulo[variavel],
           unidade = vars_unidade[variavel]) %>%
    select(variavel, rotulo, unidade, dominio, everything())

tabelas[["Tab_04_resumo_variaveis"]] <-
    salvar_tab(resumo_vars, "Tab_04_resumo_variaveis")

######@> Decomposição da variância: espaço x tempo...
## Qual fração da variação total de cada variável está entre
## MUNICÍPIOS e qual está entre MESES? A resposta define onde a
## informação da variável reside e, portanto, o que um modelo pode
## esperar extrair dela.
##
## Uma variável com quase toda a variância no tempo (caso da
## temperatura) não distingue municípios: usá-la como preditora de
## diferenças espaciais entre eles seria improdutivo. Uma variável com
## fração espacial relevante permite contraste entre municípios no
## mesmo mês.
##
## A decomposição usa somas de quadrados de um modelo aditivo com os
## dois fatores, sem interação - o resíduo é justamente a interação
## espaço-tempo, isto é, o quanto os municípios se comportam de forma
## diferente entre si ao longo do tempo.
decomp_variancia <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        d <- longo %>% filter(variavel == v, !is.na(valor))
        mm <- mean(d$valor)
        ef_mun <- d %>% group_by(geocodigo) %>%
            summarise(m = mean(valor), n = n(), .groups = "drop")
        ef_tempo <- d %>% group_by(data) %>%
            summarise(m = mean(valor), n = n(), .groups = "drop")
        sq_total <- sum((d$valor - mm)^2)
        sq_mun <- sum(ef_mun$n * (ef_mun$m - mm)^2)
        sq_tempo <- sum(ef_tempo$n * (ef_tempo$m - mm)^2)
        tibble(variavel = v,
               pct_espacial = 100 * sq_mun / sq_total,
               pct_temporal = 100 * sq_tempo / sq_total,
               pct_interacao = 100 *
                   (sq_total - sq_mun - sq_tempo) / sq_total)
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           dominio = vars_dominio[variavel],
           escala_dominante = case_when(
               pct_temporal > 70 ~ "Temporal",
               pct_espacial > 30 ~ "Espacial relevante",
               TRUE ~ "Mista")) %>%
    arrange(desc(pct_temporal))

tabelas[["Tab_05_decomposicao_variancia"]] <-
    salvar_tab(decomp_variancia, "Tab_05_decomposicao_variancia")

######@> Figura 02 - onde reside a variância de cada variável...
f02 <- decomp_variancia %>%
    select(rotulo, pct_espacial, pct_temporal, pct_interacao) %>%
    pivot_longer(-rotulo, names_to = "componente",
                 values_to = "pct") %>%
    mutate(componente = recode(componente,
                               pct_espacial = "Entre municípios",
                               pct_temporal = "Entre meses",
                               pct_interacao = "Interação espaço-tempo"),
           componente = factor(componente,
                               levels = c("Entre meses",
                                          "Entre municípios",
                                          "Interação espaço-tempo")),
           rotulo = factor(rotulo,
                           levels = rev(decomp_variancia$rotulo))) %>%
    ggplot(aes(x = pct, y = rotulo, fill = componente)) +
    geom_col(width = 0.75) +
    scale_fill_manual(values = c("Entre meses" = "#0072B2",
                                 "Entre municípios" = "#D55E00",
                                 "Interação espaço-tempo" = "#999999"),
                      name = NULL) +
    scale_x_continuous(labels = label_percent(scale = 1),
                       expand = expansion(mult = c(0, 0.01))) +
    labs(title = "Onde está a variância de cada variável climática",
         subtitle = paste0("Decomposição aditiva da soma de quadrados, ",
                           n_municipios, " municípios x ", n_anos * 12,
                           " meses"),
         x = "Participação na variância total", y = NULL,
         caption = quebrar(paste(
             "Variáveis no topo têm praticamente toda a sua variação no",
             "tempo e quase nenhuma entre municípios: não discriminam o",
             "espaço deste recorte. A interação espaço-tempo mede o",
             "quanto os municípios divergem entre si ao longo da série -",
             "é ela, e não a fração espacial, que sustenta contrastes",
             "municipais dinâmicos.")))

salvar_fig(f02, "Fig_02_decomposicao_variancia", largura = 10,
           altura = 6.5)

########################################################################
######@> Etapa 03 - Climatologia e ciclo sazonal...

message("\n--- Etapa 03: climatologia e ciclo sazonal ---")

######@> Normal climatológica de referência...
## Média de cada mês do ano, por município e variável, no período de
## referência. É a base de cálculo das anomalias e, portanto, o objeto
## mais reutilizado do script.
##
## O desvio-padrão do período de referência é guardado junto porque as
## anomalias padronizadas (anomalia dividida por este desvio) são o que
## permite comparar meses de variáveis diferentes na mesma figura: um
## desvio de 1 °C e um de 1 mm/dia não são comparáveis em unidade
## bruta, mas o são em número de desvios-padrão.
clima_ref <- longo %>%
    filter(ano >= ref_ini, ano <= ref_fim) %>%
    group_by(geocodigo, variavel, mes) %>%
    summarise(normal = mean(valor, na.rm = TRUE),
              dp_ref = sd(valor, na.rm = TRUE), .groups = "drop")

######@> Anomalias mensais...
longo <- longo %>%
    left_join(clima_ref, by = c("geocodigo", "variavel", "mes")) %>%
    mutate(anomalia = valor - normal,
           anomalia_z = ifelse(dp_ref > 0, anomalia / dp_ref, NA_real_))

######@> Climatologia do litoral...
## Agrega a normal municipal pela mesma ponderação de área usada nas
## séries, de modo que a climatologia regional e as séries regionais
## sejam mutuamente consistentes.
clima_litoral <- longo %>%
    filter(ano >= ref_ini, ano <= ref_fim) %>%
    group_by(variavel, dominio, mes) %>%
    summarise(normal = sum(valor * peso) / sum(peso),
              p10 = quantile(valor, 0.10),
              p90 = quantile(valor, 0.90),
              .groups = "drop") %>%
    mutate(mes_nome = factor(meses_abrev[mes], levels = meses_abrev),
           rotulo = vars_rotulo[variavel],
           unidade = vars_unidade[variavel])

tabelas[["Tab_06_climatologia_litoral"]] <-
    salvar_tab(clima_litoral %>%
               select(variavel, rotulo, unidade, dominio, mes,
                      mes_nome, normal, p10, p90),
               "Tab_06_climatologia_litoral")

######@> Caracterização do ciclo sazonal por variável...
## Três medidas resumem o ciclo:
##
##   amplitude          : diferença entre o mês de maior e o de menor
##                        normal, na unidade da variável;
##   amplitude_relativa : a mesma amplitude expressa em desvios-padrão
##                        da série mensal completa. Torna comparáveis
##                        variáveis de unidades distintas e responde à
##                        pergunta que interessa - a sazonalidade é
##                        grande FRENTE À variabilidade total da série?
##   mes_pico / mes_vale: quando ocorrem os extremos do ciclo.
##
## A amplitude relativa é preferida ao índice sazonal multiplicativo
## (razão entre o mês e a média anual) usado na AED do Atlas, porque
## três variáveis deste conjunto são negativas por construção
## (evaporação, calor latente, balanço hídrico) e uma razão sobre média
## negativa inverteria a leitura.
ciclo_sazonal <- clima_litoral %>%
    group_by(variavel, dominio) %>%
    summarise(media_anual = mean(normal),
              amplitude = max(normal) - min(normal),
              mes_pico = meses_abrev[mes[which.max(normal)]],
              mes_vale = meses_abrev[mes[which.min(normal)]],
              .groups = "drop") %>%
    left_join(resumo_vars %>% select(variavel, dp), by = "variavel") %>%
    mutate(amplitude_relativa = amplitude / dp,
           rotulo = vars_rotulo[variavel],
           unidade = vars_unidade[variavel]) %>%
    arrange(desc(amplitude_relativa)) %>%
    select(variavel, rotulo, unidade, dominio, media_anual, amplitude,
           amplitude_relativa, mes_pico, mes_vale)

tabelas[["Tab_07_ciclo_sazonal"]] <-
    salvar_tab(ciclo_sazonal, "Tab_07_ciclo_sazonal")

######@> Figura 03 - ciclo anual de todas as variáveis...
## Escalas livres em cada painel: o objetivo é a FORMA do ciclo, não a
## comparação de níveis entre variáveis, que seria impossível com
## unidades tão distintas quanto W/m² e mm/dia.
f03 <- clima_litoral %>%
    mutate(painel = paste0(rotulo, " (", unidade, ")"),
           painel = factor(painel,
                           levels = paste0(vars_meta$rotulo, " (",
                                           vars_meta$unidade, ")"))) %>%
    ggplot(aes(x = mes, y = normal)) +
    geom_ribbon(aes(ymin = p10, ymax = p90, fill = dominio),
                alpha = 0.25) +
    geom_line(aes(colour = dominio), linewidth = 0.8) +
    geom_point(aes(colour = dominio), size = 1.1) +
    facet_wrap(~painel, scales = "free_y", ncol = 4) +
    scale_x_continuous(breaks = c(1, 4, 7, 10),
                       labels = meses_abrev[c(1, 4, 7, 10)]) +
    scale_colour_manual(values = cores_dominio, name = "Domínio") +
    scale_fill_manual(values = cores_dominio, name = "Domínio") +
    labs(title = "Ciclo anual das variáveis climáticas do litoral",
         subtitle = paste0("Normal climatológica ", ref_ini, "-",
                           ref_fim, ", média ponderada pela área dos ",
                           n_municipios, " municípios"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Linha: normal mensal. Faixa sombreada: intervalo entre os",
             "percentis 10 e 90 das observações municipais do período de",
             "referência, que mede conjuntamente a variabilidade",
             "interanual e a dispersão entre municípios. Escalas",
             "verticais livres por painel.")))

salvar_fig(f03, "Fig_03_ciclo_anual_variaveis", largura = 13,
           altura = 9)

######@> Figura 04 - ciclo anual município a município...
## Um traço por município. A leitura decisiva desta figura é o
## PARALELISMO: se as curvas apenas se deslocam verticalmente sem mudar
## de forma, os municípios compartilham o mesmo regime sazonal e
## diferem apenas em nível - exatamente a redundância quantificada na
## Etapa 10.
f04 <- longo %>%
    filter(variavel %in% vars_chave, ano >= ref_ini, ano <= ref_fim) %>%
    group_by(variavel, municipio, mes) %>%
    summarise(normal = mean(valor), .groups = "drop") %>%
    mutate(painel = rotular(variavel),
           painel = factor(painel, levels = rotular(vars_chave))) %>%
    ggplot(aes(x = mes, y = normal, group = municipio)) +
    geom_line(alpha = 0.45, linewidth = 0.4, colour = "#0072B2") +
    facet_wrap(~painel, scales = "free_y", ncol = 3) +
    scale_x_continuous(breaks = c(1, 4, 7, 10),
                       labels = meses_abrev[c(1, 4, 7, 10)]) +
    labs(title = "Ciclo anual de cada município, sobreposto",
         subtitle = paste0("Normais ", ref_ini, "-", ref_fim, ", ",
                           n_municipios, " municípios, variáveis-chave"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Curvas paralelas indicam regime sazonal comum, com os",
             "municípios diferindo apenas em nível médio. Onde as curvas",
             "se cruzam ou mudam de forma há contraste espacial",
             "aproveitável - o que ocorre sobretudo no vento e na",
             "precipitação.")))

salvar_fig(f04, "Fig_04_ciclo_anual_municipios", largura = 12,
           altura = 7)

######@> Série vetorial de vento do litoral...
## As componentes u10 e v10 são agregadas ANTES de converter em
## direção e intensidade, porque o caminho inverso - mediar ângulos -
## seria incorreto (ver função direcao_media).
litoral_vento <- dat %>%
    left_join(select(pesos_area, geocodigo, peso), by = "geocodigo") %>%
    group_by(ano, mes, data, estacao) %>%
    summarise(u10 = sum(u10 * peso) / sum(peso),
              v10 = sum(v10 * peso) / sum(peso),
              si10 = sum(si10 * peso) / sum(peso),
              .groups = "drop") %>%
    mutate(direcao = (atan2(-u10, -v10) * 180 / pi) %% 360,
           vel_vetorial = sqrt(u10^2 + v10^2),
           constancia = vel_vetorial / si10)

######@> Rosa dos ventos sazonal...
## Direção agrupada em dezesseis setores de 22,5 graus, na convenção
## meteorológica (0 = vento vindo do norte). A contagem é de MESES, e
## não de horas: cada ponto é um mês inteiro cuja resultante vetorial
## apontou para aquele setor.
setores <- c("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
             "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO")

rosa_dados <- litoral_vento %>%
    mutate(setor_id = (floor((direcao + 11.25) / 22.5) %% 16) + 1,
           setor = factor(setores[setor_id], levels = setores),
           classe_vel = cut(si10, breaks = c(-Inf, 2.5, 3, 3.5, Inf),
                            labels = c("< 2,5", "2,5 - 3,0",
                                       "3,0 - 3,5", "> 3,5"))) %>%
    count(estacao, setor, classe_vel, .drop = FALSE) %>%
    group_by(estacao) %>%
    mutate(pct = 100 * n / sum(n)) %>%
    ungroup()

tabelas[["Tab_08_regime_vento_sazonal"]] <-
    salvar_tab(rosa_dados %>% filter(n > 0), "Tab_08_regime_vento_sazonal")

######@> Figura 05 - rosa dos ventos por estação...
f05 <- ggplot(rosa_dados, aes(x = setor, y = pct, fill = classe_vel)) +
    geom_col(width = 1, colour = "white", linewidth = 0.15) +
    coord_polar(start = -pi / 16) +
    facet_wrap(~estacao, nrow = 1) +
    scale_fill_viridis_d(option = "D", direction = -1,
                         name = "Velocidade (m/s)") +
    labs(title = "Regime direcional do vento por estação do ano",
         subtitle = paste0("Resultante vetorial mensal do litoral, ",
                           ano_ini_analise, "-", ano_fim_analise,
                           " (", n_anos * 12, " meses)"),
         x = NULL, y = "% dos meses",
         caption = quebrar(paste(
             "Convenção meteorológica: o setor indica a direção DE ONDE o",
             "vento sopra. As classes de velocidade usam si10 (média da",
             "velocidade escalar), e não o módulo da resultante, para que",
             "a intensidade não apareça atenuada pelo cancelamento",
             "direcional."))) +
    theme(axis.text.x = element_text(size = 7),
          panel.grid.major = element_line(linewidth = 0.2,
                                          colour = "grey85"))

salvar_fig(f05, "Fig_05_rosa_dos_ventos", largura = 13, altura = 5.2)

######@> Contraste entre as duas medidas de vento...
## Quantifica o achado (v) do cabeçalho município a município, para que
## a escolha entre si10 e vento_vel_m_s nas etapas seguintes fique
## documentada em número, e não apenas em argumento.
contraste_vento <- dat %>%
    group_by(geocodigo, municipio) %>%
    summarise(vel_escalar = mean(si10),
              vel_vetorial = mean(vento_vel_m_s),
              direcao = direcao_media(u10, v10),
              .groups = "drop") %>%
    mutate(constancia = vel_vetorial / vel_escalar,
           razao = vel_escalar / vel_vetorial,
           direcao_predominante =
               setores[(floor((direcao + 11.25) / 22.5) %% 16) + 1]) %>%
    select(geocodigo, municipio, vel_escalar, vel_vetorial, constancia,
           razao, direcao, direcao_predominante) %>%
    arrange(desc(constancia))

tabelas[["Tab_09_contraste_medidas_vento"]] <-
    salvar_tab(contraste_vento, "Tab_09_contraste_medidas_vento")

message("Constância direcional média: ",
        sprintf("%.3f", mean(contraste_vento$constancia)),
        " | razão si10 / módulo do vento médio: ",
        sprintf("%.2f", mean(contraste_vento$razao)))

########################################################################
######@> Etapa 04 - Estrutura temporal agregada e anomalias...

message("\n--- Etapa 04: estrutura temporal do litoral ---")

######@> Série anual do litoral em formato largo...
## Formato de exportação: uma linha por ano, uma coluna por variável.
## É a tabela que alimenta diretamente as análises posteriores que
## precisem de um índice climático anual regional.
serie_anual_larga <- litoral_anual %>%
    select(ano, variavel, valor) %>%
    pivot_wider(names_from = variavel, values_from = valor) %>%
    arrange(ano)

tabelas[["Tab_10_serie_anual_litoral"]] <-
    salvar_tab(serie_anual_larga, "Tab_10_serie_anual_litoral")

######@> Figura 06 - séries anuais de todas as variáveis...
## A média anual suprime o ciclo sazonal e deixa visível a
## variabilidade interanual e a tendência de longo prazo, que na série
## mensal ficariam encobertas pela oscilação de doze meses.
f06 <- litoral_anual %>%
    mutate(painel = paste0(vars_rotulo[variavel], " (",
                           vars_unidade[variavel], ")"),
           painel = factor(painel,
                           levels = paste0(vars_meta$rotulo, " (",
                                           vars_meta$unidade, ")"))) %>%
    ggplot(aes(x = ano, y = valor)) +
    geom_line(aes(colour = dominio), linewidth = 0.4, alpha = 0.75) +
    geom_smooth(method = "loess", formula = y ~ x, span = 0.4,
                se = FALSE, colour = "grey15", linewidth = 0.7) +
    facet_wrap(~painel, scales = "free_y", ncol = 4) +
    scale_colour_manual(values = cores_dominio, name = "Domínio") +
    labs(title = "Séries anuais do litoral catarinense",
         subtitle = paste0("Média anual ponderada pela área, ",
                           ano_ini_analise, "-", ano_fim_analise),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Linha colorida: média anual observada. Linha escura:",
             "suavização loess (span 0,4), incluída apenas como apoio",
             "visual - a avaliação formal de tendência é feita por",
             "Mann-Kendall e declividade de Sen na Etapa 09. Escalas",
             "verticais livres por painel.")))

salvar_fig(f06, "Fig_06_series_anuais_litoral", largura = 13,
           altura = 9)

######@> Anomalias mensais do litoral...
anomalia_litoral <- longo %>%
    group_by(variavel, dominio, ano, mes, data) %>%
    summarise(anomalia = sum(anomalia * peso) / sum(peso),
              anomalia_z = sum(anomalia_z * peso) / sum(peso),
              .groups = "drop") %>%
    arrange(variavel, ano, mes)

anomalia_anual <- anomalia_litoral %>%
    group_by(variavel, dominio, ano) %>%
    summarise(anomalia = mean(anomalia),
              anomalia_z = mean(anomalia_z), .groups = "drop")

######@> Figura 07 - painel de anomalias mensais padronizadas...
## Um retrato de 86 anos em que cada célula é um mês. A padronização
## (anomalia dividida pelo desvio-padrão do período de referência) é o
## que permite usar a MESMA escala de cor para variáveis de unidades
## diferentes, tornando os painéis comparáveis entre si.
##
## A escala é divergente e centrada em zero: o branco marca a normal
## 1991-2020, e a leitura vertical de cada faixa mostra se um ano
## inteiro se afastou da referência em um mesmo sentido.
f07 <- anomalia_litoral %>%
    filter(variavel %in% vars_chave) %>%
    mutate(painel = vars_rotulo[variavel],
           painel = factor(painel, levels = vars_rotulo[vars_chave])) %>%
    ggplot(aes(x = ano, y = mes, fill = anomalia_z)) +
    geom_raster() +
    facet_wrap(~painel, ncol = 1) +
    scale_fill_gradient2(low = "#2166AC", mid = "white",
                         high = "#B2182B", midpoint = 0,
                         name = "Anomalia (desvios-padrão)",
                         limits = c(-3, 3), oob = squish) +
    scale_y_continuous(breaks = c(1, 4, 7, 10),
                       labels = meses_abrev[c(1, 4, 7, 10)],
                       expand = c(0, 0)) +
    scale_x_continuous(expand = c(0, 0)) +
    labs(title = "Anomalias mensais padronizadas do litoral",
         subtitle = paste0("Desvios frente à normal ", ref_ini, "-",
                           ref_fim, ", ", ano_ini_analise, "-",
                           ano_fim_analise),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Cada célula é um mês. Valores além de tres desvios-padrão",
             "são representados pela cor do limite, para que casos",
             "isolados não achatem a escala do restante do painel. Faixas",
             "verticais contínuas indicam anos anômalos por inteiro;",
             "manchas horizontais indicam alteração restrita a uma época",
             "do ano.")))

salvar_fig(f07, "Fig_07_anomalias_mensais", largura = 12, altura = 10)

######@> Figura 08 - anomalias anuais com média móvel...
## A média móvel de onze anos é o filtro habitual em climatologia:
## suprime a variabilidade interanual - inclusive a associada a ENSO,
## de dois a sete anos - e deixa visível apenas a variação de escala
## decenal.
media_movel <- function(x, k = 11) {
    n <- length(x)
    saida <- rep(NA_real_, n)
    meia <- (k - 1) / 2
    for(i in seq_len(n)) {
        ini <- max(1, i - meia); fim <- min(n, i + meia)
        if(i > meia && i <= n - meia) saida[i] <- mean(x[ini:fim])
    }
    return(saida)
}

dados_f08 <- anomalia_anual %>%
    filter(variavel %in% vars_chave) %>%
    group_by(variavel) %>%
    arrange(ano) %>%
    mutate(suave = media_movel(anomalia_z)) %>%
    ungroup() %>%
    mutate(painel = vars_rotulo[variavel],
           painel = factor(painel, levels = vars_rotulo[vars_chave]))

f08 <- ggplot(dados_f08, aes(x = ano)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_col(aes(y = anomalia_z, fill = anomalia_z > 0), width = 0.8,
             show.legend = FALSE) +
    geom_line(aes(y = suave), colour = "grey10", linewidth = 0.8) +
    facet_wrap(~painel, scales = "free_y", ncol = 1) +
    scale_fill_manual(values = c("TRUE" = "#B2182B",
                                 "FALSE" = "#2166AC")) +
    labs(title = "Anomalias anuais padronizadas do litoral",
         subtitle = paste0("Barras: anomalia do ano. Linha: média móvel ",
                           "de 11 anos. Referência ", ref_ini, "-",
                           ref_fim),
         x = NULL, y = "Desvios-padrão",
         caption = quebrar(paste(
             "A média móvel não é definida nos cinco primeiros e nos",
             "cinco últimos anos da série, por falta de janela completa.",
             "Anomalias padronizadas permitem comparar o afastamento",
             "relativo de variáveis com unidades distintas.")))

salvar_fig(f08, "Fig_08_anomalias_anuais", largura = 11, altura = 10)

######@> Comparação entre períodos climatológicos...
## Duas perguntas de uma vez: (a) houve deslocamento do clima médio
## entre a primeira e a segunda metade da série? e (b) o período em que
## existem registros de desastre no Atlas Digital (1991-2025) é
## climaticamente representativo do restante?
##
## A segunda pergunta importa diretamente para o capítulo: se o
## subperíodo com dados de desastre for atípico, qualquer relação
## estimada entre clima e desastre estará condicionada a ele e não
## poderá ser extrapolada para o restante da série.
periodo_corte <- ref_ini - 1

comparacao_periodos <- longo %>%
    mutate(periodo = ifelse(ano <= periodo_corte,
                            paste0(ano_ini_analise, "-", periodo_corte),
                            paste0(ref_ini, "-", ano_fim_analise))) %>%
    group_by(variavel, periodo) %>%
    summarise(media = sum(valor * peso) / sum(peso), .groups = "drop") %>%
    pivot_wider(names_from = periodo, values_from = media) %>%
    rename(periodo_1 = 2, periodo_2 = 3) %>%
    left_join(select(resumo_vars, variavel, dp), by = "variavel") %>%
    mutate(diferenca = periodo_2 - periodo_1,
           diferenca_dp = diferenca / dp,
           rotulo = vars_rotulo[variavel],
           unidade = vars_unidade[variavel],
           deslocamento = case_when(
               abs(diferenca_dp) < 0.1 ~ "Desprezível",
               abs(diferenca_dp) < 0.25 ~ "Pequeno",
               TRUE ~ "Relevante")) %>%
    arrange(desc(abs(diferenca_dp))) %>%
    select(variavel, rotulo, unidade, periodo_1, periodo_2, diferenca,
           diferenca_dp, deslocamento)

names(comparacao_periodos)[4:5] <-
    c(paste0("media_", ano_ini_analise, "_", periodo_corte),
      paste0("media_", ref_ini, "_", ano_fim_analise))

tabelas[["Tab_11_comparacao_periodos"]] <-
    salvar_tab(comparacao_periodos, "Tab_11_comparacao_periodos")

######@> Médias por década...
## Recorte complementar, que mostra se o deslocamento entre os dois
## períodos foi gradual ou concentrado em alguma década.
medias_decada <- longo %>%
    group_by(variavel, decada) %>%
    summarise(media = sum(valor * peso) / sum(peso),
              n_anos = n_distinct(ano), .groups = "drop") %>%
    mutate(rotulo = vars_rotulo[variavel])

tabelas[["Tab_12_medias_por_decada"]] <-
    salvar_tab(medias_decada, "Tab_12_medias_por_decada")

message("Variáveis com deslocamento relevante entre períodos: ",
        sum(comparacao_periodos$deslocamento == "Relevante"), " de ",
        nrow(comparacao_periodos))

########################################################################
######@> Etapa 05 - Padrões municipais e gradiente espacial...

message("\n--- Etapa 05: padrões municipais ---")

######@> Perfil climático de cada município...
## Média de longo prazo de cada variável, acompanhada dos descritores
## geográficos. É a tabela de referência para os mapas e para o
## agrupamento por perfil da Etapa 13.
perfil_municipio <- mun_anual %>%
    group_by(geocodigo, municipio, variavel) %>%
    summarise(media = mean(valor), .groups = "drop") %>%
    pivot_wider(names_from = variavel, values_from = media) %>%
    left_join(select(pesos_area, geocodigo, area_km2, n_pixels,
                     lon_centroide, lat_centroide), by = "geocodigo") %>%
    arrange(lat_centroide)

tabelas[["Tab_13_perfil_municipios"]] <-
    salvar_tab(perfil_municipio, "Tab_13_perfil_municipios")

######@> Gradiente latitudinal...
## O recorte é uma faixa costeira com cerca de quatro graus de
## latitude. A pergunta é quanto dessa extensão se traduz em variação
## climática sistemática - ou seja, se a posição do município ao longo
## do litoral prediz seu clima médio.
##
## São reportadas duas medidas: a correlação com a latitude (força e
## sentido do gradiente) e a AMPLITUDE entre o município extremo norte
## e o extremo sul, expressa também em desvios-padrão da série, para
## dizer se o gradiente é grande frente à variabilidade temporal que a
## variável já tem.
gradiente_lat <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        d <- perfil_municipio %>%
            select(municipio, lat_centroide, valor = all_of(v))
        ajuste <- lm(valor ~ lat_centroide, data = d)
        tibble(variavel = v,
               cor_latitude = cor(d$valor, d$lat_centroide),
               declive_por_grau = coef(ajuste)[2],
               p_valor = summary(ajuste)$coefficients[2, 4],
               amplitude_entre_mun = diff(range(d$valor)),
               mun_maior = d$municipio[which.max(d$valor)],
               mun_menor = d$municipio[which.min(d$valor)])
    })) %>%
    left_join(select(resumo_vars, variavel, dp), by = "variavel") %>%
    mutate(amplitude_dp = amplitude_entre_mun / dp,
           rotulo = vars_rotulo[variavel],
           unidade = vars_unidade[variavel],
           gradiente = case_when(
               p_valor >= alfa ~ "Sem gradiente latitudinal",
               abs(cor_latitude) > 0.7 ~ "Gradiente forte",
               TRUE ~ "Gradiente moderado")) %>%
    arrange(desc(abs(cor_latitude))) %>%
    select(variavel, rotulo, unidade, cor_latitude, declive_por_grau,
           p_valor, amplitude_entre_mun, amplitude_dp, gradiente,
           mun_maior, mun_menor)

tabelas[["Tab_14_gradiente_latitudinal"]] <-
    salvar_tab(gradiente_lat, "Tab_14_gradiente_latitudinal")

######@> Figura 09 - variáveis-chave contra a latitude...
f09 <- perfil_municipio %>%
    select(municipio, lat_centroide, all_of(vars_chave)) %>%
    pivot_longer(all_of(vars_chave), names_to = "variavel",
                 values_to = "valor") %>%
    mutate(painel = rotular(variavel),
           painel = factor(painel, levels = rotular(vars_chave))) %>%
    ggplot(aes(x = lat_centroide, y = valor)) +
    geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
                colour = "#D55E00", fill = "#D55E00", alpha = 0.15,
                linewidth = 0.7) +
    geom_point(size = 2, colour = "#0072B2", alpha = 0.8) +
    facet_wrap(~painel, scales = "free_y", ncol = 3) +
    labs(title = "Gradiente latitudinal do clima médio municipal",
         subtitle = paste0("Médias de ", ano_ini_analise, "-",
                           ano_fim_analise, "; latitudes negativas, ",
                           "valores maiores correspondem ao norte"),
         x = "Latitude do centroide (graus)", y = NULL,
         caption = quebrar(paste(
             "Cada ponto é um município. A faixa é o intervalo de",
             "confiança da regressão linear simples. O sentido do",
             "gradiente é o esperado para uma faixa costeira subtropical:",
             "temperatura decrescente para o sul.")))

salvar_fig(f09, "Fig_09_gradiente_latitudinal", largura = 12,
           altura = 7)

######@> Figura 10 - ordenamento dos municípios ao longo do litoral...
## Os municípios aparecem na ordem geográfica (do sul para o norte), e
## não em ordem de valor, porque o que interessa aqui é reconhecer se a
## variação é CONTÍNUA ao longo da costa ou se há saltos - e um salto
## entre municípios vizinhos é indício de mudança de pixel na grade do
## ERA5, e não de mudança climática real.
f10 <- perfil_municipio %>%
    select(municipio, lat_centroide, all_of(vars_chave)) %>%
    pivot_longer(all_of(vars_chave), names_to = "variavel",
                 values_to = "valor") %>%
    mutate(painel = rotular(variavel),
           painel = factor(painel, levels = rotular(vars_chave)),
           municipio = factor(municipio,
                              levels = perfil_municipio$municipio)) %>%
    ggplot(aes(x = valor, y = municipio)) +
    geom_segment(aes(xend = -Inf, yend = municipio), colour = "grey85",
                 linewidth = 0.3) +
    geom_point(aes(colour = lat_centroide), size = 2) +
    facet_wrap(~painel, scales = "free_x", ncol = 5) +
    scale_colour_viridis_c(option = "C", name = "Latitude") +
    labs(title = "Clima médio de cada município, na ordem da costa",
         subtitle = paste0("Municípios ordenados do sul (base) para o ",
                           "norte (topo), médias ", ano_ini_analise,
                           "-", ano_fim_analise),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Degraus abruptos entre municípios adjacentes sugerem",
             "mudança da célula dominante do ERA5, e não descontinuidade",
             "climática: a resolução de 0,25 grau impõe patamares ao",
             "longo da costa."))) +
    theme(axis.text.y = element_text(size = 7),
          legend.position = "right")

salvar_fig(f10, "Fig_10_ranking_municipios", largura = 14, altura = 8)

########################################################################
######@> Etapa 06 - Heterogeneidade interna aos municípios...

message("\n--- Etapa 06: heterogeneidade interna ---")

######@> Correspondência entre variável analisada e coluna original...
## Os sufixos _dp, _min e _max existem apenas para as variáveis
## ORIGINAIS do ERA5, nas unidades brutas. As versões convertidas
## (t2m_C, tp_mm_dia, ...) e as derivadas não os têm. Como a métrica
## central desta etapa é uma RAZÃO entre duas dispersões da mesma
## coluna, a unidade se cancela e o resultado é diretamente comparável
## ao das demais variáveis.
mapa_sufixos <- tribble(
    ~base,    ~variavel,
    "t2m",    "t2m_C",
    "tp",     "tp_mm_dia",
    "cp",     "cp_mm_dia",
    "lsrr",   "lsrr_mm_dia",
    "e",      "e_mm_dia",
    "pev",    "pev_mm_dia",
    "slhf",   "slhf_W_m2",
    "ssr",    "ssr_W_m2",
    "tcc",    "tcc_pct",
    "si10",   "si10",
    "tcrw",   "tcrw",
    "ptype",  "ptype")

######@> Dispersão interna x dispersão temporal...
## A pergunta desta etapa: a média municipal é um bom resumo do que
## acontece dentro do município?
##
## Duas quantidades são confrontadas para cada variável:
##
##   amplitude_interna : média, ao longo dos meses, da diferença entre o
##                       maior e o menor valor observado ENTRE OS PIXELS
##                       do município no mesmo mês;
##   dp_temporal       : desvio-padrão da série municipal ao longo do
##                       tempo.
##
## A razão entre elas é adimensional. Acima de 1, a variação DENTRO do
## município num único mês supera toda a variação que a série municipal
## exibe ao longo de 86 anos - e nesse caso a média municipal descarta
## mais informação do que preserva.
heterogeneidade <- bind_rows(
    lapply(seq_len(nrow(mapa_sufixos)), function(i) {
        b <- mapa_sufixos$base[i]
        v <- mapa_sufixos$variavel[i]
        amp <- dat[[paste0(b, "_max")]] - dat[[paste0(b, "_min")]]
        dp_int <- dat[[paste0(b, "_dp")]]
        dp_tmp <- dat %>%
            group_by(geocodigo) %>%
            summarise(s = sd(.data[[v]]), .groups = "drop") %>%
            pull(s) %>% mean()
        ## A escala de t2m/ssr/etc. difere entre a coluna original e a
        ## convertida; a razão é calculada na escala ORIGINAL para as
        ## duas quantidades, mantendo a comparação interna coerente.
        dp_tmp_base <- dat %>%
            group_by(geocodigo) %>%
            summarise(s = sd(.data[[b]]), .groups = "drop") %>%
            pull(s) %>% mean()
        tibble(variavel = v,
               amplitude_interna = mean(amp, na.rm = TRUE),
               dp_interno = mean(dp_int, na.rm = TRUE),
               dp_temporal = dp_tmp_base,
               razao_interna_temporal = mean(amp, na.rm = TRUE) /
                   dp_tmp_base,
               dp_temporal_unidade_analise = dp_tmp)
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           dominio = vars_dominio[variavel],
           adequacao_media_municipal = case_when(
               razao_interna_temporal < 0.5 ~
                   "Média municipal representativa",
               razao_interna_temporal < 1 ~ "Representatividade parcial",
               TRUE ~ "Média municipal insuficiente")) %>%
    arrange(desc(razao_interna_temporal)) %>%
    select(variavel, rotulo, dominio, amplitude_interna, dp_interno,
           dp_temporal, razao_interna_temporal,
           adequacao_media_municipal)

tabelas[["Tab_15_heterogeneidade_interna"]] <-
    salvar_tab(heterogeneidade, "Tab_15_heterogeneidade_interna")

######@> Figura 11 - heterogeneidade interna frente à temporal...
f11 <- heterogeneidade %>%
    mutate(rotulo = factor(rotulo,
                           levels = rev(heterogeneidade$rotulo))) %>%
    ggplot(aes(x = razao_interna_temporal, y = rotulo,
               colour = adequacao_media_municipal)) +
    geom_vline(xintercept = 1, linetype = "dashed",
               colour = "grey30") +
    geom_vline(xintercept = 0.5, linetype = "dotted",
               colour = "grey55") +
    geom_segment(aes(xend = 0, yend = rotulo), linewidth = 0.5) +
    geom_point(size = 2.8) +
    scale_colour_manual(
        values = c("Média municipal representativa" = "#0072B2",
                   "Representatividade parcial" = "#E69F00",
                   "Média municipal insuficiente" = "#D55E00"),
        name = NULL) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.05))) +
    labs(title = "A média municipal resume bem o município?",
         subtitle = paste0("Razão entre a amplitude espacial interna ",
                           "média e o desvio-padrão temporal da série ",
                           "municipal"),
         x = "Amplitude entre pixels / desvio-padrão temporal",
         y = NULL,
         caption = quebrar(paste(
             "Valores acima de 1 (linha tracejada) indicam que a variação",
             "entre os pixels de um município, em um único mês, supera a",
             "variação de toda a série temporal daquele município. Para",
             "essas variáveis a agregação municipal apaga contraste",
             "relevante e o pixel é a unidade espacial mais adequada.",
             paste0("Os ", sum(pesos_area$n_pixels == 1),
                    " municípios cobertos por uma única célula têm"),
             "amplitude interna nula por construção e puxam as médias",
             "para baixo."))) +
    theme(legend.position = "bottom")

salvar_fig(f11, "Fig_11_heterogeneidade_interna", largura = 10,
           altura = 6)

######@> Heterogeneidade por município...
## Quais municípios são internamente mais diversos? A resposta depende
## quase inteiramente do número de pixels que os cobrem, e a tabela
## registra as duas colunas lado a lado para tornar essa dependência
## explícita.
heterogeneidade_mun <- dat %>%
    group_by(geocodigo, municipio) %>%
    summarise(n_pixels = first(n_pixels),
              area_km2 = first(area_km2),
              amp_t2m = mean(t2m_max - t2m_min),
              amp_si10 = mean(si10_max - si10_min),
              amp_tp = mean(tp_max - tp_min),
              amp_ssr = mean(ssr_max - ssr_min),
              .groups = "drop") %>%
    arrange(desc(amp_t2m))

tabelas[["Tab_16_heterogeneidade_municipios"]] <-
    salvar_tab(heterogeneidade_mun, "Tab_16_heterogeneidade_municipios")

message("Variáveis em que a média municipal é insuficiente: ",
        sum(heterogeneidade$adequacao_media_municipal ==
            "Média municipal insuficiente"), " de ",
        nrow(heterogeneidade))

########################################################################
######@> Etapa 07 - Painéis diagnósticos por município...

message("\n--- Etapa 07: painéis por município ---")

######@> Construção de um painel por município...
## Cada arquivo reúne, para um município, os cinco recortes que
## permitem julgar sua série sem abrir o R: o ciclo anual das duas
## variáveis-chave, a trajetória interanual da temperatura e da chuva,
## o histórico completo de anomalias e a autocorrelação remanescente
## depois de removida a sazonalidade.
##
## O painel existe porque as figuras agregadas do litoral respondem
## pela região, não pelo município - e é no município que a análise
## posterior será conduzida. Um comportamento municipal destoante ficaria
## invisível na média regional e apareceria aqui.
painel_municipio <- function(cod) {
    info <- pesos_area %>% filter(geocodigo == cod)
    nome <- info$municipio[1]

    d_mes <- longo %>% filter(geocodigo == cod)
    d_ano <- mun_anual %>% filter(geocodigo == cod)

    ## (a) Ciclo anual da temperatura e da precipitação
    p1 <- d_mes %>%
        filter(variavel %in% c("t2m_C", "tp_mm_dia"),
               ano >= ref_ini, ano <= ref_fim) %>%
        group_by(variavel, mes) %>%
        summarise(normal = mean(valor),
                  p10 = quantile(valor, 0.10),
                  p90 = quantile(valor, 0.90), .groups = "drop") %>%
        mutate(painel = factor(rotular(variavel),
                               levels = rotular(c("t2m_C",
                                                  "tp_mm_dia")))) %>%
        ggplot(aes(x = mes)) +
        geom_ribbon(aes(ymin = p10, ymax = p90), fill = "#0072B2",
                    alpha = 0.2) +
        geom_line(aes(y = normal), colour = "#0072B2",
                  linewidth = 0.8) +
        facet_wrap(~painel, scales = "free_y", nrow = 1) +
        scale_x_continuous(breaks = c(1, 4, 7, 10),
                           labels = meses_abrev[c(1, 4, 7, 10)]) +
        labs(subtitle = paste0("Ciclo anual (normal ", ref_ini, "-",
                               ref_fim, ", faixa p10-p90)"),
             x = NULL, y = NULL)

    ## (b) Séries anuais com suavização
    p2 <- d_ano %>%
        filter(variavel %in% c("t2m_C", "tp_mm_dia")) %>%
        mutate(painel = factor(rotular(variavel),
                               levels = rotular(c("t2m_C",
                                                  "tp_mm_dia")))) %>%
        ggplot(aes(x = ano, y = valor)) +
        geom_line(colour = "grey45", linewidth = 0.4) +
        geom_smooth(method = "loess", formula = y ~ x, span = 0.5,
                    se = FALSE, colour = "#D55E00", linewidth = 0.8) +
        facet_wrap(~painel, scales = "free_y", nrow = 1) +
        labs(subtitle = "Médias anuais e suavização loess",
             x = NULL, y = NULL)

    ## (c) Histórico de anomalias padronizadas da temperatura
    p3 <- d_mes %>%
        filter(variavel == "t2m_C") %>%
        ggplot(aes(x = ano, y = mes, fill = anomalia_z)) +
        geom_raster() +
        scale_fill_gradient2(low = "#2166AC", mid = "white",
                             high = "#B2182B", midpoint = 0,
                             limits = c(-3, 3), oob = squish,
                             name = "Anomalia (dp)") +
        scale_y_continuous(breaks = c(1, 4, 7, 10),
                           labels = meses_abrev[c(1, 4, 7, 10)],
                           expand = c(0, 0)) +
        scale_x_continuous(expand = c(0, 0)) +
        labs(subtitle = paste0("Anomalias mensais de temperatura ",
                               "(referência ", ref_ini, "-", ref_fim,
                               ")"),
             x = NULL, y = NULL) +
        theme(legend.position = "right",
              legend.key.width = unit(0.3, "cm"))

    ## (d) Autocorrelação das anomalias, temperatura e precipitação
    acf_t <- calcular_correlograma(
        d_mes$anomalia[d_mes$variavel == "t2m_C"], lag_max_mensal, "ACF")
    acf_p <- calcular_correlograma(
        d_mes$anomalia[d_mes$variavel == "tp_mm_dia"], lag_max_mensal,
        "ACF")

    p4 <- grafico_correlograma(acf_t, subtitulo = "ACF da anomalia de temperatura")
    p5 <- grafico_correlograma(acf_p, subtitulo = "ACF da anomalia de precipitação")

    ## Ficha numérica do município, montada como legenda do painel
    est <- perfil_municipio %>% filter(geocodigo == cod)
    mk_t <- mann_kendall(d_ano$valor[d_ano$variavel == "t2m_C"])
    sen_t <- declividade_sen(d_ano$valor[d_ano$variavel == "t2m_C"],
                             d_ano$ano[d_ano$variavel == "t2m_C"])

    ficha <- paste0(
        "Área: ", fmt_int(round(info$area_km2)), " km²  |  pixels ERA5: ",
        info$n_pixels, "  |  centroide: ",
        sprintf("%.2f", info$lat_centroide), "°, ",
        sprintf("%.2f", info$lon_centroide), "°   ||   ",
        "Temperatura média: ", sprintf("%.2f", est$t2m_C), " °C  |  ",
        "Precipitação média: ", sprintf("%.2f", est$tp_mm_dia),
        " mm/dia  |  Vento (si10): ", sprintf("%.2f", est$si10),
        " m/s   ||   Tendência térmica (Sen): ",
        sprintf("%+.4f", sen_t), " °C/ano (Mann-Kendall tau = ",
        sprintf("%.3f", mk_t$tau), ", p = ",
        format.pval(mk_t$p_valor, digits = 2, eps = 0.001), ")")

    (p1 / p2 / p3 / (p4 | p5)) +
        plot_annotation(
            title = paste0("Diagnóstico climático - ", nome),
            subtitle = paste0("Reanálise ERA5, ", ano_ini_analise, "-",
                              ano_fim_analise, " (", n_anos,
                              " anos completos)"),
            caption = quebrar(ficha, 130),
            theme = theme(plot.title =
                              element_text(face = "bold", size = 15),
                          plot.caption =
                              element_text(hjust = 0, size = 8,
                                           colour = "grey30")))
}

######@> Geração dos painéis...
for(cod in pesos_area$geocodigo) {
    nome <- pesos_area$municipio[pesos_area$geocodigo == cod]
    salvar_fig(painel_municipio(cod),
               paste0("Painel_", limpar_nome(nome)),
               largura = 11, altura = 13, diretorio = dir_fig_mun)
}

message("Painéis municipais gerados: ", nrow(pesos_area))

########################################################################
######@> Etapa 08 - Dependência temporal...

message("\n--- Etapa 08: dependência temporal ---")

######@> Séries do litoral em formato de lista...
## Duas versões de cada variável: a série BRUTA, que carrega o ciclo
## anual, e a série de ANOMALIAS, já livre da sazonalidade. Toda a
## etapa é conduzida em paralelo nas duas, porque elas respondem a
## perguntas diferentes - a primeira descreve o clima, a segunda mede
## a memória do processo.
series_litoral <- lapply(vars_dinamicas, function(v) {
    litoral_mensal %>% filter(variavel == v) %>% arrange(ano, mes) %>%
        pull(valor)
})
names(series_litoral) <- vars_dinamicas

series_anomalia <- lapply(vars_dinamicas, function(v) {
    anomalia_litoral %>% filter(variavel == v) %>% arrange(ano, mes) %>%
        pull(anomalia)
})
names(series_anomalia) <- vars_dinamicas

######@> Diagnóstico das séries agregadas...
diag_series <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        bind_rows(
            mutate(diagnosticar_serie(series_litoral[[v]]),
                   versao = "Série bruta"),
            mutate(diagnosticar_serie(series_anomalia[[v]]),
                   versao = "Anomalia"))  %>%
            mutate(variavel = v)
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           dominio = vars_dominio[variavel]) %>%
    select(variavel, rotulo, dominio, versao, everything())

tabelas[["Tab_17_diagnostico_series"]] <-
    salvar_tab(diag_series, "Tab_17_diagnostico_series")

######@> Memória das anomalias...
## Duas medidas complementares do alcance da dependência temporal:
##
##   lags_significativos : quantos dos primeiros doze lags excedem o
##                         intervalo de confiança - contagem simples,
##                         sensível ao tamanho da amostra;
##   tempo_memoria       : primeiro lag em que a ACF cai abaixo de 1/e
##                         (0,368), convenção usual em climatologia para
##                         o tempo de decorrelação.
##
## O tempo de memória é a informação que decide o passo temporal da
## modelagem: se a anomalia de um mês só informa o mês seguinte, um
## modelo com defasagem única basta; se informa vários, é preciso
## estrutura autorregressiva mais longa.
memoria_anomalias <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        ac <- calcular_correlograma(series_anomalia[[v]], 24, "ACF")
        if(nrow(ac) == 0) {
            return(tibble(variavel = v, acf1 = NA_real_,
                          lags_significativos = NA_integer_,
                          tempo_memoria = NA_real_))
        }
        primeiros <- ac %>% filter(lag <= 12)
        abaixo <- which(ac$valor < exp(-1))
        tibble(variavel = v,
               acf1 = ac$valor[1],
               lags_significativos =
                   sum(abs(primeiros$valor) > primeiros$ic),
               tempo_memoria = if(length(abaixo) > 0) min(abaixo) else
                                   NA_real_)
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           dominio = vars_dominio[variavel]) %>%
    arrange(desc(acf1)) %>%
    select(variavel, rotulo, dominio, acf1, lags_significativos,
           tempo_memoria)

tabelas[["Tab_18_memoria_anomalias"]] <-
    salvar_tab(memoria_anomalias, "Tab_18_memoria_anomalias")

######@> Figura 12 - correlogramas das séries brutas...
## O que estas figuras mostram é o CICLO ANUAL, e não memória: o pico
## no lag 12 e o vale no lag 6 são a assinatura da sazonalidade. Elas
## são incluídas justamente para tornar visível o motivo de a análise
## de dependência precisar ser feita sobre as anomalias.
correlogramas_brutos <- bind_rows(
    lapply(vars_chave, function(v) {
        bind_rows(calcular_correlograma(series_litoral[[v]],
                                        lag_max_mensal, "ACF"),
                  calcular_correlograma(series_litoral[[v]],
                                        lag_max_mensal, "PACF")) %>%
            mutate(variavel = v)
    })) %>%
    mutate(painel = factor(vars_rotulo[variavel],
                           levels = vars_rotulo[vars_chave]))

f12 <- ggplot(correlogramas_brutos, aes(x = lag, y = valor)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_hline(aes(yintercept = ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_hline(aes(yintercept = -ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_segment(aes(xend = lag, yend = 0), linewidth = 0.5,
                 colour = "grey25") +
    facet_grid(tipo ~ painel) +
    labs(title = "Correlogramas das séries mensais brutas do litoral",
         subtitle = paste0("Defasagens de 1 a ", lag_max_mensal,
                           " meses, ", ano_ini_analise, "-",
                           ano_fim_analise),
         x = "Defasagem (meses)", y = NULL,
         caption = quebrar(paste(
             "O padrão oscilatório com máximo nos lags 12, 24 e 36 e",
             "mínimo nos lags 6, 18 e 30 é o ciclo anual, não memória do",
             "processo. A PACF concentra a estrutura nos primeiros lags e",
             "no lag 12, como se espera de uma série sazonal. A leitura",
             "da dependência propriamente dita está na figura seguinte.")))

salvar_fig(f12, "Fig_12_correlogramas_brutos", largura = 13,
           altura = 6.5)

######@> Figura 13 - correlogramas das anomalias...
correlogramas_anomalia <- bind_rows(
    lapply(vars_chave, function(v) {
        bind_rows(calcular_correlograma(series_anomalia[[v]],
                                        lag_max_mensal, "ACF"),
                  calcular_correlograma(series_anomalia[[v]],
                                        lag_max_mensal, "PACF")) %>%
            mutate(variavel = v)
    })) %>%
    mutate(painel = factor(vars_rotulo[variavel],
                           levels = vars_rotulo[vars_chave]))

f13 <- ggplot(correlogramas_anomalia, aes(x = lag, y = valor)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_hline(aes(yintercept = ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_hline(aes(yintercept = -ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_segment(aes(xend = lag, yend = 0), linewidth = 0.5,
                 colour = "grey25") +
    facet_grid(tipo ~ painel) +
    labs(title = "Correlogramas das anomalias mensais do litoral",
         subtitle = paste0("Desvios frente à normal ", ref_ini, "-",
                           ref_fim, "; sazonalidade removida"),
         x = "Defasagem (meses)", y = NULL,
         caption = quebrar(paste(
             "Removido o ciclo anual, resta pouca estrutura: a",
             "autocorrelação decai nos primeiros lags e o restante",
             "flutua em torno do limite de confiança. É a assinatura de",
             "memória curta - a anomalia de um mês informa sobre os dois",
             "ou três meses seguintes, não mais que isso.")))

salvar_fig(f13, "Fig_13_correlogramas_anomalias", largura = 13,
           altura = 6.5)

######@> Decomposição STL das séries do litoral...
## A STL separa a série em tendência, componente sazonal e resíduo por
## suavizações locais sucessivas. Diferentemente da decomposição
## clássica, admite que a amplitude sazonal mude ao longo do tempo -
## requisito para uma série de 86 anos, em que supor sazonalidade
## rigidamente constante seria implausível.
stl_litoral <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        serie <- como_ts(series_litoral[[v]], ano_ini_analise)
        forca_stl(serie) %>% mutate(variavel = v)
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           dominio = vars_dominio[variavel],
           regime = case_when(
               forca_sazonal > 0.6 & forca_tendencia > 0.3 ~
                   "Sazonal com tendência",
               forca_sazonal > 0.6 ~ "Dominada pela sazonalidade",
               forca_tendencia > 0.3 ~ "Dominada pela tendência",
               TRUE ~ "Dominada pela variabilidade irregular")) %>%
    arrange(desc(forca_sazonal)) %>%
    select(variavel, rotulo, dominio, forca_sazonal, forca_tendencia,
           var_residual, regime)

tabelas[["Tab_19_decomposicao_stl"]] <-
    salvar_tab(stl_litoral, "Tab_19_decomposicao_stl")

######@> Figura 14 - mapa de regimes temporais...
## Cada variável posicionada pelas duas forças. Os quadrantes separam
## quatro comportamentos qualitativamente distintos e indicam, para
## cada variável, o que um modelo precisa representar: quem está à
## direita exige termo sazonal; quem está acima exige termo de
## tendência; quem está no canto inferior esquerdo é essencialmente
## ruído em torno de uma média estável.
f14 <- ggplot(stl_litoral, aes(x = forca_sazonal, y = forca_tendencia,
                               colour = dominio)) +
    geom_vline(xintercept = 0.6, linetype = "dashed",
               colour = "grey60") +
    geom_hline(yintercept = 0.3, linetype = "dashed",
               colour = "grey60") +
    geom_point(size = 3) +
    geom_text(aes(label = rotulo), size = 2.8, vjust = -0.9,
              show.legend = FALSE) +
    scale_colour_manual(values = cores_dominio, name = "Domínio") +
    scale_x_continuous(limits = c(0, 1.12)) +
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.12))) +
    labs(title = "Regime temporal de cada variável climática",
         subtitle = paste0("Forças das componentes da decomposição STL, ",
                           "série mensal do litoral ", ano_ini_analise,
                           "-", ano_fim_analise),
         x = "Força da sazonalidade", y = "Força da tendência",
         caption = quebrar(paste(
             "As linhas tracejadas marcam os cortes adotados para",
             "classificar o regime (0,6 para sazonalidade e 0,3 para",
             "tendência). Ambas as forças variam de 0 a 1 e são",
             "adimensionais, o que torna comparáveis variáveis de",
             "unidades distintas. Variáveis próximas da origem são",
             "dominadas por variabilidade irregular e não admitem",
             "previsão a partir apenas do calendário.")))

salvar_fig(f14, "Fig_14_regimes_temporais", largura = 9, altura = 7)

######@> Figura 15 - decomposição STL da temperatura...
## Apresentada em detalhe para a temperatura por ser a variável com a
## sazonalidade mais forte e a tendência mais nítida do conjunto - é
## nela que a leitura das componentes fica mais informativa. As demais
## têm as forças reportadas na tabela e no mapa de regimes.
serie_t2m <- como_ts(series_litoral[["t2m_C"]], ano_ini_analise)
stl_t2m <- stl(serie_t2m, s.window = "periodic")

componentes_t2m <- as.data.frame(stl_t2m$time.series) %>%
    mutate(observado = as.numeric(serie_t2m),
           tempo = as.numeric(time(serie_t2m))) %>%
    pivot_longer(c(observado, trend, seasonal, remainder),
                 names_to = "componente", values_to = "valor") %>%
    mutate(componente = recode(componente,
                               observado = "Observado",
                               trend = "Tendência",
                               seasonal = "Sazonalidade",
                               remainder = "Resíduo"),
           componente = factor(componente,
                               levels = c("Observado", "Tendência",
                                          "Sazonalidade", "Resíduo")))

f15 <- ggplot(componentes_t2m, aes(x = tempo, y = valor)) +
    geom_line(linewidth = 0.35, colour = "#0072B2") +
    facet_wrap(~componente, ncol = 1, scales = "free_y") +
    labs(title = "Decomposição STL da temperatura do litoral",
         subtitle = paste0("Série mensal ", ano_ini_analise, "-",
                           ano_fim_analise, ", janela sazonal periódica"),
         x = NULL, y = "°C",
         caption = quebrar(paste(
             "A componente sazonal domina a escala do painel observado -",
             "sua amplitude é de cerca de 8 °C, contra menos de 1 °C de",
             "variação na tendência ao longo de 86 anos. Note as escalas",
             "verticais distintas: a tendência é pequena em valor",
             "absoluto, mas monotônica e sistemática, e é ela que os",
             "testes da etapa seguinte avaliam.")))

salvar_fig(f15, "Fig_15_decomposicao_stl_temperatura", largura = 11,
           altura = 8)

######@> Diagnóstico das séries municipais...
## A pergunta desta seção é de HOMOGENEIDADE: o comportamento temporal
## descrito para o litoral vale para cada município, ou há municípios
## que destoam? Se a resposta for uniforme, a modelagem pode adotar uma
## mesma estrutura temporal para todos e concentrar a variação
## municipal nos níveis - o que simplifica substancialmente o modelo.
diag_municipal <- bind_rows(
    lapply(vars_chave, function(v) {
        bind_rows(lapply(pesos_area$geocodigo, function(cod) {
            x <- longo %>%
                filter(geocodigo == cod, variavel == v) %>%
                arrange(ano, mes)
            bind_rows(
                mutate(diagnosticar_serie(x$valor),
                       versao = "Série bruta"),
                mutate(diagnosticar_serie(x$anomalia),
                       versao = "Anomalia")) %>%
                mutate(geocodigo = cod, municipio = x$municipio[1],
                       variavel = v)
        }))
    })) %>%
    mutate(rotulo = vars_rotulo[variavel]) %>%
    select(geocodigo, municipio, variavel, rotulo, versao, everything())

tabelas[["Tab_20_diagnostico_municipal"]] <-
    salvar_tab(diag_municipal, "Tab_20_diagnostico_municipal")

######@> Concordância entre municípios...
## Resume a tabela anterior em uma linha por variável: quantos
## municípios recebem cada classificação de estacionariedade e qual a
## dispersão da autocorrelação de primeira ordem entre eles.
concordancia_municipal <- diag_municipal %>%
    filter(versao == "Anomalia") %>%
    group_by(variavel, rotulo) %>%
    summarise(acf1_min = min(acf1, na.rm = TRUE),
              acf1_mediana = median(acf1, na.rm = TRUE),
              acf1_max = max(acf1, na.rm = TRUE),
              n_estacionarias = sum(estacionaria == "Estacionária",
                                    na.rm = TRUE),
              n_tendencia = sum(estacionaria ==
                                "Tendência determinística",
                                na.rm = TRUE),
              n_nao_estacionarias =
                  sum(estacionaria == "Não estacionária", na.rm = TRUE),
              classificacao_unanime =
                  n_distinct(estacionaria) == 1,
              .groups = "drop") %>%
    arrange(desc(acf1_mediana))

tabelas[["Tab_21_concordancia_municipal"]] <-
    salvar_tab(concordancia_municipal, "Tab_21_concordancia_municipal")

message("Variáveis com diagnóstico unânime entre municípios: ",
        sum(concordancia_municipal$classificacao_unanime), " de ",
        nrow(concordancia_municipal))

########################################################################
######@> Etapa 09 - Tendência: Mann-Kendall e declividade de Sen...

message("\n--- Etapa 09: tendência de longo prazo ---")

######@> Tendência das séries anuais do litoral...
## Os testes são aplicados às MÉDIAS ANUAIS, e não às séries mensais,
## por duas razões: a sazonalidade violaria a hipótese de identidade de
## distribuição do Mann-Kendall, e a autocorrelação de curto prazo
## inflaria a significância. Com 86 médias anuais, o teste tem potência
## suficiente e as observações são muito mais próximas de
## independentes - a autocorrelação anual das anomalias é pequena, como
## a Etapa 08 mostrou.
##
## A declividade é reportada por década porque as taxas anuais das
## variáveis climáticas são números da ordem de 0,01, difíceis de ler e
## de comparar entre si.
tendencia_litoral <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        d <- litoral_anual %>% filter(variavel == v) %>% arrange(ano)
        mk <- mann_kendall(d$valor)
        sen <- declividade_sen(d$valor, d$ano)
        tibble(variavel = v, tau = mk$tau, z = mk$z,
               p_valor = mk$p_valor, sen_por_ano = sen,
               sen_por_decada = sen * 10,
               variacao_periodo = sen * (n_anos - 1),
               media = mean(d$valor))
    })) %>%
    left_join(select(resumo_vars, variavel, dp), by = "variavel") %>%
    mutate(variacao_em_dp = variacao_periodo / dp,
           rotulo = vars_rotulo[variavel],
           unidade = vars_unidade[variavel],
           dominio = vars_dominio[variavel],
           resultado = case_when(
               is.na(p_valor) ~ "Indefinido",
               p_valor >= alfa ~ "Sem tendência detectada",
               tau > 0 ~ "Aumento significativo",
               TRUE ~ "Redução significativa")) %>%
    arrange(p_valor) %>%
    select(variavel, rotulo, unidade, dominio, tau, z, p_valor,
           sen_por_ano, sen_por_decada, variacao_periodo,
           variacao_em_dp, resultado)

tabelas[["Tab_22_tendencia_litoral"]] <-
    salvar_tab(tendencia_litoral, "Tab_22_tendencia_litoral")

######@> Figura 16 - tendência de cada variável...
## A declividade é expressa em desvios-padrão da própria série ao longo
## de todo o período, e não na unidade original, porque o objetivo é
## comparar a MAGNITUDE RELATIVA das tendências: 0,8 °C e 0,4 mm/dia
## não são comparáveis em unidade bruta, mas o são quando medidos
## contra a variabilidade que cada variável já exibe.
f16 <- tendencia_litoral %>%
    mutate(rotulo = factor(rotulo,
                           levels = rotulo[order(variacao_em_dp)])) %>%
    ggplot(aes(x = variacao_em_dp, y = rotulo, colour = resultado)) +
    geom_vline(xintercept = 0, colour = "grey40") +
    geom_segment(aes(xend = 0, yend = rotulo), linewidth = 0.6) +
    geom_point(size = 3) +
    scale_colour_manual(
        values = c("Aumento significativo" = "#B2182B",
                   "Redução significativa" = "#2166AC",
                   "Sem tendência detectada" = "grey60"),
        name = NULL) +
    labs(title = "Tendência de longo prazo das variáveis climáticas",
         subtitle = paste0("Variação estimada por Sen em todo o ",
                           "período (", ano_ini_analise, "-",
                           ano_fim_analise,
                           "), em desvios-padrão da série"),
         x = "Variação no período (desvios-padrão)", y = NULL,
         caption = quebrar(paste(
             "Significância pelo teste de Mann-Kendall sobre as médias",
             "anuais, com correção para empates, ao nível de",
             paste0(round(alfa * 100), "%."),
             "A magnitude é a declividade de Sen multiplicada pela",
             "extensão do período e dividida pelo desvio-padrão da série",
             "mensal, para permitir comparação entre variáveis de",
             "unidades diferentes.")))

salvar_fig(f16, "Fig_16_tendencia_variaveis", largura = 10, altura = 6.5)

######@> Tendência por município...
tendencia_municipal <- bind_rows(
    lapply(vars_chave, function(v) {
        bind_rows(lapply(pesos_area$geocodigo, function(cod) {
            d <- mun_anual %>%
                filter(geocodigo == cod, variavel == v) %>% arrange(ano)
            mk <- mann_kendall(d$valor)
            sen <- declividade_sen(d$valor, d$ano)
            tibble(geocodigo = cod, municipio = d$municipio[1],
                   variavel = v, tau = mk$tau, p_valor = mk$p_valor,
                   sen_por_decada = sen * 10,
                   variacao_periodo = sen * (n_anos - 1))
        }))
    })) %>%
    left_join(select(pesos_area, geocodigo, lat_centroide),
              by = "geocodigo") %>%
    mutate(rotulo = vars_rotulo[variavel],
           resultado = case_when(
               is.na(p_valor) ~ "Indefinido",
               p_valor >= alfa ~ "Sem tendência detectada",
               tau > 0 ~ "Aumento significativo",
               TRUE ~ "Redução significativa"))

tabelas[["Tab_23_tendencia_municipal"]] <-
    salvar_tab(tendencia_municipal %>%
               select(geocodigo, municipio, variavel, rotulo, tau,
                      p_valor, sen_por_decada, variacao_periodo,
                      resultado),
               "Tab_23_tendencia_municipal")

######@> Figura 17 - tendência municipal das variáveis-chave...
## Municípios ordenados pela latitude. Uniformidade vertical dentro de
## um painel significa que a tendência é regional e não municipal - e
## nesse caso não há informação a extrair do contraste entre
## municípios, apenas do nível comum.
f17 <- tendencia_municipal %>%
    mutate(painel = factor(rotulo, levels = vars_rotulo[vars_chave]),
           municipio = factor(municipio,
                              levels = perfil_municipio$municipio)) %>%
    ggplot(aes(x = sen_por_decada, y = municipio, colour = resultado)) +
    geom_vline(xintercept = 0, colour = "grey40") +
    geom_point(size = 1.9) +
    facet_wrap(~painel, scales = "free_x", ncol = 5) +
    scale_colour_manual(
        values = c("Aumento significativo" = "#B2182B",
                   "Redução significativa" = "#2166AC",
                   "Sem tendência detectada" = "grey65"),
        name = NULL) +
    labs(title = "Tendência climática de cada município",
         subtitle = paste0("Declividade de Sen por década, ",
                           ano_ini_analise, "-", ano_fim_analise,
                           "; municípios do sul (base) ao norte (topo)"),
         x = "Variação por década (unidade da variável)", y = NULL,
         caption = quebrar(paste(
             "A homogeneidade das colunas indica tendência de escala",
             "regional: não há município cuja trajetória de longo prazo",
             "difira qualitativamente da dos vizinhos. Em conjunto com a",
             "redundância espacial da Etapa 10, isso desaconselha modelos",
             "com tendência específica por município."))) +
    theme(axis.text.y = element_text(size = 7),
          legend.position = "bottom")

salvar_fig(f17, "Fig_17_tendencia_municipal", largura = 14, altura = 8)

######@> Tendência por estação do ano...
## Uma tendência anual média pode esconder comportamentos opostos entre
## estações - aquecimento de verão com inverno estável, por exemplo.
## Como os desastres têm sazonalidade marcada, saber EM QUE ÉPOCA DO
## ANO a mudança se concentra é mais informativo, para o capítulo, do
## que a taxa média anual.
tendencia_estacional <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        bind_rows(lapply(ordem_estacoes, function(est) {
            d <- litoral_mensal %>%
                filter(variavel == v, estacao == est) %>%
                group_by(ano) %>%
                summarise(valor = mean(valor), .groups = "drop") %>%
                arrange(ano)
            mk <- mann_kendall(d$valor)
            sen <- declividade_sen(d$valor, d$ano)
            tibble(variavel = v, estacao = est, tau = mk$tau,
                   p_valor = mk$p_valor, sen_por_decada = sen * 10)
        }))
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           estacao = factor(estacao, levels = ordem_estacoes),
           significativa = !is.na(p_valor) & p_valor < alfa)

tabelas[["Tab_24_tendencia_estacional"]] <-
    salvar_tab(tendencia_estacional, "Tab_24_tendencia_estacional")

######@> Figura 18 - tendência por estação do ano...
f18 <- tendencia_estacional %>%
    left_join(select(resumo_vars, variavel, dp), by = "variavel") %>%
    mutate(variacao_dp = sen_por_decada / 10 * (n_anos - 1) / dp,
           rotulo = factor(rotulo,
                           levels = rev(tendencia_litoral$rotulo[
                               order(tendencia_litoral$variacao_em_dp)]))) %>%
    ggplot(aes(x = estacao, y = rotulo, fill = variacao_dp)) +
    geom_tile(colour = "white", linewidth = 0.5) +
    geom_point(data = ~filter(.x, significativa), size = 1.2,
               colour = "grey15") +
    scale_fill_gradient2(low = "#2166AC", mid = "white",
                         high = "#B2182B", midpoint = 0,
                         name = "Variação no período (dp)") +
    labs(title = "Em que estação do ano a mudança se concentra",
         subtitle = paste0("Declividade de Sen por estação, ",
                           ano_ini_analise, "-", ano_fim_analise),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Pontos marcam as combinações com tendência significativa",
             "pelo teste de Mann-Kendall. Células de cores opostas na",
             "mesma linha indicam que a variável mudou em sentidos",
             "contrários conforme a época do ano - caso em que a taxa",
             "anual média é um resumo enganoso.")))

salvar_fig(f18, "Fig_18_tendencia_estacional", largura = 9, altura = 7)

message("Variáveis com tendência significativa no litoral: ",
        sum(tendencia_litoral$resultado != "Sem tendência detectada"),
        " de ", nrow(tendencia_litoral))

########################################################################
######@> Etapa 10 - Estrutura entre variáveis e redundância espacial...

message("\n--- Etapa 10: estrutura entre variáveis e redundância ---")

######@> Matriz de anomalias do litoral...
## Todas as correlações desta etapa são calculadas sobre ANOMALIAS. Se
## fossem calculadas sobre as séries brutas, mediriam sobretudo o fato
## de que quase tudo tem ciclo anual: temperatura e radiação apareceriam
## fortemente correlacionadas apenas por ambas subirem no verão. A
## anomalia remove esse denominador comum e deixa a co-variação que de
## fato informa - se um mês mais quente que o normal é também um mês
## mais chuvoso que o normal.
matriz_anomalias <- anomalia_litoral %>%
    select(variavel, ano, mes, anomalia) %>%
    pivot_wider(names_from = variavel, values_from = anomalia) %>%
    arrange(ano, mes)

cor_variaveis <- cor(select(matriz_anomalias, all_of(vars_dinamicas)),
                     use = "pairwise.complete.obs")

cor_longa <- as.data.frame(as.table(cor_variaveis)) %>%
    setNames(c("variavel_1", "variavel_2", "correlacao")) %>%
    mutate(across(c(variavel_1, variavel_2), as.character))

tabelas[["Tab_25_correlacao_entre_variaveis"]] <-
    salvar_tab(cor_longa %>%
               filter(variavel_1 < variavel_2) %>%
               mutate(rotulo_1 = vars_rotulo[variavel_1],
                      rotulo_2 = vars_rotulo[variavel_2]) %>%
               arrange(desc(abs(correlacao))),
               "Tab_25_correlacao_entre_variaveis")

######@> Ordenação das variáveis por similaridade...
## As linhas e colunas da matriz são reordenadas por agrupamento
## hierárquico sobre a distância 1 - |r|. Sem isso, a matriz apareceria
## em ordem arbitrária e os blocos de variáveis redundantes - que são o
## conteúdo relevante da figura - ficariam dispersos.
ordem_vars <- vars_dinamicas[
    hclust(as.dist(1 - abs(cor_variaveis)), method = "average")$order]

######@> Figura 19 - matriz de correlação entre variáveis...
f19 <- cor_longa %>%
    mutate(v1 = factor(vars_rotulo[variavel_1],
                       levels = vars_rotulo[ordem_vars]),
           v2 = factor(vars_rotulo[variavel_2],
                       levels = vars_rotulo[ordem_vars])) %>%
    ggplot(aes(x = v1, y = v2, fill = correlacao)) +
    geom_tile(colour = "white", linewidth = 0.4) +
    geom_text(aes(label = sprintf("%.2f", correlacao)), size = 2.1,
              colour = ifelse(abs(cor_longa$correlacao) > 0.6, "white",
                              "grey25")) +
    scale_fill_gradient2(low = "#2166AC", mid = "white",
                         high = "#B2182B", midpoint = 0,
                         limits = c(-1, 1), name = "Correlação") +
    labs(title = "Co-variação entre as anomalias climáticas",
         subtitle = paste0("Correlação de Pearson entre anomalias ",
                           "mensais do litoral, ", ano_ini_analise, "-",
                           ano_fim_analise),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Variáveis ordenadas por agrupamento hierárquico sobre",
             "1 - |r|, de modo que blocos contíguos reúnem variáveis",
             "redundantes entre si. Correlações calculadas sobre",
             "anomalias: o ciclo anual comum a quase todas as variáveis",
             "já foi removido, e o que resta é co-variação de fato."))) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 8),
          axis.text.y = element_text(size = 8))

salvar_fig(f19, "Fig_19_correlacao_variaveis", largura = 11,
           altura = 9.5)

######@> Redundância espacial: quantas séries independentes existem?...
## Para cada variável, a matriz município x mês de anomalias é
## submetida a uma análise de componentes principais. Três resumos
## interessam:
##
##   pc1_pct        : quanto o primeiro componente explica. Próximo de
##                    100% significa que todos os municípios são
##                    variações de escala de uma única série;
##   n_comp_95      : quantos componentes são necessários para 95% da
##                    variância - a dimensionalidade efetiva da
##                    variável neste recorte;
##   cor_mediana    : correlação mediana entre pares de municípios.
##
## Esta é a etapa que quantifica o achado (ii) do cabeçalho, e seu
## resultado é a informação mais consequente de toda a AED: define
## quantos graus de liberdade espaciais a base realmente oferece.
redundancia <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        larga <- longo %>%
            filter(variavel == v) %>%
            select(municipio, ano, mes, anomalia) %>%
            pivot_wider(names_from = municipio,
                        values_from = anomalia) %>%
            arrange(ano, mes) %>%
            select(-ano, -mes)
        m <- cor(larga, use = "pairwise.complete.obs")
        autovalores <- eigen(m, only.values = TRUE)$values
        acumulada <- cumsum(autovalores) / sum(autovalores)
        tibble(variavel = v,
               pc1_pct = 100 * autovalores[1] / sum(autovalores),
               n_comp_95 = which(acumulada >= 0.95)[1],
               n_comp_kaiser = sum(autovalores > 1),
               cor_mediana = median(m[upper.tri(m)]),
               cor_minima = min(m[upper.tri(m)]))
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           dominio = vars_dominio[variavel],
           graus_liberdade_espaciais = case_when(
               n_comp_95 <= 2 ~ "Praticamente uma única série",
               n_comp_95 <= 5 ~ "Poucos graus de liberdade",
               TRUE ~ "Estrutura espacial aproveitável")) %>%
    arrange(desc(pc1_pct)) %>%
    select(variavel, rotulo, dominio, pc1_pct, n_comp_95,
           n_comp_kaiser, cor_mediana, cor_minima,
           graus_liberdade_espaciais)

tabelas[["Tab_26_redundancia_espacial"]] <-
    salvar_tab(redundancia, "Tab_26_redundancia_espacial")

######@> Figura 20 - dimensionalidade efetiva por variável...
f20 <- redundancia %>%
    mutate(rotulo = factor(rotulo, levels = rev(redundancia$rotulo))) %>%
    ggplot(aes(x = pc1_pct, y = rotulo,
               colour = graus_liberdade_espaciais)) +
    geom_segment(aes(xend = 0, yend = rotulo), linewidth = 0.5) +
    geom_point(size = 3) +
    geom_text(aes(label = paste0(n_comp_95, " comp.")), hjust = -0.45,
              size = 2.9, show.legend = FALSE) +
    scale_x_continuous(limits = c(0, 112),
                       labels = label_percent(scale = 1),
                       expand = expansion(mult = c(0, 0))) +
    scale_colour_manual(
        values = c("Praticamente uma única série" = "#D55E00",
                   "Poucos graus de liberdade" = "#E69F00",
                   "Estrutura espacial aproveitável" = "#0072B2"),
        name = NULL) +
    labs(title = paste0("Quanta informação espacial independente há ",
                        "entre os ", n_municipios, " municípios?"),
         subtitle = paste0("Variância explicada pelo primeiro ",
                           "componente principal das anomalias mensais"),
         x = "Variância explicada pelo 1º componente", y = NULL,
         caption = quebrar(paste(
             "O rótulo à direita de cada ponto informa quantos",
             "componentes são necessários para atingir 95% da variância -",
             "a dimensionalidade efetiva da variável neste recorte. Uma",
             "variável cujo primeiro componente já explica quase toda a",
             "variância não distingue municípios: os 37 valores de cada",
             "mês são reescalas de um mesmo número."))) +
    theme(legend.position = "bottom")

salvar_fig(f20, "Fig_20_redundancia_espacial", largura = 11,
           altura = 6.5)

######@> A redundância vem da grade do ERA5?...
## Hipótese a testar: a correlação quase perfeita entre municípios é
## consequência da resolução da reanálise - municípios pequenos e
## vizinhos herdam o mesmo pixel e, portanto, quase o mesmo valor.
##
## O teste compara a correlação entre pares de municípios que
## COMPARTILHAM a célula dominante do ERA5 com a dos pares que não
## compartilham, controlando pela distância entre centroides. Se os
## pares que compartilham pixel tiverem correlação sistematicamente
## maior à mesma distância, a redundância é ARTEFATO DE GRADE - e não
## um fato climático sobre o litoral.
##
## A distinção importa: o artefato de grade não desaparece com mais
## dados nem com modelo melhor; é um limite da fonte.
pixel_dominante <- tabela_pesos %>%
    group_by(geocodigo) %>%
    slice_max(fracao_cobertura, n = 1, with_ties = FALSE) %>%
    ungroup() %>%
    select(geocodigo, celula_dominante = celula,
           fracao_dominante = fracao_cobertura) %>%
    mutate(geocodigo = as.character(geocodigo))

coords_mun <- pesos_area %>%
    select(geocodigo, municipio, lon_centroide, lat_centroide) %>%
    left_join(pixel_dominante, by = "geocodigo")

pares_municipios <- expand_grid(i = seq_len(nrow(coords_mun)),
                                j = seq_len(nrow(coords_mun))) %>%
    filter(i < j) %>%
    mutate(mun_1 = coords_mun$municipio[i],
           mun_2 = coords_mun$municipio[j],
           ## Distância aproximada em km, suficiente para ordenar pares
           ## em um recorte de poucos graus de latitude.
           distancia_km = sqrt(
               ((coords_mun$lon_centroide[i] -
                 coords_mun$lon_centroide[j]) *
                111 * cos(mean(coords_mun$lat_centroide) * pi / 180))^2 +
               ((coords_mun$lat_centroide[i] -
                 coords_mun$lat_centroide[j]) * 111)^2),
           mesmo_pixel = coords_mun$celula_dominante[i] ==
               coords_mun$celula_dominante[j]) %>%
    select(mun_1, mun_2, distancia_km, mesmo_pixel)

correlacao_pares <- bind_rows(
    lapply(vars_chave, function(v) {
        larga <- longo %>%
            filter(variavel == v) %>%
            select(municipio, ano, mes, anomalia) %>%
            pivot_wider(names_from = municipio,
                        values_from = anomalia) %>%
            arrange(ano, mes) %>%
            select(-ano, -mes)
        m <- cor(larga, use = "pairwise.complete.obs")
        as.data.frame(as.table(m)) %>%
            setNames(c("mun_1", "mun_2", "correlacao")) %>%
            mutate(across(c(mun_1, mun_2), as.character)) %>%
            inner_join(pares_municipios, by = c("mun_1", "mun_2")) %>%
            mutate(variavel = v)
    })) %>%
    mutate(rotulo = factor(vars_rotulo[variavel],
                           levels = vars_rotulo[vars_chave]),
           tipo_par = ifelse(mesmo_pixel, "Mesma célula dominante",
                             "Células distintas"))

resumo_pares <- correlacao_pares %>%
    group_by(variavel, rotulo, tipo_par) %>%
    summarise(n_pares = n(),
              distancia_mediana = median(distancia_km),
              cor_mediana = median(correlacao), .groups = "drop") %>%
    pivot_wider(names_from = tipo_par,
                values_from = c(n_pares, distancia_mediana,
                                cor_mediana)) %>%
    mutate(diferenca_correlacao =
               `cor_mediana_Mesma célula dominante` -
               `cor_mediana_Células distintas`)

######@> Controle pela distância...
## A comparação acima é confundida: pares que compartilham célula estão
## também muito mais próximos entre si (mediana de cerca de 13 km,
## contra 127 km dos demais), e correlação alta a curta distância seria
## esperada mesmo sem efeito de grade.
##
## O confundimento é removido restringindo a comparação aos pares
## PRÓXIMOS - abaixo do limiar definido a seguir, faixa em que existem
## pares dos dois tipos. Se, entre municípios igualmente próximos, os
## que partilham célula ainda tiverem correlação sistematicamente
## maior, o excesso é atribuível à resolução da fonte.
limiar_proximidade <- 40

resumo_pares_proximos <- correlacao_pares %>%
    filter(distancia_km <= limiar_proximidade) %>%
    group_by(variavel, tipo_par) %>%
    summarise(n = n(), cor_mediana = median(correlacao),
              .groups = "drop") %>%
    pivot_wider(names_from = tipo_par,
                values_from = c(n, cor_mediana)) %>%
    rename(n_proximos_mesma_celula = `n_Mesma célula dominante`,
           n_proximos_celulas_distintas = `n_Células distintas`,
           cor_proximos_mesma_celula =
               `cor_mediana_Mesma célula dominante`,
           cor_proximos_celulas_distintas =
               `cor_mediana_Células distintas`) %>%
    mutate(excesso_atribuivel_a_grade =
               cor_proximos_mesma_celula -
               cor_proximos_celulas_distintas)

resumo_pares <- resumo_pares %>%
    left_join(resumo_pares_proximos, by = "variavel")

tabelas[["Tab_27_efeito_grade_era5"]] <-
    salvar_tab(resumo_pares, "Tab_27_efeito_grade_era5")

message("Excesso de correlação atribuível à grade (pares a menos de ",
        limiar_proximidade, " km): ",
        paste(sprintf("%s %+.3f", resumo_pares$variavel,
                      resumo_pares$excesso_atribuivel_a_grade),
              collapse = " | "))

######@> Figura 21 - correlação contra distância...
f21 <- ggplot(correlacao_pares,
              aes(x = distancia_km, y = correlacao, colour = tipo_par)) +
    geom_point(size = 1.5, alpha = 0.6) +
    geom_smooth(method = "loess", formula = y ~ x, se = FALSE,
                linewidth = 0.8) +
    facet_wrap(~rotulo, scales = "free_y", ncol = 5) +
    scale_colour_manual(values = c("Mesma célula dominante" = "#D55E00",
                                   "Células distintas" = "#0072B2"),
                        name = NULL) +
    labs(title = "A semelhança entre municípios é clima ou é grade?",
         subtitle = paste0("Correlação entre anomalias mensais de cada ",
                           "par de municípios, contra a distância entre ",
                           "centroides"),
         x = "Distância entre centroides (km)",
         y = "Correlação entre anomalias",
         caption = quebrar(paste(
             "Pares em laranja têm a mesma célula do ERA5 como fonte",
             "principal, e estão concentrados nas distâncias curtas. A",
             "comparação justa é feita à MESMA distância: restrita aos",
             paste0("pares a menos de ", limiar_proximidade, " km, a"),
             "diferença entre laranja e azul cai para algo entre 0,005 e",
             "0,030 (Tab_27), de modo que a semelhança entre municípios",
             "próximos é sobretudo coerência climática real, e não",
             "imposição da grade. O decaimento da correlação com a",
             "distância mede a escala espacial de cada variável - abrupto",
             "no vento, gradual na temperatura."))) +
    theme(legend.position = "bottom")

salvar_fig(f21, "Fig_21_efeito_grade", largura = 14, altura = 6)

message("Dimensionalidade efetiva (95% da variância): ",
        paste0(redundancia$variavel[1], " = ", redundancia$n_comp_95[1],
               " comp.; mediana geral = ",
               median(redundancia$n_comp_95), " comp."))

########################################################################
######@> Etapa 11 - Distribuição, caudas e meses extremos...

message("\n--- Etapa 11: distribuição e extremos ---")

######@> Forma da distribuição das anomalias...
## A pergunta desta etapa: as anomalias são simétricas e de cauda leve,
## como pressupõem os modelos gaussianos, ou têm assimetria e caudas
## pesadas?
##
## A resposta separa duas famílias de variáveis. As térmicas e
## radiativas tendem à simetria, e uma anomalia positiva de dois
## desvios é tão provável quanto a negativa. As hídricas não: a
## precipitação é limitada inferiormente por zero e ilimitada acima, de
## modo que suas anomalias são assimétricas à direita - os meses
## excepcionalmente chuvosos afastam-se muito mais da normal do que os
## excepcionalmente secos. Como são justamente esses meses que
## produzem desastre, a assimetria não é detalhe técnico.
##
## O teste de Jarque-Bera é reportado por completude, com a ressalva de
## que, com mais de mil observações, ele rejeita a normalidade diante
## de afastamentos pequenos demais para ter consequência prática. A
## leitura substantiva deve se apoiar na assimetria e na curtose.
forma_distribuicao <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        x <- series_anomalia[[v]]
        n <- length(x)
        m <- mean(x); s <- sd(x)
        assimetria <- mean((x - m)^3) / s^3
        curtose <- mean((x - m)^4) / s^4 - 3
        jb <- tryCatch(suppressWarnings(jarque.bera.test(x)$p.value),
                       error = function(e) NA_real_)
        tibble(variavel = v, n = n, assimetria = assimetria,
               curtose_excesso = curtose, jarque_bera_p = jb,
               p01 = quantile(x, 0.01), p99 = quantile(x, 0.99),
               razao_caudas = abs(quantile(x, 0.99)) /
                   abs(quantile(x, 0.01)))
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           dominio = vars_dominio[variavel],
           forma = case_when(
               abs(assimetria) < 0.3 & abs(curtose_excesso) < 1 ~
                   "Aproximadamente simétrica",
               assimetria >= 0.3 ~ "Assimétrica à direita",
               assimetria <= -0.3 ~ "Assimétrica à esquerda",
               TRUE ~ "Simétrica com caudas pesadas")) %>%
    arrange(desc(abs(assimetria))) %>%
    select(variavel, rotulo, dominio, assimetria, curtose_excesso,
           jarque_bera_p, p01, p99, razao_caudas, forma)

tabelas[["Tab_28_forma_distribuicoes"]] <-
    salvar_tab(forma_distribuicao, "Tab_28_forma_distribuicoes")

######@> Figura 22 - distribuição das anomalias padronizadas...
## A curva normal sobreposta serve de referência visual: o afastamento
## dela, e não a forma isolada, é o que a figura comunica.
dados_f22 <- anomalia_litoral %>%
    filter(variavel %in% vars_chave) %>%
    mutate(painel = factor(vars_rotulo[variavel],
                           levels = vars_rotulo[vars_chave]))

f22 <- ggplot(dados_f22, aes(x = anomalia_z)) +
    geom_histogram(aes(y = after_stat(density)), bins = 45,
                   fill = "#0072B2", colour = "white",
                   linewidth = 0.15, alpha = 0.85) +
    stat_function(fun = dnorm, colour = "#D55E00", linewidth = 0.8,
                  linetype = "dashed") +
    facet_wrap(~painel, ncol = 5) +
    labs(title = "Distribuição das anomalias mensais padronizadas",
         subtitle = paste0("Litoral, ", ano_ini_analise, "-",
                           ano_fim_analise,
                           "; linha tracejada: normal padrão"),
         x = "Anomalia (desvios-padrão)", y = "Densidade",
         caption = quebrar(paste(
             "Assimetria à direita indica que os afastamentos positivos",
             "extremos são maiores que os negativos - situação típica das",
             "variáveis hídricas, limitadas inferiormente por zero. É a",
             "cauda direita que concentra os meses associados a eventos",
             "de desastre.")))

salvar_fig(f22, "Fig_22_distribuicao_anomalias", largura = 14,
           altura = 4.5)

######@> Meses extremos da série...
## Os dez meses mais afastados da normal, para cima e para baixo, em
## cada variável-chave. Serve de ponte com o Atlas Digital: estes são
## os meses candidatos a confronto com os registros de desastre.
extremos_mensais <- anomalia_litoral %>%
    filter(variavel %in% vars_chave) %>%
    group_by(variavel) %>%
    arrange(desc(anomalia_z)) %>%
    mutate(posicao_alta = row_number()) %>%
    arrange(anomalia_z) %>%
    mutate(posicao_baixa = row_number()) %>%
    ungroup() %>%
    filter(posicao_alta <= 10 | posicao_baixa <= 10) %>%
    mutate(rotulo = vars_rotulo[variavel],
           tipo = ifelse(posicao_alta <= 10, "Extremo positivo",
                         "Extremo negativo"),
           posicao = pmin(posicao_alta, posicao_baixa),
           mes_nome = meses_abrev[mes]) %>%
    arrange(variavel, tipo, posicao) %>%
    select(variavel, rotulo, tipo, posicao, ano, mes, mes_nome,
           anomalia, anomalia_z)

tabelas[["Tab_29_meses_extremos"]] <-
    salvar_tab(extremos_mensais, "Tab_29_meses_extremos")

######@> Frequência de meses extremos ao longo do tempo...
## Um mês é classificado como extremo quando sua anomalia excede dois
## desvios-padrão da referência. A contagem por década responde a uma
## pergunta que a tendência da média não responde: a frequência de
## extremos mudou?
##
## São perguntas distintas porque a média e a cauda podem se mover em
## sentidos diferentes - uma variável pode ter média estável e extremos
## cada vez mais frequentes, se sua variabilidade aumentar. Para
## análise de desastre, é a cauda que importa.
##
## A última década é parcial (menos de dez anos completos) e por isso a
## contagem é normalizada por 120 meses, tornando as décadas
## comparáveis.
extremos_por_decada <- anomalia_litoral %>%
    mutate(decada = (ano %/% 10) * 10) %>%
    group_by(variavel, decada) %>%
    summarise(n_meses = n(),
              n_extremos_altos = sum(anomalia_z > 2, na.rm = TRUE),
              n_extremos_baixos = sum(anomalia_z < -2, na.rm = TRUE),
              .groups = "drop") %>%
    mutate(taxa_altos = 120 * n_extremos_altos / n_meses,
           taxa_baixos = 120 * n_extremos_baixos / n_meses,
           rotulo = vars_rotulo[variavel])

tabelas[["Tab_30_extremos_por_decada"]] <-
    salvar_tab(extremos_por_decada, "Tab_30_extremos_por_decada")

######@> Tendência da frequência de extremos...
tendencia_extremos <- extremos_por_decada %>%
    group_by(variavel, rotulo) %>%
    summarise(mk_altos_tau = mann_kendall(taxa_altos)$tau,
              mk_altos_p = mann_kendall(taxa_altos)$p_valor,
              mk_baixos_tau = mann_kendall(taxa_baixos)$tau,
              mk_baixos_p = mann_kendall(taxa_baixos)$p_valor,
              taxa_altos_inicio = taxa_altos[which.min(decada)],
              taxa_altos_fim = taxa_altos[which.max(decada)],
              .groups = "drop") %>%
    mutate(extremos_altos = case_when(
               is.na(mk_altos_p) ~ "Indefinido",
               mk_altos_p >= alfa ~ "Frequência estável",
               mk_altos_tau > 0 ~ "Frequência crescente",
               TRUE ~ "Frequência decrescente")) %>%
    arrange(mk_altos_p)

tabelas[["Tab_31_tendencia_extremos"]] <-
    salvar_tab(tendencia_extremos, "Tab_31_tendencia_extremos")

######@> Tendência da frequência de extremos em base ANUAL...
## A tabela anterior é descritiva: com apenas nove décadas, o
## Mann-Kendall tem potência baixa demais para sustentar conclusão, e
## quase nada seria declarado significativo mesmo diante de uma
## mudança real. A contagem ANUAL de meses extremos dá 86 observações
## ao teste e é a versão em que a tendência da cauda pode de fato ser
## avaliada.
##
## As duas são mantidas porque respondem a coisas diferentes: a
## decenal é o retrato que se lê na figura, a anual é o teste.
extremos_por_ano <- anomalia_litoral %>%
    group_by(variavel, ano) %>%
    summarise(n_altos = sum(anomalia_z > 2, na.rm = TRUE),
              n_baixos = sum(anomalia_z < -2, na.rm = TRUE),
              .groups = "drop")

tendencia_extremos_anual <- bind_rows(
    lapply(vars_dinamicas, function(v) {
        d <- extremos_por_ano %>% filter(variavel == v) %>%
            arrange(ano)
        mk_a <- mann_kendall(d$n_altos)
        mk_b <- mann_kendall(d$n_baixos)
        tibble(variavel = v,
               media_altos_por_ano = mean(d$n_altos),
               tau_altos = mk_a$tau, p_altos = mk_a$p_valor,
               sen_altos_por_decada =
                   declividade_sen(d$n_altos, d$ano) * 10,
               media_baixos_por_ano = mean(d$n_baixos),
               tau_baixos = mk_b$tau, p_baixos = mk_b$p_valor,
               sen_baixos_por_decada =
                   declividade_sen(d$n_baixos, d$ano) * 10)
    })) %>%
    mutate(rotulo = vars_rotulo[variavel],
           dominio = vars_dominio[variavel],
           resultado_altos = case_when(
               is.na(p_altos) ~ "Indefinido",
               p_altos >= alfa ~ "Frequência estável",
               tau_altos > 0 ~ "Frequência crescente",
               TRUE ~ "Frequência decrescente"),
           resultado_baixos = case_when(
               is.na(p_baixos) ~ "Indefinido",
               p_baixos >= alfa ~ "Frequência estável",
               tau_baixos > 0 ~ "Frequência crescente",
               TRUE ~ "Frequência decrescente")) %>%
    arrange(p_altos) %>%
    select(variavel, rotulo, dominio, media_altos_por_ano, tau_altos,
           p_altos, sen_altos_por_decada, resultado_altos,
           media_baixos_por_ano, tau_baixos, p_baixos,
           sen_baixos_por_decada, resultado_baixos)

tabelas[["Tab_32_tendencia_extremos_anual"]] <-
    salvar_tab(tendencia_extremos_anual,
               "Tab_32_tendencia_extremos_anual")

######@> Figura 23 - frequência de extremos por década...
f23 <- extremos_por_decada %>%
    filter(variavel %in% vars_chave) %>%
    select(rotulo, decada, taxa_altos, taxa_baixos) %>%
    pivot_longer(c(taxa_altos, taxa_baixos), names_to = "tipo",
                 values_to = "taxa") %>%
    mutate(tipo = recode(tipo,
                         taxa_altos = "Anomalia acima de +2 dp",
                         taxa_baixos = "Anomalia abaixo de -2 dp"),
           taxa = ifelse(tipo == "Anomalia abaixo de -2 dp", -taxa,
                         taxa),
           painel = factor(rotulo, levels = vars_rotulo[vars_chave])) %>%
    ggplot(aes(x = decada, y = taxa, fill = tipo)) +
    geom_col(width = 8) +
    geom_hline(yintercept = 0, colour = "grey30") +
    facet_wrap(~painel, ncol = 5) +
    scale_fill_manual(values = c("Anomalia acima de +2 dp" = "#B2182B",
                                 "Anomalia abaixo de -2 dp" = "#2166AC"),
                      name = NULL) +
    labs(title = "Frequência de meses extremos por década",
         subtitle = paste0("Meses com anomalia além de dois ",
                           "desvios-padrão da normal ", ref_ini, "-",
                           ref_fim),
         x = NULL, y = "Meses extremos por década (base 120 meses)",
         caption = quebrar(paste(
             "Barras acima do eixo: meses excepcionalmente altos; abaixo:",
             "excepcionalmente baixos. As contagens são normalizadas para",
             "120 meses porque a última década da série é parcial. A",
             "referência de padronização é 1991-2020, de modo que as",
             "décadas centrais têm, por construção, menos extremos que as",
             "extremidades da série - o que deve ser considerado na",
             "leitura."))) +
    theme(legend.position = "bottom")

salvar_fig(f23, "Fig_23_extremos_por_decada", largura = 14,
           altura = 5.5)

message("Variáveis com frequência crescente de extremos altos: ",
        sum(tendencia_extremos_anual$resultado_altos ==
            "Frequência crescente"), " de ",
        nrow(tendencia_extremos_anual), " (teste em base anual)")

########################################################################
######@> Etapa 12 - Padrões espaciais: mapas e Moran...

message("\n--- Etapa 12: padrões espaciais ---")

######@> Junção dos indicadores ao shapefile...
mapa_dados <- municipios_sf %>%
    left_join(perfil_municipio %>%
                  select(geocodigo, all_of(vars_chave),
                         balanco_hidrico, constancia_vento),
              by = "geocodigo") %>%
    left_join(tendencia_municipal %>%
                  filter(variavel == "t2m_C") %>%
                  select(geocodigo, tend_t2m = sen_por_decada,
                         p_tend_t2m = p_valor),
              by = "geocodigo") %>%
    left_join(tendencia_municipal %>%
                  filter(variavel == "tp_mm_dia") %>%
                  select(geocodigo, tend_tp = sen_por_decada),
              by = "geocodigo") %>%
    left_join(pixel_dominante, by = "geocodigo")

######@> Função de mapa coroplético...
## Centralizada para que todos os mapas compartilhem projeção, tema e
## tratamento das legendas.
mapa_base <- function(dados, variavel, titulo, subtitulo, legenda,
                      paleta = "viridis", direcao = -1,
                      caption = NULL) {
    ggplot(dados) +
        geom_sf(aes(fill = .data[[variavel]]), colour = "grey30",
                linewidth = 0.2) +
        scale_fill_viridis_c(option = paleta, direction = direcao,
                             name = legenda, na.value = "grey85") +
        labs(title = titulo, subtitle = subtitulo, caption = caption) +
        theme_void(base_size = 11) +
        theme(plot.title = element_text(face = "bold", size = 13),
              plot.subtitle = element_text(colour = "grey30", size = 10),
              plot.caption = element_text(colour = "grey45", size = 8,
                                          hjust = 0),
              legend.position = "right")
}

######@> Mapa 01 - temperatura média...
m1 <- mapa_base(mapa_dados, "t2m_C",
                "Temperatura média do ar",
                paste0("Média de ", ano_ini_analise, "-",
                       ano_fim_analise, ", reanálise ERA5"),
                "°C", paleta = "inferno", direcao = 1,
                caption = quebrar_mapa(paste(
                    "A variação total entre os municípios é de cerca de",
                    "dois graus, e o padrão é o gradiente latitudinal",
                    "esperado. Os patamares visíveis correspondem às",
                    "células de 0,25 grau da reanálise.")))

salvar_fig(m1, "Mapa_01_temperatura_media", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 02 - precipitação média...
m2 <- mapa_base(mapa_dados, "tp_mm_dia",
                "Precipitação média diária",
                paste0("Média de ", ano_ini_analise, "-",
                       ano_fim_analise, ", reanálise ERA5"),
                "mm/dia", paleta = "mako",
                caption = quebrar_mapa(paste(
                    "Ao contrário da temperatura, a precipitação não",
                    "segue um gradiente latitudinal simples: o padrão é",
                    "de núcleos, associados ao relevo e à orientação da",
                    "costa.")))

salvar_fig(m2, "Mapa_02_precipitacao_media", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 03 - velocidade média do vento...
m3 <- mapa_base(mapa_dados, "si10",
                "Velocidade média do vento a 10 m",
                paste0("Média de ", ano_ini_analise, "-",
                       ano_fim_analise, " (si10, velocidade escalar)"),
                "m/s", paleta = "viridis",
                caption = quebrar_mapa(paste(
                    "Municípios com maior fração de área sobre o mar na",
                    "célula do ERA5 apresentam vento mais intenso, pela",
                    "menor rugosidade da superfície - efeito que é",
                    "parcialmente da fonte, e não do território.")))

salvar_fig(m3, "Mapa_03_vento_medio", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 04 - tendência térmica...
m4 <- ggplot(mapa_dados) +
    geom_sf(aes(fill = tend_t2m), colour = "grey30", linewidth = 0.2) +
    scale_fill_gradient2(low = "#2166AC", mid = "white",
                         high = "#B2182B",
                         midpoint = 0, name = "°C/década",
                         na.value = "grey85") +
    labs(title = "Tendência da temperatura por município",
         subtitle = paste0("Declividade de Sen, ", ano_ini_analise, "-",
                           ano_fim_analise),
         caption = quebrar_mapa(paste(
             "A homogeneidade do mapa é o resultado relevante: o",
             "aquecimento é regional e não distingue municípios. Um",
             "modelo com tendência específica por município estaria",
             "ajustando ruído."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m4, "Mapa_04_tendencia_temperatura", largura = 8,
           altura = 9, diretorio = dir_mapa)

######@> Mapa 05 - célula dominante do ERA5...
## O mapa que torna visível o achado (ii): municípios pintados com a
## mesma cor extraem seu valor principal da MESMA célula da reanálise e
## têm, por construção, séries quase idênticas.
m5 <- ggplot(mapa_dados) +
    geom_sf(aes(fill = factor(celula_dominante)), colour = "grey20",
            linewidth = 0.25) +
    scale_fill_viridis_d(option = "turbo", guide = "none") +
    labs(title = "Célula do ERA5 que domina cada município",
         subtitle = paste0(n_distinct(mapa_dados$celula_dominante),
                           " células distintas para ", n_municipios,
                           " municípios"),
         caption = quebrar_mapa(paste(
             "Municípios de mesma cor têm a mesma célula de 0,25 grau",
             "como fonte principal de seus valores, e correlação entre",
             "suas anomalias superior a 0,99 em todas as variáveis. A",
             "Etapa 10 mostra que essa semelhança se deve principalmente",
             "à proximidade, e não ao compartilhamento do pixel: o mapa",
             "documenta a estrutura de amostragem da fonte, não a causa",
             "da redundância. Cores sem relação de ordem: servem apenas",
             "para distinguir células."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0))

salvar_fig(m5, "Mapa_05_celula_dominante", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 06 - número de pixels por município...
m6 <- mapa_base(mapa_dados %>% mutate(n_pixels = as.numeric(n_pixels)),
                "n_pixels",
                "Número de células do ERA5 por município",
                "Quanto maior, mais rica a agregação municipal",
                "Células", paleta = "cividis",
                caption = quebrar_mapa(paste(
                    "Municípios cobertos por uma única célula têm desvio",
                    "espacial interno nulo por construção: seus valores",
                    "são os do pixel, sem nenhuma agregação. Os sufixos",
                    "_dp, _min e _max são degenerados nesses casos.")))

salvar_fig(m6, "Mapa_06_pixels_por_municipio", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Autocorrelação espacial...
## Em uma base climática, a expectativa é de autocorrelação espacial
## FORTE - campos atmosféricos são contínuos por natureza, e municípios
## vizinhos partilham a mesma massa de ar. O valor informativo do
## índice de Moran aqui não é confirmar essa obviedade, mas medir sua
## MAGNITUDE: um índice próximo do máximo indica que a variável não
## carrega qualquer informação local, e que tratar municípios como
## unidades independentes seria pseudo-replicação.
##
## Como na AED do Atlas, o índice é calculado sob dois esquemas de
## vizinhança - contiguidade e k vizinhos mais próximos - para
## verificar se a conclusão depende dessa escolha.
vizinhanca <- poly2nb(mapa_dados, queen = TRUE)
componentes <- n.comp.nb(vizinhanca)$nc
sem_vizinho <- sum(card(vizinhanca) == 0)

criterio_vizinhanca <- sprintf(
    "Contiguidade (queen): %.2f vizinhos em média, %d componente(s)",
    mean(card(vizinhanca)), componentes)

coords_centroides <- suppressWarnings(
    st_coordinates(st_centroid(mapa_dados)))
vizinhanca_knn <- knn2nb(knearneigh(coords_centroides, k = 4))

pesos_viz <- nb2listw(vizinhanca, style = "W", zero.policy = TRUE)
pesos_knn <- nb2listw(vizinhanca_knn, style = "W")

message("Vizinhança espacial: ", criterio_vizinhanca)
if(sem_vizinho > 0) {
    warning("Municípios sem vizinho por contiguidade: ", sem_vizinho)
}

######@> Índice de Moran global...
indicadores_moran <- c(vars_chave, "balanco_hidrico", "tend_t2m")

testar_moran <- function(x, listw, rotulo, esquema) {
    if(all(is.na(x)) || var(x, na.rm = TRUE) == 0) return(NULL)
    teste <- moran.test(x, listw, zero.policy = TRUE)
    tibble(indicador = rotulo, esquema_vizinhanca = esquema,
           moran_i = as.numeric(teste$estimate[1]),
           esperado = as.numeric(teste$estimate[2]),
           p_valor = teste$p.value)
}

moran_global <- bind_rows(
    lapply(indicadores_moran, function(v) {
        rotulo <- ifelse(v %in% names(vars_rotulo), vars_rotulo[v],
                         "Tendência térmica (°C/década)")
        bind_rows(
            testar_moran(mapa_dados[[v]], pesos_viz, rotulo,
                         "Contiguidade"),
            testar_moran(mapa_dados[[v]], pesos_knn, rotulo,
                         "kNN (k = 4)"))
    })) %>%
    mutate(interpretacao = case_when(
               p_valor >= alfa ~ "Sem autocorrelação detectada",
               moran_i > 0.7 ~ "Agrupamento espacial muito forte",
               moran_i > 0.3 ~ "Agrupamento espacial moderado",
               moran_i > 0 ~ "Agrupamento espacial fraco",
               TRUE ~ "Dispersão espacial"))

moran_global <- moran_global %>%
    group_by(indicador) %>%
    mutate(conclusao_robusta =
               ifelse(n_distinct(interpretacao) == 1,
                      "Sim - mesma conclusão nos dois esquemas",
                      "Não - conclusão depende do esquema")) %>%
    ungroup()

tabelas[["Tab_33_moran_global"]] <-
    salvar_tab(moran_global, "Tab_33_moran_global")

######@> Moran local (LISA) sobre a temperatura média...
## O LISA decompõe o índice global em contribuições municipais e
## classifica cada município conforme seu valor e o de seus vizinhos.
## Em um campo climático suave, espera-se predominância de
## agrupamentos alto-alto e baixo-baixo, sem discordantes - e é a
## AUSÊNCIA de municípios discordantes que confirma não haver estrutura
## local a explorar.
lisa <- localmoran(mapa_dados$t2m_C, pesos_viz, zero.policy = TRUE)

media_t2m <- mean(mapa_dados$t2m_C, na.rm = TRUE)
defasagem <- lag.listw(pesos_viz, mapa_dados$t2m_C, zero.policy = TRUE)

mapa_dados <- mapa_dados %>%
    mutate(lisa_i = lisa[, 1],
           lisa_p = lisa[, ncol(lisa)],
           lisa_classe = case_when(
               lisa_p >= alfa ~ "Não significativo",
               t2m_C >= media_t2m & defasagem >= media_t2m ~
                   "Alto-Alto",
               t2m_C < media_t2m & defasagem < media_t2m ~
                   "Baixo-Baixo",
               t2m_C >= media_t2m & defasagem < media_t2m ~
                   "Alto-Baixo",
               TRUE ~ "Baixo-Alto"))

tabelas[["Tab_34_lisa_temperatura"]] <-
    salvar_tab(st_drop_geometry(mapa_dados) %>%
               select(geocodigo, municipio, t2m_C, lisa_i, lisa_p,
                      lisa_classe),
               "Tab_34_lisa_temperatura")

######@> Mapa 07 - agrupamentos LISA da temperatura...
m7 <- ggplot(mapa_dados) +
    geom_sf(aes(fill = lisa_classe), colour = "grey30",
            linewidth = 0.2) +
    scale_fill_manual(values = c("Alto-Alto" = "#B2182B",
                                 "Baixo-Baixo" = "#2166AC",
                                 "Alto-Baixo" = "#F4A582",
                                 "Baixo-Alto" = "#92C5DE",
                                 "Não significativo" = "grey88"),
                      name = "Agrupamento") +
    labs(title = "Agrupamentos locais de temperatura (LISA)",
         subtitle = paste0("Moran local sobre a média ",
                           ano_ini_analise, "-", ano_fim_analise,
                           ", vizinhança por contiguidade"),
         caption = quebrar_mapa(paste(
             "Agrupamentos Alto-Alto ao norte e Baixo-Baixo ao sul",
             "reproduzem o gradiente latitudinal, sem nenhum município",
             "discordante de seus vizinhos. A ausência de discordantes",
             "indica campo espacialmente suave, sem estrutura local a",
             "explorar."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m7, "Mapa_07_lisa_temperatura", largura = 8, altura = 9,
           diretorio = dir_mapa)

message("Moran global da temperatura (contiguidade): ",
        sprintf("%.3f", moran_global$moran_i[
            moran_global$indicador == vars_rotulo["t2m_C"] &
            moran_global$esquema_vizinhanca == "Contiguidade"]))

########################################################################
######@> Etapa 13 - Agrupamento de municípios por perfil climático...

message("\n--- Etapa 13: perfis climáticos municipais ---")

######@> Construção da matriz de perfis...
## O perfil de um município reúne três blocos de informação:
##
##   nível      : médias de longo prazo das variáveis-chave;
##   sazonal    : amplitude do ciclo anual de temperatura e chuva, que
##                distingue municípios de estações contrastadas dos de
##                clima mais uniforme;
##   superfície : cobertura de vegetação alta e índice de área foliar,
##                os descritores estáticos recuperados na Etapa 02.
##
## Incluir os descritores estáticos é o que dá sentido ao agrupamento:
## se apenas as médias climáticas fossem usadas, o resultado
## reproduziria o gradiente latitudinal e nada acrescentaria ao que os
## mapas já mostram.
amplitude_sazonal_mun <- longo %>%
    filter(variavel %in% c("t2m_C", "tp_mm_dia"),
           ano >= ref_ini, ano <= ref_fim) %>%
    group_by(municipio, variavel, mes) %>%
    summarise(normal = mean(valor), .groups = "drop") %>%
    group_by(municipio, variavel) %>%
    summarise(amplitude = max(normal) - min(normal), .groups = "drop") %>%
    pivot_wider(names_from = variavel, values_from = amplitude,
                names_prefix = "amp_")

perfil_matriz <- perfil_municipio %>%
    select(geocodigo, municipio, all_of(vars_chave),
           balanco_hidrico, constancia_vento) %>%
    left_join(amplitude_sazonal_mun, by = "municipio") %>%
    left_join(select(descritores_fixos, geocodigo, cvh, lai_hv),
              by = "geocodigo")

vars_perfil <- setdiff(names(perfil_matriz),
                       c("geocodigo", "municipio"))

matriz_z <- perfil_matriz %>%
    select(all_of(vars_perfil)) %>%
    scale() %>%
    as.data.frame()
rownames(matriz_z) <- perfil_matriz$municipio

######@> Agrupamento hierárquico...
## Distância euclidiana sobre as variáveis padronizadas e ligação de
## Ward, que tende a formar grupos de tamanho equilibrado - preferível
## aqui, onde o objetivo é descrever tipologias e não isolar valores
## extremos. A padronização é indispensável: sem ela, a distância seria
## dominada pela radiação, cuja escala numérica é duas ordens de
## grandeza maior que a das demais.
distancias <- dist(matriz_z, method = "euclidean")
agrupamento <- hclust(distancias, method = "ward.D2")

######@> Escolha do número de grupos pela silhueta média...
## A silhueta de cada município compara sua distância média aos
## companheiros de grupo com a distância média ao grupo vizinho mais
## próximo; varia de -1 a 1, e valores altos indicam agrupamento bem
## separado. É calculada no próprio script para não acrescentar
## dependência de pacote apenas por esta métrica.
##
## O critério NÃO é o máximo simples. Neste conjunto a silhueta cresce
## monotonicamente até o limite da faixa examinada, de modo que o
## "máximo" seria apenas o maior k testado - um artefato de borda, e
## não um ótimo. Isso é esperado quando os municípios se distribuem ao
## longo de um gradiente contínuo, sem grupos naturalmente separados:
## qualquer partição adicional melhora um pouco a métrica.
##
## Adota-se, por isso, uma regra de parcimônia declarada: o MENOR k
## cuja silhueta esteja a menos de uma tolerância do melhor valor
## observado. Ganhos marginais abaixo dessa tolerância não justificam
## um grupo a mais em uma tipologia descritiva com 37 unidades.
silhueta_media <- function(matriz_dist, grupos) {
    m <- as.matrix(matriz_dist)
    unicos <- unique(grupos)
    if(length(unicos) < 2) return(NA_real_)
    valores <- vapply(seq_along(grupos), function(i) {
        proprio <- grupos == grupos[i]
        proprio[i] <- FALSE
        if(!any(proprio)) return(0)
        a <- mean(m[i, proprio])
        b <- min(vapply(setdiff(unicos, grupos[i]), function(g)
            mean(m[i, grupos == g]), numeric(1)))
        (b - a) / max(a, b)
    }, numeric(1))
    mean(valores)
}

tolerancia_silhueta <- 0.02

avaliacao_k <- tibble(k = 2:6) %>%
    mutate(silhueta = vapply(k, function(kk)
        silhueta_media(distancias, cutree(agrupamento, k = kk)),
        numeric(1)),
        distancia_do_melhor = max(silhueta) - silhueta,
        aceitavel = distancia_do_melhor <= tolerancia_silhueta)

n_clusters <- min(avaliacao_k$k[avaliacao_k$aceitavel])

tabelas[["Tab_35_escolha_num_perfis"]] <-
    salvar_tab(avaliacao_k, "Tab_35_escolha_num_perfis")

message("Número de perfis escolhido: ", n_clusters,
        " (silhueta = ",
        sprintf("%.3f", avaliacao_k$silhueta[avaliacao_k$k ==
                                             n_clusters]),
        "; melhor observada = ",
        sprintf("%.3f", max(avaliacao_k$silhueta)),
        ", em k = ", avaliacao_k$k[which.max(avaliacao_k$silhueta)],
        ")")

grupos_cluster <- cutree(agrupamento, k = n_clusters)

perfil_matriz <- perfil_matriz %>%
    mutate(perfil = paste0("Perfil ",
                           grupos_cluster[match(municipio,
                                                names(grupos_cluster))]))

######@> Caracterização dos perfis...
caracterizacao <- perfil_matriz %>%
    group_by(perfil) %>%
    summarise(n_municipios = n(),
              across(all_of(vars_perfil), mean),
              municipios = paste(municipio, collapse = ", "),
              .groups = "drop")

tabelas[["Tab_36_perfis_municipios"]] <-
    salvar_tab(perfil_matriz %>%
               select(geocodigo, municipio, perfil, everything()),
               "Tab_36_perfis_municipios")

tabelas[["Tab_37_caracterizacao_perfis"]] <-
    salvar_tab(caracterizacao, "Tab_37_caracterizacao_perfis")

######@> Extração dos segmentos do dendrograma...
## Feita manualmente para desenhar a árvore em ggplot sem acrescentar
## dependência de pacote apenas para isso, mantendo o tema visual do
## documento.
segmentos_dendrograma <- function(h) {
    posicoes <- order(order(h$order))
    coord_x <- numeric(nrow(h$merge))
    coord_y <- numeric(nrow(h$merge))
    segs <- list()
    for(k in seq_len(nrow(h$merge))) {
        filhos <- h$merge[k, ]
        xs <- numeric(2); ys <- numeric(2)
        for(j in 1:2) {
            if(filhos[j] < 0) {
                xs[j] <- posicoes[-filhos[j]]
                ys[j] <- 0
            } else {
                xs[j] <- coord_x[filhos[j]]
                ys[j] <- coord_y[filhos[j]]
            }
        }
        coord_x[k] <- mean(xs)
        coord_y[k] <- h$height[k]
        segs[[k]] <- data.frame(
            x = c(xs[1], xs[1], xs[2]),
            y = c(ys[1], h$height[k], h$height[k]),
            xend = c(xs[1], xs[2], xs[2]),
            yend = c(h$height[k], h$height[k], ys[2]))
    }
    do.call(rbind, segs)
}

######@> Figura 24 - dendrograma dos perfis...
ordem_dend <- agrupamento$labels[agrupamento$order]
altura_corte <- mean(rev(sort(agrupamento$height))[c(n_clusters - 1,
                                                     n_clusters)])

f24 <- ggplot() +
    geom_segment(data = segmentos_dendrograma(agrupamento),
                 aes(x = x, y = y, xend = xend, yend = yend),
                 colour = "grey35", linewidth = 0.4) +
    geom_hline(yintercept = altura_corte, linetype = "dashed",
               colour = "#D55E00") +
    scale_x_continuous(breaks = seq_along(ordem_dend),
                       labels = ordem_dend, expand = c(0.02, 0.02)) +
    labs(title = "Agrupamento dos municípios por perfil climático",
         subtitle = paste0("Ligação de Ward sobre ", length(vars_perfil),
                           " variáveis padronizadas de nível, ",
                           "sazonalidade e superfície"),
         x = NULL, y = "Distância",
         caption = quebrar(paste0(
             "Linha tracejada: corte adotado, em ", n_clusters,
             " perfis. A silhueta média cresce monotonicamente na faixa ",
             "examinada (2 a 6 grupos), sinal de gradiente contínuo e ",
             "não de grupos naturalmente separados; adotou-se por isso o ",
             "menor k a menos de ", tolerancia_silhueta,
             " do melhor valor observado. Ver Tab_37 para a ",
             "caracterização de cada perfil."))) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5,
                                     size = 8))

salvar_fig(f24, "Fig_24_dendrograma_perfis", largura = 12, altura = 7)

######@> Figura 25 - assinatura dos perfis...
## Mostra, para cada perfil, o afastamento médio de cada variável em
## relação ao conjunto - em desvios-padrão. É o que permite NOMEAR os
## perfis: um grupo com temperatura alta, amplitude sazonal baixa e
## vegetação alta densa é qualitativamente distinto de outro com o
## padrão oposto, e a figura torna essa distinção legível de uma vez.
assinatura <- matriz_z %>%
    mutate(municipio = rownames(matriz_z),
           perfil = perfil_matriz$perfil[match(rownames(matriz_z),
                                               perfil_matriz$municipio)]) %>%
    pivot_longer(all_of(vars_perfil), names_to = "variavel",
                 values_to = "z") %>%
    group_by(perfil, variavel) %>%
    summarise(z_medio = mean(z), .groups = "drop") %>%
    mutate(rotulo = case_when(
               variavel %in% names(vars_rotulo) ~
                   vars_rotulo[variavel],
               variavel == "amp_t2m_C" ~ "Amplitude sazonal térmica",
               variavel == "amp_tp_mm_dia" ~ "Amplitude sazonal da chuva",
               variavel == "cvh" ~ "Cobertura de vegetação alta",
               variavel == "lai_hv" ~ "Índice de área foliar (alta)",
               TRUE ~ variavel))

f25 <- ggplot(assinatura, aes(x = perfil, y = rotulo, fill = z_medio)) +
    geom_tile(colour = "white", linewidth = 0.5) +
    geom_text(aes(label = sprintf("%+.1f", z_medio)), size = 2.9,
              colour = ifelse(abs(assinatura$z_medio) > 1.2, "white",
                              "grey20")) +
    scale_fill_gradient2(low = "#2166AC", mid = "white",
                         high = "#B2182B", midpoint = 0,
                         name = "Desvios-padrão") +
    labs(title = "Assinatura de cada perfil climático",
         subtitle = paste0("Afastamento médio em relação ao conjunto ",
                           "dos ", n_municipios, " municípios"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Valores positivos indicam que o perfil está acima da média",
             "do litoral naquela variável. Como as variáveis foram",
             "padronizadas antes do agrupamento, a escala é comparável",
             "entre linhas.")))

salvar_fig(f25, "Fig_25_assinatura_perfis", largura = 9, altura = 6.5)

######@> Mapa 08 - distribuição espacial dos perfis...
m8 <- municipios_sf %>%
    left_join(select(perfil_matriz, geocodigo, perfil),
              by = "geocodigo") %>%
    ggplot() +
    geom_sf(aes(fill = perfil), colour = "grey30", linewidth = 0.2) +
    scale_fill_brewer(palette = "Set2", name = "Perfil") +
    labs(title = "Perfis climáticos dos municípios costeiros",
         subtitle = paste0(n_clusters, " agrupamentos por ligação de ",
                           "Ward sobre variáveis padronizadas"),
         caption = quebrar_mapa(paste(
             "A contiguidade dos perfis ao longo da costa indica que o",
             "agrupamento recupera, em boa medida, a organização",
             "latitudinal do clima - resultado esperado, e que serve",
             "aqui como verificação de coerência da tipologia."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m8, "Mapa_08_perfis_climaticos", largura = 8, altura = 9,
           diretorio = dir_mapa)

########################################################################
######@> Etapa 14 - Exportação consolidada e síntese...

message("\n--- Etapa 14: exportação e síntese ---")

######@> Arquivo XLSX com todas as tabelas...
## Nomes de aba limitados a 31 caracteres pela especificação do formato.
nomes_abas <- substr(names(tabelas), 1, 31)
names(tabelas) <- nomes_abas

write_xlsx(map(tabelas, as.data.frame),
           file.path(dir_tab, "AED_ERA5_todas_as_tabelas.xlsx"))

######@> Atalhos para os números citados no relatório...
## Extraídos em variáveis nomeadas para que o texto abaixo seja legível
## e para que qualquer alteração no cálculo se propague ao relatório
## sem edição manual.
mk_t2m <- tendencia_litoral %>% filter(variavel == "t2m_C")
mk_tp <- tendencia_litoral %>% filter(variavel == "tp_mm_dia")
red_t2m <- redundancia %>% filter(variavel == "t2m_C")
red_tp <- redundancia %>% filter(variavel == "tp_mm_dia")
mem_t2m <- memoria_anomalias %>% filter(variavel == "t2m_C")
stl_t <- stl_litoral %>% filter(variavel == "t2m_C")
het_vento <- heterogeneidade %>% filter(variavel == "si10")
het_temp <- heterogeneidade %>% filter(variavel == "t2m_C")

######@> Relatório de síntese em texto...
## Registra os números que sustentam as afirmações do capítulo, de modo
## que possam ser citados sem reabrir os objetos do R.
linhas_relatorio <- c(
    "########################################################################",
    "## ANÁLISE EXPLORATÓRIA - REANÁLISE ERA5",
    paste0("## Litoral de Santa Catarina | ", ano_ini_analise, "-",
           ano_fim_analise),
    paste0("## Gerado em ", format(Sys.time(), "%d/%m/%Y %H:%M")),
    "########################################################################",
    "",
    "1. COBERTURA DA BASE",
    paste0("   Municípios analisados       : ", n_municipios),
    paste0("   Período                     : ", ano_ini_analise, " a ",
           ano_fim_analise, " (", n_anos, " anos, ", n_anos * 12,
           " meses)"),
    paste0("   Ano parcial excluído        : ", ano_max, " (",
           meses_ano_parcial, " meses)"),
    paste0("   Observações município-mês   : ", fmt_int(nrow(dat))),
    paste0("   Células ERA5 utilizadas     : ",
           n_distinct(tabela_pesos$celula), " (grade de 0,25°)"),
    paste0("   Células dominantes distintas: ",
           n_distinct(pixel_dominante$celula_dominante), " para ",
           n_municipios, " municípios"),
    paste0("   Municípios com 1 única célula: ",
           sum(pesos_area$n_pixels == 1)),
    paste0("   Normal de referência        : ", ref_ini, "-", ref_fim),
    "",
    "2. TRIAGEM DAS VARIÁVEIS",
    paste0("   Variáveis dinâmicas         : ", length(vars_dinamicas),
           " (", sum(vars_meta$origem == "ERA5"), " do ERA5 + ",
           sum(vars_meta$origem == "Derivada"), " derivadas)"),
    paste0("   Campos estáticos            : ",
           sum(triagem_vars$classificacao == "Campo estático"), " (",
           paste(triagem_vars$variavel[
               triagem_vars$classificacao == "Campo estático"],
               collapse = ", "), ")"),
    paste0("   Climatologias fixas         : ",
           sum(triagem_vars$classificacao == "Climatologia fixa"), " (",
           paste(triagem_vars$variavel[
               triagem_vars$classificacao == "Climatologia fixa"],
               collapse = ", "), ")"),
    "   NOTA: as seis variáveis reprovadas repetem o mesmo valor todos os",
    "   anos e NÃO podem servir como preditoras dinâmicas. Foram mantidas",
    "   apenas como descritores fixos de superfície no agrupamento.",
    "",
    "3. ONDE RESIDE A VARIÂNCIA",
    paste0("   ", format(decomp_variancia$rotulo, width = 28),
           "temporal ", sprintf("%5.1f", decomp_variancia$pct_temporal),
           "% | espacial ",
           sprintf("%5.1f", decomp_variancia$pct_espacial),
           "% | interação ",
           sprintf("%5.1f", decomp_variancia$pct_interacao), "%"),
    "",
    "4. CICLO SAZONAL (amplitude em desvios-padrão da série)",
    paste0("   ", format(ciclo_sazonal$rotulo, width = 28),
           sprintf("%5.2f", ciclo_sazonal$amplitude_relativa),
           " | pico em ", format(ciclo_sazonal$mes_pico, width = 4),
           " | mínimo em ", ciclo_sazonal$mes_vale),
    "",
    "5. REGIME TEMPORAL (decomposição STL)",
    paste0("   ", format(stl_litoral$rotulo, width = 28),
           "sazonal ", sprintf("%.3f", stl_litoral$forca_sazonal),
           " | tendência ",
           sprintf("%.3f", stl_litoral$forca_tendencia),
           " | ", stl_litoral$regime),
    "",
    "6. MEMÓRIA DAS ANOMALIAS (sazonalidade removida)",
    paste0("   ", format(memoria_anomalias$rotulo, width = 28),
           "ACF(1) = ", sprintf("%5.3f", memoria_anomalias$acf1),
           " | lags significativos (1-12): ",
           format(memoria_anomalias$lags_significativos, width = 2),
           " | decorrelação em ",
           ifelse(is.na(memoria_anomalias$tempo_memoria),
                  "mais de 24 meses",
                  paste0(memoria_anomalias$tempo_memoria,
                         ifelse(memoria_anomalias$tempo_memoria == 1,
                                " mês", " meses")))),
    "",
    "7. TENDÊNCIA DE LONGO PRAZO (Mann-Kendall sobre médias anuais)",
    paste0("   ", format(tendencia_litoral$rotulo, width = 28),
           sprintf("%+9.4f", tendencia_litoral$sen_por_decada),
           " ", format(tendencia_litoral$unidade, width = 8),
           "/década | tau = ",
           sprintf("%+.3f", tendencia_litoral$tau),
           " | p = ", format.pval(tendencia_litoral$p_valor, digits = 2,
                                  eps = 0.001),
           " | ", tendencia_litoral$resultado),
    "",
    paste0("   Variáveis com tendência significativa: ",
           sum(tendencia_litoral$resultado !=
               "Sem tendência detectada"), " de ",
           nrow(tendencia_litoral)),
    paste0("   Aquecimento no período     : ",
           sprintf("%+.2f", mk_t2m$variacao_periodo), " °C em ",
           n_anos, " anos (", sprintf("%+.3f", mk_t2m$sen_por_decada),
           " °C/década)"),
    "",
    "8. REDUNDÂNCIA ESPACIAL - O ACHADO MAIS CONSEQUENTE",
    paste0("   ", format(redundancia$rotulo, width = 28),
           "PC1 = ", sprintf("%5.1f", redundancia$pc1_pct),
           "% | comp. p/ 95%: ", format(redundancia$n_comp_95,
                                        width = 2),
           " | r mediano = ", sprintf("%.3f", redundancia$cor_mediana)),
    "",
    paste0("   Dimensionalidade efetiva mediana: ",
           median(redundancia$n_comp_95), " componentes para ",
           n_municipios, " municípios"),
    "",
    "   EFEITO DA GRADE DO ERA5 (correlação mediana entre pares):",
    paste0("   ", format(resumo_pares$rotulo, width = 28),
           "mesma célula ",
           sprintf("%.3f", resumo_pares$`cor_mediana_Mesma célula dominante`),
           " | células distintas ",
           sprintf("%.3f", resumo_pares$`cor_mediana_Células distintas`),
           " | diferença ",
           sprintf("%+.3f", resumo_pares$diferenca_correlacao)),
    "   NOTA: os pares que compartilham célula estão também mais próximos",
    "   entre si, de modo que parte da diferença acima é distância, e não",
    "   grade. Restringindo a comparação a pares igualmente próximos",
    paste0("   (menos de ", limiar_proximidade,
           " km), o excesso remanescente é atribuível à resolução:"),
    paste0("   ", format(resumo_pares$rotulo, width = 28),
           "mesma célula ",
           sprintf("%.3f", resumo_pares$cor_proximos_mesma_celula),
           " | células distintas ",
           sprintf("%.3f", resumo_pares$cor_proximos_celulas_distintas),
           " | excesso ",
           sprintf("%+.3f", resumo_pares$excesso_atribuivel_a_grade),
           " (n = ", resumo_pares$n_proximos_mesma_celula, " e ",
           resumo_pares$n_proximos_celulas_distintas, " pares)"),
    "   CONCLUSÃO: o excesso remanescente é pequeno. A redundância entre",
    "   municípios é coerência espacial GENUÍNA, e não artefato de grade -",
    "   o que reforça, em vez de enfraquecer, a implicação (a) da seção 14:",
    "   uma fonte de maior resolução não devolveria os graus de liberdade",
    "   espaciais que a base não tem.",
    "",
    "9. HETEROGENEIDADE INTERNA AOS MUNICÍPIOS",
    paste0("   ", format(heterogeneidade$rotulo, width = 28),
           "amplitude interna / dp temporal = ",
           sprintf("%5.3f", heterogeneidade$razao_interna_temporal),
           " | ", heterogeneidade$adequacao_media_municipal),
    "",
    "10. FORMA DAS DISTRIBUIÇÕES (anomalias)",
    paste0("   ", format(forma_distribuicao$rotulo, width = 28),
           "assimetria ",
           sprintf("%+.2f", forma_distribuicao$assimetria),
           " | curtose ",
           sprintf("%+.2f", forma_distribuicao$curtose_excesso),
           " | ", forma_distribuicao$forma),
    "",
    "11. AUTOCORRELAÇÃO ESPACIAL",
    paste0("   Vizinhança : ", criterio_vizinhanca),
    paste0("   ", format(moran_global$indicador, width = 28),
           format(moran_global$esquema_vizinhanca, width = 14),
           "I = ", sprintf("%6.3f", moran_global$moran_i),
           " | p = ", format.pval(moran_global$p_valor, digits = 2,
                                  eps = 0.001),
           " | ", moran_global$interpretacao),
    paste0("   Indicadores com conclusão robusta aos dois esquemas: ",
           n_distinct(moran_global$indicador[
               grepl("^Sim", moran_global$conclusao_robusta)]),
           " de ", n_distinct(moran_global$indicador)),
    "",
    "12. REPRESENTATIVIDADE DO PERÍODO COM DADOS DE DESASTRE",
    paste0("   Comparação ", ano_ini_analise, "-", periodo_corte,
           " contra ", ref_ini, "-", ano_fim_analise, ":"),
    paste0("   ", format(comparacao_periodos$rotulo, width = 28),
           sprintf("%+7.3f", comparacao_periodos$diferenca), " ",
           format(comparacao_periodos$unidade, width = 8),
           " (", sprintf("%+.2f", comparacao_periodos$diferenca_dp),
           " dp) | ", comparacao_periodos$deslocamento),
    "",
    "13. PERFIS CLIMÁTICOS MUNICIPAIS",
    paste0("   Número de perfis adotado : ", n_clusters,
           " (silhueta ",
           sprintf("%.3f", avaliacao_k$silhueta[avaliacao_k$k ==
                                                n_clusters]), ")"),
    paste0("   ", format(caracterizacao$perfil, width = 12),
           format(caracterizacao$n_municipios, width = 3),
           " municípios | t2m ",
           sprintf("%.2f", caracterizacao$t2m_C), " °C | chuva ",
           sprintf("%.2f", caracterizacao$tp_mm_dia), " mm/dia"),
    "",
    "14. IMPLICAÇÕES PARA A MODELAGEM",
    "",
    "   (a) UNIDADE ESPACIAL",
    paste0("       Os ", n_municipios, " municípios NÃO fornecem ",
           n_municipios, " séries independentes. Na"),
    paste0("       temperatura, o primeiro componente principal explica ",
           sprintf("%.1f", red_t2m$pc1_pct), "% da"),
    paste0("       variância e ", red_t2m$n_comp_95,
           " componente(s) bastam para 95% dela: o litoral"),
    "       tem, para efeitos térmicos, UMA série. A precipitação preserva",
    paste0("       mais estrutura (PC1 = ",
           sprintf("%.1f", red_tp$pc1_pct), "%, ", red_tp$n_comp_95,
           " componentes para 95%), e o vento"),
    "       é a variável com mais graus de liberdade espaciais.",
    "       CONSEQUÊNCIA: um modelo com efeito espacial livre por município",
    "       estará estimando parâmetros para variação que a base não contém.",
    "       Efeitos aleatórios com estrutura espacial, ou agregação a poucas",
    "       regiões, são alternativas compatíveis com a informação disponível.",
    "",
    "   (b) ESTRUTURA TEMPORAL",
    paste0("       A sazonalidade domina (força STL de ",
           sprintf("%.3f", stl_t$forca_sazonal),
           " na temperatura) e precisa"),
    "       ser removida ou modelada explicitamente antes de qualquer leitura",
    paste0("       de dependência. Feito isso, a memória é CURTA: ACF(1) = ",
           sprintf("%.3f", mem_t2m$acf1), " e"),
    paste0("       decorrelação em ",
           ifelse(is.na(mem_t2m$tempo_memoria), "poucos",
                  as.character(mem_t2m$tempo_memoria)),
           " meses. Termos autorregressivos de ordem baixa"),
    "       sobre as anomalias devem bastar; estruturas de memória longa não",
    "       encontram respaldo nos dados.",
    "",
    "   (c) TENDÊNCIA",
    paste0("       ", sum(tendencia_litoral$resultado !=
                          "Sem tendência detectada"), " das ",
           nrow(tendencia_litoral),
           " variáveis têm tendência significativa, e ela é"),
    "       REGIONAL: o Mapa 04 não distingue municípios. Um termo de",
    "       tendência comum é suficiente e preferível a termos municipais.",
    paste0("       A magnitude térmica (",
           sprintf("%+.2f", mk_t2m$variacao_periodo), " °C em ", n_anos,
           " anos) é pequena frente à"),
    paste0("       variabilidade mensal (",
           sprintf("%.2f", mk_t2m$variacao_em_dp),
           " desvios-padrão no período inteiro), o que"),
    "       significa que a tendência é detectável mas não domina a série.",
    "",
    "   (d) ESCOLHA DAS VARIÁVEIS",
    "       Seis colunas da base são campos fixos e devem ser tratadas como",
    "       covariáveis de superfície, nunca como preditoras dinâmicas.",
    "       Entre as dinâmicas, a matriz de correlação (Fig_19) mostra blocos",
    "       redundantes - evaporação e fluxo de calor latente são a mesma",
    "       informação em unidades distintas. Selecionar uma variável por",
    "       bloco evita colinearidade sem perda de conteúdo.",
    "       Para intensidade de vento, use si10 (velocidade escalar) e não",
    paste0("       vento_vel_m_s, que é ",
           sprintf("%.1f", mean(contraste_vento$razao)),
           " vezes menor por cancelamento vetorial."),
    "",
    "   (e) ESCALA DE AGREGAÇÃO",
    paste0("       Para o vento, a amplitude interna a um município (",
           sprintf("%.2f", het_vento$amplitude_interna),
           ") supera seu"),
    paste0("       próprio desvio-padrão temporal (",
           sprintf("%.2f", het_vento$dp_temporal), ", razão ",
           sprintf("%.2f", het_vento$razao_interna_temporal), "): a média"),
    "       municipal descarta mais informação do que preserva, e a análise",
    "       de vento ganharia em ser conduzida no nível do pixel.",
    paste0("       Para a temperatura ocorre o oposto (razão ",
           sprintf("%.2f", het_temp$razao_interna_temporal),
           ") e a média"),
    "       municipal é um resumo adequado.",
    "",
    "   (f) RESSALVA QUE ATRAVESSA TUDO",
    "       ERA5 é REANÁLISE, não observação: é a saída de um modelo",
    "       assimilando observações, e sua qualidade sobre uma faixa costeira",
    "       estreita depende de quantas observações havia disponíveis - muito",
    "       menos nas primeiras décadas da série que nas últimas. Tendências",
    "       de longo prazo podem, em parte, refletir a evolução do sistema de",
    "       observação assimilado, e não apenas mudança climática. A",
    "       comparação com estações meteorológicas de superfície, onde",
    "       existirem, é o único caminho para separar os dois efeitos.",
    "",
    "########################################################################")

writeLines(linhas_relatorio,
           file.path(dir_res, "AED_ERA5_relatorio_sintese.txt"))

######@> Resumo final do processamento...
n_figs <- length(list.files(dir_fig, pattern = "\\.png$"))
n_figs_mun <- length(list.files(dir_fig_mun, pattern = "\\.png$"))
n_mapas <- length(list.files(dir_mapa, pattern = "\\.png$"))
n_tabs <- length(list.files(dir_tab, pattern = "\\.csv$"))

message("\n=== AED concluída ===")
message("Figuras gerais         : ", n_figs)
message("Painéis por município  : ", n_figs_mun)
message("Mapas                  : ", n_mapas)
message("Tabelas (CSV)          : ", n_tabs, " + 1 XLSX consolidado")
message("Relatório de síntese   : AED_ERA5_relatorio_sintese.txt")
message("Saídas em              : ", normalizePath(dir_res))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
