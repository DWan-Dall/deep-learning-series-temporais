########################################################################
## Description: Padronização, concatenação e organização das séries
##              temporais do MapBiomas por município costeiro de Santa
##              Catarina...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: seg ago 18 14:00:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: MapBiomas - estatísticas exportadas da plataforma
##                (plataforma.brasil.mapbiomas.org), organizadas em
##                ../Dados/Compilacao_01/MapBiomas/<Município>/<Tema>/
##                *.csv. Quatro temas (Cobertura 30m, Urbano, Água
##                Mensal e Risco Climático), 12 arquivos por município,
##                35 municípios, 420 arquivos. Áreas em HECTARES.
##
### Commentary:
##
## Este script padroniza e concatena os dados do MapBiomas seguindo a
## MESMA arquitetura adotada para o Copernicus ERA5
## (script_ERA5_extracao_municipios_ver01.R): shapefile padronizado em
## WGS84, vínculo pelo geocódigo IBGE, séries temporais concatenadas e
## saídas em Parquet e RData, em dois níveis de agregação.
##
## Diferença fundamental em relação ao ERA5: aqui NÃO há extração
## espacial. Os dados já vêm tabulados por município pela plataforma do
## MapBiomas. O trabalho, portanto, é de PADRONIZAÇÃO e INTEGRAÇÃO:
## os arquivos têm formatos heterogêneos, nomes de coluna instáveis e
## rótulos temporais inconsistentes, e precisam ser reduzidos a um
## modelo de dados único e confiável.
##
## Fluxo geral do processamento:
##
##   01) Leitura e padronização do shapefile (datum WGS84 / EPSG:4326)
##       e dissolução das feições por município;
##   02) Inventário dos 420 arquivos CSV, extraindo tema e relatório
##       a partir da estrutura de pastas e dos nomes de arquivo;
##   03) Leitura genérica dos CSVs para um formato longo canônico,
##       tolerante às irregularidades documentadas na Etapa 03;
##   04) Vínculo com o shapefile pelo nome normalizado, atribuindo o
##       geocódigo IBGE como chave definitiva;
##   05) Separação entre séries anuais e agregados de período;
##   06) Cálculo de área relativa e montagem das séries em formato
##       largo (uma coluna por classe), prontas para modelagem;
##   07) Diagnóstico de completude, ausências e redundâncias;
##   08) Exportação por município em Parquet e RData.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Leitura/manipulação de dados vetoriais
library(readr)          ## Leitura robusta de CSV (UTF-8, BOM, quotes)
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem (formato longo <-> largo)
library(purrr)          ## Programação funcional (map/reduce)
library(stringi)        ## Transliteração de acentos (normalização)
library(arrow)          ## Escrita de arquivos Parquet

######@> Opções globais...
## Evita que strings sejam convertidas em fatores e desliga a notação
## científica, o que facilita a leitura dos códigos de município (IBGE).
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente (garante reprodutibilidade de qualquer etapa
######@> eventualmente estocástica)...
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
## O script assume que está sendo executado a partir da pasta R_Work,
## portanto todos os caminhos são relativos a ela.
dir_dados <- "../Dados"
dir_mapb <- file.path(dir_dados, "Compilacao_01", "MapBiomas")
dir_shape <- file.path(dir_dados, "Shapefiles")

######@> Diretórios de saída...
## As saídas do MapBiomas ficam em subpasta própria dentro de Outputs,
## para não se misturarem às do ERA5 (que já ocupam Outputs/Parquet e
## Outputs/RData). A estrutura interna, porém, é a MESMA: um diretório
## por formato, com os arquivos por município em "Municipal/".
dir_out <- file.path(dir_dados, "Outputs", "MapBiomas")
dir_pq <- file.path(dir_out, "Parquet")
dir_rd <- file.path(dir_out, "RData")
dir_pq_mun <- file.path(dir_pq, "Municipal")
dir_rd_mun <- file.path(dir_rd, "Municipal")

######@> Criação da estrutura de saída (recursive = TRUE cria os níveis
######@> intermediários; showWarnings = FALSE evita aviso caso já
######@> exista)...
for(d in c(dir_out, dir_pq, dir_rd, dir_pq_mun, dir_rd_mun)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> Arquivo do shapefile de municípios costeiros...
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Datum/CRS de referência do projeto...
## EPSG:4326 = WGS84 em coordenadas geográficas (graus decimais). Mesmo
## referencial adotado no processamento do ERA5, garantindo que as duas
## bases sejam espacialmente compatíveis entre si.
crs_projeto <- 4326

######@> CRS auxiliar para cálculo de áreas...
## EPSG:5880 = SIRGAS 2000 / Brazil Polyconic. Projeção equivalente
## (preserva área), usada para calcular a área dos municípios em km2 e
## permitir a comparação com as áreas informadas pelo MapBiomas.
crs_area <- 5880

######@> Número máximo de níveis hierárquicos de classe...
## A plataforma do MapBiomas exporta a classe em colunas "Nível 1" a
## "Nível N". Verificou-se que N varia por relatório: 4 no tema
## Cobertura e 5 no relatório de Vegetação urbana. O script detecta as
## colunas dinamicamente, mas este limite documenta o observado.
n_niveis_max <- 5

########################################################################
######@> Funções auxiliares...

######@> Função para transliterar nomes em nomes seguros de arquivo...
## Remove acentos (stri_trans_general), troca qualquer caractere não
## alfanumérico por "_" e elimina underscores duplicados/terminais.
## Necessária porque os nomes dos municípios possuem acentuação
## (ex.: "Balneário Camboriú" -> "Balneario_Camboriu").
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Função de normalização para PAREAMENTO de nomes...
## Diferente de limpar_nome(): serve apenas para comparar nomes vindos
## de fontes distintas. Remove acentos, colapsa espaços e passa para
## maiúsculas. É indispensável porque as pastas do MapBiomas usam
## conectivos em minúscula ("Balneário Arroio do Silva") enquanto o
## shapefile os grafa em maiúscula ("Balneário Arroio Do Silva") ---
## divergência verificada em 6 dos 35 municípios.
normalizar_nome <- function(x) {
    x <- stri_trans_general(trimws(x), "Latin-ASCII")
    x <- gsub("\\s+", " ", x)
    return(toupper(x))
}

######@> Função para extrair o nome limpo do relatório...
## Os nomes de arquivo trazem um sufixo temporal após o último marcador
## "•" (ex.: "• 1985 - 2024", "• 2024", "• Infinity - -Infinity",
## "• NaN - NaN"). Esse sufixo é REMOVIDO por duas razões:
##   (a) é redundante --- os anos reais são lidos do cabeçalho do CSV,
##       que é a fonte confiável;
##   (b) é instável --- há municípios com "Infinity" e "NaN" no lugar
##       dos anos, e o intervalo do tema Água varia de município para
##       município (1992-2025, 2003-2025, 2014-2022 ...).
## O prefixo "Série temporal de " também é retirado, pois a natureza
## temporal do arquivo passa a ser registrada em coluna própria. Assim,
## a série e o "snapshot" de um mesmo indicador recebem o MESMO nome de
## relatório, o que torna a redundância entre eles visível.
extrair_relatorio <- function(nome_arquivo) {
    x <- sub("\\.csv$", "", nome_arquivo)
    ## Remove o sufixo temporal (ano, intervalo, Infinity ou NaN)
    x <- sub(paste0("\\s*\u2022\\s*(-?Infinity|NaN|[0-9]{4})",
                    "(\\s*-\\s*(-?Infinity|NaN|[0-9]{4}))?$"), "", x)
    ## Remove o prefixo que apenas indica ser série temporal
    x <- sub("^S\u00e9rie temporal de\\s*", "", x)
    ## Remove underscore inicial espúrio gerado pela plataforma
    ## (ex.: "• _Áreas urbanas suscetíveis...")
    x <- gsub("\u2022\\s*_", "\u2022 ", x)
    return(trimws(x))
}

######@> Função para classificar uma coluna de valores do CSV...
## Cada CSV tem colunas de identificação ("Nível N") e colunas de
## valores. Esta função determina o que a coluna de valores representa:
##   - "ano"      : rótulo com 4 dígitos -> ponto de uma série anual;
##   - "periodo"  : rótulo "AAAA - AAAA" -> agregado sobre o período
##                  inteiro (ex.: número de mudanças, transições);
##   - "coorte"   : rótulo inválido ("undefined", vazio, "-Infinity")
##                  -> o valor existe, mas não se refere a um ano; é o
##                  caso dos "Períodos de urbanização", em que a coorte
##                  já está descrita no próprio rótulo da classe.
classificar_coluna <- function(nome_coluna) {
    if(grepl("^[0-9]{4}$", nome_coluna)) {
        return("ano")
    }
    if(grepl("^[0-9]{4}\\s*-\\s*[0-9]{4}$", nome_coluna)) {
        return("periodo")
    }
    return("coorte")
}

######@> Função de leitura genérica de um CSV do MapBiomas...
## Retorna sempre o mesmo formato longo, qualquer que seja o relatório.
## Decisões de implementação:
##   - col_types = character para TODAS as colunas: os números vêm às
##     vezes entre aspas (ex.: "53.599") e às vezes não. Ler tudo como
##     texto e converter explicitamente com as.numeric() elimina
##     qualquer ambiguidade de parsing;
##   - name_repair = "unique": há arquivos com nome de coluna VAZIO
##     ("Urbano • Períodos de urbanização por classe.csv"), que sem isso
##     provocaria erro de leitura;
##   - arquivos com APENAS a coluna "Nível 1" e nenhuma coluna de valor
##     existem (10 municípios no tema Água e 1 no Risco Climático) e
##     significam AUSÊNCIA de dados, não erro. Nesses casos a função
##     devolve uma tabela vazia, e a ausência é registrada no
##     diagnóstico da Etapa 07.
ler_csv_mapbiomas <- function(arquivo) {
    dados <- read_csv(arquivo,
                      col_types = cols(.default = col_character()),
                      name_repair = "unique",
                      progress = FALSE)
    ## Identificação das colunas de hierarquia de classe
    cols_nivel <- grep("^N\u00edvel\\s*[0-9]+$", names(dados), value = TRUE)
    cols_valor <- setdiff(names(dados), cols_nivel)
    ## Arquivo sem nenhuma coluna de valor -> ausência de dados
    if(length(cols_valor) == 0 || nrow(dados) == 0) {
        return(tibble(rotulo_temporal = character(),
                      valor = numeric(),
                      classe_caminho = character(),
                      classe = character(),
                      nivel_profundidade = integer()))
    }
    ## Construção do rótulo hierárquico da classe -----------------------
    ## A plataforma preenche "Nível 1" e deixa em branco os níveis mais
    ## profundos quando a linha representa o TOTAL daquele nível. Assim:
    ##   - classe_caminho    : caminho completo ("Floresta > Mangue");
    ##   - classe            : rótulo mais profundo não vazio ("Mangue");
    ##   - nivel_profundidade: quantos níveis estão preenchidos.
    matriz_niveis <- as.matrix(dados[, cols_nivel, drop = FALSE])
    matriz_niveis[is.na(matriz_niveis)] <- ""
    matriz_niveis <- trimws(matriz_niveis)
    dados$classe_caminho <- apply(matriz_niveis, 1, function(linha) {
        paste(linha[linha != ""], collapse = " > ")
    })
    dados$classe <- apply(matriz_niveis, 1, function(linha) {
        preenchidos <- linha[linha != ""]
        if(length(preenchidos) == 0) NA_character_ else
            preenchidos[length(preenchidos)]
    })
    dados$nivel_profundidade <- apply(matriz_niveis, 1, function(linha) {
        sum(linha != "")
    })
    ## Pivotagem das colunas de valor para o formato longo
    resultado <- dados %>%
        select(all_of(c("classe_caminho", "classe", "nivel_profundidade",
                        cols_valor))) %>%
        pivot_longer(cols = all_of(cols_valor),
                     names_to = "rotulo_temporal",
                     values_to = "valor_texto") %>%
        mutate(valor = suppressWarnings(as.numeric(valor_texto))) %>%
        select(-valor_texto)
    return(resultado)
}

########################################################################
######@> Etapa 01 - Leitura e padronização do shapefile...

######@> Leitura do shapefile de municípios costeiros...
message("Lendo shapefile de municípios costeiros...")
shape_bruto <- st_read(arq_shape, quiet = TRUE)

######@> Correção de geometrias inválidas...
## O shapefile possui polígonos com ordem de rotação (winding order)
## incorreta e 2 geometrias inválidas. st_make_valid() corrige esses
## problemas, que de outro modo provocariam erro no cálculo de áreas.
shape_bruto <- st_make_valid(shape_bruto)

######@> Padronização do datum para WGS84...
## O shapefile já se encontra em GCS_WGS_1984, mas o arquivo .prj usa a
## nomenclatura antiga do ESRI ("D_WGS_1984"), sem código EPSG
## explícito. st_transform() para EPSG:4326 formaliza o CRS, mantendo a
## base espacialmente compatível com o processamento do ERA5.
shape_bruto <- st_transform(shape_bruto, crs_projeto)

######@> Consolidação dos atributos de identificação do município...
## O shapefile resultou da união de três camadas distintas e, por isso,
## possui 29 colunas com TRÊS blocos redundantes de atributos
## ("nome"/"codigo_ibg", "MUNICIPIO"/"GEOCODIGO" e
## "MUNICIPIO_"/"GEOCODIGO_"). Cada feição preenche apenas um dos
## blocos, deixando os demais como NA. coalesce() percorre os blocos na
## ordem e assume o primeiro valor não-nulo, recuperando nome e código
## IBGE para as 81 feições sem nenhum NA.
atributos <- st_drop_geometry(shape_bruto)
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))

######@> Dissolução das feições por município...
## As 81 feições originais correspondem a apenas 37 municípios (há
## polígonos repetidos e municípios fragmentados em várias partes, como
## ilhas). O agrupamento por geocódigo + nome, seguido de summarise(),
## dissolve as partes em uma única geometria por município.
municipios <- shape_bruto %>%
    group_by(geocodigo, municipio) %>%
    summarise(.groups = "drop") %>%
    st_make_valid() %>%
    arrange(municipio)

######@> Cálculo da área municipal (km2) e do centroide...
## A área calculada no shapefile serve de referência independente para
## conferir as áreas informadas pelo MapBiomas (ver Etapa 07).
municipios$area_km2_shape <-
    as.numeric(st_area(st_transform(municipios, crs_area))) / 1e6
centroides <- suppressWarnings(st_coordinates(st_centroid(municipios)))
municipios$lon_centroide <- centroides[, "X"]
municipios$lat_centroide <- centroides[, "Y"]

######@> Tabela de metadados dos municípios (sem geometria)...
## As saídas do MapBiomas são tabelas, não objetos espaciais; a geometria
## é descartada aqui, mas o vínculo permanece pelo geocódigo.
meta_municipios <- municipios %>%
    st_drop_geometry() %>%
    mutate(nome_norm = normalizar_nome(municipio))

message("Municípios no shapefile: ", nrow(meta_municipios))
message("CRS de trabalho: EPSG:", st_crs(municipios)$epsg)

########################################################################
######@> Etapa 02 - Inventário dos arquivos do MapBiomas...

######@> Listagem recursiva de todos os CSVs...
## A estrutura de diretórios é <Município>/<Tema>/<arquivo>.csv, de modo
## que município e tema são recuperados diretamente do caminho.
arqs_csv <- list.files(dir_mapb, pattern = "\\.csv$", recursive = TRUE,
                       full.names = TRUE)

######@> Decomposição do caminho relativo...
caminho_rel <- sub(paste0("^", dir_mapb, "/"), "", arqs_csv)
partes <- strsplit(caminho_rel, "/", fixed = TRUE)

inventario <- tibble(
    arquivo = arqs_csv,
    pasta_municipio = map_chr(partes, 1),
    tema = map_chr(partes, 2),
    nome_arquivo = map_chr(partes, 3)) %>%
    mutate(
        ## Nome do relatório, já livre do sufixo temporal instável
        relatorio = extrair_relatorio(nome_arquivo),
        ## Registra se o arquivo foi exportado como série temporal.
        ## Junto com "relatorio", permite identificar os pares
        ## série/snapshot que carregam a mesma informação.
        exportado_como_serie = grepl("^S\u00e9rie temporal de",
                                     nome_arquivo),
        nome_norm = normalizar_nome(pasta_municipio))

message("Arquivos CSV encontrados: ", nrow(inventario))
message("Municípios com pasta no MapBiomas: ",
        length(unique(inventario$pasta_municipio)))
message("Temas: ", paste(sort(unique(inventario$tema)), collapse = " | "))

########################################################################
######@> Etapa 03 - Leitura e concatenação de todos os CSVs...

######@> Observações sobre as irregularidades tratadas...
## A inspeção prévia dos 420 arquivos revelou os seguintes problemas,
## todos absorvidos pela função ler_csv_mapbiomas():
##
##   (a) BOM UTF-8 no início de cada arquivo -> tratado pelo readr;
##   (b) nomes de classe COM VÍRGULA ("Praia, Duna e Areal") -> exige
##       parser CSV de verdade; separar por vírgula quebraria a coluna;
##   (c) números às vezes entre aspas, às vezes não -> tudo lido como
##       texto e convertido explicitamente;
##   (d) nome de coluna VAZIO em um dos relatórios -> name_repair;
##   (e) arquivos SEM coluna de valor (só "Nível 1"), indicando
##       ausência de dados -> devolvem tabela vazia, e a ausência é
##       registrada no diagnóstico;
##   (f) número de colunas "Nível" variável entre relatórios (4 no tema
##       Cobertura, 5 em Vegetação urbana) -> detecção dinâmica.

######@> Leitura de todos os arquivos...
## O laço percorre o inventário e anexa a cada tabela lida os
## identificadores de origem (município, tema, relatório), produzindo
## uma única tabela longa canônica.
message("Lendo ", nrow(inventario), " arquivos CSV...")

lista_dados <- vector("list", nrow(inventario))

for(i in seq_len(nrow(inventario))) {
    conteudo <- ler_csv_mapbiomas(inventario$arquivo[i])
    if(nrow(conteudo) > 0) {
        lista_dados[[i]] <- conteudo %>%
            mutate(pasta_municipio = inventario$pasta_municipio[i],
                   nome_norm = inventario$nome_norm[i],
                   tema = inventario$tema[i],
                   relatorio = inventario$relatorio[i],
                   exportado_como_serie =
                       inventario$exportado_como_serie[i],
                   .before = 1)
    }
}

######@> Concatenação de toda a base...
dados_longo <- bind_rows(lista_dados)

######@> Classificação do rótulo temporal...
## Aplicada de uma só vez sobre os rótulos distintos (poucas dezenas),
## e não linha a linha, por eficiência.
rotulos <- tibble(rotulo_temporal = unique(dados_longo$rotulo_temporal)) %>%
    mutate(tipo_temporal = map_chr(rotulo_temporal, classificar_coluna),
           ## Ano numérico, apenas quando o rótulo é um ano de fato
           ano = ifelse(tipo_temporal == "ano",
                        suppressWarnings(as.integer(rotulo_temporal)),
                        NA_integer_),
           ## Período textual, quando o rótulo cobre um intervalo
           periodo = ifelse(tipo_temporal == "periodo",
                            rotulo_temporal, NA_character_))

dados_longo <- dados_longo %>%
    left_join(rotulos, by = "rotulo_temporal")

message("Registros lidos (formato longo): ", nrow(dados_longo))

########################################################################
######@> Etapa 04 - Vínculo com o shapefile...

######@> Conferência do pareamento antes de unir...
## O pareamento é feito pelo nome normalizado, e o GEOCÓDIGO do
## shapefile passa a ser a chave definitiva --- exatamente como no
## processamento do ERA5. Isso garante que as duas bases possam ser
## cruzadas sem ambiguidade.
nomes_mapb <- sort(unique(inventario$nome_norm))
nomes_shape <- sort(unique(meta_municipios$nome_norm))

sem_shape <- setdiff(nomes_mapb, nomes_shape)
sem_mapb <- setdiff(nomes_shape, nomes_mapb)

if(length(sem_shape) > 0) {
    warning("Pastas do MapBiomas sem correspondência no shapefile: ",
            paste(sem_shape, collapse = ", "))
}

######@> Municípios do shapefile SEM dados do MapBiomas...
## Verificado: Camboriú (4203204) e Paulo Lopes (4212304) não possuem
## pasta no MapBiomas. Não é erro de pareamento --- os dados simplesmente
## não foram baixados para esses dois municípios. A ausência é
## registrada explicitamente no diagnóstico, para que não passe por
## omissão silenciosa.
municipios_sem_dados <- meta_municipios %>%
    filter(nome_norm %in% sem_mapb) %>%
    select(geocodigo, municipio)

if(nrow(municipios_sem_dados) > 0) {
    message("ATENÇÃO - municípios do shapefile SEM dados MapBiomas: ",
            paste(municipios_sem_dados$municipio, collapse = ", "))
}

######@> Junção com os metadados dos municípios...
## inner_join pelo nome normalizado; o nome oficial adotado nas saídas é
## o do SHAPEFILE (não o da pasta), assegurando grafia uniforme entre as
## bases MapBiomas e ERA5.
dados_longo <- dados_longo %>%
    inner_join(meta_municipios %>%
                   select(nome_norm, geocodigo, municipio,
                          area_km2_shape, lon_centroide, lat_centroide),
               by = "nome_norm") %>%
    select(-nome_norm, -pasta_municipio)

######@> Reordenação das colunas para leitura...
dados_longo <- dados_longo %>%
    select(geocodigo, municipio, tema, relatorio, exportado_como_serie,
           classe_caminho, classe, nivel_profundidade,
           tipo_temporal, rotulo_temporal, ano, periodo, valor,
           area_km2_shape, lon_centroide, lat_centroide)

message("Registros após vínculo com o shapefile: ", nrow(dados_longo))

########################################################################
######@> Etapa 05 - Separação entre séries anuais e agregados...

######@> Área total de referência de cada município...
## Calculada a partir do tema Cobertura, somando apenas as linhas de
## PRIMEIRO nível (nivel_profundidade == 1), que são mutuamente
## exclusivas e recobrem todo o município. Verificou-se que essa soma é
## CONSTANTE ao longo dos anos --- a área do município não muda, apenas
## sua composição --- o que serve como validação embutida.
######@> Nome da classe de nível 1 que representa água/mar...
classe_agua <- "Água e Ambiente Marinho"

area_total_municipio <- dados_longo %>%
    filter(tema == "Cobertura 30m",
           grepl("^Cobertura", relatorio),
           tipo_temporal == "ano",
           nivel_profundidade == 1) %>%
    group_by(geocodigo, ano) %>%
    summarise(area_ha_ano = sum(valor, na.rm = TRUE),
              ## Área da classe água/mar no mesmo ano, para permitir o
              ## cálculo de um denominador estritamente terrestre
              area_ha_agua_ano = sum(valor[classe == classe_agua],
                                     na.rm = TRUE),
              .groups = "drop") %>%
    group_by(geocodigo) %>%
    summarise(area_ha_mapbiomas = mean(area_ha_ano),
              ## Amplitude entre anos: deve ser ~0 se a soma é constante
              area_ha_amplitude = max(area_ha_ano) - min(area_ha_ano),
              ## Área terrestre = total menos água/mar. Usa-se a MÉDIA
              ## entre os anos para manter o denominador CONSTANTE, de
              ## modo que variações no indicador reflitam apenas o
              ## numerador (a classe de interesse), e não oscilações da
              ## própria área de referência.
              area_ha_terrestre = mean(area_ha_ano - area_ha_agua_ano),
              area_ha_agua = mean(area_ha_agua_ano),
              .groups = "drop")

######@> Justificativa dos DOIS denominadores...
## Verificou-se que a classe "Água e Ambiente Marinho" responde por uma
## fração muito variável da área municipal (de ~0% a 35%), e que sua
## natureza NÃO é a mesma em todos os municípios. Há dois casos
## distintos, e eles apontam para lados opostos:
##
##  (a) ÁGUA MARINHA EXTERNA (baía) - o polígono do MapBiomas avança
##      sobre o mar, além do limite do shapefile:
##        Florianópolis   : +11.018 ha (razão total 1,248), integralmente
##                          explicados pelos 14.135 ha de água/mar;
##        Gov. Celso Ramos: +1.751 ha (1,187);
##        São José        : +1.305 ha (1,114);
##        Palhoça         : +3.583 ha (1,109).
##      Aqui a área total INFLA o denominador, e excluir a água aproxima
##      a razão de 1 (Florianópolis vai a 0,92).
##
##  (b) ÁGUA CONTINENTAL INTERNA (laguna) - o corpo d'água está DENTRO
##      do território municipal e lhe pertence legitimamente:
##        Pescaria Brava : 35,0% de água, razão total 1,013;
##        Laguna         : 34,5% de água, razão total 0,988.
##      Aqui a área total já está correta, e excluir a água DERRUBA a
##      razão para ~0,65 --- ou seja, subestima o município.
##
## Não existe, portanto, um denominador universalmente correto. Ambos são
## exportados, e a escolha depende da pergunta:
##   - area_pct           : fração do TERRITÓRIO municipal (inclui
##                          lagunas). Adequado para Laguna, Pescaria
##                          Brava e afins, e para séries dentro de um
##                          mesmo município;
##   - area_pct_terrestre : fração da porção TERRESTRE (exclui água).
##                          Adequado para comparar a ocupação do solo
##                          entre municípios sem que os de baía
##                          apareçam artificialmente diluídos.
##
## O efeito é material: para Floresta em 2024, São Francisco do Sul passa
## de 53,1% para 69,9% e Florianópolis de 34,6% para 47,0%. Relatar o
## indicador sem dizer qual denominador foi usado é, portanto, ambíguo.
## A coluna pct_area_agua (em resumo_municipios) indica onde a escolha
## faz diferença.

######@> Séries temporais ANUAIS (o produto principal)...
## Este é o objeto que responde ao pedido de "séries temporais
## organizadas de forma funcional": uma linha por município, classe e
## ano, em formato tidy, com a área em hectares e em percentual da área
## municipal.
series_anuais <- dados_longo %>%
    filter(tipo_temporal == "ano") %>%
    left_join(area_total_municipio, by = "geocodigo") %>%
    mutate(area_ha = valor,
           ## Percentual em relação à área total do município. Permite
           ## comparar municípios de tamanhos muito diferentes
           ## (Joinville ~1130 km2 vs Bombinhas ~36 km2).
           area_pct = 100 * area_ha / area_ha_mapbiomas,
           ## Percentual sobre a área terrestre --- medida recomendada
           ## para comparações ENTRE municípios (ver justificativa acima)
           area_pct_terrestre = 100 * area_ha / area_ha_terrestre) %>%
    select(geocodigo, municipio, tema, relatorio, exportado_como_serie,
           classe_caminho, classe, nivel_profundidade, ano,
           area_ha, area_pct, area_pct_terrestre,
           area_ha_mapbiomas, area_ha_terrestre) %>%
    arrange(municipio, tema, relatorio, classe_caminho, ano)

######@> Agregados de PERÍODO e COORTES...
## Não são séries anuais e por isso ficam em objeto separado, evitando
## que se misturem indevidamente às séries na hora da análise:
##   - "periodo": valor único para todo o intervalo 1985-2024
##                (número de mudanças, número de classes, transições);
##   - "coorte" : valor associado a uma faixa temporal já descrita no
##                rótulo da classe (períodos de urbanização).
agregados_periodo <- dados_longo %>%
    filter(tipo_temporal %in% c("periodo", "coorte")) %>%
    left_join(area_total_municipio, by = "geocodigo") %>%
    mutate(area_ha = valor,
           area_pct = 100 * area_ha / area_ha_mapbiomas,
           area_pct_terrestre = 100 * area_ha / area_ha_terrestre) %>%
    select(geocodigo, municipio, tema, relatorio, exportado_como_serie,
           classe_caminho, classe, nivel_profundidade,
           tipo_temporal, rotulo_temporal, periodo,
           area_ha, area_pct, area_pct_terrestre) %>%
    arrange(municipio, tema, relatorio, classe_caminho)

message("Séries anuais: ", nrow(series_anuais), " registros")
message("Agregados de período/coorte: ", nrow(agregados_periodo),
        " registros")

########################################################################
######@> Etapa 06 - Séries em formato largo...

######@> Hierarquia de classes do tema Cobertura...
## Catálogo das classes observadas, com seu caminho e profundidade.
## Exportado junto às bases para que a estrutura aninhada fique
## documentada e o risco de dupla contagem seja explícito.
hierarquia_classes <- dados_longo %>%
    distinct(tema, relatorio, classe_caminho, classe,
             nivel_profundidade) %>%
    arrange(tema, relatorio, classe_caminho)

######@> Série de Cobertura em formato largo (uma coluna por classe)...
## ATENÇÃO METODOLÓGICA: as classes do MapBiomas são ANINHADAS. A linha
## de "Floresta" (nível 1) é a SOMA de suas filhas de nível 2
## ("Formação Florestal", "Restinga Arbórea", "Mangue", ...) ---
## verificado numericamente. Portanto, somar todas as classes de uma vez
## DUPLICA a área.
##
## Para evitar esse erro, a tabela larga é montada por NÍVEL:
##   - cobertura_larga_n1 : apenas nível 1 (5 classes mutuamente
##                          exclusivas; a soma fecha a área do município);
##   - cobertura_larga_n2 : apenas nível 2 (detalhe fino, também
##                          mutuamente exclusivo entre si).
## Quem precisar de outro corte pode partir de series_anuais, filtrando
## nivel_profundidade.
montar_larga <- function(dados, nivel, valor_col = "area_ha") {
    dados %>%
        filter(tema == "Cobertura 30m",
               grepl("^Cobertura", relatorio),
               nivel_profundidade == nivel) %>%
        select(geocodigo, municipio, ano, classe,
               valor = all_of(valor_col)) %>%
        ## Nomes de coluna seguros a partir dos rótulos das classes
        mutate(classe = limpar_nome(classe)) %>%
        pivot_wider(names_from = classe, values_from = valor,
                    values_fn = sum) %>%
        arrange(municipio, ano)
}

cobertura_larga_n1 <- montar_larga(series_anuais, 1)
cobertura_larga_n2 <- montar_larga(series_anuais, 2)

message("Cobertura larga nível 1: ", nrow(cobertura_larga_n1), " x ",
        ncol(cobertura_larga_n1))
message("Cobertura larga nível 2: ", nrow(cobertura_larga_n2), " x ",
        ncol(cobertura_larga_n2))

########################################################################
######@> Etapa 07 - Diagnóstico da base...

######@> Dicionário dos relatórios...
## Descreve cada relatório encontrado, sua natureza temporal, o intervalo
## de anos efetivamente presente e quantos municípios o possuem. É o mapa
## de leitura da base.
dicionario_relatorios <- dados_longo %>%
    group_by(tema, relatorio, exportado_como_serie, tipo_temporal) %>%
    summarise(n_municipios = n_distinct(geocodigo),
              n_classes = n_distinct(classe_caminho),
              niveis = paste(sort(unique(nivel_profundidade)),
                             collapse = ", "),
              ano_min = suppressWarnings(min(ano, na.rm = TRUE)),
              ano_max = suppressWarnings(max(ano, na.rm = TRUE)),
              n_registros = n(),
              .groups = "drop") %>%
    ## min/max de vetores sem anos devolvem Inf; convertidos para NA
    mutate(across(c(ano_min, ano_max),
                  ~ ifelse(is.finite(.x), .x, NA_integer_))) %>%
    arrange(tema, relatorio, desc(exportado_como_serie))

######@> Cobertura de dados por município e relatório...
## Cruza TODOS os municípios do shapefile (inclusive os dois sem dados)
## com TODOS os relatórios existentes, de modo que cada lacuna apareça
## como uma linha explícita. É o instrumento para saber o que falta.
grade_completa <- expand_grid(
    meta_municipios %>% select(geocodigo, municipio),
    dicionario_relatorios %>%
        distinct(tema, relatorio, exportado_como_serie))

diagnostico <- grade_completa %>%
    left_join(dados_longo %>%
                  group_by(geocodigo, tema, relatorio,
                           exportado_como_serie) %>%
                  summarise(n_registros = n(),
                            n_anos = n_distinct(ano[!is.na(ano)]),
                            .groups = "drop"),
              by = c("geocodigo", "tema", "relatorio",
                     "exportado_como_serie")) %>%
    mutate(n_registros = coalesce(n_registros, 0L),
           n_anos = coalesce(n_anos, 0L),
           tem_dados = n_registros > 0) %>%
    arrange(municipio, tema, relatorio)

######@> Resumo de completude por município...
resumo_municipios <- meta_municipios %>%
    select(geocodigo, municipio, area_km2_shape) %>%
    left_join(area_total_municipio, by = "geocodigo") %>%
    left_join(diagnostico %>%
                  group_by(geocodigo) %>%
                  summarise(n_relatorios_com_dados = sum(tem_dados),
                            n_relatorios_vazios = sum(!tem_dados),
                            .groups = "drop"),
              by = "geocodigo") %>%
    mutate(tem_mapbiomas = n_relatorios_com_dados > 0,
           ## Razão entre a área TOTAL do MapBiomas e a do shapefile.
           ## Valores bem acima de 1 indicam que o polígono do MapBiomas
           ## incorpora água/mar (municípios de baía).
           razao_area_mapb_shape = area_ha_mapbiomas /
               (area_km2_shape * 100),
           ## Razão considerando apenas a área terrestre. Fica próxima de
           ## 1 justamente nos municípios em que a razão total se afasta,
           ## confirmando que a diferença é água e não erro de limite.
           razao_area_terrestre_shape = area_ha_terrestre /
               (area_km2_shape * 100),
           ## Proporção da área municipal que o MapBiomas classifica como
           ## água/mar --- útil para saber onde area_pct fica diluído.
           pct_area_agua = 100 * area_ha_agua / area_ha_mapbiomas) %>%
    arrange(desc(area_km2_shape))

message("\n--- Diagnóstico ---")
message("Municípios com dados MapBiomas: ",
        sum(resumo_municipios$tem_mapbiomas), " de ",
        nrow(resumo_municipios))
message("Relatórios distintos: ", nrow(dicionario_relatorios))
message("Lacunas (município x relatório sem dados): ",
        sum(!diagnostico$tem_dados))

########################################################################
######@> Etapa 08 - Exportação dos resultados...

######@> Exportação das bases consolidadas...
write_parquet(series_anuais,
              file.path(dir_pq, "MapBiomas_series_anuais_completo.parquet"))
write_parquet(agregados_periodo,
              file.path(dir_pq, "MapBiomas_periodos_completo.parquet"))
write_parquet(cobertura_larga_n1,
              file.path(dir_pq, "MapBiomas_cobertura_larga_nivel1.parquet"))
write_parquet(cobertura_larga_n2,
              file.path(dir_pq, "MapBiomas_cobertura_larga_nivel2.parquet"))
write_parquet(hierarquia_classes,
              file.path(dir_pq, "MapBiomas_hierarquia_classes.parquet"))
write_parquet(dicionario_relatorios,
              file.path(dir_pq, "MapBiomas_dicionario_relatorios.parquet"))
write_parquet(diagnostico,
              file.path(dir_pq, "MapBiomas_diagnostico.parquet"))
write_parquet(resumo_municipios,
              file.path(dir_pq, "MapBiomas_resumo_municipios.parquet"))

save(series_anuais, agregados_periodo,
     cobertura_larga_n1, cobertura_larga_n2,
     hierarquia_classes, dicionario_relatorios,
     diagnostico, resumo_municipios,
     file = file.path(dir_rd, "MapBiomas_SC_completo.RData"))

######@> Exportação individual por município...
## Um par de arquivos (Parquet + RData) por município, contendo a série
## anual e os agregados de período daquele município. O nome combina o
## geocódigo do IBGE (chave estável) com o nome transliterado, seguindo
## exatamente a convenção adotada no ERA5.
message("\nExportando arquivos por município...")

for(g in sort(unique(series_anuais$geocodigo))) {
    ## Subconjuntos do município corrente
    dados_municipio <- series_anuais %>%
        filter(geocodigo == g)
    dados_municipio_periodos <- agregados_periodo %>%
        filter(geocodigo == g)
    ## Montagem do nome-base do arquivo
    nome_muni <- limpar_nome(unique(dados_municipio$municipio))
    nome_base <- paste0("MapBiomas_", g, "_", nome_muni)
    ## Gravação em Parquet (formato colunar, compacto e interoperável)
    write_parquet(dados_municipio,
                  file.path(dir_pq_mun, paste0(nome_base, ".parquet")))
    write_parquet(dados_municipio_periodos,
                  file.path(dir_pq_mun,
                            paste0(nome_base, "_periodos.parquet")))
    ## Gravação em RData (formato nativo do R). Os objetos são sempre
    ## salvos com os nomes "dados_municipio" e
    ## "dados_municipio_periodos", garantindo previsibilidade ao
    ## carregar qualquer arquivo com load().
    save(dados_municipio, dados_municipio_periodos,
         file = file.path(dir_rd_mun, paste0(nome_base, ".RData")))
    message(sprintf("  %-48s %5d linhas (série) | %4d (período)",
                    nome_base, nrow(dados_municipio),
                    nrow(dados_municipio_periodos)))
}

######@> Resumo final do processamento...
message("\n=== Processamento concluído ===")
message("Municípios exportados  : ",
        length(unique(series_anuais$geocodigo)))
message("Temas                  : ",
        paste(sort(unique(series_anuais$tema)), collapse = " | "))
message("Período das séries     : ", min(series_anuais$ano), " a ",
        max(series_anuais$ano))
message("Registros (série anual): ", nrow(series_anuais))
message("Registros (períodos)   : ", nrow(agregados_periodo))
message("Saídas em              : ", normalizePath(dir_out))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
