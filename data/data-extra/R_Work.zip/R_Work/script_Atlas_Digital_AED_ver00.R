########################################################################
## Description: Análise exploratória de dados (AED) das séries de
##              desastres do Atlas Digital por município costeiro de
##              Santa Catarina, com foco nos padrões espaço-temporais
##              por grupo de desastre...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: ter ago 19 11:00:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: Bases padronizadas pelo
##                script_Atlas_Digital_extracao_municipios_ver00.R:
##                  - serie_mensal_grupo : município x ano x mês x grupo
##                                         (58.800 linhas, grade completa)
##                  - serie_anual_grupo  : município x ano x grupo
##                                         (4.900 linhas, grade completa)
##                Complementadas por "eventos" (registro individual),
##                "resumo_municipios" e pelo shapefile de municípios.
##                Período 1991-2025, 35 municípios, 4 grupos de desastre.
##
### Commentary:
##
## Esta é a análise exploratória que antecede a modelagem. Seu propósito
## não é responder às perguntas da dissertação, e sim estabelecer O QUE
## OS DADOS PERMITEM PERGUNTAR: qual a estrutura temporal das séries,
## quanta dependência elas carregam, como os grupos de desastre se
## diferenciam, como os municípios se organizam no espaço e quais
## famílias de modelo são compatíveis com a distribuição observada.
##
## Três decisões estruturam o documento:
##
##   (i) AS DUAS ESCALAS SÃO ANALISADAS SEPARADAMENTE. A série mensal e
##       a anual não são versões da mesma coisa: a sondagem preliminar
##       mostrou que, no nível município-mês, a razão variância/média é
##       próxima de 1 (compatível com Poisson), enquanto no agregado do
##       litoral ela chega a 7,3. A sobredispersão, portanto, NÃO nasce
##       da heterogeneidade entre municípios - nasce do agrupamento
##       ESPACIAL dos eventos, já que uma mesma tempestade gera registro
##       em vários municípios no mesmo mês. Essa distinção decide a
##       família de modelos a ser usada adiante e é perseguida em todo o
##       script;
##
##  (ii) TENDÊNCIA E SAZONALIDADE SÃO SEPARADAS ANTES DE INTERPRETAR A
##       AUTOCORRELAÇÃO. A ACF da série bruta decai lentamente em todos
##       os lags, o que poderia sugerir memória longa; mas o teste KPSS
##       rejeita estacionariedade em nível enquanto a série diferenciada
##       passa no mesmo teste. Ou seja: a autocorrelação aparente é, em
##       boa parte, TENDÊNCIA. Todas as ACF/PACF são por isso
##       apresentadas em duas versões - série bruta e série sem
##       tendência - para que o leitor veja o que sobra depois de
##       remover o crescimento de longo prazo;
##
## (iii) O AGREGADO ESCONDE OS GRUPOS. A sazonalidade do conjunto é
##       fraca, mas isso resulta de CANCELAMENTO: os desastres
##       hidrológicos concentram-se no verão (índice 2,44 em janeiro) e
##       os meteorológicos no inverno (2,14 em julho). Analisar apenas o
##       total apagaria o achado. Por isso o recorte por grupo atravessa
##       todas as seções.
##
## Fluxo geral da análise:
##
##   01) Leitura das bases e preparação dos objetos de trabalho;
##   02) Panorama geral e completude;
##   03) Estrutura temporal agregada (anual e mensal, total e por grupo);
##   04) Sazonalidade e padrão intra-anual;
##   05) Padrões municipais: rankings, composição e séries individuais;
##   06) Painéis diagnósticos por município (um arquivo por município);
##   07) Dependência temporal: ACF, PACF, Ljung-Box, estacionariedade,
##       decomposição STL;
##   08) Tendência: Mann-Kendall e declividade de Sen;
##   09) Distribuição das contagens e sobredispersão;
##   10) Padrões espaciais: mapas e autocorrelação espacial (Moran);
##   11) Agrupamento de municípios por perfil de desastre;
##   12) Exportação das tabelas e relatório de síntese.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Dados vetoriais e mapas
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem e grades
library(purrr)          ## Programação funcional
library(stringi)        ## Transliteração de acentos
library(ggplot2)        ## Gráficos
library(patchwork)      ## Composição de painéis
library(scales)         ## Escalas e formatação de eixos
library(forecast)       ## Decomposição STL e utilitários de séries
library(tseries)        ## Testes de estacionariedade (ADF, KPSS)
library(MASS)           ## Ajuste binomial negativo (glm.nb)
library(pscl)           ## Modelos inflacionados de zeros
library(spdep)          ## Autocorrelação espacial (Moran)
library(writexl)        ## Exportação consolidada em XLSX

######@> Resolução de conflitos de nomes...
## MASS::select() e dplyr::select() colidem. A fixação explícita evita
## erros silenciosos de seleção de colunas ao longo do script.
select <- dplyr::select
filter <- dplyr::filter

######@> Opções globais...
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente...
## Fixada porque a etapa de agrupamento (k-means) é estocástica.
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
dir_dados <- "../Dados"
dir_out_atlas <- file.path(dir_dados, "Outputs", "Atlas_Digital")
dir_shape <- file.path(dir_dados, "Shapefiles")

arq_base <- file.path(dir_out_atlas, "RData", "Atlas_SC_completo.RData")
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Diretórios de saída...
## A AED gera três famílias de produto, que ficam em subpastas próprias
## para que o material possa ser localizado pelo tipo: tabelas (insumo
## de texto e de análises posteriores), figuras (séries e diagnósticos)
## e mapas (recorte espacial).
dir_res <- "../Results/AED_Atlas"
dir_tab <- file.path(dir_res, "Tabelas")
dir_fig <- file.path(dir_res, "Figuras")
dir_fig_mun <- file.path(dir_fig, "Municipios")
dir_mapa <- file.path(dir_res, "Mapas")

for(d in c(dir_res, dir_tab, dir_fig, dir_fig_mun, dir_mapa)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> CRS de referência...
crs_projeto <- 4326      ## WGS84, mesmo das demais bases
crs_area <- 5880         ## SIRGAS 2000 / Brazil Polyconic (áreas)

######@> Parâmetros da análise...
## lag_max_mensal : 36 meses cobre três ciclos anuais, suficiente para
##                  revelar (ou descartar) periodicidade sazonal;
## lag_max_anual  : 10 anos - além disso, com 35 observações, as
##                  estimativas de autocorrelação perdem qualquer
##                  precisão útil;
## min_anos_evento: número mínimo de anos com ocorrência para que um
##                  teste de tendência seja aplicado a uma série. Séries
##                  quase todas nulas produzem estatísticas degeneradas,
##                  e é preferível devolver NA com justificativa a
##                  devolver um número sem significado;
## alfa           : nível de significância adotado nos testes.
lag_max_mensal <- 36
lag_max_anual <- 10
min_anos_evento <- 5
alfa <- 0.05

######@> Paleta de cores dos grupos de desastre...
## Paleta Okabe-Ito, segura para daltonismo. As cores foram atribuídas
## com apoio semântico: azul para hidrológico (água), laranja para
## climatológico (calor/seca), roxo para meteorológico (tempestade) e
## cinza para a categoria residual.
cores_grupo <- c("Climatológico" = "#E69F00",
                 "Hidrológico"   = "#0072B2",
                 "Meteorológico" = "#CC79A7",
                 "Outros"        = "#999999")

######@> Nomes dos meses (rótulos dos eixos)...
meses_abrev <- c("Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
                 "Jul", "Ago", "Set", "Out", "Nov", "Dez")

########################################################################
######@> Funções auxiliares...

######@> Tema gráfico do documento...
## Centralizar o tema garante que as dezenas de figuras produzidas
## tenham a mesma aparência, o que é requisito para que possam ser
## usadas lado a lado no texto da dissertação.
tema_aed <- function(base = 11) {
    theme_bw(base_size = base) +
        theme(panel.grid.minor = element_blank(),
              panel.grid.major = element_line(linewidth = 0.25,
                                              colour = "grey88"),
              strip.background = element_rect(fill = "grey92",
                                              colour = "grey70"),
              strip.text = element_text(face = "bold", size = base - 1),
              plot.title = element_text(face = "bold", size = base + 2),
              plot.subtitle = element_text(colour = "grey30",
                                           size = base - 1),
              plot.caption = element_text(colour = "grey45",
                                          size = base - 3, hjust = 0),
              legend.position = "bottom",
              legend.title = element_text(face = "bold", size = base - 1))
}

theme_set(tema_aed())

######@> Quebra de linha em legendas longas...
## O ggplot NÃO quebra automaticamente o texto de caption: legendas
## longas são simplesmente cortadas na borda direita da figura. Esta
## função insere as quebras antes da plotagem, mantendo as notas de
## rodapé legíveis independentemente da largura do arquivo gerado.
quebrar <- function(texto, largura = 105) {
    paste(strwrap(paste(texto, collapse = " "), width = largura),
          collapse = "\n")
}

######@> Função de gravação de figuras...
## Padroniza formato, resolução e diretório. dpi = 300 atende a
## requisitos de impressão de dissertação.
salvar_fig <- function(plot, arquivo, largura = 10, altura = 6,
                       diretorio = dir_fig) {
    ggsave(filename = file.path(diretorio, paste0(arquivo, ".png")),
           plot = plot, width = largura, height = altura, dpi = 300,
           bg = "white")
    invisible(NULL)
}

######@> Função de gravação de tabelas...
## Grava em CSV com separador ";" e decimal "," (padrão brasileiro,
## abre corretamente no Excel em português) e devolve a tabela para que
## também seja acumulada no XLSX consolidado.
salvar_tab <- function(dados, arquivo) {
    write.table(dados, file.path(dir_tab, paste0(arquivo, ".csv")),
                sep = ";", dec = ",", row.names = FALSE,
                fileEncoding = "UTF-8")
    invisible(dados)
}

######@> Formatação de inteiros com separador de milhar...
## Duas armadilhas são evitadas aqui:
##   - big.mark = "." sozinho dispara aviso, porque no locale padrão do R
##     o separador DECIMAL também é "."; declarar decimal.mark = ","
##     (a convenção brasileira) elimina a ambiguidade;
##   - format = "d" converteria o valor para inteiro, e o impacto
##     econômico acumulado (~9,2 bilhões) ULTRAPASSA o limite de inteiros
##     do R (2.147.483.647), gerando NA silencioso. format = "f" com zero
##     casas decimais formata em ponto flutuante e não tem esse teto.
fmt_int <- function(x) {
    formatC(x, format = "f", digits = 0, big.mark = ".",
            decimal.mark = ",")
}

######@> Função para transliterar nomes em nomes seguros de arquivo...
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Teste de tendência de Mann-Kendall...
## Implementado no próprio script, e não importado de pacote, por duas
## razões: (a) mantém o script executável sem dependências além das já
## utilizadas no projeto; (b) torna explícita a CORREÇÃO PARA EMPATES,
## que é indispensável aqui - as séries de contagem têm muitos valores
## repetidos (vários anos com 0, 1 ou 2 eventos), e a variância sem
## correção superestimaria a significância.
##
## O teste é não-paramétrico e avalia a hipótese de tendência monotônica
## (não necessariamente linear), o que é adequado a séries de contagem
## assimétricas como estas.
mann_kendall <- function(x) {
    x <- as.numeric(x[!is.na(x)])
    n <- length(x)
    if(n < 4) {
        return(tibble(S = NA_real_, tau = NA_real_, z = NA_real_,
                      p_valor = NA_real_))
    }
    ## Estatística S: soma dos sinais de todas as diferenças aos pares
    dif <- outer(x, x, "-")
    S <- sum(sign(dif[lower.tri(dif)]))
    ## Variância com correção para empates
    empates <- as.numeric(table(x))
    var_S <- (n * (n - 1) * (2 * n + 5) -
              sum(empates * (empates - 1) * (2 * empates + 5))) / 18
    if(var_S <= 0) {
        return(tibble(S = S, tau = NA_real_, z = NA_real_,
                      p_valor = NA_real_))
    }
    ## Correção de continuidade no cálculo de z
    z <- if(S > 0) (S - 1) / sqrt(var_S) else
         if(S < 0) (S + 1) / sqrt(var_S) else 0
    tau <- S / (n * (n - 1) / 2)
    tibble(S = S, tau = tau, z = z, p_valor = 2 * pnorm(-abs(z)))
}

######@> Declividade de Sen (Theil-Sen)...
## Mediana das declividades entre todos os pares de pontos. É o
## estimador de magnitude que acompanha o Mann-Kendall: robusto a
## valores extremos, e por isso preferível à regressão linear em séries
## com anos atípicos como 2022 (119 registros).
declividade_sen <- function(y, x) {
    ok <- !is.na(y) & !is.na(x)
    y <- y[ok]; x <- x[ok]
    if(length(y) < 4) return(NA_real_)
    dy <- outer(y, y, "-")
    dx <- outer(x, x, "-")
    decl <- (dy / dx)[lower.tri(dy)]
    return(median(decl[is.finite(decl)], na.rm = TRUE))
}

######@> Cálculo de ACF/PACF em formato de tabela...
## Devolve um data.frame com o lag, o valor e o limite do intervalo de
## confiança, permitindo tanto a plotagem em ggplot quanto a exportação
## da autocorrelação como tabela.
calcular_correlograma <- function(x, lag_max, tipo = c("ACF", "PACF")) {
    tipo <- match.arg(tipo)
    x <- as.numeric(x)
    n <- length(x)
    ## Série constante (por exemplo, um município sem nenhum evento em
    ## um grupo) não admite autocorrelação: devolve tabela vazia em vez
    ## de propagar NaN para dentro dos gráficos.
    if(n < 8 || var(x, na.rm = TRUE) == 0) {
        return(tibble(lag = integer(), valor = numeric(),
                      ic = numeric(), tipo = character()))
    }
    lag_max <- min(lag_max, floor(n / 3))
    if(tipo == "ACF") {
        obj <- acf(x, lag.max = lag_max, plot = FALSE, na.action = na.pass)
        valores <- as.numeric(obj$acf)[-1]
    } else {
        obj <- pacf(x, lag.max = lag_max, plot = FALSE, na.action = na.pass)
        valores <- as.numeric(obj$acf)
    }
    tibble(lag = seq_along(valores), valor = valores,
           ic = qnorm(1 - alfa / 2) / sqrt(n), tipo = tipo)
}

######@> Gráfico de correlograma em ggplot...
## Reimplementado em ggplot (em vez de usar o plot base de acf()) para
## que os correlogramas possam ser combinados com as demais figuras em
## painéis e sigam o mesmo tema visual.
grafico_correlograma <- function(tabela, titulo = NULL,
                                 subtitulo = NULL) {
    if(nrow(tabela) == 0) {
        return(ggplot() +
               annotate("text", x = 0, y = 0,
                        label = "Série sem variabilidade\n(correlograma não definido)",
                        size = 3, colour = "grey40") +
               labs(title = titulo) + theme_void())
    }
    ic <- tabela$ic[1]
    ggplot(tabela, aes(x = lag, y = valor)) +
        geom_hline(yintercept = 0, colour = "grey40") +
        geom_hline(yintercept = c(-ic, ic), linetype = "dashed",
                   colour = "#0072B2", linewidth = 0.4) +
        geom_segment(aes(xend = lag, yend = 0), linewidth = 0.6,
                     colour = "grey25") +
        geom_point(size = 1.1, colour = "grey15") +
        labs(title = titulo, subtitle = subtitulo,
             x = "Defasagem (lag)", y = tabela$tipo[1])
}

######@> Bateria de diagnósticos de uma série temporal...
## Reúne, em uma linha, tudo o que se costuma olhar antes de modelar:
## autocorrelação de 1ª ordem, teste global de ruído branco
## (Ljung-Box), os dois testes de estacionariedade e a dispersão.
##
## ADF e KPSS têm hipóteses nulas OPOSTAS - o ADF testa H0: raiz
## unitária (não estacionária) e o KPSS testa H0: estacionariedade -, e
## por isso são reportados juntos: concordância entre eles é evidência
## forte; discordância indica série com tendência determinística, que é
## exatamente o caso observado aqui.
diagnosticar_serie <- function(x, sazonal = FALSE, lag_teste = 12) {
    x <- as.numeric(x)
    n <- length(x)
    res <- tibble(n = n,
                  media = mean(x, na.rm = TRUE),
                  variancia = var(x, na.rm = TRUE),
                  razao_var_media = NA_real_,
                  prop_zeros = mean(x == 0, na.rm = TRUE),
                  acf1 = NA_real_,
                  ljung_box_p = NA_real_,
                  adf_p = NA_real_,
                  kpss_p = NA_real_,
                  estacionaria = NA_character_)
    res$razao_var_media <- ifelse(res$media > 0,
                                  res$variancia / res$media, NA_real_)
    if(n < 12 || var(x, na.rm = TRUE) == 0) return(res)
    res$acf1 <- as.numeric(acf(x, lag.max = 1, plot = FALSE)$acf[2])
    lag_teste <- min(lag_teste, floor(n / 4))
    res$ljung_box_p <- tryCatch(
        Box.test(x, lag = lag_teste, type = "Ljung-Box")$p.value,
        error = function(e) NA_real_)
    res$adf_p <- tryCatch(suppressWarnings(adf.test(x)$p.value),
                          error = function(e) NA_real_)
    res$kpss_p <- tryCatch(suppressWarnings(kpss.test(x)$p.value),
                           error = function(e) NA_real_)
    ## Leitura conjunta dos dois testes. Os p-valores de adf.test() e
    ## kpss.test() são truncados nos extremos da tabela (0,01 e 0,10),
    ## o que não afeta a classificação abaixo.
    res$estacionaria <- dplyr::case_when(
        is.na(res$adf_p) | is.na(res$kpss_p) ~ NA_character_,
        res$adf_p < alfa & res$kpss_p > alfa ~ "Estacionária",
        res$adf_p >= alfa & res$kpss_p <= alfa ~ "Não estacionária",
        res$adf_p < alfa & res$kpss_p <= alfa ~ "Tendência determinística",
        TRUE ~ "Indefinida")
    return(res)
}

######@> Remoção de tendência por regressão linear...
## Usada apenas para inspecionar a autocorrelação REMANESCENTE. A
## alternativa - diferenciar a série - também é aplicada no script, mas
## introduz autocorrelação negativa artificial de 1ª ordem (verificada:
## a ACF da série diferenciada tem lag 1 = -0,41), o que confundiria a
## leitura. Os resíduos da regressão preservam melhor a estrutura de
## curto prazo.
remover_tendencia <- function(x) {
    t <- seq_along(x)
    residuals(lm(x ~ t))
}

########################################################################
######@> Etapa 01 - Leitura das bases e preparação...

message("=== AED Atlas Digital - início ===")
message("Lendo bases padronizadas...")

if(!file.exists(arq_base)) {
    stop("Base não encontrada. Execute antes ",
         "script_Atlas_Digital_extracao_municipios_ver00.R")
}

load(arq_base)

######@> Objetos focais da análise...
## As duas bases pedidas. Todo o restante do script deriva delas, de
## modo que os totais aqui apresentados são, por construção, coerentes
## com as séries por grupo - não há caminho alternativo de cálculo que
## possa divergir.
mensal_grupo <- serie_mensal_grupo
anual_grupo <- serie_anual_grupo

######@> Conferência de integridade antes de analisar...
## O total de registros nas duas séries deve ser idêntico e igual ao
## número de linhas da base de eventos. Se não for, algo se perdeu na
## agregação e nenhuma conclusão adiante seria confiável.
total_eventos <- nrow(eventos)
stopifnot(sum(mensal_grupo$n_eventos) == total_eventos,
          sum(anual_grupo$n_eventos) == total_eventos)

message("Registros conferidos: ", total_eventos,
        " (idênticos nas duas séries)")

######@> Vetores de referência...
grupos <- sort(unique(anual_grupo$grupo_desastre))
municipios_nomes <- sort(unique(anual_grupo$municipio))
anos <- sort(unique(anual_grupo$ano))
ano_min <- min(anos); ano_max <- max(anos)
n_municipios <- length(municipios_nomes)
n_anos <- length(anos)

######@> Fator de grupo com ordem estável...
## Sem a ordenação explícita, cada figura poderia empilhar os grupos em
## ordem diferente conforme a frequência local, prejudicando a
## comparação visual entre painéis.
mensal_grupo <- mensal_grupo %>%
    mutate(grupo_desastre = factor(grupo_desastre, levels = grupos))
anual_grupo <- anual_grupo %>%
    mutate(grupo_desastre = factor(grupo_desastre, levels = grupos))

######@> Séries agregadas para o conjunto do litoral...
## Somam os 35 municípios, mantendo o recorte por grupo. É a escala em
## que a estrutura temporal aparece com menos ruído amostral.
litoral_anual_grupo <- anual_grupo %>%
    group_by(ano, grupo_desastre) %>%
    summarise(n_eventos = sum(n_eventos),
              n_reconhecidos = sum(n_reconhecidos),
              dh_afetados_total = sum(dh_afetados_total),
              dh_mortos = sum(dh_mortos),
              impacto_economico_total = sum(impacto_economico_total),
              .groups = "drop")

litoral_anual <- litoral_anual_grupo %>%
    group_by(ano) %>%
    summarise(across(where(is.numeric), sum), .groups = "drop")

litoral_mensal_grupo <- mensal_grupo %>%
    group_by(ano, mes, data, grupo_desastre) %>%
    summarise(n_eventos = sum(n_eventos), .groups = "drop")

litoral_mensal <- litoral_mensal_grupo %>%
    group_by(ano, mes, data) %>%
    summarise(n_eventos = sum(n_eventos), .groups = "drop") %>%
    arrange(ano, mes)

######@> Séries municipais totais (soma dos grupos)...
mun_anual <- anual_grupo %>%
    group_by(geocodigo, municipio, area_km2_shape, ano) %>%
    summarise(n_eventos = sum(n_eventos),
              n_reconhecidos = sum(n_reconhecidos),
              dh_afetados_total = sum(dh_afetados_total),
              dh_mortos = sum(dh_mortos),
              impacto_economico_total = sum(impacto_economico_total),
              .groups = "drop")

mun_mensal <- mensal_grupo %>%
    group_by(geocodigo, municipio, ano, mes, data) %>%
    summarise(n_eventos = sum(n_eventos), .groups = "drop")

######@> Leitura e preparo do shapefile para os mapas...
message("Lendo shapefile...")
shape_bruto <- st_read(arq_shape, quiet = TRUE) %>% st_make_valid()
shape_bruto <- st_transform(shape_bruto, crs_projeto)

atributos <- st_drop_geometry(shape_bruto)
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))

municipios_sf <- shape_bruto %>%
    group_by(geocodigo, municipio) %>%
    summarise(.groups = "drop") %>%
    st_make_valid()

######@> Recorte espacial da análise...
## Os dois municípios sem registros no Atlas (Camboriú e Paulo Lopes)
## são mantidos na base cartográfica, para que apareçam nos mapas como
## "sem dados" em vez de virarem um buraco no litoral, mas ficam FORA de
## todas as estatísticas. É a mesma decisão adotada na padronização.
municipios_sf <- municipios_sf %>%
    mutate(tem_dados = geocodigo %in% unique(anual_grupo$geocodigo))

message("Municípios analisados: ", n_municipios,
        " | no mapa: ", nrow(municipios_sf))

######@> Lista acumuladora das tabelas exportadas...
## Cada tabela produzida é registrada aqui e, ao final, todas são
## gravadas também em um único arquivo XLSX com uma aba por tabela.
tabelas <- list()

########################################################################
######@> Etapa 02 - Panorama geral e completude...

######@> Ficha da base analisada...
panorama <- tibble(
    Indicador = c("Período coberto",
                  "Municípios analisados",
                  "Municípios sem registro (fora da análise)",
                  "Grupos de desastre",
                  "Registros de desastre",
                  "Registros reconhecidos",
                  "Meses da grade (por município)",
                  "Linhas da série mensal por grupo",
                  "Linhas da série anual por grupo",
                  "Média de registros por ano (litoral)",
                  "Média de registros por município-ano",
                  "Meses sem nenhum registro no litoral",
                  "Pessoas afetadas (total)",
                  "Mortos (total)",
                  "Impacto econômico total (R$)"),
    Valor = c(paste(ano_min, "a", ano_max),
              as.character(n_municipios),
              paste(sum(!municipios_sf$tem_dados), "(Camboriú e Paulo Lopes)"),
              as.character(length(grupos)),
              fmt_int(total_eventos),
              fmt_int(sum(eventos$reconhecido)),
              as.character(n_anos * 12),
              fmt_int(nrow(mensal_grupo)),
              fmt_int(nrow(anual_grupo)),
              format(round(mean(litoral_anual$n_eventos), 1), nsmall = 1),
              format(round(mean(mun_anual$n_eventos), 2), nsmall = 2),
              paste0(sum(litoral_mensal$n_eventos == 0), " de ",
                     nrow(litoral_mensal)),
              fmt_int(sum(eventos$dh_afetados_total)),
              as.character(sum(eventos$dh_mortos)),
              fmt_int(sum(eventos$impacto_economico_total))))

tabelas$T01_panorama <- salvar_tab(panorama, "Tab_01_panorama_geral")

######@> Distribuição dos registros por grupo...
resumo_grupos <- anual_grupo %>%
    group_by(grupo_desastre) %>%
    summarise(registros = sum(n_eventos),
              reconhecidos = sum(n_reconhecidos),
              municipios_atingidos = n_distinct(geocodigo[n_eventos > 0]),
              anos_com_registro = n_distinct(ano[n_eventos > 0]),
              afetados = sum(dh_afetados_total),
              mortos = sum(dh_mortos),
              impacto_reais = sum(impacto_economico_total),
              .groups = "drop") %>%
    mutate(pct_registros = 100 * registros / sum(registros),
           pct_reconhecidos = 100 * reconhecidos / registros,
           impacto_medio_por_registro = impacto_reais / registros) %>%
    arrange(desc(registros))

tabelas$T02_grupos <- salvar_tab(resumo_grupos, "Tab_02_resumo_por_grupo")

message("\n--- Panorama ---")
message("Registros por grupo: ",
        paste(resumo_grupos$grupo_desastre, resumo_grupos$registros,
              sep = "=", collapse = " | "))

########################################################################
######@> Etapa 03 - Estrutura temporal agregada...

######@> Figura 01 - série anual do litoral, total e por grupo...
## O painel superior mostra o total com a declividade de Sen sobreposta;
## o inferior decompõe o mesmo total nos quatro grupos. A justaposição
## permite ver se o crescimento agregado vem de todos os grupos ou de
## um só.
sen_litoral <- declividade_sen(litoral_anual$n_eventos, litoral_anual$ano)
mk_litoral <- mann_kendall(litoral_anual$n_eventos)

p_anual_total <- ggplot(litoral_anual, aes(x = ano, y = n_eventos)) +
    geom_col(fill = "grey55", width = 0.75) +
    geom_smooth(method = "loess", se = TRUE, span = 0.6,
                colour = "#D55E00", fill = "#D55E00", alpha = 0.15,
                linewidth = 0.8, formula = y ~ x) +
    scale_x_continuous(breaks = seq(ano_min, ano_max, 5)) +
    labs(title = "Registros de desastre no litoral catarinense",
         subtitle = sprintf(paste("Total anual dos %d municípios |",
                                  "Mann-Kendall: tau = %.2f, p = %s |",
                                  "Sen: %+.2f registros/ano"),
                            n_municipios, mk_litoral$tau,
                            format.pval(mk_litoral$p_valor, digits = 2,
                                        eps = 0.001),
                            sen_litoral),
         x = NULL, y = "Registros")

p_anual_grupo <- ggplot(litoral_anual_grupo,
                        aes(x = ano, y = n_eventos, fill = grupo_desastre)) +
    geom_col(width = 0.75) +
    scale_fill_manual(values = cores_grupo, name = "Grupo") +
    scale_x_continuous(breaks = seq(ano_min, ano_max, 5)) +
    labs(subtitle = "Decomposição por grupo de desastre",
         x = "Ano", y = "Registros",
         caption = quebrar(paste("Fonte: Atlas Digital de Desastres (S2iD/CEPED-UFSC).",
                                 "O crescimento reflete tanto a ocorrência quanto",
                                 "a melhoria do registro administrativo.")))

salvar_fig(p_anual_total / p_anual_grupo,
           "Fig_01_serie_anual_litoral", 10, 8)

######@> Figura 02 - série mensal do litoral...
## A série mensal bruta é ruidosa; a média móvel de 12 meses revela a
## componente de baixa frequência sem impor forma funcional.
litoral_mensal <- litoral_mensal %>%
    arrange(data) %>%
    mutate(media_movel_12 = stats::filter(n_eventos, rep(1/12, 12),
                                          sides = 2))

p_mensal <- ggplot(litoral_mensal, aes(x = data)) +
    geom_col(aes(y = n_eventos), fill = "grey65", width = 25) +
    geom_line(aes(y = media_movel_12), colour = "#0072B2",
              linewidth = 0.9, na.rm = TRUE) +
    scale_x_date(date_breaks = "5 years", date_labels = "%Y") +
    labs(title = "Série mensal de registros no litoral catarinense",
         subtitle = paste("Barras: registros no mês |",
                          "Linha: média móvel centrada de 12 meses"),
         x = NULL, y = "Registros no mês",
         caption = sprintf(quebrar(paste("%d dos %d meses da série não têm",
                                         "nenhum registro. Máximo mensal: %d",
                                         "registros (%s).")),
                           sum(litoral_mensal$n_eventos == 0),
                           nrow(litoral_mensal),
                           max(litoral_mensal$n_eventos),
                           format(litoral_mensal$data[
                               which.max(litoral_mensal$n_eventos)],
                               "%m/%Y")))

salvar_fig(p_mensal, "Fig_02_serie_mensal_litoral", 11, 5)

######@> Figura 03 - composição relativa por grupo ao longo do tempo...
## A pergunta aqui não é "quantos desastres", e sim "de que tipo". A
## série em proporção elimina o efeito do crescimento do volume e mostra
## se a natureza dos desastres registrados mudou.
p_comp_abs <- ggplot(litoral_anual_grupo,
                     aes(x = ano, y = n_eventos, fill = grupo_desastre)) +
    geom_area(alpha = 0.9) +
    scale_fill_manual(values = cores_grupo, name = "Grupo") +
    scale_x_continuous(breaks = seq(ano_min, ano_max, 5)) +
    labs(title = "Composição dos registros por grupo de desastre",
         subtitle = "Valores absolutos", x = NULL, y = "Registros")

p_comp_rel <- ggplot(litoral_anual_grupo,
                     aes(x = ano, y = n_eventos, fill = grupo_desastre)) +
    geom_area(position = "fill", alpha = 0.9) +
    scale_fill_manual(values = cores_grupo, name = "Grupo") +
    scale_y_continuous(labels = percent_format(accuracy = 1)) +
    scale_x_continuous(breaks = seq(ano_min, ano_max, 5)) +
    labs(subtitle = "Participação relativa", x = "Ano", y = "% dos registros",
         caption = quebrar(paste("Anos iniciais têm poucos registros; suas",
                                 "proporções são instáveis e devem ser lidas",
                                 "com cautela.")))

salvar_fig(p_comp_abs / p_comp_rel + plot_layout(guides = "collect") &
           theme(legend.position = "bottom"),
           "Fig_03_composicao_grupos", 10, 8)

######@> Tabela - série anual por grupo em formato largo...
tab_anual_grupo <- litoral_anual_grupo %>%
    select(ano, grupo_desastre, n_eventos) %>%
    pivot_wider(names_from = grupo_desastre, values_from = n_eventos) %>%
    mutate(Total = rowSums(across(all_of(as.character(grupos)))))

tabelas$T03_serie_anual <- salvar_tab(tab_anual_grupo,
                                      "Tab_03_serie_anual_por_grupo")

########################################################################
######@> Etapa 04 - Sazonalidade e padrão intra-anual...

######@> Índice de sazonalidade por grupo...
## O índice é a razão entre o total do mês e a média mensal do grupo:
## 1 significa "mês típico", 2 significa "o dobro do esperado". A
## normalização é o que permite comparar grupos de tamanhos muito
## diferentes (732 registros hidrológicos contra 42 climatológicos) na
## mesma escala.
sazonal_grupo <- mensal_grupo %>%
    group_by(grupo_desastre, mes) %>%
    summarise(registros = sum(n_eventos), .groups = "drop") %>%
    group_by(grupo_desastre) %>%
    mutate(indice_sazonal = registros / mean(registros),
           pct_do_grupo = 100 * registros / sum(registros)) %>%
    ungroup() %>%
    mutate(mes_nome = factor(meses_abrev[mes], levels = meses_abrev))

sazonal_total <- litoral_mensal %>%
    group_by(mes) %>%
    summarise(registros = sum(n_eventos), .groups = "drop") %>%
    mutate(indice_sazonal = registros / mean(registros),
           mes_nome = factor(meses_abrev[mes], levels = meses_abrev))

tabelas$T04_sazonalidade <- salvar_tab(
    sazonal_grupo %>%
        select(grupo_desastre, mes, mes_nome, registros, pct_do_grupo,
               indice_sazonal),
    "Tab_04_indice_sazonal_por_grupo")

######@> Figura 04 - sazonalidade por grupo...
## Este é o gráfico que justifica analisar os grupos separadamente: as
## curvas hidrológica e meteorológica são quase espelhadas.
## O guia da escala de COR é suprimido de propósito. Os dois painéis
## usam aesthetics diferentes (colour em cima, fill embaixo) para as
## mesmas quatro categorias e nas mesmas cores; sem a supressão, o
## patchwork coletaria DUAS legendas idênticas lado a lado, e a segunda
## seria cortada na borda da figura.
p_saz_linha <- ggplot(sazonal_grupo,
                      aes(x = mes, y = indice_sazonal,
                          colour = grupo_desastre)) +
    geom_hline(yintercept = 1, linetype = "dashed", colour = "grey50") +
    geom_line(linewidth = 1) +
    geom_point(size = 2) +
    scale_colour_manual(values = cores_grupo, guide = "none") +
    scale_x_continuous(breaks = 1:12, labels = meses_abrev) +
    labs(title = "Sazonalidade dos registros por grupo de desastre",
         subtitle = paste("Índice sazonal = registros do mês ÷ média",
                          "mensal do grupo. Linha tracejada = mês típico"),
         x = NULL, y = "Índice sazonal")

p_saz_barra <- ggplot(sazonal_grupo,
                      aes(x = mes_nome, y = registros,
                          fill = grupo_desastre)) +
    geom_col() +
    scale_fill_manual(values = cores_grupo, name = "Grupo") +
    labs(subtitle = "Total de registros por mês (todos os anos somados)",
         x = "Mês", y = "Registros",
         caption = quebrar(paste("Os desastres hidrológicos concentram-se no verão e os",
                                 "meteorológicos no inverno. Somados, os dois padrões se",
                                 "cancelam parcialmente - razão pela qual a sazonalidade",
                                 "do total é fraca.")))

salvar_fig(p_saz_linha / p_saz_barra + plot_layout(guides = "collect") &
           theme(legend.position = "bottom"),
           "Fig_04_sazonalidade_por_grupo", 10, 8)

######@> Figura 05 - heatmap ano x mês...
## Mostra simultaneamente a sazonalidade (colunas) e a evolução
## interanual (linhas), além de destacar os meses excepcionais.
p_heat_total <- ggplot(litoral_mensal,
                       aes(x = factor(mes), y = ano, fill = n_eventos)) +
    geom_tile(colour = "white", linewidth = 0.2) +
    scale_fill_viridis_c(option = "magma", direction = -1,
                         name = "Registros") +
    scale_x_discrete(labels = meses_abrev) +
    scale_y_reverse(breaks = seq(ano_min, ano_max, 2)) +
    labs(title = "Registros de desastre por ano e mês",
         subtitle = "Litoral catarinense, todos os municípios",
         x = "Mês", y = NULL) +
    theme(legend.position = "right")

salvar_fig(p_heat_total, "Fig_05_heatmap_ano_mes", 8, 9)

######@> Figura 06 - heatmap ano x mês por grupo...
p_heat_grupo <- ggplot(litoral_mensal_grupo,
                       aes(x = factor(mes), y = ano, fill = n_eventos)) +
    geom_tile(colour = "white", linewidth = 0.1) +
    facet_wrap(~ grupo_desastre, nrow = 1) +
    scale_fill_viridis_c(option = "magma", direction = -1,
                         name = "Registros") +
    scale_x_discrete(labels = substr(meses_abrev, 1, 1)) +
    scale_y_reverse(breaks = seq(ano_min, ano_max, 5)) +
    labs(title = "Registros por ano e mês, segundo o grupo de desastre",
         x = "Mês", y = NULL) +
    theme(legend.position = "right")

salvar_fig(p_heat_grupo, "Fig_06_heatmap_ano_mes_grupo", 13, 7)

########################################################################
######@> Etapa 05 - Padrões municipais...

######@> Perfil consolidado por município...
## Reúne volume, intensidade, composição e regularidade temporal. É a
## tabela de referência para o texto e para a seleção de municípios em
## análises de caso.
perfil_municipio <- mun_anual %>%
    group_by(geocodigo, municipio, area_km2_shape) %>%
    summarise(registros = sum(n_eventos),
              reconhecidos = sum(n_reconhecidos),
              anos_com_registro = sum(n_eventos > 0),
              ano_pico = ano[which.max(n_eventos)],
              max_anual = max(n_eventos),
              media_anual = mean(n_eventos),
              dp_anual = sd(n_eventos),
              afetados = sum(dh_afetados_total),
              mortos = sum(dh_mortos),
              impacto_reais = sum(impacto_economico_total),
              .groups = "drop") %>%
    mutate(registros_por_mil_km2 = 1000 * registros / area_km2_shape,
           pct_anos_com_registro = 100 * anos_com_registro / n_anos,
           ## Coeficiente de variação: mede a irregularidade da série.
           ## Valores altos indicam município com poucos anos de muitos
           ## registros, em vez de ocorrência distribuída.
           cv_anual = dp_anual / media_anual,
           ## Razão variância/média na escala anual. Acima de 1 indica
           ## agrupamento temporal dos registros.
           razao_var_media_anual = dp_anual^2 / media_anual)

######@> Composição por grupo em cada município...
comp_municipio <- anual_grupo %>%
    group_by(geocodigo, municipio, grupo_desastre) %>%
    summarise(registros = sum(n_eventos), .groups = "drop") %>%
    group_by(geocodigo, municipio) %>%
    mutate(pct = 100 * registros / sum(registros)) %>%
    ungroup()

comp_municipio_largo <- comp_municipio %>%
    select(geocodigo, municipio, grupo_desastre, registros) %>%
    pivot_wider(names_from = grupo_desastre, values_from = registros) %>%
    left_join(comp_municipio %>%
                  group_by(geocodigo) %>%
                  slice_max(registros, n = 1, with_ties = FALSE) %>%
                  select(geocodigo, grupo_predominante = grupo_desastre,
                         pct_grupo_predominante = pct),
              by = "geocodigo")

perfil_municipio <- perfil_municipio %>%
    left_join(comp_municipio_largo %>% select(-municipio),
              by = "geocodigo") %>%
    arrange(desc(registros))

tabelas$T05_perfil_municipio <- salvar_tab(perfil_municipio,
                                           "Tab_05_perfil_municipios")
tabelas$T06_composicao <- salvar_tab(comp_municipio,
                                     "Tab_06_composicao_grupo_municipio")

######@> Figura 07 - ranking de municípios...
## Dois painéis com ordenações diferentes de propósito: o volume bruto
## responde "onde há mais registros" e a densidade responde "onde o
## território é mais frequentemente atingido". As respostas não
## coincidem, e essa discrepância é informativa.
ordem_volume <- perfil_municipio$municipio[order(perfil_municipio$registros)]

p_rank_abs <- perfil_municipio %>%
    mutate(municipio = factor(municipio, levels = ordem_volume)) %>%
    ggplot(aes(x = registros, y = municipio)) +
    geom_col(fill = "grey55") +
    geom_text(aes(label = registros), hjust = -0.25, size = 2.7) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.12))) +
    labs(title = "Registros de desastre por município",
         subtitle = "Volume total, 1991-2025", x = "Registros", y = NULL)

ordem_dens <- perfil_municipio$municipio[
    order(perfil_municipio$registros_por_mil_km2)]

p_rank_dens <- perfil_municipio %>%
    mutate(municipio = factor(municipio, levels = ordem_dens)) %>%
    ggplot(aes(x = registros_por_mil_km2, y = municipio)) +
    geom_col(fill = "#0072B2") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.12))) +
    labs(subtitle = "Densidade: registros por mil km² de território",
         x = "Registros / mil km²", y = NULL,
         caption = quebrar(paste("A densidade favorece municípios pequenos:",
                                 "Balneário Camboriú tem cerca de 46 km² e",
                                 "Joinville, 1.130 km².")))

salvar_fig(p_rank_abs | p_rank_dens, "Fig_07_ranking_municipios", 13, 8)

######@> Figura 08 - composição por grupo em cada município...
p_comp_mun <- comp_municipio %>%
    mutate(municipio = factor(municipio, levels = ordem_volume)) %>%
    ggplot(aes(x = pct, y = municipio, fill = grupo_desastre)) +
    geom_col() +
    scale_fill_manual(values = cores_grupo, name = "Grupo") +
    scale_x_continuous(labels = percent_format(scale = 1),
                       expand = c(0, 0)) +
    labs(title = "Composição dos registros por grupo, em cada município",
         subtitle = "Municípios ordenados pelo volume total de registros",
         x = "% dos registros do município", y = NULL,
         caption = quebrar(paste("O predomínio hidrológico é generalizado, mas a",
                                 "participação meteorológica varia bastante entre",
                                 "municípios.")))

salvar_fig(p_comp_mun, "Fig_08_composicao_por_municipio", 10, 8)

######@> Figura 09 - séries anuais de todos os municípios...
## "Small multiples": 35 painéis com a mesma escala, ordenados por
## volume. Permite comparar formas de série - crescimento contínuo,
## picos isolados, séries intermitentes - de uma só vez.
p_small <- mun_anual %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_volume))) %>%
    ggplot(aes(x = ano, y = n_eventos)) +
    geom_col(fill = "grey45", width = 0.9) +
    facet_wrap(~ municipio, ncol = 5, scales = "free_y") +
    scale_x_continuous(breaks = seq(2000, 2020, 10)) +
    labs(title = "Séries anuais de registros por município",
         subtitle = paste("Escala vertical livre em cada painel;",
                          "painéis ordenados por volume total"),
         x = "Ano", y = "Registros") +
    theme(strip.text = element_text(size = 7),
          axis.text = element_text(size = 6.5))

salvar_fig(p_small, "Fig_09_small_multiples_municipios", 13, 12)

######@> Figura 10 - heatmap município x ano...
## Revela sincronia entre municípios: colunas verticais escuras indicam
## anos em que quase todo o litoral registrou desastre, evidência
## direta do agrupamento espacial que produz a sobredispersão.
p_heat_mun <- mun_anual %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_volume))) %>%
    ggplot(aes(x = ano, y = municipio, fill = n_eventos)) +
    geom_tile(colour = "white", linewidth = 0.15) +
    scale_fill_viridis_c(option = "rocket", direction = -1,
                         name = "Registros") +
    scale_x_continuous(breaks = seq(ano_min, ano_max, 5),
                       expand = c(0, 0)) +
    labs(title = "Registros de desastre por município e ano",
         subtitle = paste("Colunas escuras indicam anos de ocorrência",
                          "sincronizada em todo o litoral"),
         x = "Ano", y = NULL) +
    theme(legend.position = "right",
          axis.text.y = element_text(size = 8))

salvar_fig(p_heat_mun, "Fig_10_heatmap_municipio_ano", 11, 9)

######@> Figura 11 - séries municipais por grupo...
## Mesma leitura da Figura 09, mas decomposta: mostra se o padrão
## temporal de um município é dominado por um único grupo.
p_small_grupo <- anual_grupo %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_volume))) %>%
    ggplot(aes(x = ano, y = n_eventos, fill = grupo_desastre)) +
    geom_col(width = 0.9) +
    facet_wrap(~ municipio, ncol = 5, scales = "free_y") +
    scale_fill_manual(values = cores_grupo, name = "Grupo") +
    scale_x_continuous(breaks = seq(2000, 2020, 10)) +
    labs(title = "Séries anuais por município e grupo de desastre",
         x = "Ano", y = "Registros") +
    theme(strip.text = element_text(size = 7),
          axis.text = element_text(size = 6.5))

salvar_fig(p_small_grupo, "Fig_11_small_multiples_grupos", 13, 12)

########################################################################
######@> Etapa 06 - Painéis diagnósticos por município...

######@> Construção de um painel por município...
## Cada arquivo reúne, para um município: (a) a série anual decomposta
## por grupo; (b) a série mensal; (c) o perfil sazonal; (d) a ACF e (e)
## a PACF da série mensal. É o material de consulta individual pedido
## pela análise - 35 arquivos, um por município.
##
## Observação metodológica: as séries MENSAIS municipais são muito
## esparsas (entre 2,4% e 13,8% dos meses têm registro). Seus
## correlogramas são, por isso, pouco informativos isoladamente, e
## devem ser lidos como indicação de ausência de estrutura de curto
## prazo no nível municipal - não como evidência de independência dos
## processos, que se manifesta na escala agregada.
message("\nGerando painéis por município...")

diagnostico_municipal <- vector("list", n_municipios)

for(i in seq_along(municipios_nomes)) {
    mun <- municipios_nomes[i]
    dados_a <- anual_grupo %>% filter(municipio == mun)
    dados_at <- mun_anual %>% filter(municipio == mun) %>% arrange(ano)
    dados_m <- mun_mensal %>% filter(municipio == mun) %>% arrange(data)
    dados_mg <- mensal_grupo %>% filter(municipio == mun)
    geo <- unique(dados_at$geocodigo)

    ## (a) Série anual empilhada por grupo
    g1 <- ggplot(dados_a, aes(x = ano, y = n_eventos,
                              fill = grupo_desastre)) +
        geom_col(width = 0.85) +
        scale_fill_manual(values = cores_grupo, name = "Grupo",
                          drop = FALSE) +
        scale_x_continuous(breaks = seq(ano_min, ano_max, 5)) +
        labs(subtitle = "Série anual por grupo", x = NULL,
             y = "Registros")

    ## (b) Série mensal
    g2 <- ggplot(dados_m, aes(x = data, y = n_eventos)) +
        geom_col(fill = "grey45", width = 25) +
        scale_x_date(date_breaks = "5 years", date_labels = "%Y") +
        labs(subtitle = "Série mensal", x = NULL, y = "Registros")

    ## (c) Perfil sazonal por grupo
    saz_mun <- dados_mg %>%
        group_by(grupo_desastre, mes) %>%
        summarise(registros = sum(n_eventos), .groups = "drop")

    g3 <- ggplot(saz_mun, aes(x = mes, y = registros,
                              fill = grupo_desastre)) +
        geom_col(width = 0.85) +
        scale_fill_manual(values = cores_grupo, name = "Grupo",
                          drop = FALSE) +
        scale_x_continuous(breaks = 1:12, labels = meses_abrev) +
        labs(subtitle = "Perfil sazonal", x = NULL, y = "Registros")

    ## (d) e (e) Correlogramas da série mensal
    acf_m <- calcular_correlograma(dados_m$n_eventos, lag_max_mensal, "ACF")
    pacf_m <- calcular_correlograma(dados_m$n_eventos, lag_max_mensal, "PACF")
    g4 <- grafico_correlograma(acf_m, subtitulo = "ACF da série mensal")
    g5 <- grafico_correlograma(pacf_m, subtitulo = "PACF da série mensal")

    ## Composição do painel
    painel <- (g1 / g2 / g3 / (g4 | g5)) +
        plot_layout(heights = c(1, 1, 1, 1), guides = "collect") +
        plot_annotation(
            title = paste0(mun, " (", geo, ")"),
            subtitle = sprintf(paste("%d registros em %d anos |",
                                     "grupo predominante: %s |",
                                     "%.1f%% dos meses com registro"),
                               sum(dados_at$n_eventos),
                               sum(dados_at$n_eventos > 0),
                               as.character(perfil_municipio$grupo_predominante[
                                   perfil_municipio$geocodigo == geo]),
                               100 * mean(dados_m$n_eventos > 0)),
            caption = quebrar(paste("AED Atlas Digital |",
                                    "Linhas tracejadas nos correlogramas:",
                                    "limite de significância a 5%"))) &
        theme(legend.position = "bottom")

    salvar_fig(painel,
               paste0("Painel_", geo, "_", limpar_nome(mun)),
               10, 13, diretorio = dir_fig_mun)

    ## Diagnóstico numérico do município, acumulado para a tabela final
    diag_mensal <- diagnosticar_serie(dados_m$n_eventos, lag_teste = 12)
    diag_anual <- diagnosticar_serie(dados_at$n_eventos, lag_teste = 5)
    mk_mun <- mann_kendall(dados_at$n_eventos)

    diagnostico_municipal[[i]] <- tibble(
        geocodigo = geo, municipio = mun,
        ## Escala mensal
        m_prop_zeros = diag_mensal$prop_zeros,
        m_media = diag_mensal$media,
        m_razao_var_media = diag_mensal$razao_var_media,
        m_acf1 = diag_mensal$acf1,
        m_ljung_p = diag_mensal$ljung_box_p,
        ## Escala anual
        a_media = diag_anual$media,
        a_razao_var_media = diag_anual$razao_var_media,
        a_acf1 = diag_anual$acf1,
        a_ljung_p = diag_anual$ljung_box_p,
        a_adf_p = diag_anual$adf_p,
        a_kpss_p = diag_anual$kpss_p,
        a_estacionaria = diag_anual$estacionaria,
        ## Tendência
        mk_tau = mk_mun$tau, mk_p = mk_mun$p_valor,
        sen_registros_ano = declividade_sen(dados_at$n_eventos,
                                            dados_at$ano))
}

diagnostico_municipal <- bind_rows(diagnostico_municipal) %>%
    mutate(autocorrelacao_mensal = ifelse(m_ljung_p < alfa,
                                          "Sim", "Não"),
           autocorrelacao_anual = ifelse(a_ljung_p < alfa, "Sim", "Não"),
           tendencia = case_when(is.na(mk_p) ~ "Indefinida",
                                 mk_p >= alfa ~ "Sem tendência",
                                 mk_tau > 0 ~ "Crescente",
                                 TRUE ~ "Decrescente")) %>%
    arrange(desc(a_media))

tabelas$T07_diag_municipal <- salvar_tab(
    diagnostico_municipal, "Tab_07_diagnostico_series_municipais")

message("Painéis gerados: ", n_municipios)

########################################################################
######@> Etapa 07 - Dependência temporal...

######@> Séries de trabalho como objetos ts...
## frequency = 12 informa ao STL e aos utilitários de séries qual é o
## ciclo candidato a sazonal.
ts_litoral_mensal <- ts(litoral_mensal$n_eventos,
                        start = c(ano_min, 1), frequency = 12)
ts_litoral_anual <- ts(litoral_anual$n_eventos, start = ano_min,
                       frequency = 1)

######@> Diagnóstico das séries agregadas...
## Note a inclusão da série SEM TENDÊNCIA ao lado da bruta. A comparação
## entre as duas linhas é o resultado central desta etapa.
diag_series <- bind_rows(
    diagnosticar_serie(litoral_mensal$n_eventos, lag_teste = 24) %>%
        mutate(serie = "Litoral - mensal (bruta)", .before = 1),
    diagnosticar_serie(remover_tendencia(litoral_mensal$n_eventos),
                       lag_teste = 24) %>%
        mutate(serie = "Litoral - mensal (sem tendência)", .before = 1),
    diagnosticar_serie(as.numeric(diff(ts_litoral_mensal)),
                       lag_teste = 24) %>%
        mutate(serie = "Litoral - mensal (1ª diferença)", .before = 1),
    diagnosticar_serie(litoral_anual$n_eventos, lag_teste = 8) %>%
        mutate(serie = "Litoral - anual (bruta)", .before = 1),
    diagnosticar_serie(remover_tendencia(litoral_anual$n_eventos),
                       lag_teste = 8) %>%
        mutate(serie = "Litoral - anual (sem tendência)", .before = 1),
    map_dfr(grupos, function(g) {
        x <- litoral_mensal_grupo %>%
            filter(grupo_desastre == g) %>%
            arrange(ano, mes)
        diagnosticar_serie(x$n_eventos, lag_teste = 24) %>%
            mutate(serie = paste0("Mensal - ", g), .before = 1)
    }),
    map_dfr(grupos, function(g) {
        x <- litoral_anual_grupo %>%
            filter(grupo_desastre == g) %>%
            arrange(ano)
        diagnosticar_serie(x$n_eventos, lag_teste = 8) %>%
            mutate(serie = paste0("Anual - ", g), .before = 1)
    }))

tabelas$T08_diag_series <- salvar_tab(diag_series,
                                      "Tab_08_diagnostico_series_agregadas")

######@> Figura 12 - correlogramas da série mensal do litoral...
## Três colunas: série bruta, série sem tendência e primeira diferença.
## A leitura conjunta separa o que é tendência do que é dependência
## genuína de curto prazo.
acf_bruta <- calcular_correlograma(litoral_mensal$n_eventos,
                                   lag_max_mensal, "ACF")
pacf_bruta <- calcular_correlograma(litoral_mensal$n_eventos,
                                    lag_max_mensal, "PACF")
serie_sem_tend <- remover_tendencia(litoral_mensal$n_eventos)
acf_sem_tend <- calcular_correlograma(serie_sem_tend, lag_max_mensal, "ACF")
pacf_sem_tend <- calcular_correlograma(serie_sem_tend, lag_max_mensal, "PACF")
serie_diff <- as.numeric(diff(ts_litoral_mensal))
acf_diff <- calcular_correlograma(serie_diff, lag_max_mensal, "ACF")
pacf_diff <- calcular_correlograma(serie_diff, lag_max_mensal, "PACF")

painel_acf <- (grafico_correlograma(acf_bruta, "Série bruta") |
               grafico_correlograma(acf_sem_tend, "Sem tendência") |
               grafico_correlograma(acf_diff, "1ª diferença")) /
    (grafico_correlograma(pacf_bruta) |
     grafico_correlograma(pacf_sem_tend) |
     grafico_correlograma(pacf_diff)) +
    plot_annotation(
        title = "Estrutura de autocorrelação da série mensal do litoral",
        subtitle = paste("A ACF da série bruta decai lentamente em todos",
                         "os lags - assinatura de TENDÊNCIA, não de",
                         "memória longa"),
        caption = quebrar(paste("Após remover a tendência, resta autocorrelação de curto",
                                "prazo. A 1ª diferença introduz autocorrelação negativa",
                                "artificial no lag 1, indicando sobrediferenciação.")))

salvar_fig(painel_acf, "Fig_12_correlogramas_litoral_mensal", 13, 8)

######@> Figura 13 - correlogramas por grupo (série mensal)...
acf_grupos <- map_dfr(grupos, function(g) {
    x <- litoral_mensal_grupo %>% filter(grupo_desastre == g) %>%
        arrange(ano, mes)
    bind_rows(
        calcular_correlograma(x$n_eventos, lag_max_mensal, "ACF"),
        calcular_correlograma(x$n_eventos, lag_max_mensal, "PACF")) %>%
        mutate(grupo_desastre = g)
})

p_acf_grupo <- ggplot(acf_grupos, aes(x = lag, y = valor)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_hline(aes(yintercept = ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_hline(aes(yintercept = -ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_segment(aes(xend = lag, yend = 0, colour = grupo_desastre),
                 linewidth = 0.6) +
    facet_grid(tipo ~ grupo_desastre) +
    scale_colour_manual(values = cores_grupo, guide = "none") +
    labs(title = "Correlogramas das séries mensais, por grupo de desastre",
         subtitle = "Séries brutas, sem remoção de tendência",
         x = "Defasagem (meses)", y = NULL)

salvar_fig(p_acf_grupo, "Fig_13_correlogramas_por_grupo", 13, 7)

######@> Figura 14 - correlogramas da série anual...
acf_anual <- calcular_correlograma(litoral_anual$n_eventos,
                                   lag_max_anual, "ACF")
pacf_anual <- calcular_correlograma(litoral_anual$n_eventos,
                                    lag_max_anual, "PACF")
acf_anual_st <- calcular_correlograma(
    remover_tendencia(litoral_anual$n_eventos), lag_max_anual, "ACF")
pacf_anual_st <- calcular_correlograma(
    remover_tendencia(litoral_anual$n_eventos), lag_max_anual, "PACF")

painel_acf_anual <- (grafico_correlograma(acf_anual, "Série bruta") |
                     grafico_correlograma(acf_anual_st, "Sem tendência")) /
    (grafico_correlograma(pacf_anual) |
     grafico_correlograma(pacf_anual_st)) +
    plot_annotation(
        title = "Estrutura de autocorrelação da série ANUAL do litoral",
        caption = quebrar(paste("Com apenas", n_anos, "observações, as estimativas de",
                                "autocorrelação anual têm precisão limitada e devem",
                                "ser lidas como indicativas.")))

salvar_fig(painel_acf_anual, "Fig_14_correlogramas_litoral_anual", 10, 7)

######@> Decomposição STL da série mensal...
## O STL separa a série em tendência, sazonalidade e resíduo. As
## "forças" de tendência e sazonalidade são calculadas segundo a
## definição usual (1 - var(resíduo) / var(componente + resíduo)) e
## variam de 0 a 1, permitindo comparar componentes entre séries de
## escalas diferentes.
stl_litoral <- stl(ts_litoral_mensal, s.window = "periodic")

forca_componente <- function(objeto_stl) {
    comp <- as.data.frame(objeto_stl$time.series)
    r <- comp$remainder
    tibble(forca_tendencia = max(0, 1 - var(r) / var(comp$trend + r)),
           forca_sazonal = max(0, 1 - var(r) / var(comp$seasonal + r)))
}

stl_tabela <- bind_rows(
    forca_componente(stl_litoral) %>% mutate(serie = "Litoral (total)",
                                             .before = 1),
    map_dfr(grupos, function(g) {
        x <- litoral_mensal_grupo %>% filter(grupo_desastre == g) %>%
            arrange(ano, mes)
        s <- stl(ts(x$n_eventos, start = c(ano_min, 1), frequency = 12),
                 s.window = "periodic")
        forca_componente(s) %>% mutate(serie = g, .before = 1)
    }))

tabelas$T09_stl <- salvar_tab(stl_tabela, "Tab_09_forca_componentes_stl")

######@> Figura 15 - decomposição STL do litoral...
stl_longo <- as.data.frame(stl_litoral$time.series) %>%
    mutate(data = litoral_mensal$data,
           observado = as.numeric(ts_litoral_mensal)) %>%
    pivot_longer(c(observado, trend, seasonal, remainder),
                 names_to = "componente", values_to = "valor") %>%
    mutate(componente = factor(componente,
                               levels = c("observado", "trend",
                                          "seasonal", "remainder"),
                               labels = c("Observado", "Tendência",
                                          "Sazonalidade", "Resíduo")))

p_stl <- ggplot(stl_longo, aes(x = data, y = valor)) +
    geom_line(linewidth = 0.5, colour = "grey20") +
    facet_wrap(~ componente, ncol = 1, scales = "free_y") +
    scale_x_date(date_breaks = "5 years", date_labels = "%Y") +
    labs(title = "Decomposição STL da série mensal do litoral",
         subtitle = sprintf(paste("Força da tendência = %.3f |",
                                  "Força da sazonalidade = %.3f"),
                            stl_tabela$forca_tendencia[1],
                            stl_tabela$forca_sazonal[1]),
         x = NULL, y = "Registros",
         caption = quebrar(paste("A tendência domina a sazonalidade nesta base. A",
                                 "sazonalidade fraca do total resulta do cancelamento",
                                 "entre grupos com fases opostas (ver Figura 04).")))

salvar_fig(p_stl, "Fig_15_decomposicao_stl", 11, 9)

######@> Figura 16 - correlação cruzada entre os grupos...
## Verifica se os grupos ocorrem juntos no tempo. A ausência de
## correlação relevante justifica tratá-los como processos distintos na
## modelagem posterior.
matriz_grupos <- litoral_mensal_grupo %>%
    select(ano, mes, grupo_desastre, n_eventos) %>%
    pivot_wider(names_from = grupo_desastre, values_from = n_eventos) %>%
    select(all_of(as.character(grupos)))

cor_grupos <- cor(matriz_grupos, method = "spearman")

cor_longo <- as.data.frame(as.table(cor_grupos)) %>%
    setNames(c("grupo_x", "grupo_y", "correlacao"))

p_cor <- ggplot(cor_longo, aes(x = grupo_x, y = grupo_y,
                               fill = correlacao)) +
    geom_tile(colour = "white", linewidth = 0.5) +
    geom_text(aes(label = sprintf("%.2f", correlacao)), size = 3.5) +
    scale_fill_gradient2(low = "#0072B2", mid = "white", high = "#D55E00",
                         midpoint = 0, limits = c(-1, 1),
                         name = "Spearman") +
    labs(title = "Correlação entre as séries mensais dos grupos",
         subtitle = paste("Correlação de Spearman entre as contagens",
                          "mensais do litoral"),
         x = NULL, y = NULL,
         caption = quebrar(paste("Correlações fracas indicam que os grupos",
                                 "respondem a processos distintos e podem ser",
                                 "modelados separadamente."))) +
    theme(axis.text.x = element_text(angle = 20, hjust = 1))

salvar_fig(p_cor, "Fig_16_correlacao_entre_grupos", 8, 7)

tabelas$T10_cor_grupos <- salvar_tab(
    as.data.frame(cor_grupos) %>% tibble::rownames_to_column("grupo"),
    "Tab_10_correlacao_entre_grupos")

########################################################################
######@> Etapa 08 - Tendência: Mann-Kendall e Sen...

######@> Tendência por município e por grupo...
## O teste é aplicado apenas às séries com um mínimo de anos com
## ocorrência. As demais recebem NA e um motivo explícito - o que
## preserva a informação de que a série existe, mas é curta demais para
## sustentar um teste.
tendencias <- anual_grupo %>%
    group_by(geocodigo, municipio, grupo_desastre) %>%
    arrange(ano, .by_group = TRUE) %>%
    group_modify(function(.x, .y) {
        anos_evento <- sum(.x$n_eventos > 0)
        if(anos_evento < min_anos_evento) {
            return(tibble(anos_com_registro = anos_evento,
                          registros = sum(.x$n_eventos),
                          tau = NA_real_, p_valor = NA_real_,
                          sen = NA_real_,
                          situacao = paste0("Série curta (< ",
                                            min_anos_evento,
                                            " anos com registro)")))
        }
        mk <- mann_kendall(.x$n_eventos)
        tibble(anos_com_registro = anos_evento,
               registros = sum(.x$n_eventos),
               tau = mk$tau, p_valor = mk$p_valor,
               sen = declividade_sen(.x$n_eventos, .x$ano),
               situacao = "Testada")
    }) %>%
    ungroup() %>%
    mutate(resultado = case_when(
               situacao != "Testada" ~ situacao,
               p_valor >= alfa ~ "Sem tendência",
               tau > 0 ~ "Crescimento significativo",
               TRUE ~ "Redução significativa"))

######@> Tendência do TOTAL de cada município...
tendencia_total <- mun_anual %>%
    group_by(geocodigo, municipio) %>%
    arrange(ano, .by_group = TRUE) %>%
    group_modify(function(.x, .y) {
        mk <- mann_kendall(.x$n_eventos)
        tibble(registros = sum(.x$n_eventos),
               tau = mk$tau, p_valor = mk$p_valor,
               sen = declividade_sen(.x$n_eventos, .x$ano))
    }) %>%
    ungroup() %>%
    mutate(resultado = case_when(is.na(p_valor) ~ "Indefinida",
                                 p_valor >= alfa ~ "Sem tendência",
                                 tau > 0 ~ "Crescimento significativo",
                                 TRUE ~ "Redução significativa")) %>%
    arrange(desc(tau))

tabelas$T11_tendencias <- salvar_tab(tendencias,
                                     "Tab_11_tendencia_municipio_grupo")
tabelas$T12_tend_total <- salvar_tab(tendencia_total,
                                     "Tab_12_tendencia_municipio_total")

######@> Figura 17 - tendências municipais...
## O tau de Kendall mede a direção e a consistência da tendência; o
## ponto é preenchido quando significativo. Ordenar por tau expõe o
## gradiente entre municípios.
p_tend <- tendencia_total %>%
    mutate(municipio = factor(municipio,
                              levels = municipio[order(tau)]),
           significativo = p_valor < alfa) %>%
    ggplot(aes(x = tau, y = municipio)) +
    geom_vline(xintercept = 0, colour = "grey40") +
    geom_segment(aes(xend = 0, yend = municipio), colour = "grey70") +
    geom_point(aes(fill = significativo), shape = 21, size = 3,
               colour = "grey20") +
    scale_fill_manual(values = c("TRUE" = "#D55E00", "FALSE" = "white"),
                      labels = c("TRUE" = paste0("p < ", alfa),
                                 "FALSE" = "Não significativo"),
                      name = NULL) +
    labs(title = "Tendência monotônica dos registros, por município",
         subtitle = paste("Tau de Mann-Kendall sobre a série anual",
                          "total, 1991-2025"),
         x = "Tau de Kendall", y = NULL,
         caption = quebrar(paste("Valores positivos indicam aumento do número de",
                                 "registros ao longo do período. Ver ressalva sobre",
                                 "esforço de registro.")))

salvar_fig(p_tend, "Fig_17_tendencia_municipios", 9, 8)

######@> Figura 18 - tendência por grupo em cada município...
p_tend_grupo <- tendencias %>%
    filter(situacao == "Testada") %>%
    mutate(municipio = factor(municipio, levels = rev(ordem_volume)),
           significativo = p_valor < alfa) %>%
    ggplot(aes(x = tau, y = municipio, colour = grupo_desastre)) +
    geom_vline(xintercept = 0, colour = "grey40") +
    geom_point(aes(shape = significativo), size = 2.4) +
    scale_colour_manual(values = cores_grupo, name = "Grupo") +
    scale_shape_manual(values = c("TRUE" = 16, "FALSE" = 1),
                       labels = c("TRUE" = paste0("p < ", alfa),
                                  "FALSE" = "Não significativo"),
                       name = NULL) +
    labs(title = "Tendência por grupo de desastre em cada município",
         subtitle = paste("Apenas séries com pelo menos",
                          min_anos_evento, "anos com registro"),
         x = "Tau de Kendall", y = NULL)

salvar_fig(p_tend_grupo, "Fig_18_tendencia_por_grupo", 10, 9)

########################################################################
######@> Etapa 09 - Distribuição das contagens e sobredispersão...

######@> A questão que esta etapa responde...
## Qual família de distribuição descreve as contagens? A resposta muda
## conforme a escala de agregação, e essa é justamente a informação
## decisiva para a modelagem futura. Ajustam-se quatro modelos apenas
## com intercepto - Poisson, binomial negativa e suas versões
## inflacionadas de zeros - a cada escala, comparando-os por AIC e pela
## capacidade de reproduzir o número de zeros observado.
ajustar_distribuicoes <- function(y, rotulo) {
    n_zeros_obs <- sum(y == 0)
    ## Poisson
    m_pois <- glm(y ~ 1, family = poisson)
    lambda <- exp(coef(m_pois)[1])
    zeros_pois <- length(y) * dpois(0, lambda)
    ## Binomial negativa
    m_nb <- tryCatch(glm.nb(y ~ 1), error = function(e) NULL)
    zeros_nb <- if(!is.null(m_nb)) {
        mu <- exp(coef(m_nb)[1])
        length(y) * dnbinom(0, size = m_nb$theta, mu = mu)
    } else NA_real_
    ## Versões inflacionadas de zeros
    m_zip <- tryCatch(zeroinfl(y ~ 1 | 1, dist = "poisson"),
                      error = function(e) NULL)
    m_zinb <- tryCatch(zeroinfl(y ~ 1 | 1, dist = "negbin"),
                       error = function(e) NULL)
    tibble(escala = rotulo,
           n = length(y),
           media = mean(y),
           variancia = var(y),
           razao_var_media = var(y) / mean(y),
           zeros_observados = n_zeros_obs,
           zeros_esperados_poisson = zeros_pois,
           zeros_esperados_nb = zeros_nb,
           aic_poisson = AIC(m_pois),
           aic_nb = if(!is.null(m_nb)) AIC(m_nb) else NA_real_,
           aic_zip = if(!is.null(m_zip)) AIC(m_zip) else NA_real_,
           aic_zinb = if(!is.null(m_zinb)) AIC(m_zinb) else NA_real_,
           theta_nb = if(!is.null(m_nb)) m_nb$theta else NA_real_)
}

distribuicoes <- bind_rows(
    ajustar_distribuicoes(mun_mensal$n_eventos, "Município-mês"),
    ajustar_distribuicoes(mun_anual$n_eventos, "Município-ano"),
    ajustar_distribuicoes(litoral_mensal$n_eventos, "Litoral-mês"),
    ajustar_distribuicoes(litoral_anual$n_eventos, "Litoral-ano"),
    map_dfr(grupos, function(g) {
        y <- mensal_grupo %>% filter(grupo_desastre == g) %>%
            pull(n_eventos)
        ajustar_distribuicoes(y, paste0("Município-mês - ", g))
    })) %>%
    mutate(melhor_modelo = c("Poisson", "NB", "ZIP", "ZINB")[
        apply(across(c(aic_poisson, aic_nb, aic_zip, aic_zinb)), 1,
              function(v) if(all(is.na(v))) NA_integer_ else which.min(v))])

tabelas$T13_distribuicoes <- salvar_tab(
    distribuicoes, "Tab_13_ajuste_distribuicoes_contagem")

######@> Leitura sintética do ajuste, para o relatório final...
## As quatro primeiras linhas são as escalas de agregação, na ordem
## crescente do nível de agregação - é essa progressão que revela a
## origem da sobredispersão.
dist_escalas <- distribuicoes %>%
    filter(escala %in% c("Município-mês", "Município-ano",
                         "Litoral-mês", "Litoral-ano")) %>%
    mutate(escala = factor(escala, levels = c("Município-mês",
                                              "Município-ano",
                                              "Litoral-mês",
                                              "Litoral-ano"))) %>%
    arrange(escala)

######@> A inflação de zeros acrescenta algo?...
## Comparação direta: em alguma escala o AIC de um modelo inflacionado
## fica ABAIXO do da binomial negativa? Se não, o excesso de zeros já
## está explicado pela sobredispersão e um parâmetro de inflação seria
## complexidade sem retorno.
zi_melhora <- any(
    pmin(distribuicoes$aic_zip, distribuicoes$aic_zinb, na.rm = TRUE) <
    distribuicoes$aic_nb - 2, na.rm = TRUE)

######@> Sobredispersão por município e escala...
## Isola a origem da sobredispersão. A sondagem preliminar indicou que
## ela é baixa na escala município-mês e alta na escala anual e
## agregada; esta tabela documenta o padrão município a município.
sobredispersao <- diagnostico_municipal %>%
    select(geocodigo, municipio,
           razao_vm_mensal = m_razao_var_media,
           razao_vm_anual = a_razao_var_media,
           prop_zeros_mensal = m_prop_zeros) %>%
    arrange(desc(razao_vm_anual))

tabelas$T14_sobredispersao <- salvar_tab(
    sobredispersao, "Tab_14_sobredispersao_por_municipio")

######@> Figura 19 - relação variância-média nas duas escalas...
## Cada ponto é um município. A linha de identidade representa o
## comportamento Poisson; pontos acima dela indicam sobredispersão. A
## comparação entre painéis mostra em que escala o excesso de variância
## aparece.
## A ordem dos painéis é fixada do MENOR para o MAIOR nível de
## agregação, que é a ordem em que o fenômeno deve ser lido: sem isso,
## o ggplot ordenaria alfabeticamente ("ano" antes de "mês") e
## inverteria a progressão descrita na legenda.
vm_longo <- bind_rows(
    diagnostico_municipal %>%
        transmute(municipio, escala = "Escala município-mês",
                  media = m_media, variancia = m_razao_var_media * m_media),
    diagnostico_municipal %>%
        transmute(municipio, escala = "Escala município-ano",
                  media = a_media, variancia = a_razao_var_media * a_media)) %>%
    mutate(escala = factor(escala, levels = c("Escala município-mês",
                                              "Escala município-ano")))

p_vm <- ggplot(vm_longo, aes(x = media, y = variancia)) +
    geom_abline(slope = 1, intercept = 0, linetype = "dashed",
                colour = "#D55E00", linewidth = 0.8) +
    geom_point(size = 2.2, alpha = 0.8, colour = "#0072B2") +
    facet_wrap(~ escala, scales = "free") +
    labs(title = "Relação variância-média das contagens municipais",
         subtitle = paste("Linha tracejada: variância = média",
                          "(comportamento Poisson).",
                          "Pontos acima indicam sobredispersão"),
         x = "Média de registros", y = "Variância",
         caption = quebrar(paste("Na escala município-mês os pontos acompanham a",
                                 "identidade; na escala anual afastam-se dela. A",
                                 "sobredispersão emerge da agregação temporal e do",
                                 "agrupamento espacial dos eventos, não da",
                                 "heterogeneidade do processo mensal.")))

salvar_fig(p_vm, "Fig_19_variancia_media", 11, 5.5)

######@> Figura 20 - distribuição das contagens...
p_dist <- bind_rows(
    tibble(escala = "Município-mês", n = mun_mensal$n_eventos),
    tibble(escala = "Município-ano", n = mun_anual$n_eventos),
    tibble(escala = "Litoral-mês", n = litoral_mensal$n_eventos),
    tibble(escala = "Litoral-ano", n = litoral_anual$n_eventos)) %>%
    mutate(escala = factor(escala, levels = c("Município-mês",
                                              "Município-ano",
                                              "Litoral-mês",
                                              "Litoral-ano"))) %>%
    ggplot(aes(x = n)) +
    geom_histogram(binwidth = 1, fill = "grey45", colour = "white",
                   linewidth = 0.2) +
    facet_wrap(~ escala, scales = "free") +
    labs(title = "Distribuição das contagens de registros",
         subtitle = "Quatro escalas de agregação espaço-temporal",
         x = "Registros no período", y = "Frequência",
         caption = quebrar(paste("O excesso de zeros na escala município-mês é",
                                 "estrutural: a maior parte dos meses não tem",
                                 "desastre em um dado município.")))

salvar_fig(p_dist, "Fig_20_distribuicao_contagens", 10, 7)

########################################################################
######@> Etapa 10 - Padrões espaciais...

######@> Junção dos indicadores ao shapefile...
mapa_dados <- municipios_sf %>%
    left_join(perfil_municipio %>%
                  select(geocodigo, registros, registros_por_mil_km2,
                         media_anual, cv_anual, grupo_predominante,
                         pct_grupo_predominante, afetados, mortos,
                         impacto_reais),
              by = "geocodigo") %>%
    left_join(tendencia_total %>%
                  select(geocodigo, tau_tendencia = tau,
                         p_tendencia = p_valor, sen_tendencia = sen),
              by = "geocodigo")

######@> Função de mapa coroplético...
## Centralizada para que todos os mapas compartilhem projeção, tema e
## tratamento dos municípios sem dados.
mapa_base <- function(dados, variavel, titulo, subtitulo, legenda,
                      paleta = "viridis", caption = NULL) {
    ggplot(dados) +
        geom_sf(aes(fill = .data[[variavel]]), colour = "grey30",
                linewidth = 0.2) +
        scale_fill_viridis_c(option = paleta, direction = -1,
                             name = legenda, na.value = "grey85") +
        labs(title = titulo, subtitle = subtitulo, caption = caption) +
        theme_void(base_size = 11) +
        theme(plot.title = element_text(face = "bold", size = 13),
              plot.subtitle = element_text(colour = "grey30", size = 10),
              plot.caption = element_text(colour = "grey45", size = 8,
                                          hjust = 0),
              legend.position = "right")
}

######@> Mapa 01 - volume total de registros...
m1 <- mapa_base(mapa_dados, "registros",
                "Registros de desastre por município",
                paste0("Total acumulado, ", ano_min, "-", ano_max),
                "Registros",
                caption = quebrar(paste("Em cinza: municípios sem registro no",
                                        "Atlas (Camboriú e Paulo Lopes).")))

######@> Mapa 02 - densidade de registros...
m2 <- mapa_base(mapa_dados, "registros_por_mil_km2",
                "Densidade de registros de desastre",
                "Registros por mil km² de território municipal",
                "Reg./mil km²", paleta = "rocket")

salvar_fig(m1 | m2, "Mapa_01_volume_e_densidade", 13, 7,
           diretorio = dir_mapa)

######@> Mapa 03 - grupo predominante...
m3 <- ggplot(mapa_dados) +
    geom_sf(aes(fill = grupo_predominante), colour = "grey30",
            linewidth = 0.2) +
    scale_fill_manual(values = cores_grupo, na.value = "grey85",
                      name = "Grupo predominante") +
    labs(title = "Grupo de desastre predominante em cada município",
         subtitle = paste("Grupo com maior número de registros no",
                          "período completo"),
         caption = quebrar(paste("O predomínio hidrológico é quase universal no",
                                 "litoral; ver o painel à direita para a",
                                 "intensidade desse predomínio."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

m4 <- mapa_base(mapa_dados, "pct_grupo_predominante",
                "Concentração no grupo predominante",
                "% dos registros do município no grupo mais frequente",
                "% dos registros", paleta = "mako")

salvar_fig(m3 | m4, "Mapa_02_grupo_predominante", 13, 7,
           diretorio = dir_mapa)

######@> Mapa 04 - registros por grupo (facetas)...
mapa_grupo <- municipios_sf %>%
    left_join(anual_grupo %>%
                  group_by(geocodigo, grupo_desastre) %>%
                  summarise(registros = sum(n_eventos), .groups = "drop"),
              by = "geocodigo") %>%
    filter(!is.na(grupo_desastre))

m5 <- ggplot(mapa_grupo) +
    geom_sf(aes(fill = registros), colour = "grey40", linewidth = 0.15) +
    facet_wrap(~ grupo_desastre, nrow = 1) +
    scale_fill_viridis_c(option = "viridis", direction = -1,
                         name = "Registros", na.value = "grey85") +
    labs(title = "Distribuição espacial dos registros por grupo de desastre",
         subtitle = paste0("Total acumulado ", ano_min, "-", ano_max,
                           "; escala de cor comum aos quatro painéis"),
         caption = quebrar(paste("A escala compartilhada evidencia a dominância",
                                 "do grupo hidrológico em volume."))) +
    theme_void(base_size = 10) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          strip.text = element_text(face = "bold"),
          legend.position = "right")

salvar_fig(m5, "Mapa_03_registros_por_grupo", 14, 6, diretorio = dir_mapa)

######@> Mapa 05 - evolução por período...
## Quatro recortes temporais aproximadamente equilibrados permitem ver
## se o crescimento dos registros é homogêneo no espaço ou se avança de
## uma porção do litoral para outra.
mapa_periodo <- municipios_sf %>%
    left_join(mun_anual %>%
                  mutate(periodo = cut(ano,
                                       breaks = c(1990, 1999, 2009,
                                                  2019, 2025),
                                       labels = c("1991-1999", "2000-2009",
                                                  "2010-2019",
                                                  "2020-2025"))) %>%
                  group_by(geocodigo, periodo) %>%
                  summarise(registros = sum(n_eventos), .groups = "drop"),
              by = "geocodigo") %>%
    filter(!is.na(periodo))

m6 <- ggplot(mapa_periodo) +
    geom_sf(aes(fill = registros), colour = "grey40", linewidth = 0.15) +
    facet_wrap(~ periodo, nrow = 1) +
    scale_fill_viridis_c(option = "inferno", direction = -1,
                         name = "Registros", na.value = "grey85") +
    labs(title = "Evolução espacial dos registros de desastre",
         subtitle = "Totais acumulados em cada período",
         caption = quebrar(paste("Os períodos têm durações diferentes",
                                 "(9, 10, 10 e 6 anos); a comparação é de",
                                 "padrão espacial, não de intensidade."))) +
    theme_void(base_size = 10) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          strip.text = element_text(face = "bold"),
          legend.position = "right")

salvar_fig(m6, "Mapa_04_evolucao_por_periodo", 14, 6, diretorio = dir_mapa)

######@> Autocorrelação espacial...
## A pergunta: municípios vizinhos têm números de registro parecidos?
## Uma resposta afirmativa significa que as observações NÃO são
## independentes no espaço - o que invalida modelos que as tratem como
## tal e é, portanto, informação decisiva para a etapa analítica
## seguinte.
##
## A vizinhança é definida por CONTIGUIDADE (critério queen: basta
## compartilhar um ponto de fronteira), que é o critério natural para
## municípios.
##
## Há, porém, uma complicação específica deste recorte. O litoral é uma
## FAIXA, e não uma malha: cada município tem em média menos de três
## vizinhos, e a cadeia se sustenta pelos elos sucessivos. Ao excluir
## Camboriú e Paulo Lopes - que não têm registros no Atlas, mas existem
## no território -, dois elos dessa cadeia se rompem e o grafo se parte
## em SUB-GRAFOS desconexos: o trecho ao norte e o trecho ao sul deixam
## de ter qualquer ligação entre si.
##
## Isso não invalida o índice de Moran, que continua definido, mas altera
## o que ele mede: a comparação passa a ocorrer apenas DENTRO de cada
## trecho, nunca entre eles. Como a decisão de excluir os dois
## municípios é analítica (não há dado) e não geográfica, o script
## calcula o índice sob DOIS esquemas de vizinhança e reporta ambos:
##
##   - contiguidade : fiel à geografia, porém desconexo neste recorte;
##   - k vizinhos mais próximos (k = 4) : sempre conexo, ao custo de
##     criar vizinhanças que atravessam o vão deixado pelos municípios
##     excluídos.
##
## Concordância entre os dois é evidência de que o resultado não é
## artefato do esquema de pesos; discordância é sinal de que a conclusão
## espacial depende dessa escolha e precisa ser relatada com ressalva.
mapa_analise <- mapa_dados %>% filter(tem_dados)

vizinhanca <- poly2nb(mapa_analise, queen = TRUE)

######@> Diagnóstico da conectividade do grafo...
## n.comp.nb() conta as componentes conexas. Um grafo conexo tem 1.
componentes <- n.comp.nb(vizinhanca)$nc
sem_vizinho <- sum(card(vizinhanca) == 0)

criterio_vizinhanca <- sprintf(
    "Contiguidade (queen): %.2f vizinhos em média, %d componente(s)",
    mean(card(vizinhanca)), componentes)

######@> Esquema alternativo, sempre conexo...
coords_mun <- suppressWarnings(st_coordinates(st_centroid(mapa_analise)))
vizinhanca_knn <- knn2nb(knearneigh(coords_mun, k = 4))

######@> Pesos padronizados por linha...
## style = "W" faz cada linha somar 1, de modo que municípios com muitos
## vizinhos não pesem mais que os de poucos - apropriado quando o número
## de vizinhos varia tanto quanto aqui (de 1 a 5).
## zero.policy = TRUE permite que eventuais municípios sem vizinho
## permaneçam na análise com contribuição nula, em vez de derrubar o
## cálculo.
pesos <- nb2listw(vizinhanca, style = "W", zero.policy = TRUE)
pesos_knn <- nb2listw(vizinhanca_knn, style = "W")

message("\nVizinhança espacial: ", criterio_vizinhanca)
if(componentes > 1) {
    message("  ATENÇÃO: o grafo de contiguidade está desconexo (",
            componentes, " trechos), efeito da exclusão de Camboriú e ",
            "Paulo Lopes. Resultados conferidos também com kNN (k = 4).")
}
if(sem_vizinho > 0) {
    warning("Municípios sem vizinho por contiguidade: ", sem_vizinho)
}

######@> Índice de Moran global para vários indicadores...
## Calculado sob os dois esquemas de vizinhança, lado a lado.
indicadores_moran <- list(
    c("registros", "Total de registros"),
    c("registros_por_mil_km2", "Registros por mil km²"),
    c("media_anual", "Média anual de registros"),
    c("cv_anual", "Irregularidade temporal (CV)"),
    c("tau_tendencia", "Tau da tendência"))

testar_moran <- function(x, listw, rotulo, esquema) {
    if(all(is.na(x)) || var(x, na.rm = TRUE) == 0) return(NULL)
    teste <- moran.test(x, listw, zero.policy = TRUE)
    tibble(indicador = rotulo,
           esquema_vizinhanca = esquema,
           moran_i = as.numeric(teste$estimate[1]),
           esperado = as.numeric(teste$estimate[2]),
           z = as.numeric(teste$statistic),
           p_valor = teste$p.value,
           interpretacao = ifelse(
               teste$p.value < alfa,
               ifelse(teste$estimate[1] > teste$estimate[2],
                      "Agrupamento espacial", "Dispersão espacial"),
               "Padrão aleatório"))
}

moran_global <- map_dfr(indicadores_moran, function(v) {
    x <- mapa_analise[[v[1]]]
    bind_rows(testar_moran(x, pesos, v[2], "Contiguidade"),
              testar_moran(x, pesos_knn, v[2], "kNN (k = 4)"))
})

######@> Concordância entre os dois esquemas...
## Marca explicitamente os indicadores cuja conclusão MUDA conforme o
## esquema de pesos - exatamente os que exigem cautela no texto.
moran_global <- moran_global %>%
    group_by(indicador) %>%
    mutate(conclusao_robusta = ifelse(
               n_distinct(interpretacao) == 1,
               "Sim (mesma conclusão nos dois esquemas)",
               "Não - conclusão depende do esquema de vizinhança")) %>%
    ungroup()

tabelas$T15_moran <- salvar_tab(moran_global,
                                "Tab_15_moran_global")

######@> Moran global ano a ano...
## Mostra se a dependência espacial é permanente ou episódica -
## concentrada nos anos de eventos regionais.
moran_anual <- map_dfr(anos, function(a) {
    x <- mun_anual %>% filter(ano == a) %>%
        right_join(st_drop_geometry(mapa_analise) %>% select(geocodigo),
                   by = "geocodigo") %>%
        arrange(match(geocodigo, mapa_analise$geocodigo)) %>%
        pull(n_eventos)
    x[is.na(x)] <- 0
    if(var(x) == 0) {
        return(tibble(ano = a, moran_i = NA_real_, p_valor = NA_real_,
                      registros = sum(x)))
    }
    teste <- moran.test(x, pesos, zero.policy = TRUE)
    tibble(ano = a, moran_i = as.numeric(teste$estimate[1]),
           p_valor = teste$p.value, registros = sum(x))
})

tabelas$T16_moran_anual <- salvar_tab(moran_anual,
                                      "Tab_16_moran_anual")

######@> Figura 21 - Moran global ao longo do tempo...
p_moran_ano <- ggplot(moran_anual, aes(x = ano, y = moran_i)) +
    geom_hline(yintercept = -1 / (nrow(mapa_analise) - 1),
               linetype = "dashed", colour = "grey40") +
    geom_line(colour = "grey60", na.rm = TRUE) +
    geom_point(aes(fill = p_valor < alfa, size = registros),
               shape = 21, colour = "grey20", na.rm = TRUE) +
    scale_fill_manual(values = c("TRUE" = "#D55E00", "FALSE" = "white"),
                      labels = c("TRUE" = paste0("p < ", alfa),
                                 "FALSE" = "Não significativo"),
                      name = NULL, na.value = "grey80") +
    scale_size_continuous(name = "Registros no ano", range = c(1.5, 6)) +
    scale_x_continuous(breaks = seq(ano_min, ano_max, 5)) +
    labs(title = "Autocorrelação espacial dos registros, ano a ano",
         subtitle = paste("Índice de Moran global sobre o número de",
                          "registros de cada município"),
         x = "Ano", y = "I de Moran",
         caption = quebrar(paste("Linha tracejada: valor esperado sob ausência de",
                                 "autocorrelação. Anos com poucos registros produzem",
                                 "estimativas instáveis.")))

salvar_fig(p_moran_ano, "Fig_21_moran_anual", 11, 6)

######@> Moran local (LISA) sobre o total de registros...
## Identifica ONDE está o agrupamento: municípios de valor alto cercados
## por vizinhos altos (alto-alto) formam o núcleo do padrão.
lisa <- localmoran(mapa_analise$registros, pesos, zero.policy = TRUE)

x_padr <- as.numeric(scale(mapa_analise$registros))
lag_padr <- as.numeric(scale(lag.listw(pesos, mapa_analise$registros)))

mapa_analise <- mapa_analise %>%
    mutate(lisa_i = lisa[, 1],
           lisa_p = lisa[, ncol(lisa)],
           lisa_classe = case_when(
               lisa_p >= alfa ~ "Não significativo",
               x_padr > 0 & lag_padr > 0 ~ "Alto-Alto",
               x_padr < 0 & lag_padr < 0 ~ "Baixo-Baixo",
               x_padr > 0 & lag_padr < 0 ~ "Alto-Baixo",
               TRUE ~ "Baixo-Alto"))

cores_lisa <- c("Alto-Alto" = "#D55E00", "Baixo-Baixo" = "#0072B2",
                "Alto-Baixo" = "#E69F00", "Baixo-Alto" = "#56B4E9",
                "Não significativo" = "grey88")

m7 <- ggplot() +
    geom_sf(data = municipios_sf, fill = "grey93", colour = "grey60",
            linewidth = 0.15) +
    geom_sf(data = mapa_analise, aes(fill = lisa_classe),
            colour = "grey30", linewidth = 0.2) +
    scale_fill_manual(values = cores_lisa, name = "Agrupamento local") +
    labs(title = "Agrupamentos espaciais locais de registros (LISA)",
         subtitle = paste("Moran local sobre o total de registros,",
                          ano_min, "-", ano_max),
         caption = quebrar(paste0("Vizinhança: ", criterio_vizinhanca,
                                  ". 'Alto-Alto' indica município com muitos ",
                                  "registros cercado por vizinhos também com ",
                                  "muitos registros."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m7, "Mapa_05_lisa_agrupamentos", 9, 8, diretorio = dir_mapa)

######@> Figura 22 - diagrama de espalhamento de Moran...
p_moran_scatter <- tibble(x = x_padr, y = lag_padr,
                          municipio = mapa_analise$municipio,
                          classe = mapa_analise$lisa_classe) %>%
    ggplot(aes(x = x, y = y)) +
    geom_hline(yintercept = 0, colour = "grey50") +
    geom_vline(xintercept = 0, colour = "grey50") +
    geom_smooth(method = "lm", se = FALSE, colour = "#D55E00",
                linewidth = 0.8, formula = y ~ x) +
    geom_point(aes(fill = classe), shape = 21, size = 3,
               colour = "grey25") +
    scale_fill_manual(values = cores_lisa, name = "Agrupamento local") +
    labs(title = "Diagrama de espalhamento de Moran",
         subtitle = sprintf(paste("Total de registros por município |",
                                  "I de Moran = %.3f (p = %s)"),
                            moran_global$moran_i[1],
                            format.pval(moran_global$p_valor[1],
                                        digits = 2, eps = 0.001)),
         x = "Registros (padronizado)",
         y = "Média dos vizinhos (padronizado)",
         caption = quebrar(paste("A inclinação da reta é o próprio I de Moran.",
                                 "Cada ponto é um município.")))

salvar_fig(p_moran_scatter, "Fig_22_moran_scatterplot", 9, 7)

tabelas$T17_lisa <- salvar_tab(
    st_drop_geometry(mapa_analise) %>%
        select(geocodigo, municipio, registros, lisa_i, lisa_p,
               lisa_classe) %>%
        arrange(desc(lisa_i)),
    "Tab_17_lisa_municipios")

########################################################################
######@> Etapa 11 - Agrupamento de municípios por perfil...

######@> Construção da matriz de perfis...
## As variáveis descrevem o município em quatro dimensões: volume,
## regularidade temporal, composição por grupo e sazonalidade. A
## padronização (escala z) é indispensável porque as variáveis têm
## unidades incomparáveis.
perfil_matriz <- perfil_municipio %>%
    select(geocodigo, municipio, registros, registros_por_mil_km2,
           pct_anos_com_registro, cv_anual) %>%
    left_join(comp_municipio %>%
                  select(geocodigo, grupo_desastre, pct) %>%
                  pivot_wider(names_from = grupo_desastre,
                              values_from = pct,
                              names_prefix = "pct_"),
              by = "geocodigo") %>%
    left_join(mensal_grupo %>%
                  group_by(geocodigo) %>%
                  summarise(pct_verao = 100 *
                                sum(n_eventos[mes %in% c(12, 1, 2)]) /
                                pmax(1, sum(n_eventos)),
                            pct_inverno = 100 *
                                sum(n_eventos[mes %in% c(6, 7, 8)]) /
                                pmax(1, sum(n_eventos)),
                            .groups = "drop"),
              by = "geocodigo")

matriz_z <- perfil_matriz %>%
    select(-geocodigo, -municipio) %>%
    mutate(across(everything(), ~ replace(.x, is.na(.x), 0))) %>%
    scale()

rownames(matriz_z) <- perfil_matriz$municipio

######@> Agrupamento hierárquico...
## Distância euclidiana sobre as variáveis padronizadas e ligação de
## Ward, que tende a formar grupos de tamanho equilibrado - preferível
## aqui, onde o objetivo é descrever tipologias e não isolar valores
## extremos.
distancias <- dist(matriz_z, method = "euclidean")
agrupamento <- hclust(distancias, method = "ward.D2")

######@> Escolha do número de grupos...
## Quatro grupos: número que mantém os agrupamentos interpretáveis com
## 35 municípios. A escolha é deliberadamente conservadora e está
## registrada aqui para que possa ser revista.
n_clusters <- 4
grupos_cluster <- cutree(agrupamento, k = n_clusters)

perfil_matriz <- perfil_matriz %>%
    mutate(cluster = paste0("Perfil ", grupos_cluster[municipio]))

######@> Caracterização dos agrupamentos...
caracterizacao <- perfil_matriz %>%
    group_by(cluster) %>%
    summarise(n_municipios = n(),
              municipios = paste(municipio, collapse = ", "),
              across(c(registros, registros_por_mil_km2,
                       pct_anos_com_registro, cv_anual,
                       starts_with("pct_")), mean),
              .groups = "drop")

tabelas$T18_clusters <- salvar_tab(
    perfil_matriz %>% select(geocodigo, municipio, cluster,
                             everything()),
    "Tab_18_perfis_municipios")
tabelas$T19_caracterizacao <- salvar_tab(
    caracterizacao, "Tab_19_caracterizacao_perfis")

######@> Figura 23 - dendrograma...
dend_dados <- as.dendrogram(agrupamento)
ordem_dend <- labels(dend_dados)

p_dend <- ggplot() +
    geom_segment(data = ggdendro_segmentos <- {
        h <- agrupamento
        ## Extração manual dos segmentos do dendrograma, evitando uma
        ## dependência adicional apenas para desenhar a árvore.
        merge_mat <- h$merge
        alturas <- h$height
        posicoes <- order(order(h$order))
        coord_x <- numeric(nrow(merge_mat))
        coord_y <- numeric(nrow(merge_mat))
        segs <- list()
        for(k in seq_len(nrow(merge_mat))) {
            filhos <- merge_mat[k, ]
            xs <- numeric(2); ys <- numeric(2)
            for(j in 1:2) {
                if(filhos[j] < 0) {
                    xs[j] <- posicoes[-filhos[j]]
                    ys[j] <- 0
                } else {
                    xs[j] <- coord_x[filhos[j]]
                    ys[j] <- coord_y[filhos[j]]
                }
            }
            coord_x[k] <- mean(xs)
            coord_y[k] <- alturas[k]
            segs[[k]] <- data.frame(
                x = c(xs[1], xs[1], xs[2]),
                y = c(ys[1], alturas[k], alturas[k]),
                xend = c(xs[1], xs[2], xs[2]),
                yend = c(alturas[k], alturas[k], ys[2]))
        }
        do.call(rbind, segs)
    }, aes(x = x, y = y, xend = xend, yend = yend),
    colour = "grey35", linewidth = 0.4) +
    scale_x_continuous(breaks = seq_along(ordem_dend),
                       labels = ordem_dend, expand = c(0.02, 0.02)) +
    labs(title = "Agrupamento dos municípios por perfil de desastre",
         subtitle = paste("Ligação de Ward sobre variáveis padronizadas",
                          "de volume, regularidade, composição e",
                          "sazonalidade"),
         x = NULL, y = "Distância",
         caption = quebrar(paste("Corte adotado:", n_clusters, "perfis.",
                                 "Ver Tab_19 para a caracterização de cada um."))) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5,
                                     size = 8))

salvar_fig(p_dend, "Fig_23_dendrograma_perfis", 12, 7)

######@> Mapa 06 - distribuição espacial dos perfis...
m8 <- municipios_sf %>%
    left_join(perfil_matriz %>% select(geocodigo, cluster),
              by = "geocodigo") %>%
    ggplot() +
    geom_sf(aes(fill = cluster), colour = "grey30", linewidth = 0.2) +
    scale_fill_brewer(palette = "Set2", na.value = "grey85",
                      name = "Perfil") +
    labs(title = "Distribuição espacial dos perfis de desastre",
         subtitle = paste("Agrupamento por volume, regularidade,",
                          "composição e sazonalidade"),
         caption = quebrar(paste("A coincidência (ou não) entre os perfis e a",
                                 "geografia indica se o padrão de desastres",
                                 "segue um gradiente espacial."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m8, "Mapa_06_perfis_municipais", 9, 8, diretorio = dir_mapa)

######@> Figura 24 - assinatura dos perfis...
## Mostra em que cada perfil se distingue, em unidades de desvio-padrão
## em relação à média do litoral.
assinatura <- as.data.frame(matriz_z) %>%
    mutate(municipio = rownames(matriz_z),
           cluster = perfil_matriz$cluster[
               match(municipio, perfil_matriz$municipio)]) %>%
    pivot_longer(-c(municipio, cluster), names_to = "variavel",
                 values_to = "z") %>%
    group_by(cluster, variavel) %>%
    summarise(z_medio = mean(z), .groups = "drop")

p_assinatura <- ggplot(assinatura,
                       aes(x = variavel, y = z_medio, fill = z_medio)) +
    geom_col() +
    geom_hline(yintercept = 0, colour = "grey30") +
    facet_wrap(~ cluster, ncol = 2) +
    scale_fill_gradient2(low = "#0072B2", mid = "grey90",
                         high = "#D55E00", midpoint = 0,
                         guide = "none") +
    coord_flip() +
    labs(title = "Assinatura de cada perfil municipal",
         subtitle = paste("Média padronizada (escala z) de cada variável",
                          "dentro do perfil"),
         x = NULL, y = "Desvios-padrão em relação à média do litoral")

salvar_fig(p_assinatura, "Fig_24_assinatura_perfis", 11, 8)

########################################################################
######@> Etapa 12 - Exportação consolidada e síntese...

######@> Arquivo XLSX com todas as tabelas...
## Nomes de aba limitados a 31 caracteres pela especificação do formato.
nomes_abas <- substr(names(tabelas), 1, 31)
names(tabelas) <- nomes_abas

write_xlsx(map(tabelas, as.data.frame),
           file.path(dir_tab, "AED_Atlas_todas_as_tabelas.xlsx"))

######@> Relatório de síntese em texto...
## Registra os números que sustentam as afirmações do capítulo, de modo
## que possam ser citados sem reabrir os objetos do R.
linhas_relatorio <- c(
    "########################################################################",
    "## ANÁLISE EXPLORATÓRIA - ATLAS DIGITAL DE DESASTRES",
    paste0("## Litoral de Santa Catarina | ", ano_min, "-", ano_max),
    paste0("## Gerado em ", format(Sys.time(), "%d/%m/%Y %H:%M")),
    "########################################################################",
    "",
    "1. COBERTURA DA BASE",
    paste0("   Municípios analisados      : ", n_municipios),
    paste0("   Municípios sem registro    : ",
           sum(!municipios_sf$tem_dados), " (excluídos das séries)"),
    paste0("   Registros de desastre      : ", total_eventos),
    paste0("   Período                    : ", ano_min, " a ", ano_max,
           " (", n_anos, " anos, ", n_anos * 12, " meses)"),
    "",
    "2. COMPOSIÇÃO POR GRUPO",
    paste0("   ", format(resumo_grupos$grupo_desastre, width = 16),
           format(resumo_grupos$registros, width = 5), " registros (",
           sprintf("%5.1f", resumo_grupos$pct_registros), "%)"),
    "",
    "3. ESTRUTURA TEMPORAL",
    paste0("   Tendência anual (Mann-Kendall) : tau = ",
           sprintf("%.3f", mk_litoral$tau), ", p = ",
           format.pval(mk_litoral$p_valor, digits = 3, eps = 0.001)),
    paste0("   Declividade de Sen             : ",
           sprintf("%+.2f", sen_litoral), " registros/ano"),
    paste0("   Força da tendência (STL)       : ",
           sprintf("%.3f", stl_tabela$forca_tendencia[1])),
    paste0("   Força da sazonalidade (STL)    : ",
           sprintf("%.3f", stl_tabela$forca_sazonal[1])),
    paste0("   Estacionariedade (série bruta) : ",
           diag_series$estacionaria[
               diag_series$serie == "Litoral - mensal (bruta)"]),
    paste0("   Estacionariedade (sem tend.)   : ",
           diag_series$estacionaria[
               diag_series$serie == "Litoral - mensal (sem tendência)"]),
    "",
    "4. SAZONALIDADE POR GRUPO (mês de pico e índice)",
    paste0("   ",
           format(as.character(
               sazonal_grupo$grupo_desastre[
                   !duplicated(sazonal_grupo$grupo_desastre)]),
               width = 16),
           map_chr(levels(sazonal_grupo$grupo_desastre), function(g) {
               s <- sazonal_grupo %>% filter(grupo_desastre == g)
               sprintf("pico em %s (índice %.2f), mínimo em %s (%.2f)",
                       s$mes_nome[which.max(s$indice_sazonal)],
                       max(s$indice_sazonal),
                       s$mes_nome[which.min(s$indice_sazonal)],
                       min(s$indice_sazonal))
           })),
    "",
    "5. DISPERSÃO E FAMÍLIA DE DISTRIBUIÇÃO",
    paste0("   ", format(as.character(dist_escalas$escala), width = 16),
           "var/média = ",
           sprintf("%6.2f", dist_escalas$razao_var_media),
           " | zeros obs/NB/Poisson = ",
           formatC(fmt_int(dist_escalas$zeros_observados), width = 7),
           " /", formatC(fmt_int(dist_escalas$zeros_esperados_nb),
                         width = 7),
           " /", formatC(fmt_int(dist_escalas$zeros_esperados_poisson),
                         width = 7),
           " | melhor: ", dist_escalas$melhor_modelo),
    "",
    "6. AUTOCORRELAÇÃO ESPACIAL",
    paste0("   Vizinhança : ", criterio_vizinhanca),
    if(componentes > 1)
        paste0("   NOTA: grafo de contiguidade desconexo (", componentes,
               " trechos) pela exclusão de Camboriú e Paulo Lopes;",
               " conferido com kNN.") else NULL,
    paste0("   ", format(moran_global$indicador, width = 30),
           format(moran_global$esquema_vizinhanca, width = 14),
           "I = ", sprintf("%6.3f", moran_global$moran_i),
           " | p = ", format.pval(moran_global$p_valor, digits = 2,
                                  eps = 0.001),
           " | ", moran_global$interpretacao),
    paste0("   Indicadores com conclusão robusta aos dois esquemas: ",
           n_distinct(moran_global$indicador[
               grepl("^Sim", moran_global$conclusao_robusta)]),
           " de ", n_distinct(moran_global$indicador)),
    "",
    "7. TENDÊNCIA POR MUNICÍPIO",
    paste0("   Com crescimento significativo : ",
           sum(tendencia_total$resultado == "Crescimento significativo"),
           " de ", nrow(tendencia_total)),
    paste0("   Sem tendência detectada       : ",
           sum(tendencia_total$resultado == "Sem tendência")),
    paste0("   Com redução significativa     : ",
           sum(tendencia_total$resultado == "Redução significativa")),
    "",
    "8. IMPLICAÇÕES PARA A MODELAGEM",
    "   (a) FAMÍLIA DE DISTRIBUIÇÃO",
    paste0("       A sobredispersão já existe na menor escala",
           " (var/média = ",
           sprintf("%.2f", dist_escalas$razao_var_media[1]),
           ") e CRESCE"),
    paste0("       de forma monotônica com o nível de agregação:"),
    paste0("         ",
           paste(sprintf("%s = %.1f", dist_escalas$escala,
                         dist_escalas$razao_var_media),
                 collapse = "  ->  "), "."),
    "       O crescimento monotônico indica que a variância extra não vem",
    "       apenas da heterogeneidade entre municípios: vem do agrupamento",
    "       de registros no espaço e no tempo (um fenômeno regional gera",
    "       registro simultâneo em vários municípios). Poisson é inadequada",
    "       em todas as escalas.",
    paste0("       A binomial negativa reproduz os zeros observados com",
           " precisão"),
    paste0("       (escala ", dist_escalas$escala[3], ": ",
           fmt_int(dist_escalas$zeros_observados[3]),
           " zeros observados, ",
           fmt_int(dist_escalas$zeros_esperados_nb[3]),
           " previstos pela NB contra ",
           fmt_int(dist_escalas$zeros_esperados_poisson[3]),
           " pela Poisson)."),
    paste0("       Inflação de zeros NÃO é necessária: ",
           ifelse(zi_melhora,
                  "os modelos ZI melhoram o AIC em alguma escala.",
                  paste("em nenhuma escala o AIC dos modelos ZI supera",
                        "o da NB;")),
           ""),
    "       o excesso de zeros já é explicado pela própria sobredispersão.",
    "",
    "   (b) ESTRUTURA TEMPORAL",
    "       A ACF da série bruta reflete sobretudo TENDÊNCIA: o teste KPSS",
    "       rejeita estacionariedade em nível, mas a série sem tendência",
    "       passa no mesmo teste. Modelos de série temporal devem incluir",
    "       termo de tendência ou operar sobre a série já destendenciada.",
    paste0("       Força da tendência (STL) = ",
           sprintf("%.3f", stl_tabela$forca_tendencia[1]),
           " contra sazonalidade = ",
           sprintf("%.3f", stl_tabela$forca_sazonal[1]), "."),
    "",
    "   (c) POR QUE NÃO MODELAR O TOTAL AGREGADO",
    "       A sazonalidade do total é fraca por CANCELAMENTO, e não por",
    "       ausência de sinal: os grupos hidrológico e meteorológico têm",
    "       fases opostas (picos em janeiro e julho, respectivamente).",
    paste0("       As séries mensais dos grupos são fracamente",
           " correlacionadas entre si"),
    paste0("       (|rho| máximo = ",
           sprintf("%.2f", max(abs(cor_grupos[upper.tri(cor_grupos)]))),
           "), o que favorece modelos separados por grupo."),
    "",
    "   (d) DEPENDÊNCIA ESPACIAL",
    paste0("       Significativa nos DOIS esquemas de vizinhança em ",
           n_distinct(moran_global$indicador[
               grepl("^Sim", moran_global$conclusao_robusta) &
               moran_global$p_valor < alfa]),
           " de ", n_distinct(moran_global$indicador), " indicadores;"),
    paste0("       dependente do esquema em ",
           n_distinct(moran_global$indicador[
               grepl("^Não", moran_global$conclusao_robusta)]),
           " (ver Tab_15 - a exclusão de dois municípios parte a"),
    "       cadeia costeira em dois trechos e enfraquece o teste por",
    "       contiguidade). O sinal mais firme é o da DENSIDADE de",
    "       registros, significativo sob os dois critérios.",
    "       Observações municipais não devem ser tratadas como",
    "       independentes sem verificação: erros-padrão seriam subestimados.",
    "",
    "   (e) RESSALVA QUE ATRAVESSA TUDO",
    "       O crescimento do número de registros confunde ocorrência e",
    "       esforço administrativo de reporte, e esta base não permite",
    "       separar os dois. Variáveis de INTENSIDADE por registro (mortos,",
    "       afetados ou prejuízo por evento) são menos sensíveis a esse",
    "       artefato do que a contagem de registros.",
    "",
    "########################################################################")

writeLines(linhas_relatorio,
           file.path(dir_res, "AED_Atlas_relatorio_sintese.txt"))

######@> Resumo final do processamento...
n_figs <- length(list.files(dir_fig, pattern = "\\.png$"))
n_figs_mun <- length(list.files(dir_fig_mun, pattern = "\\.png$"))
n_mapas <- length(list.files(dir_mapa, pattern = "\\.png$"))
n_tabs <- length(list.files(dir_tab, pattern = "\\.csv$"))

message("\n=== AED concluída ===")
message("Figuras gerais         : ", n_figs)
message("Painéis por município  : ", n_figs_mun)
message("Mapas                  : ", n_mapas)
message("Tabelas (CSV)          : ", n_tabs, " + 1 XLSX consolidado")
message("Relatório de síntese   : AED_Atlas_relatorio_sintese.txt")
message("Saídas em              : ", normalizePath(dir_res))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
