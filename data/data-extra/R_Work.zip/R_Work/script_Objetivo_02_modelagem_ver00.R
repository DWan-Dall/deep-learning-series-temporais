########################################################################
## Description: Modelagem dos eventos hidrológicos de Enxurradas,
##              Inundações e Alagamentos nos municípios costeiros de
##              Santa Catarina em função de descritores climáticos
##              (ERA5) e de uso e cobertura da terra (MapBiomas), por
##              abordagens estatísticas, de aprendizado de máquina e de
##              aprendizado profundo...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: sex ago 21 09:40:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: Base consolidada pelo
##                script_Consolidacao_bases_ver00.R:
##                  - base_anual  : município x ano (3.219 x 234)
##                  - base_mensal : município x ano x mês (38.443 x 216)
##                  - dicionario_anual, dicionario_variaveis
##                  - municipios, diagnostico_cobertura
##                Complementada pelo shapefile de municípios.
##
### Commentary:
##
## Este é o primeiro script INFERENCIAL do capítulo. As quatro análises
## exploratórias que o antecedem estabeleceram o que os dados permitem
## perguntar; este responde a uma pergunta específica:
##
##      QUAIS CARACTERÍSTICAS AMBIENTAIS E DE USO DA TERRA ESTÃO
##      ASSOCIADAS À OCORRÊNCIA DE ENXURRADAS, INUNDAÇÕES E
##      ALAGAMENTOS NOS MUNICÍPIOS COSTEIROS DE SANTA CATARINA?
##
## ------------------------------------------------------------------
## A UNIDADE DE ANÁLISE É O MUNICÍPIO-ANO, E NÃO POR ESCOLHA
## ------------------------------------------------------------------
##
## A tipologia do Atlas Digital - que separa Enxurradas, Inundações e
## Alagamentos das demais categorias - só existe na base ANUAL. A base
## mensal traz o agregado por GRUPO (hidrológico, meteorológico,
## climatológico), e o grupo hidrológico contém, além dos três tipos de
## interesse, movimentos de massa e erosão, que respondem a outros
## processos. Somar os três tipos exige, portanto, a escala anual.
##
## Isso tem uma consequência que atravessa o script: a base mensal não é
## descartada, é usada para CONSTRUIR DESCRITORES. Um total anual de
## chuva de 1.700 mm não distingue o ano que a distribuiu uniformemente
## daquele que concentrou 700 mm em um trimestre - e é o segundo que
## produz enxurrada. Os descritores de intensidade, de frequência de
## extremos e de concentração sazonal são calculados mês a mês e depois
## resumidos ao ano (Etapa 02).
##
## ------------------------------------------------------------------
## O DESENHO: SEPARAR O GATILHO DA PREDISPOSIÇÃO
## ------------------------------------------------------------------
##
## Existem duas perguntas dentro da pergunta, e confundi-las é o erro
## mais fácil de cometer aqui:
##
##   (a) POR QUE ALGUNS ANOS têm mais eventos que outros, DENTRO de um
##       mesmo município? Esta é a pergunta do GATILHO. O território é
##       aproximadamente constante ao longo de 34 anos; o que varia é o
##       clima do ano - e, mais lentamente, a cobertura da terra;
##
##   (b) POR QUE ALGUNS MUNICÍPIOS têm mais eventos que outros? Esta é
##       a pergunta da PREDISPOSIÇÃO. Aqui o clima entra como
##       CLIMATOLOGIA (o município é sistematicamente mais chuvoso) e o
##       território entra como característica estrutural.
##
## Uma regressão comum sobre município-ano MISTURA as duas, e o
## coeficiente resultante é uma média ponderada de dois efeitos que
## podem ter sinais diferentes. A AED integrada já havia mostrado um
## caso desses: a correlação bruta entre cobertura florestal e número de
## eventos é POSITIVA (0,53) entre municípios, porque o litoral norte
## tem simultaneamente mais floresta e mais registros - enquanto o efeito
## esperado da floresta sobre o escoamento é de atenuação.
##
## A solução adotada é a decomposição DENTRO/ENTRE (também chamada de
## especificação de Mundlak, ou modelo híbrido): cada preditor entra
## duas vezes, como média municipal (componente ENTRE, sufixo _B) e como
## desvio do ano em relação a essa média (componente DENTRO, sufixo _W).
## Os dois coeficientes são estimados no mesmo modelo e respondem,
## separadamente, às perguntas (a) e (b). Como consequência técnica, a
## especificação também elimina o viés de variável omitida de nível
## municipal - que é exatamente o que produzia a correlação espúria com
## a floresta.
##
## ------------------------------------------------------------------
## AS TRÊS FAMÍLIAS DE MODELO E O QUE CADA UMA RESPONDE
## ------------------------------------------------------------------
##
## As três abordagens pedidas não são três tentativas de fazer a mesma
## coisa: são três instrumentos com propósitos distintos, e a comparação
## entre elas é, ela própria, um resultado.
##
##   ESTATÍSTICA (GLM, GLMM, GAM, elastic net) - responde COM QUANTO e
##   COM QUE INCERTEZA. Entrega coeficientes com erro-padrão, razões de
##   taxa interpretáveis e testes de hipótese. É a única família que
##   sustenta afirmações do tipo "um trimestre 1 desvio-padrão mais
##   chuvoso multiplica a taxa esperada por 1,39". É também a única com
##   diagnóstico formal de adequação (DHARMa, dispersão, Moran nos
##   resíduos);
##
##   APRENDIZADO DE MÁQUINA (random forest, gradient boosting) -
##   responde SE HÁ ESTRUTURA QUE O MODELO PARAMÉTRICO NÃO CAPTUROU.
##   Não impõe forma funcional nem aditividade, e por isso funciona
##   como TESTE DA ESPECIFICAÇÃO: se o boosting supera folgadamente o
##   GLMM na validação cruzada, há não-linearidade ou interação
##   relevante que o modelo paramétrico está perdendo; se não supera, a
##   especificação linear é adequada e os coeficientes podem ser lidos
##   com confiança;
##
##   APRENDIZADO PROFUNDO (rede neural com perda de Poisson e camada de
##   embedding municipal) - acrescenta duas coisas específicas. A
##   primeira é o EMBEDDING: em vez de tratar o município como 34
##   variáveis indicadoras independentes, a rede aprende uma
##   representação de poucas dimensões em que municípios com regimes
##   semelhantes ficam próximos - o análogo aprendido do efeito
##   aleatório, com a vantagem de ser INSPECIONÁVEL (Etapa 18). A
##   segunda é a capacidade de representar interações de ordem alta sem
##   que precisem ser especificadas. Contra ela pesa o tamanho da
##   amostra: 1.190 observações e 414 eventos são pouco para uma rede,
##   e o script trata isso explicitamente com regularização forte,
##   parada antecipada e a mesma validação cruzada em blocos das demais
##   famílias.
##
## ------------------------------------------------------------------
## SEIS DECISÕES METODOLÓGICAS QUE ATRAVESSAM O SCRIPT
## ------------------------------------------------------------------
##
##   (1) A JANELA É 1991-2024. O Atlas começa em 1991 e o MapBiomas
##       termina em 2024. Fora dessa interseção não há como colocar
##       resposta, clima e uso da terra na mesma linha. São 35
##       municípios x 34 anos = 1.190 observações, com 414 eventos e
##       73,6% de zeros. O ERA5 anterior a 1991 NÃO é descartado: é ele
##       que fornece a climatologia de referência contra a qual as
##       anomalias e os percentis são calculados;
##
##   (2) A FAMÍLIA É POISSON COM EFEITO DE MUNICÍPIO, E ISSO É TESTADO,
##       NÃO ASSUMIDO. A Etapa 07 ajusta a sequência completa - Poisson,
##       quase-Poisson, binomial negativo (nbinom1 e nbinom2), inflado
##       de zeros - e compara por AIC e por dispersão de Pearson. O
##       resultado replica o da AED: a sobredispersão aparente é
##       heterogeneidade entre municípios, e some quando o termo
##       municipal entra. Não há excesso de zeros a modelar;
##
##   (3) O TAMANHO DO MUNICÍPIO ENTRA COMO OFFSET, NÃO COMO PREDITOR. A
##       AED mostrou que a área é o único descritor territorial cuja
##       associação com o número de registros sobrevive ao controle da
##       latitude (correlação parcial 0,40). Um município dez vezes
##       maior tem mais assentamentos, mais bacias e mais chance de que
##       ALGUM ponto seja atingido. Modelar log(área) como offset
##       significa modelar DENSIDADE de eventos por unidade de área, e
##       não contagem bruta - que é a quantidade comparável entre
##       municípios;
##
##   (4) O VIÉS DE REGISTRO É CONTROLADO, NÃO IGNORADO. O achado mais
##       consequente da AED integrada é que a série de desastres mede,
##       em parte, a evolução do sistema de registro: a contagem anual
##       do litoral cresce com correlação de +0,82 com o ano, enquanto a
##       frequência de meses de chuva extrema não cresce (+0,02). O ano
##       entra em TODOS os modelos como covariável de controle, e a
##       Etapa 19 refaz a análise restrita a 2012-2024 - o período
##       posterior à consolidação do S2iD - para verificar se as
##       conclusões dependem do trecho anterior;
##
##   (5) A REDUNDÂNCIA ENTRE PREDITORES É PODADA POR REGRA EXPLÍCITA, E
##       NÃO POR JULGAMENTO. Os descritores climáticos do ERA5 são
##       fortemente correlacionados entre si e as frações de cobertura
##       do MapBiomas são COMPOSICIONAIS - somam 100% e portanto são
##       linearmente dependentes por construção. A Etapa 04 aplica, em
##       sequência, um filtro de correlação (|rho| > 0,80, preservando o
##       membro do par mais associado à resposta) e uma poda iterativa
##       por VIF, ambos documentados e reprodutíveis;
##
##   (6) A VALIDAÇÃO É EM BLOCOS, E EM DOIS ESQUEMAS. Validação cruzada
##       aleatória sobre dados espaço-temporais é otimista: vizinhos no
##       espaço e no tempo vazam informação entre treino e teste. Os dois
##       esquemas usados aqui respondem a perguntas diferentes - BLOCOS
##       DE ANOS ("o modelo prevê um ano que não viu?") e BLOCOS DE
##       MUNICÍPIOS ("o modelo prevê um município que não viu?"). O
##       segundo é o teste severo, porque exige que o modelo generalize
##       a partir das características do território. As seis abordagens
##       passam pelos mesmos blocos e são medidas pelas mesmas
##       estatísticas.
##
## Duas ressalvas permanecem em pé do começo ao fim, e nenhum modelo as
## resolve. A primeira: o Atlas é registro ADMINISTRATIVO, e a ausência
## de registro não é ausência de evento. A segunda: nenhuma associação
## estimada aqui é causal - o desenho é observacional, e a decomposição
## dentro/entre reduz, mas não elimina, a confusão por variáveis
## omitidas. Nenhuma imputação é feita em ponto algum; onde falta dado,
## falta, e o número de observações efetivamente usado é reportado em
## cada modelo.
##
## Fluxo geral da análise:
##
##   01) Leitura da base consolidada e do shapefile;
##   02) Construção dos descritores anuais a partir da base mensal;
##   03) A variável resposta: composição, zeros e sobredispersão;
##   04) Preditores candidatos: blocos, redundância e colinearidade;
##   05) Decomposição dentro/entre e montagem das matrizes de modelo;
##   06) Protocolo de validação cruzada em blocos;
##   07) Estatística I: qual família de contagem a base exige;
##   08) Estatística II: o modelo dentro/entre e seus coeficientes;
##   09) Estatística III: GAM, não-linearidade e superfície espacial;
##   10) Estatística IV: regularização e seleção por elastic net;
##   11) Diagnóstico dos modelos estatísticos;
##   12) Aprendizado de máquina I: random forest;
##   13) Aprendizado de máquina II: gradient boosting;
##   14) Aprendizado profundo: rede neural com embedding municipal;
##   15) Comparação preditiva entre as três famílias;
##   16) Importância consolidada dos preditores;
##   17) Formas funcionais: efeitos parciais, PDP e SHAP;
##   18) O embedding municipal e a tipologia aprendida;
##   19) Análises de sensibilidade;
##   20) Mapas;
##   21) Exportação consolidada e relatório de síntese.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Dados vetoriais e mapas
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem e grades
library(purrr)          ## Programação funcional
library(stringi)        ## Transliteração de acentos
library(zoo)            ## Janelas móveis (acumulados trimestrais)
library(ggplot2)        ## Gráficos
library(patchwork)      ## Composição de painéis
library(scales)         ## Escalas e formatação de eixos
library(ggrepel)        ## Rótulos que não se sobrepõem
library(MASS)           ## glm.nb e utilitários
library(car)            ## Fatores de inflação de variância (VIF)
library(glmmTMB)        ## GLMM de contagem (Poisson, NB, inflado)
library(mgcv)           ## Modelos aditivos generalizados
library(DHARMa)         ## Diagnóstico por resíduos simulados
library(glmnet)         ## Regularização L1/L2 (elastic net)
library(ranger)         ## Random forest com divisão de Poisson
library(xgboost)        ## Gradient boosting e valores de Shapley
library(torch)          ## Redes neurais (aprendizado profundo)
library(spdep)          ## Autocorrelação espacial (Moran)
library(cluster)        ## Silhueta e agrupamento
library(writexl)        ## Exportação consolidada em XLSX

######@> Resolução de conflitos de nomes...
## MASS::select mascara dplyr::select e car::recode mascara
## dplyr::recode - esta última com assinatura incompatível, de modo que
## a chamada não devolve resultado errado em silêncio, e sim falha com
## mensagem obscura sobre argumentos não utilizados. A fixação explícita
## é a mesma dos demais scripts do projeto, aqui com dois nomes a mais.
select <- dplyr::select
filter <- dplyr::filter
recode <- dplyr::recode

######@> Opções globais...
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente...
## Fixada porque praticamente todas as etapas a partir da 06 envolvem
## sorteio: partição dos blocos de validação, reamostragem das florestas
## aleatórias, subamostragem do boosting, inicialização e dropout da
## rede neural e permutações do teste de importância.
set.seed(42)
torch_manual_seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
dir_dados <- "../Dados"
dir_cons <- file.path(dir_dados, "Outputs", "Consolidado")
dir_shape <- file.path(dir_dados, "Shapefiles")

arq_base <- file.path(dir_cons, "RData", "Consolidado_SC.RData")
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Diretórios de saída...
## A modelagem gera quatro famílias de produto. As tabelas são o insumo
## direto do texto; as figuras cobrem diagnóstico, efeitos e comparação;
## os mapas trazem o recorte espacial dos ajustes; e os modelos ajustados
## são gravados em RData para que as etapas seguintes do capítulo possam
## reaproveitá-los sem reajustar.
dir_res <- "../Results/Objetivo_02"
dir_tab <- file.path(dir_res, "Tabelas")
dir_fig <- file.path(dir_res, "Figuras")
dir_mapa <- file.path(dir_res, "Mapas")
dir_mod <- file.path(dir_res, "Modelos")

for(d in c(dir_res, dir_tab, dir_fig, dir_mapa, dir_mod)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> CRS de referência...
crs_projeto <- 4326      ## WGS84, mesmo das demais bases
crs_area <- 5880         ## SIRGAS 2000 / Brazil Polyconic

######@> Janela de análise...
## ano_ini/ano_fim   : interseção Atlas x MapBiomas, único trecho em que
##                     resposta, clima e uso da terra coexistem;
## ref_ini/ref_fim   : normal climatológica de referência (padrão OMM),
##                     base dos percentis e anomalias locais;
## clim_ini          : início da série ERA5 usada para a climatologia;
## ano_corte_s2id    : marco da consolidação do sistema de registro,
##                     usado no controle de viés e na sensibilidade.
ano_ini <- 1991
ano_fim <- 2024
ref_ini <- 1991
ref_fim <- 2020
clim_ini <- 1961
ano_corte_s2id <- 2012

######@> Parâmetros da seleção de preditores...
## cor_max   : limite do filtro de redundância entre preditores. 0,80 é
##             o valor usado na AED integrada e mantido aqui;
## vif_max   : limite da poda iterativa por colinearidade. 5 é o critério
##             conservador usual para modelos interpretativos;
## defasagem_uso : janela, em anos, da variação da cobertura da terra. A
##             cobertura muda devagar: cinco anos é o horizonte em que a
##             mudança é mensurável e ainda atribuível ao período.
cor_max <- 0.80
vif_max <- 5
defasagem_uso <- 5

######@> Parâmetros da validação cruzada...
## n_blocos  : cinco blocos em cada esquema. Com 34 anos e 35
##             municípios, cinco blocos deixam ~7 unidades por bloco de
##             teste - suficiente para estimar o desempenho sem reduzir
##             demais o conjunto de treino;
## n_perm    : permutações do teste de importância por embaralhamento.
n_blocos <- 5
n_perm <- 30

######@> Parâmetros dos modelos de aprendizado...
## Os hiperparâmetros do boosting e da rede são deliberadamente
## conservadores. Com 1.190 observações e 414 eventos, o risco dominante
## é o sobreajuste, não a falta de capacidade: árvores rasas, taxa de
## aprendizado baixa, decaimento de peso alto e parada antecipada.
rf_arvores <- 1000
rf_no_min <- 10
xgb_profundidade <- 3
xgb_taxa <- 0.05
xgb_rodadas_max <- 800
dl_dim_emb <- 3
dl_neuronios <- 24
dl_dropout <- 0.30
dl_decaimento <- 1e-2
dl_taxa <- 0.005
dl_epocas_max <- 3000
dl_paciencia <- 400

######@> Nível de significância...
alfa <- 0.05

######@> Paleta das famílias de modelo...
## Okabe-Ito, segura para daltonismo. A mesma cor identifica a família
## em todas as figuras de comparação e de importância.
cores_familia <- c("Estatística"            = "#0072B2",
                   "Aprendizado de máquina" = "#D55E00",
                   "Aprendizado profundo"   = "#009E73",
                   "Referência"             = "#999999")

ordem_familias <- names(cores_familia)

######@> Paleta dos blocos de preditor...
cores_bloco <- c("Clima (gatilho)"        = "#0072B2",
                 "Clima (climatologia)"   = "#56B4E9",
                 "Uso e cobertura"        = "#009E73",
                 "Território e exposição" = "#E69F00",
                 "Registro"               = "#999999")

######@> Paleta dos componentes dentro/entre...
cores_comp <- c("Dentro do município (gatilho)" = "#0072B2",
                "Entre municípios (predisposição)" = "#E69F00")

######@> Nomes dos meses (rótulos dos eixos)...
meses_abrev <- c("Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
                 "Jul", "Ago", "Set", "Out", "Nov", "Dez")

########################################################################
######@> Funções auxiliares...

######@> Tema gráfico do documento...
## Centralizado para que as dezenas de figuras produzidas possam ser
## usadas lado a lado no texto da dissertação. É o mesmo tema das
## análises exploratórias do capítulo.
tema_mod <- function(base = 11) {
    theme_bw(base_size = base) +
        theme(panel.grid.minor = element_blank(),
              panel.grid.major = element_line(linewidth = 0.25,
                                              colour = "grey88"),
              strip.background = element_rect(fill = "grey92",
                                              colour = "grey70"),
              strip.text = element_text(face = "bold", size = base - 1),
              plot.title = element_text(face = "bold", size = base + 2),
              plot.subtitle = element_text(colour = "grey30",
                                           size = base - 1),
              plot.caption = element_text(colour = "grey45",
                                          size = base - 3, hjust = 0),
              legend.position = "bottom",
              legend.title = element_text(face = "bold", size = base - 1))
}

theme_set(tema_mod())

######@> Quebra de linha em legendas longas...
## O ggplot NÃO quebra automaticamente o texto de caption: legendas
## longas são cortadas na borda direita da figura.
quebrar <- function(texto, largura = 105) {
    paste(strwrap(paste(texto, collapse = " "), width = largura),
          collapse = "\n")
}

quebrar_mapa <- function(texto) {
    quebrar(texto, largura = 78)
}

quebrar_rotulo <- function(x, largura = 16) {
    vapply(as.character(x), function(z)
        paste(strwrap(z, width = largura), collapse = "\n"),
        character(1), USE.NAMES = FALSE)
}

######@> Gravação de figuras...
salvar_fig <- function(plot, arquivo, largura = 10, altura = 6,
                       diretorio = dir_fig) {
    ggsave(filename = file.path(diretorio, paste0(arquivo, ".png")),
           plot = plot, width = largura, height = altura, dpi = 300,
           bg = "white")
    invisible(NULL)
}

######@> Gravação de tabelas...
## CSV com separador ";" e decimal "," (padrão brasileiro), devolvendo a
## tabela para que também seja acumulada no XLSX consolidado.
salvar_tab <- function(dados, arquivo) {
    write.table(dados, file.path(dir_tab, paste0(arquivo, ".csv")),
                sep = ";", dec = ",", row.names = FALSE,
                fileEncoding = "UTF-8")
    invisible(dados)
}

######@> Formatação de inteiros com separador de milhar...
fmt_int <- function(x) {
    formatC(x, format = "f", digits = 0, big.mark = ".",
            decimal.mark = ",")
}

######@> Transliteração de nomes em nomes seguros de arquivo...
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Estatísticas tolerantes a séries inteiramente ausentes...
## As séries mensais têm lacunas em municípios e anos específicos, e
## max()/min() sobre vetores só de NA devolvem -Inf com aviso, que se
## propaga silenciosamente até as tabelas finais.
max_seguro <- function(x) {
    if(all(is.na(x))) return(NA_real_)
    max(x, na.rm = TRUE)
}

soma_segura <- function(x) {
    if(all(is.na(x))) return(NA_real_)
    sum(x, na.rm = TRUE)
}

media_segura <- function(x) {
    if(all(is.na(x))) return(NA_real_)
    mean(x, na.rm = TRUE)
}

######@> Padronização com centro e escala explícitos...
## A padronização precisa ser feita com os parâmetros do conjunto de
## TREINO e aplicada ao de teste. Fazer scale() separadamente em cada
## partição vazaria informação do teste para o treino - erro sutil e
## comum em validação cruzada.
padroniza <- function(x, centro = NULL, escala = NULL) {
    if(is.null(centro)) centro <- colMeans(x, na.rm = TRUE)
    if(is.null(escala)) {
        escala <- apply(x, 2, sd, na.rm = TRUE)
        escala[escala == 0 | is.na(escala)] <- 1
    }
    z <- scale(x, center = centro, scale = escala)
    list(x = matrix(as.numeric(z), nrow = nrow(x),
                    dimnames = dimnames(x)),
         centro = centro, escala = escala)
}

######@> Deviance de Poisson...
## Métrica primária de comparação entre as três famílias. É a medida
## natural de ajuste para contagens: penaliza tanto a previsão alta em
## observação zero quanto a previsão baixa em observação alta, o que o
## erro quadrático faz mal quando a maioria das observações é zero.
deviance_pois <- function(y, mu) {
    mu <- pmax(mu, 1e-10)
    2 * sum(ifelse(y > 0, y * log(y / mu), 0) - (y - mu))
}

######@> Pseudo-R2 de deviance...
## Fração da deviance do modelo nulo (taxa constante) explicada pelo
## modelo. Zero significa desempenho igual ao da média; negativo
## significa PIOR que a média, o que é possível fora da amostra e é
## informação relevante, não erro.
pseudo_r2 <- function(y, mu) {
    1 - deviance_pois(y, mu) / deviance_pois(y, rep(mean(y), length(y)))
}

######@> Área sob a curva ROC pela estatística de Mann-Whitney...
## Mede a capacidade de ORDENAR: dado um par formado por um
## município-ano com evento e outro sem, com que probabilidade o modelo
## atribui taxa maior ao primeiro? Como a resposta tem 73,6% de zeros, a
## discriminação entre "houve" e "não houve" é tão informativa quanto a
## previsão da contagem, e é comparável entre modelos de qualquer
## família.
auc_mw <- function(pred, y) {
    ocorreu <- y > 0
    n1 <- sum(ocorreu)
    n0 <- sum(!ocorreu)
    if(n1 == 0 || n0 == 0) return(NA_real_)
    r <- rank(pred)
    (sum(r[ocorreu]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

######@> Conjunto padrão de métricas de desempenho...
## Todas as comparações do script passam por aqui, o que garante que
## nenhuma família seja avaliada por critério próprio.
metricas <- function(nome, familia, esquema, y, pred) {
    ok <- is.finite(pred) & is.finite(y)
    y <- y[ok]
    pred <- pmax(pred[ok], 1e-10)
    tibble(modelo = nome, familia = familia, esquema = esquema,
           n = length(y),
           deviance = deviance_pois(y, pred),
           pseudo_r2 = pseudo_r2(y, pred),
           rmse = sqrt(mean((y - pred)^2)),
           mae = mean(abs(y - pred)),
           spearman = suppressWarnings(cor(pred, y, method = "spearman")),
           auc = auc_mw(pred, y),
           soma_obs = sum(y),
           soma_prev = sum(pred),
           vies_pct = 100 * (sum(pred) - sum(y)) / sum(y))
}

######@> Força de associação de um preditor com a resposta...
## Os dois filtros de poda precisam decidir, entre variáveis
## intercambiáveis, qual conservar. O critério é a associação com a
## resposta - mas medida NAS DUAS ESCALAS do desenho, e tomando a maior
## delas. A razão é direta: o modelo separa o efeito entre municípios do
## efeito dentro do município, e uma variável fortemente associada em
## APENAS UMA das duas escalas é plenamente útil ao modelo. Julgá-la
## pela correlação bruta - que mistura as duas e pode aproximar-se de
## zero quando os sinais se opõem - descartaria justamente os preditores
## que motivaram a decomposição.
forca_associacao <- function(dados, vars, resposta) {
    med <- dados %>%
        group_by(geocodigo) %>%
        summarise(across(all_of(c(vars, resposta)), ~ mean(.x, na.rm = TRUE)),
                  .groups = "drop")
    des <- dados %>%
        group_by(geocodigo) %>%
        mutate(across(all_of(c(vars, resposta)),
                      ~ .x - mean(.x, na.rm = TRUE))) %>%
        ungroup()
    vapply(vars, function(v) {
        re <- suppressWarnings(cor(med[[v]], med[[resposta]],
                                   method = "spearman",
                                   use = "complete.obs"))
        rd <- suppressWarnings(cor(des[[v]], des[[resposta]],
                                   method = "spearman",
                                   use = "complete.obs"))
        max(abs(c(re, rd))[is.finite(c(re, rd))], 0)
    }, numeric(1))
}

######@> Filtro de redundância entre preditores...
## Percorre os pares com |rho| acima do limite e, em cada um, DESCARTA o
## membro menos associado à resposta. A ordem importa: os pares são
## examinados do mais correlacionado ao menos, para que a decisão de
## maior impacto seja tomada primeiro. A alternativa - escolher "a
## variável mais interpretável" - produziria um conjunto que depende de
## quem escreve o script, e não do que os dados mostram.
poda_redundancia <- function(dados, vars, resposta, limite = cor_max) {
    m <- suppressWarnings(cor(dados[, vars], use = "pairwise.complete.obs",
                              method = "spearman"))
    m[!is.finite(m)] <- 0
    forca <- forca_associacao(dados, vars, resposta)
    forca[!is.finite(forca)] <- 0
    mantidas <- vars
    descartes <- tibble(descartada = character(), mantida = character(),
                        rho = numeric())
    repeat {
        mm <- m[mantidas, mantidas, drop = FALSE]
        diag(mm) <- 0
        if(max(abs(mm)) < limite) break
        idx <- which(abs(mm) == max(abs(mm)), arr.ind = TRUE)[1, ]
        a <- mantidas[idx[1]]
        b <- mantidas[idx[2]]
        fora <- if(forca[a] >= forca[b]) b else a
        dentro <- if(fora == a) b else a
        descartes <- bind_rows(descartes,
                               tibble(descartada = fora, mantida = dentro,
                                      rho = mm[idx[1], idx[2]]))
        mantidas <- setdiff(mantidas, fora)
        if(length(mantidas) < 2) break
    }
    list(mantidas = mantidas, descartes = descartes)
}

######@> Poda iterativa por VIF...
## Necessária depois do filtro de correlação, e não no lugar dele: as
## frações de cobertura da terra somam 100% por construção, o que é uma
## dependência LINEAR MULTIVARIADA que não aparece em nenhuma
## correlação par a par.
##
## O critério de descarte merece justificativa, porque a escolha óbvia é
## a errada. Remover a cada passo a variável de MAIOR VIF - que é o
## procedimento usual - tem, sobre dados composicionais, um efeito
## perverso e sistemático: quem tem o maior VIF é justamente a MAIOR
## fração da composição, porque é ela que as demais somadas melhor
## reproduzem. Aplicado a esta base, esse critério eliminava a cobertura
## florestal (VIF 152) e a precipitação anual (VIF 26) e conservava
## mangue, restinga e pastagem - as três frações marginais, com
## associação com a resposta próxima de zero. O modelo resultante era
## tecnicamente correto e substantivamente vazio.
##
## O critério adotado inverte a escolha DENTRO do conjunto problemático,
## e a definição desse conjunto é a parte que importa. A cada passo:
##
##   (i) identifica-se a variável de maior VIF - a que está no centro da
##       colinearidade;
##  (ii) monta-se o GRUPO REDUNDANTE: ela e todas as variáveis com as
##       quais se correlaciona acima de cor_grupo;
## (iii) descarta-se o membro MENOS associado à resposta do grupo.
##
## O passo (ii) é indispensável, e sua ausência foi o segundo erro da
## versão anterior. Colinearidade é uma propriedade de PARES ou GRUPOS,
## nunca de uma variável isolada; restringir os candidatos ao descarte
## àquelas que individualmente excedem o limite faz com que, num par
## colinear em que apenas um dos membros ultrapassa o limite, seja
## sempre esse membro o removido - ainda que seja o informativo. Foi o
## que ocorreu com cobertura florestal e área agropecuária: as duas são
## as frações dominantes do território e explicam-se mutuamente, mas a
## floresta, por ser a maior, carregava o VIF mais alto e era eliminada,
## conservando-se a agropecuária, cuja associação com a resposta é três
## vezes menor. Com o grupo redundante definido corretamente, as duas
## competem entre si e sobrevive a informativa.
poda_vif <- function(dados, vars, resposta, offset_var = NULL,
                     limite = vif_max, cor_grupo = 0.5) {
    mantidas <- vars
    forca <- forca_associacao(dados, vars, resposta)
    correl <- suppressWarnings(cor(dados[, vars], method = "spearman",
                                   use = "pairwise.complete.obs"))
    correl[!is.finite(correl)] <- 0
    descartes <- tibble(descartada = character(), vif = numeric(),
                        forca = numeric(), grupo = character())
    repeat {
        if(length(mantidas) < 2) break
        f <- paste(resposta, "~", paste(mantidas, collapse = " + "))
        if(!is.null(offset_var)) f <- paste(f, "+ offset(", offset_var, ")")
        m <- try(glm(as.formula(f), family = poisson, data = dados),
                 silent = TRUE)
        if(inherits(m, "try-error")) break
        v <- try(car::vif(m), silent = TRUE)
        if(inherits(v, "try-error")) break
        if(is.matrix(v)) v <- v[, 1]
        if(max(v) <= limite) break
        centro <- names(v)[which.max(v)]
        grupo <- mantidas[abs(correl[centro, mantidas]) >= cor_grupo]
        grupo <- union(grupo, centro)
        fora <- grupo[which.min(forca[grupo])]
        descartes <- bind_rows(descartes,
                               tibble(descartada = fora,
                                      vif = as.numeric(v[fora]),
                                      forca = as.numeric(forca[fora]),
                                      grupo = paste(setdiff(grupo, fora),
                                                    collapse = ", ")))
        mantidas <- setdiff(mantidas, fora)
    }
    list(mantidas = mantidas, descartes = descartes)
}

######@> Fatores de inflação de variância de um conjunto...
vif_conjunto <- function(dados, vars, resposta, offset_var = NULL) {
    f <- paste(resposta, "~", paste(vars, collapse = " + "))
    if(!is.null(offset_var)) f <- paste(f, "+ offset(", offset_var, ")")
    m <- glm(as.formula(f), family = poisson, data = dados)
    v <- car::vif(m)
    if(is.matrix(v)) v <- v[, 1]
    tibble(variavel = names(v), vif = as.numeric(v)) %>%
        arrange(desc(vif))
}

######@> Importância por permutação, comum a todas as famílias...
## Embaralha uma coluna por vez e mede quanto a deviance PIORA. É a
## única medida de importância que pode ser calculada do mesmo jeito
## para um GLMM, uma floresta e uma rede neural - e por isso é a base da
## consolidação da Etapa 16. A permutação é repetida n_perm vezes porque
## uma única realização tem variabilidade apreciável com n = 1.190.
importancia_perm <- function(prever, dados, vars, y, repeticoes = n_perm) {
    base_dev <- deviance_pois(y, pmax(prever(dados), 1e-10))
    res <- map_dfr(vars, function(v) {
        ganhos <- vapply(seq_len(repeticoes), function(i) {
            d <- dados
            d[[v]] <- sample(d[[v]])
            deviance_pois(y, pmax(prever(d), 1e-10)) - base_dev
        }, numeric(1))
        tibble(variavel = v, ganho = mean(ganhos), ganho_dp = sd(ganhos))
    })
    res %>%
        mutate(ganho_rel = ganho / base_dev,
               importancia = pmax(ganho, 0) / max(pmax(res$ganho, 0))) %>%
        arrange(desc(ganho))
}

######@> Rótulos legíveis dos preditores...
## As tabelas e figuras finais vão para o texto da dissertação, onde
## "clim_tp3_max" não é um rótulo aceitável. O dicionário é construído
## como função para que qualquer variável nova receba tratamento e
## nenhuma fique sem rótulo.
rotular <- function(x) {
    base <- c(
        clim_tp_ano      = "Precipitação anual",
        clim_tp_max      = "Maior total mensal",
        clim_tp3_max     = "Maior acumulado trimestral",
        clim_n_p90       = "Meses acima do p90 local",
        clim_n_p95       = "Meses acima do p95 local",
        clim_z_max       = "Maior anomalia mensal padronizada",
        clim_z_med       = "Anomalia média do ano",
        clim_cp_frac     = "Fração convectiva da chuva",
        clim_vt_max      = "Maior vento médio mensal",
        clim_n_vt_p90    = "Meses de vento acima do p90 local",
        clim_t2m_med     = "Temperatura média do ano",
        clim_t2m_max     = "Maior temperatura mensal",
        clim_tcc_med     = "Cobertura de nuvens média",
        clim_conc        = "Concentração sazonal da chuva",
        clim_bal         = "Balanço hídrico anual",
        clim_tp_verao    = "Chuva de verão",
        clim_tp_inverno  = "Chuva de inverno",
        urb_pct          = "Área urbanizada",
        flo_pct          = "Cobertura florestal",
        agr_pct          = "Área agropecuária",
        ala_pct          = "Campo alagado e área pantanosa",
        urb_veg          = "Fração vegetada da mancha urbana",
        delta_urb        = "Expansão urbana no quinquênio",
        delta_flo        = "Variação florestal no quinquênio",
        risco_pct        = "Área urbana suscetível a inundação",
        lat_centroide    = "Latitude do centroide",
        lon_centroide    = "Longitude do centroide",
        log_area         = "Área do município (log)",
        ano              = "Ano (viés de registro)",
        ano_z            = "Ano (viés de registro)",
        municipio        = "Identidade do município")
    saida <- vapply(as.character(x), function(z) {
        raiz <- sub("_(W|B)$", "", z)
        rot <- if(raiz %in% names(base)) base[[raiz]] else raiz
        if(grepl("_W$", z)) paste0(rot, " (dentro)")
        else if(grepl("_B$", z)) paste0(rot, " (entre)")
        else rot
    }, character(1), USE.NAMES = FALSE)
    saida
}

######@> Bloco temático de cada preditor...
bloco_de <- function(x) {
    vapply(as.character(x), function(z) {
        raiz <- sub("_(W|B)$", "", z)
        if(grepl("^clim_", raiz)) {
            if(grepl("_B$", z)) "Clima (climatologia)" else "Clima (gatilho)"
        } else if(raiz %in% c("urb_pct", "flo_pct", "agr_pct", "ala_pct",
                              "urb_veg", "delta_urb", "delta_flo",
                              "risco_pct")) {
            "Uso e cobertura"
        } else if(raiz %in% c("lat_centroide", "lon_centroide", "log_area",
                              "lat", "municipio")) {
            "Território e exposição"
        } else if(raiz %in% c("ano", "ano_z")) {
            "Registro"
        } else {
            "Território e exposição"
        }
    }, character(1), USE.NAMES = FALSE)
}

########################################################################
######@> Etapa 01 - Leitura da base consolidada e do shapefile...

message("Etapa 01 - lendo a base consolidada...")

######@> Base consolidada...
load(arq_base)

######@> Lista acumuladora das tabelas exportadas...
tabelas <- list()

######@> Shapefile dos municípios...
## O shapefile chega com uma feição por parte de polígono e com três
## grafias possíveis do código IBGE, herdadas das sucessivas junções que
## o produziram. A dissolução por código resolve as duas coisas.
message("Etapa 01 - lendo o shapefile...")
shape_bruto <- st_read(arq_shape, quiet = TRUE) %>%
    st_make_valid() %>%
    st_transform(crs_projeto)

atributos <- st_drop_geometry(shape_bruto)
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))

municipios_sf <- shape_bruto %>%
    group_by(geocodigo) %>%
    summarise(.groups = "drop") %>%
    st_make_valid()

########################################################################
######@> Etapa 02 - Descritores anuais a partir da base mensal...

message("Etapa 02 - construindo descritores climáticos anuais...")

######@> Série mensal de clima...
## Só os campos efetivamente usados na construção dos descritores. A
## série começa em clim_ini e não em ano_ini porque os percentis e as
## anomalias precisam de uma climatologia de referência mais longa que a
## janela de análise.
clima_mensal <- base_mensal %>%
    filter(ano >= clim_ini, ano <= ano_fim) %>%
    select(geocodigo, municipio, ano, mes, data, estacao,
           tp = era5_tp_mm_mes,
           cp = era5_cp_mm_mes,
           vento = era5_vento_vel_m_s,
           t2m = era5_t2m_C,
           tcc = era5_tcc_pct,
           pev = era5_pev_mm_dia,
           dias = dias_no_mes) %>%
    arrange(geocodigo, data)

######@> Climatologia local por município e mês do ano...
## A dupla estratificação é a mesma decisão metodológica da AED
## integrada, e pelo mesmo motivo: um mês de 200 mm é ordinário em
## Joinville e extremo em Passo de Torres, e 200 mm em janeiro não é o
## mesmo que 200 mm em julho. Sem padronizar por município E por mês do
## ano, o "extremo" mediria geografia e sazonalidade, não anomalia.
climatologia <- clima_mensal %>%
    filter(ano >= ref_ini, ano <= ref_fim) %>%
    group_by(geocodigo, mes) %>%
    summarise(tp_med = media_segura(tp),
              tp_dp = sd(tp, na.rm = TRUE),
              tp_p90 = quantile(tp, 0.90, na.rm = TRUE),
              tp_p95 = quantile(tp, 0.95, na.rm = TRUE),
              vt_p90 = quantile(vento, 0.90, na.rm = TRUE),
              .groups = "drop")

######@> Série mensal com anomalias e acumulados móveis...
## O acumulado trimestral é a peça central do bloco climático. A
## enxurrada responde ao evento de chuva; a inundação responde à
## SATURAÇÃO do solo e ao enchimento da bacia, que se constroem ao longo
## de semanas. A soma móvel de três meses é o descritor mais próximo
## desse processo que a resolução mensal do ERA5 permite construir.
clima_mensal <- clima_mensal %>%
    left_join(climatologia, by = c("geocodigo", "mes")) %>%
    group_by(geocodigo) %>%
    mutate(tp3 = zoo::rollapplyr(tp, 3, sum, fill = NA),
           z_tp = ifelse(tp_dp > 0, (tp - tp_med) / tp_dp, NA_real_)) %>%
    ungroup()

######@> Resumo anual dos descritores climáticos...
## Dezessete descritores organizados em quatro ideias: QUANTO choveu
## (total, balanço), COM QUE INTENSIDADE (maior mês, maior trimestre,
## maior anomalia), COM QUE FREQUÊNCIA o clima passou do ordinário
## (meses acima do p90 e do p95, locais) e COM QUE ESTRUTURA (fração
## convectiva, concentração sazonal, repartição verão/inverno). O
## conjunto é deliberadamente maior que o necessário: a poda da Etapa 04
## decide o que fica, por regra, e o que fica precisa ter tido chance de
## competir.
clima_anual <- clima_mensal %>%
    filter(ano >= ano_ini) %>%
    group_by(geocodigo, ano) %>%
    summarise(
        n_meses         = sum(!is.na(tp)),
        clim_tp_ano     = soma_segura(tp),
        clim_tp_max     = max_seguro(tp),
        clim_tp3_max    = max_seguro(tp3),
        clim_n_p90      = sum(tp > tp_p90, na.rm = TRUE),
        clim_n_p95      = sum(tp > tp_p95, na.rm = TRUE),
        clim_z_max      = max_seguro(z_tp),
        clim_z_med      = media_segura(z_tp),
        clim_cp_frac    = soma_segura(cp) / soma_segura(tp),
        clim_vt_max     = max_seguro(vento),
        clim_n_vt_p90   = sum(vento > vt_p90, na.rm = TRUE),
        clim_t2m_med    = media_segura(t2m),
        clim_t2m_max    = max_seguro(t2m),
        clim_tcc_med    = media_segura(tcc),
        clim_bal        = soma_segura(tp) - soma_segura(pev * dias),
        clim_tp_verao   = soma_segura(tp[estacao == "Verão"]),
        clim_tp_inverno = soma_segura(tp[estacao == "Inverno"]),
        clim_conc       = {
            p <- tp / soma_segura(tp)
            soma_segura(p^2)
        },
        .groups = "drop") %>%
    filter(n_meses == 12) %>%
    select(-n_meses)

message("Etapa 02 - descritores climáticos: ",
        fmt_int(nrow(clima_anual)), " município-anos completos.")

######@> Dinâmica da cobertura da terra...
## A cobertura da terra é quase constante de um ano para o outro, e por
## isso o NÍVEL responde à pergunta da predisposição, não à do gatilho.
## O que varia de forma mensurável dentro de um município é a TAXA de
## mudança acumulada em alguns anos - a expansão da mancha urbana e a
## perda ou o ganho de floresta. As duas variações são calculadas sobre
## a série completa do MapBiomas (a partir de 1985) e não sobre a janela
## de análise, o que evita perder os primeiros anos por falta de
## defasagem.
uso_dinamica <- base_anual %>%
    filter(ano >= min(base_anual$ano[base_anual$tem_mapbiomas]),
           ano <= ano_fim) %>%
    select(geocodigo, ano,
           u = mapb_cob_n2_area_urbanizada_pct,
           f = mapb_cob_n1_floresta_pct) %>%
    group_by(geocodigo) %>%
    arrange(ano) %>%
    mutate(delta_urb = u - dplyr::lag(u, defasagem_uso),
           delta_flo = f - dplyr::lag(f, defasagem_uso)) %>%
    ungroup() %>%
    select(geocodigo, ano, delta_urb, delta_flo)

######@> Montagem da base analítica...
## A resposta é a soma dos três tipos de interesse. O total de eventos
## de OUTROS tipos no mesmo município-ano é guardado (outros_ev): não
## entra como preditor no modelo principal - é um desfecho, não uma
## causa, e usá-lo introduziria condicionamento em variável
## pós-tratamento - mas serve de proxy da capacidade de registro do
## município na análise de sensibilidade da Etapa 19.
base_mod <- base_anual %>%
    filter(tem_atlas, ano >= ano_ini, ano <= ano_fim) %>%
    mutate(EIA = atlas_n_eventos_tip_enxurradas +
               atlas_n_eventos_tip_inundacoes +
               atlas_n_eventos_tip_alagamentos,
           enxurradas = atlas_n_eventos_tip_enxurradas,
           inundacoes = atlas_n_eventos_tip_inundacoes,
           alagamentos = atlas_n_eventos_tip_alagamentos,
           outros_ev = atlas_n_eventos - EIA) %>%
    select(geocodigo, municipio, ano, EIA, enxurradas, inundacoes,
           alagamentos, outros_ev, atlas_n_eventos,
           urb_pct   = mapb_cob_n2_area_urbanizada_pct,
           flo_pct   = mapb_cob_n1_floresta_pct,
           agr_pct   = mapb_cob_n1_agropecuaria_pct,
           ala_pct   = mapb_cob_n2_campo_alagado_e_area_pantanosa_pct,
           urb_veg   = mapb_urb_pct_vegetada,
           risco_ha  = mapb_risco_total_ha,
           risco_alto_ha = mapb_risco_muito_alto_ha) %>%
    left_join(clima_anual, by = c("geocodigo", "ano")) %>%
    left_join(uso_dinamica, by = c("geocodigo", "ano")) %>%
    left_join(municipios %>%
              select(geocodigo, lat_centroide, lon_centroide,
                     area_km2 = area_km2_shape),
              by = "geocodigo") %>%
    mutate(log_area = log(area_km2),
           risco_pct = 100 * risco_ha / (area_km2 * 100),
           municipio = factor(municipio),
           ano_z = as.numeric(scale(ano)))

######@> Registro das perdas por dado ausente...
## Nenhuma imputação é feita. O que se faz é CONTAR o que se perde e
## dizer de onde vem, para que a diferença entre o n nominal e o n
## efetivo de cada modelo seja rastreável.
perdas <- tibble(
    Etapa = c("Município-anos na janela 1991-2024",
              "Sem descritor climático completo",
              "Sem dinâmica de uso da terra",
              "Base analítica completa",
              "Sem suscetibilidade MapBiomas (só sensibilidade)"),
    n = c(nrow(base_mod),
          sum(is.na(base_mod$clim_tp3_max)),
          sum(is.na(base_mod$delta_urb)),
          sum(complete.cases(base_mod %>%
                             select(EIA, starts_with("clim_"),
                                    urb_pct, flo_pct, delta_urb,
                                    log_area))),
          sum(is.na(base_mod$risco_pct))))

tabelas[["01_perdas_por_ausencia"]] <- salvar_tab(perdas,
                                                  "Tab_01_perdas_por_ausencia")

######@> Base efetivamente modelada...
## O corte é feito uma única vez, aqui, sobre o conjunto de preditores
## candidatos. Todos os modelos das Etapas 07 a 18 usam exatamente estas
## linhas, o que é condição para que a comparação da Etapa 15 seja
## legítima: modelos ajustados a amostras diferentes não são comparáveis
## por deviance nem por AIC.
## ------------------------------------------------------------------
## O BLOCO DE COBERTURA DA TERRA É ESCOLHIDO A PRIORI, E NÃO PODADO
## ------------------------------------------------------------------
##
## As frações do MapBiomas formam uma HIERARQUIA, e não uma lista plana:
## mangue e restinga arbórea estão DENTRO de floresta (nível 1);
## pastagem e silvicultura estão DENTRO de agropecuária; área urbanizada
## está DENTRO de área não vegetada. Somar níveis diferentes na mesma
## matriz cria dependências lineares EXATAS por definição - não por
## propriedade dos dados - e nenhum filtro estatístico é o instrumento
## certo para desfazê-las.
##
## A primeira versão desta análise deixou a poda automática resolver o
## problema, e o resultado mostrou por que isso não funciona: como a
## variável mais bem reproduzida pelas demais é sempre a MAIOR fração da
## composição, o filtro eliminava a cobertura florestal (VIF 152) e a
## precipitação anual e conservava mangue, restinga e pastagem - frações
## marginais, com associação com a resposta próxima de zero. O modelo
## era tecnicamente correto e substantivamente vazio.
##
## O bloco abaixo é, portanto, definido por construção: quatro classes
## MUTUAMENTE EXCLUSIVAS - nenhuma contida em outra - escolhidas por
## corresponderem aos processos que a literatura associa a enxurradas,
## inundações e alagamentos:
##
##   urb_pct : impermeabilização e ocupação. O mecanismo mais direto;
##   flo_pct : cobertura florestal, atenuação do escoamento superficial;
##   agr_pct : uso agropecuário, compactação e supressão da vegetação;
##   ala_pct : campo alagado e área pantanosa, a planície de inundação
##             remanescente.
##
## Três decisões acompanham a escolha. Água e ambiente marinho fica de
## fora porque FECHA a composição - com ela o VIF sobe de 6 para 92 - e
## porque, em municípios costeiros, mede sobretudo quanto de oceano o
## polígono municipal contém. As classes aninhadas (mangue, restinga,
## pastagem, silvicultura) ficam de fora por redundância definicional
## com as classes de nível 1 que as contêm. E a composição resultante
## NÃO é exaustiva - soma entre 85% e 97% da área - o que é justamente o
## que quebra o fechamento e mantém o VIF em nível interpretável.
##
## Somam-se a elas três descritores que não pertencem à composição e
## portanto não sofrem o problema: a fração vegetada DENTRO da mancha
## urbana e as duas taxas de mudança quinquenal, que são o único
## componente do uso da terra com variação interanual apreciável.
vars_uso <- c("urb_pct", "flo_pct", "agr_pct", "ala_pct", "urb_veg",
              "delta_urb", "delta_flo")

vars_candidatas <- c(grep("^clim_", names(base_mod), value = TRUE),
                     vars_uso)

dados <- base_mod %>%
    filter(if_all(all_of(c(vars_candidatas, "EIA", "log_area",
                           "lat_centroide")), ~ !is.na(.x))) %>%
    droplevels()

n_obs <- nrow(dados)
n_mun <- n_distinct(dados$geocodigo)
n_anos <- n_distinct(dados$ano)

message("Etapa 02 - base analítica: ", fmt_int(n_obs),
        " município-anos, ", n_mun, " municípios, ", n_anos, " anos.")

########################################################################
######@> Etapa 03 - A variável resposta...

message("Etapa 03 - caracterizando a resposta...")

######@> Composição da resposta...
## A soma dos três tipos é a resposta pedida pelo objetivo, mas os três
## não têm o mesmo peso: as enxurradas respondem por dois terços do
## total. Isso precisa estar declarado porque significa que o modelo da
## soma é, em boa medida, um modelo de enxurradas - e a Etapa 19 verifica
## se os três se comportam do mesmo modo.
composicao <- dados %>%
    summarise(Enxurradas = sum(enxurradas),
              Inundações = sum(inundacoes),
              Alagamentos = sum(alagamentos)) %>%
    pivot_longer(everything(), names_to = "Tipo", values_to = "Eventos") %>%
    mutate(Percentual = 100 * Eventos / sum(Eventos),
           `Municípios com registro` = c(
               sum(tapply(dados$enxurradas, dados$geocodigo, sum) > 0),
               sum(tapply(dados$inundacoes, dados$geocodigo, sum) > 0),
               sum(tapply(dados$alagamentos, dados$geocodigo, sum) > 0)),
           `Anos com registro` = c(
               sum(tapply(dados$enxurradas, dados$ano, sum) > 0),
               sum(tapply(dados$inundacoes, dados$ano, sum) > 0),
               sum(tapply(dados$alagamentos, dados$ano, sum) > 0)))

tabelas[["02_composicao_resposta"]] <-
    salvar_tab(composicao, "Tab_02_composicao_resposta")

######@> Distribuição das contagens e sobredispersão...
media_eia <- mean(dados$EIA)
var_eia <- var(dados$EIA)
prop_zeros <- mean(dados$EIA == 0)

perfil_resposta <- tibble(
    Indicador = c("Município-anos analisados",
                  "Municípios", "Anos",
                  "Eventos (Enxurradas + Inundações + Alagamentos)",
                  "Município-anos com ao menos um evento",
                  "Proporção de zeros",
                  "Média de eventos por município-ano",
                  "Variância", "Razão variância/média",
                  "Máximo em um município-ano",
                  "Densidade média (eventos por 1.000 km2 por ano)"),
    Valor = c(fmt_int(n_obs), as.character(n_mun), as.character(n_anos),
              fmt_int(sum(dados$EIA)),
              paste0(fmt_int(sum(dados$EIA > 0)), " (",
                     sprintf("%.1f%%", 100 * mean(dados$EIA > 0)), ")"),
              sprintf("%.3f", prop_zeros),
              sprintf("%.3f", media_eia),
              sprintf("%.3f", var_eia),
              sprintf("%.3f", var_eia / media_eia),
              as.character(max(dados$EIA)),
              sprintf("%.2f", 1000 * sum(dados$EIA) /
                              sum(unique(dados[, c("geocodigo",
                                                   "area_km2")])$area_km2) /
                              n_anos)))

tabelas[["03_perfil_resposta"]] <-
    salvar_tab(perfil_resposta, "Tab_03_perfil_resposta")

######@> Figura 01 - a resposta em três recortes...
## O painel reúne o que determina o desenho do modelo: a distribuição
## das contagens (que família), a série do litoral (o viés de registro),
## o perfil por município (a heterogeneidade que o termo municipal
## precisa absorver) e a composição por tipo (o que está sendo somado).
obs_por_contagem <- dados %>%
    count(EIA) %>%
    mutate(esperado_pois = n_obs * dpois(EIA, media_eia))

p1a <- obs_por_contagem %>%
    ggplot(aes(x = factor(EIA))) +
    geom_col(aes(y = n), fill = cores_familia[["Estatística"]],
             alpha = 0.85) +
    geom_point(aes(y = esperado_pois), colour = cores_familia[["Aprendizado de máquina"]],
               size = 2.4) +
    geom_line(aes(y = esperado_pois, group = 1),
              colour = cores_familia[["Aprendizado de máquina"]],
              linewidth = 0.6) +
    scale_y_continuous(labels = fmt_int) +
    labs(title = "Distribuição das contagens",
         subtitle = paste0("Barras: observado. Pontos: Poisson de média ",
                           sprintf("%.2f", media_eia)),
         x = "Eventos no município-ano", y = "Município-anos")

serie_litoral <- dados %>%
    group_by(ano) %>%
    summarise(EIA = sum(EIA), .groups = "drop")

p1b <- serie_litoral %>%
    ggplot(aes(x = ano, y = EIA)) +
    geom_col(fill = cores_familia[["Estatística"]], alpha = 0.85) +
    geom_smooth(method = "loess", formula = y ~ x, se = FALSE,
                colour = cores_familia[["Aprendizado de máquina"]],
                linewidth = 0.8) +
    geom_vline(xintercept = ano_corte_s2id - 0.5, linetype = "dashed",
               colour = "grey40") +
    annotate("text", x = ano_corte_s2id + 0.4, y = max(serie_litoral$EIA),
             label = "consolidação do S2iD", hjust = 0, size = 3,
             colour = "grey30") +
    labs(title = "Total do litoral por ano",
         subtitle = "A tendência é, em parte, do sistema de registro",
         x = "Ano", y = "Eventos")

perfil_mun <- dados %>%
    group_by(municipio) %>%
    summarise(EIA = sum(EIA), area = first(area_km2), .groups = "drop") %>%
    mutate(dens = 1000 * EIA / area / n_anos)

p1c <- perfil_mun %>%
    ggplot(aes(x = reorder(municipio, EIA), y = EIA)) +
    geom_col(fill = cores_familia[["Estatística"]], alpha = 0.85) +
    coord_flip() +
    labs(title = "Total por município",
         subtitle = "Contagem bruta, sem correção de área",
         x = NULL, y = "Eventos")

p1d <- composicao %>%
    ggplot(aes(x = reorder(Tipo, Eventos), y = Eventos)) +
    geom_col(fill = cores_familia[["Estatística"]], alpha = 0.85) +
    geom_text(aes(label = sprintf("%s (%.0f%%)", fmt_int(Eventos),
                                  Percentual)),
              hjust = -0.1, size = 3.2) +
    coord_flip() +
    scale_y_continuous(expand = expansion(mult = c(0, 0.22))) +
    labs(title = "Composição da resposta",
         subtitle = "As enxurradas dominam o agregado",
         x = NULL, y = "Eventos")

fig01 <- (p1a + p1b) / (p1c + p1d) +
    plot_annotation(
        title = "A resposta modelada: Enxurradas, Inundações e Alagamentos",
        subtitle = paste0(fmt_int(sum(dados$EIA)), " eventos em ",
                          fmt_int(n_obs), " município-anos (",
                          ano_ini, "-", ano_fim, "), ",
                          sprintf("%.1f%%", 100 * prop_zeros),
                          " de zeros"),
        caption = quebrar(paste(
            "Fonte: Atlas Digital de Desastres no Brasil, tipologias",
            "Enxurradas, Inundações e Alagamentos somadas por",
            "município e ano. A curva de Poisson no primeiro painel usa",
            "a média global e serve de referência visual: o afastamento",
            "entre barras e pontos é a sobredispersão que o termo",
            "municipal precisa absorver. A linha tracejada no segundo",
            "painel marca a consolidação do S2iD, discutida no achado",
            "de viés de registro da análise exploratória integrada.")))

salvar_fig(fig01, "Fig_01_resposta_modelada", largura = 13, altura = 10)

########################################################################
######@> Etapa 04 - Preditores: blocos, redundância e colinearidade...

message("Etapa 04 - selecionando preditores...")

######@> Correlação bruta de cada candidato com a resposta...
## Calculada em duas escalas porque elas respondem a perguntas
## diferentes, e a diferença entre as duas colunas é o primeiro
## diagnóstico do problema que a decomposição dentro/entre resolve. A
## coluna "entre municípios" usa os totais municipais; a coluna "dentro"
## usa os desvios de cada ano em relação à média do próprio município.
medias_mun <- dados %>%
    group_by(geocodigo) %>%
    summarise(across(all_of(vars_candidatas), ~ mean(.x, na.rm = TRUE)),
              EIA_mun = mean(EIA), .groups = "drop")

desvios <- dados %>%
    group_by(geocodigo) %>%
    mutate(across(all_of(vars_candidatas), ~ .x - mean(.x, na.rm = TRUE)),
           EIA_W = EIA - mean(EIA)) %>%
    ungroup()

correlacoes <- tibble(variavel = vars_candidatas) %>%
    mutate(
        rho_bruto = vapply(variavel, function(v)
            suppressWarnings(cor(dados[[v]], dados$EIA,
                                 method = "spearman",
                                 use = "complete.obs")), numeric(1)),
        rho_entre = vapply(variavel, function(v)
            suppressWarnings(cor(medias_mun[[v]], medias_mun$EIA_mun,
                                 method = "spearman",
                                 use = "complete.obs")), numeric(1)),
        rho_dentro = vapply(variavel, function(v)
            suppressWarnings(cor(desvios[[v]], desvios$EIA_W,
                                 method = "spearman",
                                 use = "complete.obs")), numeric(1)),
        bloco = bloco_de(variavel),
        rotulo = rotular(variavel)) %>%
    arrange(desc(abs(rho_bruto)))

tabelas[["04_correlacoes_candidatas"]] <-
    salvar_tab(correlacoes %>%
               mutate(across(where(is.numeric), ~ round(.x, 3))),
               "Tab_04_correlacoes_candidatas")

######@> Figura 02 - a mesma variável, dois sinais...
## Esta figura é o argumento visual do desenho. Cada preditor aparece
## com duas correlações; onde os pontos ficam em quadrantes opostos, a
## associação entre municípios e a associação dentro do município têm
## SINAIS CONTRÁRIOS, e qualquer regressão que não as separe estimará a
## média das duas.
fig02 <- correlacoes %>%
    ggplot(aes(x = rho_entre, y = rho_dentro, colour = bloco)) +
    geom_hline(yintercept = 0, colour = "grey60", linewidth = 0.3) +
    geom_vline(xintercept = 0, colour = "grey60", linewidth = 0.3) +
    geom_abline(slope = 1, intercept = 0, linetype = "dotted",
                colour = "grey70") +
    geom_point(size = 2.6, alpha = 0.9) +
    geom_text_repel(aes(label = rotulo), size = 2.7, max.overlaps = 40,
                    show.legend = FALSE, segment.colour = "grey70") +
    scale_colour_manual(values = cores_bloco, name = "Bloco") +
    labs(title = "As duas perguntas não têm a mesma resposta",
         subtitle = paste("Correlação de Spearman com a contagem de",
                          "eventos, entre municípios e dentro do município"),
         x = "Correlação ENTRE municípios (predisposição)",
         y = "Correlação DENTRO do município (gatilho)",
         caption = quebrar(paste(
             "Cada ponto é um preditor candidato. O eixo horizontal usa",
             "as médias municipais dos 34 anos; o eixo vertical usa os",
             "desvios de cada ano em relação à média do próprio",
             "município. Pontos sobre a diagonal pontilhada têm o mesmo",
             "efeito nas duas escalas e poderiam entrar uma única vez",
             "no modelo. Pontos em quadrantes opostos - sinal positivo",
             "em uma escala e negativo na outra - são a razão de ser da",
             "decomposição dentro/entre da Etapa 05: uma regressão",
             "comum estimaria uma média ponderada dos dois efeitos e",
             "não representaria nenhum dos dois.")))

salvar_fig(fig02, "Fig_02_correlacao_entre_dentro", largura = 11,
           altura = 8)

######@> Poda por redundância...
poda_cor <- poda_redundancia(dados, vars_candidatas, "EIA")

message("Etapa 04 - filtro de correlação: ",
        length(vars_candidatas), " candidatas -> ",
        length(poda_cor$mantidas), " mantidas.")

######@> Poda por colinearidade multivariada...
## Necessária depois do filtro de correlação, e não no lugar dele: as
## frações de cobertura da terra somam 100% por construção, o que é uma
## dependência LINEAR que não aparece em nenhuma correlação par a par.
poda_col <- poda_vif(dados, poda_cor$mantidas, "EIA", "log_area")

vars_modelo <- poda_col$mantidas

message("Etapa 04 - poda por VIF: ", length(poda_cor$mantidas),
        " -> ", length(vars_modelo), " preditores no conjunto final.")

######@> Registro das duas podas...
selecao <- bind_rows(
    poda_cor$descartes %>%
    transmute(variavel = descartada,
              criterio = "Redundância (|rho| > 0,80)",
              detalhe = sprintf("rho = %+.2f com %s", rho,
                                rotular(mantida))),
    poda_col$descartes %>%
    transmute(variavel = descartada,
              criterio = paste0("Colinearidade (VIF > ", vif_max, ")"),
              detalhe = sprintf("VIF = %.1f; associação = %.3f; perde para %s",
                                vif, forca, substr(grupo, 1, 60)))) %>%
    mutate(rotulo = rotular(variavel), .before = 1) %>%
    bind_rows(tibble(rotulo = rotular(vars_modelo),
                     variavel = vars_modelo,
                     criterio = "Mantida",
                     detalhe = "Integra o conjunto final")) %>%
    arrange(criterio, rotulo)

tabelas[["05_selecao_preditores"]] <-
    salvar_tab(selecao, "Tab_05_selecao_preditores")

######@> Colinearidade antes e depois...
vif_antes <- vif_conjunto(dados, vars_candidatas, "EIA", "log_area") %>%
    mutate(conjunto = "Candidatas")
vif_depois <- vif_conjunto(dados, vars_modelo, "EIA", "log_area") %>%
    mutate(conjunto = "Conjunto final")

vif_tab <- bind_rows(vif_antes, vif_depois) %>%
    mutate(rotulo = rotular(variavel), bloco = bloco_de(variavel))

tabelas[["06_colinearidade"]] <-
    salvar_tab(vif_tab %>% mutate(vif = round(vif, 2)),
               "Tab_06_colinearidade")

######@> Figura 03 - a poda em duas imagens...
p3a <- vif_tab %>%
    mutate(conjunto = factor(conjunto,
                             levels = c("Candidatas", "Conjunto final"))) %>%
    ggplot(aes(x = reorder(rotulo, vif), y = vif, fill = bloco)) +
    geom_col(alpha = 0.9) +
    geom_hline(yintercept = vif_max, linetype = "dashed",
               colour = "grey30") +
    coord_flip() +
    facet_wrap(~ conjunto, scales = "free") +
    scale_y_log10(labels = label_number(accuracy = 0.1)) +
    scale_fill_manual(values = cores_bloco, name = "Bloco") +
    labs(title = "Fator de inflação de variância antes e depois da poda",
         subtitle = paste0("Linha tracejada: limite adotado (VIF = ",
                           vif_max, "). Escala logarítmica"),
         x = NULL, y = "VIF")

mat_cor <- suppressWarnings(cor(dados[, vars_modelo],
                                method = "spearman",
                                use = "pairwise.complete.obs"))
dimnames(mat_cor) <- list(rotular(vars_modelo), rotular(vars_modelo))

p3b <- as.data.frame(as.table(mat_cor)) %>%
    setNames(c("a", "b", "rho")) %>%
    ggplot(aes(x = a, y = b, fill = rho)) +
    geom_tile(colour = "white", linewidth = 0.2) +
    scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
                         midpoint = 0, limits = c(-1, 1),
                         name = "Spearman") +
    labs(title = "Correlação no conjunto final",
         subtitle = paste0("Nenhum par acima de |rho| = ", cor_max),
         x = NULL, y = NULL) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
          axis.text.y = element_text(size = 7))

fig03 <- p3a / p3b +
    plot_layout(heights = c(1, 1.25)) +
    plot_annotation(
        caption = quebrar(paste(
            "A poda é feita em duas passagens e por regra explícita. A",
            "primeira remove, de cada par com |rho| acima de", cor_max,
            ", o membro menos associado à resposta. A segunda remove",
            "iterativamente a variável de maior VIF até que todas",
            "fiquem abaixo de", paste0(vif_max, "."), "A segunda",
            "passagem é indispensável porque as frações de cobertura da",
            "terra somam 100% por construção: a dependência é",
            "multivariada e não aparece em correlações par a par.")))

salvar_fig(fig03, "Fig_03_poda_preditores", largura = 12, altura = 13)

########################################################################
######@> Etapa 05 - Decomposição dentro/entre e matrizes de modelo...

message("Etapa 05 - decompondo os preditores em componentes...")

######@> Componentes de cada preditor...
## Para cada preditor x do município i no ano t:
##
##    x_B(i)    = média de x no município i ao longo dos 34 anos
##    x_W(i,t)  = x(i,t) - x_B(i)
##
## A soma dos dois recupera a variável original, de modo que nenhuma
## informação é perdida - o que muda é que os dois efeitos passam a ter
## coeficientes próprios. O componente ENTRE responde à pergunta da
## predisposição (municípios sistematicamente mais chuvosos, mais
## urbanizados, maiores) e o componente DENTRO responde à do gatilho
## (anos anormalmente chuvosos naquele município).
componentes <- dados %>%
    group_by(geocodigo) %>%
    mutate(across(all_of(vars_modelo), ~ mean(.x, na.rm = TRUE),
                  .names = "{.col}_media")) %>%
    ungroup()

for(v in vars_modelo) {
    componentes[[paste0(v, "_W")]] <-
        componentes[[v]] - componentes[[paste0(v, "_media")]]
    componentes[[paste0(v, "_B")]] <- componentes[[paste0(v, "_media")]]
}

######@> Padronização SEPARADA dos dois componentes...
## Cada componente é padronizado pelo seu PRÓPRIO desvio-padrão, e não
## pelo da variável original. A razão é de leitura: a variação de
## cobertura florestal dentro de um município ao longo de 34 anos é
## pequena diante da variação entre municípios, e padronizar os dois
## pela mesma escala produziria um coeficiente "dentro" enorme e um
## "entre" pequeno que refletem a escala, não o efeito. Com a
## padronização separada, cada coeficiente lê "mudança na taxa esperada
## por desvio-padrão daquele componente", e os dois são comparáveis
## entre si e entre variáveis.
escalas_comp <- tibble(termo = character(), media = numeric(),
                       dp = numeric())

for(v in vars_modelo) {
    for(suf in c("_W", "_B")) {
        nm <- paste0(v, suf)
        mu <- mean(componentes[[nm]], na.rm = TRUE)
        s <- sd(componentes[[nm]], na.rm = TRUE)
        if(!is.finite(s) || s == 0) s <- 1
        componentes[[nm]] <- (componentes[[nm]] - mu) / s
        escalas_comp <- bind_rows(escalas_comp,
                                  tibble(termo = nm, media = mu, dp = s))
    }
}

######@> Descritores estritamente municipais...
## Latitude e área não variam no tempo e por isso só têm componente
## ENTRE. A área entra como offset (decisão 3 do cabeçalho) e a latitude
## como preditor - ela é o eixo ao longo do qual se organizam o relevo,
## o regime de chuva e a ocupação do litoral catarinense, e a análise
## exploratória mostrou que é o principal confundidor das associações
## entre municípios.
componentes$lat_B <- as.numeric(scale(componentes$lat_centroide))
componentes$lon_B <- as.numeric(scale(componentes$lon_centroide))

######@> Bloco DENTRO: todos os preditores selecionados...
termos_W <- paste0(vars_modelo, "_W")

######@> Bloco ENTRE: poda adicional por colinearidade...
## O bloco ENTRE tem apenas 35 unidades independentes - uma por
## município - e não 1.190. Carregá-lo com um coeficiente por preditor
## seria ajustar 20 parâmetros a 35 pontos, o que produz erros-padrão
## inúteis e coeficientes instáveis. A poda por VIF é aplicada de novo,
## agora sobre o bloco ENTRE acrescido da latitude, e reduz o bloco ao
## que os 35 municípios efetivamente sustentam.
cand_B <- c(paste0(vars_modelo, "_B"), "lat_B")
poda_B <- poda_vif(componentes, cand_B, "EIA", "log_area")
termos_B <- poda_B$mantidas

message("Etapa 05 - bloco ENTRE: ", length(cand_B), " -> ",
        length(termos_B), " termos após poda.")

######@> Termos do modelo estatístico principal...
## O ano fecha a lista como controle do viés de registro (decisão 4).
termos_mod <- c(termos_W, termos_B, "ano_z")

dic_termos <- tibble(termo = termos_mod) %>%
    mutate(rotulo = rotular(termo),
           bloco = bloco_de(termo),
           componente = case_when(
               grepl("_W$", termo) ~ "Dentro do município (gatilho)",
               grepl("_B$", termo) ~ "Entre municípios (predisposição)",
               TRUE ~ "Entre municípios (predisposição)"))

tabelas[["07_termos_do_modelo"]] <-
    salvar_tab(dic_termos, "Tab_07_termos_do_modelo")

######@> Conjunto de preditores das famílias de aprendizado...
## Árvores e redes não precisam da decomposição: elas aprendem a
## interação entre a identidade do município e os preditores por conta
## própria, e impor a decomposição a elas seria dar-lhes informação já
## processada que o modelo estatístico teve de estimar. Recebem,
## portanto, os preditores em ESCALA ORIGINAL, mais a posição, a área e
## o ano. A comparação da Etapa 15 é, assim, uma comparação entre
## representações do mesmo problema, e não entre matrizes diferentes.
## O log da área aparece nas duas funções que a árvore e a rede
## recebem: como OFFSET (base_margin no boosting, termo somado ao
## preditor linear na rede) e também como PREDITOR. Não é redundância
## por descuido. O offset impõe coeficiente 1 - a hipótese de que os
## eventos escalam proporcionalmente à área - e oferecer a mesma
## variável como preditor permite ao modelo corrigir esse coeficiente se
## os dados discordarem. A floresta aleatória, que não tem mecanismo de
## offset, depende inteiramente da segunda via.
vars_ml <- c(vars_modelo, "lat_centroide", "lon_centroide", "log_area",
             "ano")

######@> Objeto de trabalho...
dm <- componentes %>%
    mutate(mun_id = as.integer(factor(geocodigo)))

######@> Figura 04 - quanto de cada preditor é "entre" e quanto é "dentro"...
## Decide, na prática, o que cada componente pode explicar. Uma variável
## cuja variação é quase toda ENTRE municípios - como a latitude ou a
## cobertura florestal - não tem como explicar por que um ano teve mais
## eventos que o outro, por mais forte que seja sua associação bruta com
## a resposta.
particao_var <- tibble(variavel = vars_modelo) %>%
    mutate(
        var_entre = vapply(variavel, function(v)
            var(tapply(dados[[v]], dados$geocodigo, mean)), numeric(1)),
        var_dentro = vapply(variavel, function(v) {
            m <- tapply(dados[[v]], dados$geocodigo, mean)
            mean(tapply(dados[[v]] - m[as.character(dados$geocodigo)],
                        dados$geocodigo, var))
        }, numeric(1)),
        prop_entre = var_entre / (var_entre + var_dentro),
        rotulo = rotular(variavel),
        bloco = bloco_de(variavel))

tabelas[["08_particao_variancia"]] <-
    salvar_tab(particao_var %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_08_particao_variancia")

fig04 <- particao_var %>%
    ggplot(aes(x = reorder(rotulo, prop_entre), y = prop_entre,
               fill = bloco)) +
    geom_col(alpha = 0.9) +
    geom_hline(yintercept = 0.5, linetype = "dashed", colour = "grey30") +
    coord_flip() +
    scale_y_continuous(labels = percent_format(accuracy = 1),
                       limits = c(0, 1)) +
    scale_fill_manual(values = cores_bloco, name = "Bloco") +
    labs(title = "Onde está a variação de cada preditor",
         subtitle = paste("Fração da variância total que ocorre ENTRE",
                          "municípios, e não dentro deles"),
         x = NULL, y = "Proporção da variância entre municípios",
         caption = quebrar(paste(
             "Barras próximas de 100% identificam variáveis",
             "essencialmente estruturais: elas distinguem municípios,",
             "mas são quase constantes ao longo dos 34 anos e portanto",
             "não podem explicar por que um ano teve mais eventos que o",
             "outro. Barras abaixo da linha tracejada identificam",
             "variáveis predominantemente interanuais, que é onde o",
             "gatilho climático se manifesta. A decomposição da Etapa 05",
             "garante que cada uma seja lida na escala em que de fato",
             "varia.")))

salvar_fig(fig04, "Fig_04_particao_variancia", largura = 10, altura = 8)

########################################################################
######@> Etapa 06 - Protocolo de validação cruzada em blocos...

message("Etapa 06 - definindo os blocos de validação...")

######@> Blocos de anos...
## Anos inteiros são atribuídos a blocos por sorteio, e não em janelas
## consecutivas. Há uma razão específica: o ano é preditor no modelo
## (controle de viés de registro), e reservar os últimos anos para teste
## exigiria EXTRAPOLAR esse termo - coisa que árvores e redes não fazem
## por construção, o que penalizaria injustamente as duas famílias por
## um artefato do desenho, não por menor capacidade preditiva. Sortear
## anos inteiros preserva o que interessa: nenhum município-ano do teste
## compartilha ano com o treino, de modo que a correlação espacial
## dentro do ano - todos os municípios sujeitos ao mesmo sistema
## sinótico - não vaza entre as partições.
anos_unicos <- sort(unique(dm$ano))
blocos_ano <- split(sample(anos_unicos),
                    rep(1:n_blocos, length.out = length(anos_unicos)))

######@> Blocos de municípios...
## Municípios contíguos ficam no MESMO bloco. Sortear municípios ao
## acaso deixaria vizinhos imediatos em partições diferentes, e como
## municípios vizinhos compartilham bacia, relevo e sistema de chuva, o
## modelo aprenderia o vizinho e pareceria estar generalizando. O
## agrupamento é feito ao longo da latitude, que é o eixo do litoral
## catarinense: cada bloco é um trecho contíguo de costa, e prever um
## bloco significa prever um trecho de litoral inteiramente ausente do
## treino. É o teste severo.
ordem_lat <- dm %>%
    distinct(geocodigo, lat_centroide) %>%
    arrange(desc(lat_centroide)) %>%
    mutate(bloco = as.integer(cut(seq_len(n()),
                                  breaks = n_blocos,
                                  labels = FALSE)))

blocos_mun <- split(ordem_lat$geocodigo, ordem_lat$bloco)

######@> Índices de teste de cada esquema...
particoes <- list(
    `Blocos de anos` = lapply(blocos_ano, function(a) which(dm$ano %in% a)),
    `Blocos de municípios` = lapply(blocos_mun,
                                    function(g) which(dm$geocodigo %in% g)))

######@> Descrição das partições...
desc_particoes <- imap_dfr(particoes, function(pt, esquema) {
    imap_dfr(pt, function(idx, k) {
        tibble(Esquema = esquema, Bloco = as.integer(k),
               `Município-anos no teste` = length(idx),
               `Eventos no teste` = sum(dm$EIA[idx]),
               Conteudo = if(esquema == "Blocos de anos") {
                              paste(range(dm$ano[idx]), collapse = "-")
                          } else {
                              paste(sort(unique(as.character(
                                  dm$municipio[idx])))[c(1, length(
                                      unique(dm$municipio[idx])))],
                                  collapse = " ... ")
                          })
    })
})

tabelas[["09_particoes_validacao"]] <-
    salvar_tab(desc_particoes, "Tab_09_particoes_validacao")

######@> Acumuladores das previsões fora da amostra...
## Uma matriz por esquema, com uma coluna por modelo. Cada linha recebe
## a previsão feita quando aquela observação estava no bloco de TESTE, o
## que garante que nenhuma previsão avaliada tenha visto sua própria
## observação no treino.
modelos_avaliados <- c("GLM Poisson", "GLMM Poisson", "GLMM dentro/entre",
                       "GAM", "Elastic net", "Random forest",
                       "Gradient boosting", "Rede neural")

previsoes <- lapply(names(particoes), function(e) {
    m <- matrix(NA_real_, nrow = nrow(dm), ncol = length(modelos_avaliados),
                dimnames = list(NULL, modelos_avaliados))
    as.data.frame(m)
})
names(previsoes) <- names(particoes)

######@> Registro de receitas de ajuste e previsão...
## Cada modelo é declarado como um par de funções - uma que ajusta a um
## subconjunto de treino, outra que prevê para um subconjunto de teste -
## e registrado nesta lista. A validação cruzada da Etapa 15 percorre o
## registro sem saber de que família é cada modelo, o que torna
## impossível que uma família receba tratamento diferente da outra por
## descuido. As Etapas 07 a 14 preenchem o registro e, ao mesmo tempo,
## ajustam cada modelo à base completa para extrair coeficientes,
## efeitos e importâncias.
receitas <- list()

########################################################################
######@> Etapa 07 - Estatística I: qual família de contagem...

message("Etapa 07 - comparando famílias de contagem...")

######@> Fórmula de referência...
## A mesma estrutura de preditores em todas as famílias, para que a
## comparação isole a DISTRIBUIÇÃO e não a especificação da média.
f_fixa <- as.formula(paste("EIA ~", paste(termos_mod, collapse = " + "),
                           "+ offset(log_area)"))
f_mista <- as.formula(paste("EIA ~", paste(termos_mod, collapse = " + "),
                            "+ offset(log_area) + (1 | municipio)"))

######@> Dispersão de Pearson...
## Razão entre a soma dos quadrados dos resíduos de Pearson e os graus
## de liberdade. Um valor próximo de 1 indica que a variância observada
## é a que a Poisson prevê; acima de 1, há variação que a família não
## acomoda. É o diagnóstico que decide entre Poisson e binomial
## negativo, e é por isso que precisa ser calculado do mesmo modo para
## os modelos com e sem efeito aleatório.
dispersao_de <- function(modelo, dados_aj) {
    mu <- fitted(modelo)
    y <- dados_aj$EIA
    r <- (y - mu) / sqrt(pmax(mu, 1e-10))
    npar <- if(inherits(modelo, "glmmTMB")) {
                length(fixef(modelo)$cond) + 1
            } else {
                length(coef(modelo))
            }
    sum(r^2) / (length(y) - npar)
}

######@> Zeros previstos por cada família...
## A pergunta "há excesso de zeros?" não se responde olhando a
## proporção de zeros da amostra: uma Poisson de média 0,35 já produz
## 70% de zeros sozinha. A comparação correta é entre os zeros
## OBSERVADOS e os que a família ajustada prevê.
zeros_previstos <- function(modelo, dados_aj) {
    mu <- fitted(modelo)
    fam <- family(modelo)$family
    if(grepl("nbinom2|Negative Binomial", fam)) {
        th <- sigma(modelo)
        sum((th / (th + mu))^th)
    } else if(grepl("nbinom1", fam)) {
        th <- mu / sigma(modelo)
        sum((th / (th + mu))^th)
    } else {
        sum(dpois(0, mu))
    }
}

######@> Ajuste da sequência de famílias...
ajustes_familia <- list(
    `Poisson (sem termo municipal)` =
        glmmTMB(f_fixa, family = poisson, data = dm),
    `Binomial negativo (sem termo municipal)` =
        glmmTMB(f_fixa, family = nbinom2, data = dm),
    `Poisson + efeito de município` =
        glmmTMB(f_mista, family = poisson, data = dm),
    `Binomial negativo I + efeito de município` =
        glmmTMB(f_mista, family = nbinom1, data = dm),
    `Binomial negativo II + efeito de município` =
        glmmTMB(f_mista, family = nbinom2, data = dm),
    `Poisson inflado de zeros + município` =
        glmmTMB(f_mista, family = poisson, ziformula = ~ 1, data = dm))

comparacao_familia <- imap_dfr(ajustes_familia, function(m, nome) {
    tibble(Modelo = nome,
           Parametros = length(fixef(m)$cond) +
               ifelse(grepl("nbinom", family(m)$family), 1, 0) +
               ifelse(grepl("município", nome), 1, 0),
           `Log-verossimilhança` = as.numeric(logLik(m)),
           AIC = AIC(m), BIC = BIC(m),
           `Dispersão de Pearson` = dispersao_de(m, dm),
           `Zeros previstos` = zeros_previstos(m, dm))
}) %>%
    mutate(`Zeros observados` = sum(dm$EIA == 0),
           dAIC = AIC - min(AIC)) %>%
    arrange(AIC)

tabelas[["10_familias_contagem"]] <-
    salvar_tab(comparacao_familia %>%
               mutate(across(where(is.numeric), ~ round(.x, 2))),
               "Tab_10_familias_contagem")

familia_escolhida <- comparacao_familia$Modelo[1]
disp_sem_mun <- comparacao_familia$`Dispersão de Pearson`[
    comparacao_familia$Modelo == "Poisson (sem termo municipal)"]
disp_com_mun <- comparacao_familia$`Dispersão de Pearson`[
    comparacao_familia$Modelo == "Poisson + efeito de município"]

message("Etapa 07 - família de menor AIC: ", familia_escolhida)
message("Etapa 07 - dispersão de Pearson: ",
        sprintf("%.2f sem termo municipal, %.2f com", disp_sem_mun,
                disp_com_mun))

######@> Figura 05 - a sobredispersão é dos municípios...
p5a <- comparacao_familia %>%
    ggplot(aes(x = reorder(Modelo, -dAIC), y = dAIC)) +
    geom_col(fill = cores_familia[["Estatística"]], alpha = 0.85) +
    geom_text(aes(label = sprintf("%+.1f", dAIC)), hjust = -0.15,
              size = 3.1) +
    coord_flip() +
    scale_x_discrete(labels = function(x) quebrar_rotulo(x, 28)) +
    scale_y_continuous(expand = expansion(mult = c(0, 0.18))) +
    labs(title = "Diferença de AIC em relação ao melhor modelo",
         subtitle = "Menor é melhor; zero é o modelo selecionado",
         x = NULL, y = "delta AIC")

p5b <- comparacao_familia %>%
    ggplot(aes(x = reorder(Modelo, `Dispersão de Pearson`),
               y = `Dispersão de Pearson`)) +
    geom_col(fill = cores_familia[["Aprendizado de máquina"]],
             alpha = 0.85) +
    geom_hline(yintercept = 1, linetype = "dashed", colour = "grey30") +
    geom_text(aes(label = sprintf("%.2f", `Dispersão de Pearson`)),
              hjust = -0.15, size = 3.1) +
    coord_flip() +
    scale_x_discrete(labels = function(x) quebrar_rotulo(x, 28)) +
    scale_y_continuous(expand = expansion(mult = c(0, 0.18))) +
    labs(title = "Dispersão de Pearson",
         subtitle = "Linha tracejada: variância igual à média (Poisson)",
         x = NULL, y = "Dispersão")

p5c <- comparacao_familia %>%
    ggplot(aes(x = reorder(Modelo, `Zeros previstos`),
               y = `Zeros previstos`)) +
    geom_col(fill = cores_familia[["Aprendizado profundo"]], alpha = 0.85) +
    geom_hline(yintercept = sum(dm$EIA == 0), linetype = "dashed",
               colour = "grey30") +
    coord_flip() +
    scale_x_discrete(labels = function(x) quebrar_rotulo(x, 28)) +
    labs(title = "Zeros previstos e observados",
         subtitle = paste0("Linha tracejada: zeros observados (",
                           fmt_int(sum(dm$EIA == 0)), ")"),
         x = NULL, y = "Município-anos com zero previsto")

fig05 <- p5a / p5b / p5c +
    plot_annotation(
        title = "Que família de contagem a base exige",
        subtitle = paste("Mesma estrutura de preditores em todos;",
                         "muda apenas a distribuição"),
        caption = quebrar(paste(
            "A sequência responde a duas perguntas de uma vez. A",
            "primeira: a Poisson é suficiente? Sem o termo municipal a",
            "dispersão é de",
            paste0(sprintf("%.2f", disp_sem_mun), ","),
            "o que sugeriria binomial negativo; com o termo municipal",
            "ela cai para", paste0(sprintf("%.2f", disp_com_mun), ","),
            "e o binomial negativo deixa de acrescentar ajuste. A",
            "variância extra era heterogeneidade ENTRE MUNICÍPIOS, e o",
            "remédio é o termo municipal, não a troca de família. A",
            "segunda: há excesso de zeros? Não - a Poisson com termo",
            "municipal já prevê praticamente o número de zeros",
            "observado, e a inflação explícita não melhora o AIC.",
            "O resultado replica, na escala anual e para os três tipos",
            "hidrológicos, o que a análise exploratória integrada havia",
            "encontrado na escala mensal para o conjunto dos",
            "desastres.")))

salvar_fig(fig05, "Fig_05_familia_contagem", largura = 11, altura = 13)

########################################################################
######@> Etapa 08 - Estatística II: o modelo dentro/entre...

message("Etapa 08 - ajustando os modelos estatísticos principais...")

######@> Progressão de três especificações...
## A progressão existe para mostrar o que cada decisão do desenho
## compra, e não apenas para chegar ao modelo final:
##
##   (i)   GLM Poisson       - preditores em escala original, sem termo
##                             municipal. É a especificação ingênua, a
##                             que se obteria sem a análise exploratória;
##   (ii)  GLMM Poisson      - acrescenta o efeito aleatório de
##                             município. Absorve a heterogeneidade, mas
##                             ao custo de CONFUNDIR os dois efeitos: o
##                             coeficiente de cada preditor continua
##                             sendo uma média ponderada do efeito entre
##                             e do efeito dentro;
##   (iii) GLMM dentro/entre - separa os dois. É o modelo do capítulo.
f_glm <- as.formula(paste("EIA ~",
                          paste(c(vars_modelo, "lat_centroide", "ano_z"),
                                collapse = " + "),
                          "+ offset(log_area)"))
f_glmm <- as.formula(paste("EIA ~",
                           paste(c(vars_modelo, "lat_centroide", "ano_z"),
                                 collapse = " + "),
                           "+ offset(log_area) + (1 | municipio)"))

mod_glm <- glm(f_glm, family = poisson, data = dm)
mod_glmm <- glmmTMB(f_glmm, family = poisson, data = dm)
mod_we <- glmmTMB(f_mista, family = poisson, data = dm)

######@> Receitas registradas...
## As três compartilham a previsão: taxa esperada na escala da resposta,
## com o offset de área embutido. allow.new.levels devolve, para um
## município ausente do treino, a previsão do efeito aleatório MÉDIO -
## que é exatamente a previsão honesta no esquema de blocos de
## municípios, onde o município do teste nunca foi visto.
receitas[["GLM Poisson"]] <- list(
    familia = "Estatística",
    ajusta = function(tr) glm(f_glm, family = poisson, data = tr),
    preve = function(m, te) as.numeric(predict(m, newdata = te,
                                               type = "response")))

receitas[["GLMM Poisson"]] <- list(
    familia = "Estatística",
    ajusta = function(tr) glmmTMB(f_glmm, family = poisson, data = tr),
    preve = function(m, te) as.numeric(predict(m, newdata = te,
                                               type = "response",
                                               allow.new.levels = TRUE)))

receitas[["GLMM dentro/entre"]] <- list(
    familia = "Estatística",
    ajusta = function(tr) glmmTMB(f_mista, family = poisson, data = tr),
    preve = function(m, te) as.numeric(predict(m, newdata = te,
                                               type = "response",
                                               allow.new.levels = TRUE)))

######@> Comparação das três especificações...
progressao <- tibble(
    Especificação = c("GLM Poisson (ingênuo)",
                      "GLMM Poisson (termo municipal)",
                      "GLMM dentro/entre (modelo do capítulo)"),
    Parametros = c(length(coef(mod_glm)),
                   length(fixef(mod_glmm)$cond) + 1,
                   length(fixef(mod_we)$cond) + 1),
    AIC = c(AIC(mod_glm), AIC(mod_glmm), AIC(mod_we)),
    `Dispersão de Pearson` = c(dispersao_de(mod_glm, dm),
                               dispersao_de(mod_glmm, dm),
                               dispersao_de(mod_we, dm)),
    `Variância do efeito municipal` = c(
        NA_real_,
        as.numeric(VarCorr(mod_glmm)$cond$municipio[1]),
        as.numeric(VarCorr(mod_we)$cond$municipio[1]))) %>%
    mutate(dAIC = AIC - min(AIC))

tabelas[["11_progressao_especificacoes"]] <-
    salvar_tab(progressao %>%
               mutate(across(where(is.numeric), ~ round(.x, 3))),
               "Tab_11_progressao_especificacoes")

var_mun_glmm <- progressao$`Variância do efeito municipal`[2]
var_mun_we <- progressao$`Variância do efeito municipal`[3]

message("Etapa 08 - variância do efeito municipal: ",
        sprintf("%.3f no GLMM comum, %.3f no dentro/entre",
                var_mun_glmm, var_mun_we))

######@> Coeficientes do modelo do capítulo...
## Os coeficientes de uma Poisson com ligação logarítmica são lidos
## exponenciados: exp(beta) é a RAZÃO DE TAXAS associada ao aumento de
## um desvio-padrão do componente. Um valor de 1,40 significa "40% a
## mais de eventos esperados"; 0,75 significa "25% a menos". O intervalo
## de confiança é calculado na escala do preditor linear e depois
## exponenciado, que é onde a aproximação normal é razoável.
coef_we <- summary(mod_we)$coefficients$cond
coeficientes <- tibble(
    termo = rownames(coef_we),
    estimativa = coef_we[, 1],
    erro = coef_we[, 2],
    z = coef_we[, 3],
    p = coef_we[, 4]) %>%
    filter(termo != "(Intercept)") %>%
    mutate(rr = exp(estimativa),
           rr_inf = exp(estimativa - qnorm(1 - alfa / 2) * erro),
           rr_sup = exp(estimativa + qnorm(1 - alfa / 2) * erro),
           rotulo = rotular(termo),
           bloco = bloco_de(termo),
           componente = case_when(
               grepl("_W$", termo) ~ "Dentro do município (gatilho)",
               TRUE ~ "Entre municípios (predisposição)"),
           significativo = p < alfa,
           efeito_pct = 100 * (rr - 1)) %>%
    arrange(desc(abs(z)))

tabelas[["12_coeficientes_dentro_entre"]] <-
    salvar_tab(coeficientes %>%
               select(rotulo, termo, componente, bloco, estimativa, erro,
                      z, p, rr, rr_inf, rr_sup, efeito_pct,
                      significativo) %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_12_coeficientes_dentro_entre")

######@> Figura 06 - o resultado central do capítulo...
## Cada preditor aparece uma vez em cada painel, e a leitura conjunta é
## que responde à pergunta do objetivo: o painel da esquerda diz o que
## faz um ANO ser pior que outro no mesmo município; o da direita diz o
## que faz um MUNICÍPIO ser pior que outro.
fig06 <- coeficientes %>%
    mutate(componente = factor(componente, levels = names(cores_comp)),
           rotulo_curto = sub(" \\((dentro|entre)\\)$", "", rotulo)) %>%
    ggplot(aes(x = rr, y = reorder(rotulo_curto, rr), colour = bloco,
               alpha = significativo)) +
    geom_vline(xintercept = 1, linetype = "dashed", colour = "grey40") +
    geom_errorbarh(aes(xmin = rr_inf, xmax = rr_sup), height = 0.25,
                   linewidth = 0.6) +
    geom_point(size = 2.8) +
    facet_wrap(~ componente, scales = "free_y") +
    scale_x_log10(breaks = c(0.5, 0.7, 1, 1.4, 2, 3)) +
    scale_colour_manual(values = cores_bloco, name = "Bloco") +
    scale_alpha_manual(values = c(`TRUE` = 1, `FALSE` = 0.35),
                       name = paste0("p < ", alfa),
                       labels = c(`TRUE` = "sim", `FALSE` = "não")) +
    labs(title = "O que explica os eventos hidrológicos",
         subtitle = paste("Razão de taxas por desvio-padrão do",
                          "componente, com intervalo de 95%"),
         x = "Razão de taxas (escala logarítmica)", y = NULL,
         caption = quebrar(paste(
             "Modelo de Poisson com efeito aleatório de município e",
             "offset de log(área), ajustado a", fmt_int(n_obs),
             "município-anos. Cada preditor entra duas vezes: como",
             "média municipal (painel da direita, predisposição) e como",
             "desvio do ano em relação a essa média (painel da",
             "esquerda, gatilho). Valores acima de 1 indicam aumento da",
             "taxa esperada de eventos; abaixo de 1, redução. Pontos",
             "esmaecidos não atingem significância a", paste0(alfa, "."),
             "O ano entra como controle do viés de registro e não",
             "aparece nos painéis por não ser característica do",
             "território.")))

salvar_fig(fig06, "Fig_06_coeficientes_dentro_entre", largura = 13,
           altura = 8)

######@> Figura 07 - o que a decomposição muda...
## Compara, preditor a preditor, o coeficiente único do GLMM comum com
## os dois coeficientes do modelo decomposto. Onde a barra do meio se
## afasta das outras duas, o coeficiente único estava representando uma
## média de efeitos distintos.
coef_glmm <- summary(mod_glmm)$coefficients$cond
comp_coef <- tibble(termo = rownames(coef_glmm),
                    est_unico = coef_glmm[, 1],
                    erro_unico = coef_glmm[, 2]) %>%
    filter(termo %in% vars_modelo) %>%
    left_join(coeficientes %>%
              filter(grepl("_W$", termo)) %>%
              transmute(termo = sub("_W$", "", termo),
                        est_W = estimativa, erro_W = erro),
              by = "termo") %>%
    left_join(coeficientes %>%
              filter(grepl("_B$", termo)) %>%
              transmute(termo = sub("_B$", "", termo),
                        est_B = estimativa, erro_B = erro),
              by = "termo") %>%
    filter(!is.na(est_W)) %>%
    mutate(rotulo = rotular(termo))

fig07 <- comp_coef %>%
    select(rotulo, est_W, est_B) %>%
    pivot_longer(-rotulo, names_to = "comp", values_to = "est") %>%
    mutate(comp = ifelse(comp == "est_W",
                         "Dentro do município (gatilho)",
                         "Entre municípios (predisposição)")) %>%
    filter(!is.na(est)) %>%
    ggplot(aes(x = est, y = reorder(rotulo, est), colour = comp)) +
    geom_vline(xintercept = 0, linetype = "dashed", colour = "grey40") +
    geom_line(aes(group = rotulo), colour = "grey75", linewidth = 0.5) +
    geom_point(size = 3) +
    scale_colour_manual(values = cores_comp, name = NULL) +
    labs(title = "Os dois efeitos de cada preditor",
         subtitle = paste("Coeficientes na escala do preditor linear;",
                          "linhas ligam os dois componentes de um mesmo",
                          "preditor"),
         x = "Coeficiente (log da razão de taxas)", y = NULL,
         caption = quebrar(paste(
             "Preditores cujos dois pontos ficam em lados opostos do",
             "zero têm efeito de sinal contrário nas duas escalas: a",
             "característica que distingue os municípios com mais",
             "eventos NÃO é a mesma que faz um ano ser pior que outro",
             "dentro do município. Um modelo sem a decomposição",
             "estimaria um único coeficiente intermediário entre os",
             "dois, que não descreve corretamente nenhum dos dois",
             "processos. Comprimento da linha cinza mede o quanto se",
             "perderia ao não separar.")))

salvar_fig(fig07, "Fig_07_efeitos_separados", largura = 11, altura = 8)

######@> Efeitos aleatórios municipais...
## Depois de controlados clima, uso da terra, posição e área, o que
## sobra no efeito de cada município é a parte NÃO EXPLICADA pelo
## modelo: relevo, forma da bacia, densidade de ocupação em área
## suscetível, capacidade da defesa civil local. É um resíduo
## estruturado, e vale como pauta - os municípios no topo são aqueles
## onde há mais eventos do que suas características ambientais e de uso
## da terra fazem prever.
efeitos_mun <- ranef(mod_we)$cond$municipio %>%
    as.data.frame() %>%
    tibble::rownames_to_column("municipio") %>%
    setNames(c("municipio", "efeito")) %>%
    left_join(dm %>%
              group_by(municipio) %>%
              summarise(EIA = sum(EIA), area = first(area_km2),
                        lat = first(lat_centroide), .groups = "drop") %>%
              mutate(municipio = as.character(municipio)),
              by = "municipio") %>%
    mutate(fator = exp(efeito)) %>%
    arrange(desc(efeito))

tabelas[["13_efeitos_municipais"]] <-
    salvar_tab(efeitos_mun %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_13_efeitos_municipais")

fig08 <- efeitos_mun %>%
    ggplot(aes(x = fator, y = reorder(municipio, fator),
               fill = efeito > 0)) +
    geom_vline(xintercept = 1, linetype = "dashed", colour = "grey40") +
    geom_col(alpha = 0.9) +
    scale_fill_manual(values = c(`TRUE` = cores_familia[["Aprendizado de máquina"]],
                                 `FALSE` = cores_familia[["Estatística"]]),
                      guide = "none") +
    scale_x_continuous(trans = "log10") +
    labs(title = "O que o modelo não explica, município a município",
         subtitle = paste("Efeito aleatório exponenciado: fator",
                          "multiplicativo sobre a taxa prevista"),
         x = "Fator multiplicativo (escala logarítmica)", y = NULL,
         caption = quebrar(paste(
             "Valores acima de 1 identificam municípios com MAIS",
             "eventos do que o clima, o uso da terra, a posição e a",
             "área fazem prever; abaixo de 1, o oposto. O que resta",
             "aqui é aquilo que a base não contém - relevo e forma da",
             "bacia, densidade de ocupação em área suscetível,",
             "capacidade de registro e atuação da defesa civil local. A",
             "dispersão desses efeitos é",
             paste0(sprintf("%.3f", var_mun_we), ","),
             "contra", paste0(sprintf("%.3f", var_mun_glmm)),
             "no modelo sem decomposição: os termos ENTRE já absorveram",
             "boa parte da heterogeneidade que antes era atribuída à",
             "identidade do município.")))

salvar_fig(fig08, "Fig_08_efeitos_municipais", largura = 10, altura = 8)

########################################################################
######@> Etapa 09 - Estatística III: GAM e superfície espacial...

message("Etapa 09 - ajustando o modelo aditivo...")

######@> Especificação do GAM...
## O modelo aditivo relaxa duas imposições do GLMM, uma de cada vez:
##
##   - a LINEARIDADE na escala do log. Cada componente DENTRO entra como
##     spline penalizada, e os graus de liberdade efetivos estimados
##     dizem o quanto a relação se afasta da reta. Um edf próximo de 1
##     é a confirmação de que o termo linear do GLMM bastava - resultado
##     tão informativo quanto o contrário;
##
##   - a ADITIVIDADE ESPACIAL. A superfície s(lon, lat) substitui a
##     latitude por uma função suave bidimensional da posição, capaz de
##     representar o gradiente do litoral e os desvios locais. É o
##     tratamento explícito da autocorrelação espacial que a análise
##     exploratória detectou.
##
## O k das splines é deliberadamente pequeno (5 nós): com 414 eventos,
## splines flexíveis ajustariam ruído. A penalização por REML decide o
## quanto de flexibilidade usar dentro desse limite.
termos_suaves <- paste(sprintf("s(%s, k = 5)", termos_W), collapse = " + ")
termos_lineares <- paste(c(termos_B, "ano_z"), collapse = " + ")

f_gam <- as.formula(paste("EIA ~", termos_suaves, "+", termos_lineares,
                          "+ s(lon_centroide, lat_centroide, k = 20)",
                          "+ s(municipio, bs = 're') + offset(log_area)"))

mod_gam <- gam(f_gam, family = poisson, data = dm, method = "REML",
               select = TRUE)

## A previsão do GAM precisa tratar o efeito municipal LINHA A LINHA, e
## a razão é a diferença entre os dois esquemas de validação. No esquema
## de blocos de ANOS todos os municípios do teste estão no treino, e
## descartar o termo s(municipio) jogaria fora informação que todos os
## demais modelos usam - o GAM apareceria artificialmente pior por
## defeito do código de previsão, não do método. No esquema de blocos de
## MUNICÍPIOS ocorre o oposto: o nível não existe no ajuste e o termo
## PRECISA ser excluído, ou a previsão é indefinida. A função abaixo
## prevê das duas maneiras e escolhe, para cada linha, a que
## corresponde à situação daquele município - que é o comportamento que
## o allow.new.levels do glmmTMB já dá automaticamente aos modelos
## mistos, e que aqui precisa ser reproduzido à mão.
receitas[["GAM"]] <- list(
    familia = "Estatística",
    ajusta = function(tr) gam(f_gam, family = poisson, data = tr,
                              method = "REML", select = TRUE),
    preve = function(m, te) {
        conhecidos <- as.character(te$municipio) %in%
            levels(m$model$municipio)
        te2 <- te
        ## Os níveis não vistos recebem um rótulo qualquer do treino só
        ## para que a matriz de predição possa ser montada; o efeito
        ## correspondente é descartado logo em seguida.
        if(any(!conhecidos)) {
            te2$municipio <- factor(
                ifelse(conhecidos, as.character(te2$municipio),
                       levels(m$model$municipio)[1]),
                levels = levels(m$model$municipio))
        }
        com_mun <- suppressWarnings(
            predict(m, newdata = te2, type = "response"))
        sem_mun <- suppressWarnings(
            predict(m, newdata = te2, type = "response",
                    exclude = "s(municipio)"))
        as.numeric(ifelse(conhecidos, com_mun, sem_mun))
    })

######@> Termos suaves e graus de liberdade efetivos...
resumo_gam <- summary(mod_gam)
suaves <- as.data.frame(resumo_gam$s.table) %>%
    tibble::rownames_to_column("termo") %>%
    setNames(c("termo", "edf", "ref_df", "chi2", "p")) %>%
    mutate(variavel = gsub("^s\\(|\\)$", "", termo),
           rotulo = ifelse(grepl(",", variavel),
                           "Superfície espacial (lon, lat)",
                           rotular(variavel)),
           forma = case_when(
               edf < 0.05 ~ "Anulado pela penalização",
               edf < 1.15 ~ "Praticamente linear",
               edf < 2.5 ~ "Curvatura moderada",
               TRUE ~ "Marcadamente não linear"),
           significativo = p < alfa) %>%
    arrange(desc(chi2))

parametricos <- as.data.frame(resumo_gam$p.table) %>%
    tibble::rownames_to_column("termo") %>%
    setNames(c("termo", "estimativa", "erro", "z", "p")) %>%
    filter(termo != "(Intercept)") %>%
    mutate(rotulo = rotular(termo), rr = exp(estimativa))

tabelas[["14_gam_termos_suaves"]] <-
    salvar_tab(suaves %>%
               select(rotulo, termo, edf, ref_df, chi2, p, forma,
                      significativo) %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_14_gam_termos_suaves")

tabelas[["15_gam_termos_lineares"]] <-
    salvar_tab(parametricos %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_15_gam_termos_lineares")

message("Etapa 09 - deviance explicada pelo GAM: ",
        sprintf("%.1f%%", 100 * resumo_gam$dev.expl))

######@> Figura 09 - as formas funcionais estimadas...
## Extrai os efeitos parciais na escala do preditor linear e os desenha
## com a banda de erro-padrão. Um termo cuja banda contém a linha
## horizontal em toda a extensão não tem efeito distinguível de zero,
## por mais que a curva pareça sugestiva.
extrai_suave <- function(modelo, termo, dados_ref, n = 200) {
    v <- gsub("^s\\(|, k.*$|\\)$", "", termo)
    if(grepl(",", v) || !v %in% names(dados_ref)) return(NULL)
    grade <- dados_ref[rep(1, n), , drop = FALSE]
    for(col in names(grade)) {
        if(is.numeric(grade[[col]])) grade[[col]] <- 0
    }
    grade[[v]] <- seq(quantile(dados_ref[[v]], 0.02, na.rm = TRUE),
                      quantile(dados_ref[[v]], 0.98, na.rm = TRUE),
                      length.out = n)
    grade$municipio <- dados_ref$municipio[1]
    grade$log_area <- 0
    p <- predict(modelo, newdata = grade, type = "terms",
                 se.fit = TRUE)
    col <- which(colnames(p$fit) == paste0("s(", v, ")"))
    if(length(col) == 0) return(NULL)
    tibble(variavel = v, x = grade[[v]],
           y = p$fit[, col], se = p$se.fit[, col])
}

curvas <- map_dfr(paste0("s(", termos_W, ")"),
                  ~ extrai_suave(mod_gam, .x, dm))

if(nrow(curvas) > 0) {
    curvas <- curvas %>%
        left_join(suaves %>% select(variavel, edf, p), by = "variavel") %>%
        mutate(rotulo = sprintf("%s\n(edf = %.2f, p = %s)",
                                rotular(variavel), edf,
                                ifelse(p < 0.001, "<0,001",
                                       sprintf("%.3f", p))))

    fig09 <- curvas %>%
        ggplot(aes(x = x, y = exp(y))) +
        geom_hline(yintercept = 1, linetype = "dashed", colour = "grey50") +
        geom_ribbon(aes(ymin = exp(y - 1.96 * se),
                        ymax = exp(y + 1.96 * se)),
                    fill = cores_familia[["Estatística"]], alpha = 0.2) +
        geom_line(colour = cores_familia[["Estatística"]],
                  linewidth = 0.8) +
        facet_wrap(~ rotulo, scales = "free", ncol = 4) +
        scale_y_log10() +
        labs(title = "Formas funcionais dos componentes interanuais",
             subtitle = paste("Efeito parcial sobre a taxa esperada,",
                              "em desvios-padrão do componente DENTRO"),
             x = "Desvio do ano em relação à média do município (dp)",
             y = "Fator multiplicativo sobre a taxa",
             caption = quebrar(paste(
                 "Modelo aditivo generalizado de Poisson com seleção de",
                 "termos por penalização (REML). Os graus de liberdade",
                 "efetivos indicados em cada painel medem o afastamento",
                 "da reta: valores próximos de 1 confirmam que o termo",
                 "linear do modelo da Etapa 08 era suficiente; valores",
                 "próximos de zero indicam termos anulados pela",
                 "penalização, ou seja, sem efeito detectável. A banda",
                 "sombreada é o intervalo de 95%; onde ela contém a",
                 "linha tracejada em toda a extensão, não há efeito",
                 "distinguível de zero.")))

    salvar_fig(fig09, "Fig_09_formas_funcionais", largura = 14,
               altura = 8)
}

######@> Figura 10 - a superfície espacial...
## Mostra o que sobra de estrutura geográfica depois de controlados
## clima e uso da terra: se a superfície fosse plana, a posição não
## acrescentaria nada ao que os preditores já dizem.
grade_esp <- expand.grid(
    lon_centroide = seq(min(dm$lon_centroide), max(dm$lon_centroide),
                        length.out = 90),
    lat_centroide = seq(min(dm$lat_centroide), max(dm$lat_centroide),
                        length.out = 90))

for(v in c(termos_W, termos_B, "ano_z")) grade_esp[[v]] <- 0
grade_esp$municipio <- dm$municipio[1]
grade_esp$log_area <- 0

pred_esp <- predict(mod_gam, newdata = grade_esp, type = "terms")
col_esp <- grep("lon_centroide,lat_centroide", colnames(pred_esp))

if(length(col_esp) > 0) {
    grade_esp$efeito <- pred_esp[, col_esp[1]]

    ## Máscara: só o entorno dos municípios observados tem sentido
    dist_min <- apply(
        as.matrix(dist(rbind(grade_esp[, c("lon_centroide",
                                           "lat_centroide")],
                             distinct(dm, lon_centroide,
                                      lat_centroide))))[
            seq_len(nrow(grade_esp)),
            nrow(grade_esp) + seq_len(n_distinct(dm$geocodigo))],
        1, min)
    grade_esp <- grade_esp[dist_min < 0.35, ]

    fig10 <- ggplot() +
        geom_raster(data = grade_esp,
                    aes(x = lon_centroide, y = lat_centroide,
                        fill = exp(efeito))) +
        geom_sf(data = municipios_sf, fill = NA, colour = "grey25",
                linewidth = 0.2) +
        geom_point(data = distinct(dm, lon_centroide, lat_centroide),
                   aes(x = lon_centroide, y = lat_centroide),
                   size = 0.8, colour = "grey15") +
        scale_fill_gradient2(low = "#2166AC", mid = "white",
                             high = "#B2182B", midpoint = 1,
                             trans = "log10",
                             name = "Fator sobre\na taxa") +
        coord_sf(expand = FALSE) +
        labs(title = "Estrutura espacial residual",
             subtitle = paste("Superfície suave da posição, com clima e",
                              "uso da terra já controlados"),
             x = "Longitude", y = "Latitude",
             caption = quebrar_mapa(paste(
                 "Termo s(lon, lat) do modelo aditivo, exponenciado. A",
                 "superfície mede o quanto a taxa esperada de eventos",
                 "sobe ou desce por efeito da POSIÇÃO, depois de",
                 "descontado tudo o que os preditores climáticos e de",
                 "uso da terra explicam. Uma superfície plana",
                 "significaria que a geografia não acrescenta",
                 "informação; os gradientes visíveis indicam processos",
                 "organizados espacialmente que a base não contém -",
                 "relevo, orientação das bacias e histórico de",
                 "ocupação são os candidatos naturais. A superfície é",
                 "mostrada apenas na vizinhança dos municípios",
                 "observados; fora dela seria extrapolação.")))

    salvar_fig(fig10, "Fig_10_superficie_espacial", largura = 9,
               altura = 9, diretorio = dir_mapa)
}

########################################################################
######@> Etapa 10 - Estatística IV: regularização...

message("Etapa 10 - ajustando a regularização elastic net...")

######@> Elastic net de Poisson...
## Serve a dois propósitos distintos. O primeiro é de SELEÇÃO: a
## penalização L1 zera coeficientes, e o conjunto que sobrevive ao
## lambda de melhor validação é uma segunda opinião sobre quais
## preditores importam - obtida por um critério (erro de predição)
## diferente do usado nas Etapas 04 e 08 (correlação, VIF, valor-p). O
## segundo é de CONTROLE: se o modelo penalizado perde pouco em
## desempenho fora da amostra em relação ao GLMM completo, é sinal de
## que o GLMM não está sobreajustando.
##
## alpha = 0,5 mistura L1 e L2 em partes iguais. A escolha é deliberada:
## L1 puro, diante de preditores ainda correlacionados entre si,
## seleciona arbitrariamente um do grupo e descarta os demais, o que
## torna a lista de sobreviventes instável; o componente L2 distribui o
## coeficiente entre eles e estabiliza a seleção.
X_net <- as.matrix(dm[, termos_mod])
y_net <- dm$EIA

cv_net <- cv.glmnet(X_net, y_net, family = "poisson",
                    offset = dm$log_area, alpha = 0.5, nfolds = 10,
                    type.measure = "deviance")

mod_net <- glmnet(X_net, y_net, family = "poisson",
                  offset = dm$log_area, alpha = 0.5)

receitas[["Elastic net"]] <- list(
    familia = "Estatística",
    ajusta = function(tr) {
        Xt <- as.matrix(tr[, termos_mod])
        cvm <- cv.glmnet(Xt, tr$EIA, family = "poisson",
                         offset = tr$log_area, alpha = 0.5, nfolds = 10,
                         type.measure = "deviance")
        list(cv = cvm, termos = termos_mod)
    },
    preve = function(m, te) {
        Xe <- as.matrix(te[, m$termos])
        as.numeric(predict(m$cv, newx = Xe, s = "lambda.1se",
                           newoffset = te$log_area, type = "response"))
    })

######@> Coeficientes sob os dois lambdas de referência...
## lambda.min é o de menor erro de validação; lambda.1se é o maior
## lambda cujo erro fica a menos de um erro-padrão do mínimo - a escolha
## parcimoniosa, e a adotada aqui como conjunto "essencial".
coef_min <- as.matrix(coef(cv_net, s = "lambda.min"))
coef_1se <- as.matrix(coef(cv_net, s = "lambda.1se"))

regularizacao <- tibble(
    termo = rownames(coef_min),
    coef_min = as.numeric(coef_min),
    coef_1se = as.numeric(coef_1se)) %>%
    filter(termo != "(Intercept)") %>%
    mutate(rotulo = rotular(termo),
           bloco = bloco_de(termo),
           componente = ifelse(grepl("_W$", termo),
                               "Dentro do município (gatilho)",
                               "Entre municípios (predisposição)"),
           sobrevive_1se = coef_1se != 0,
           sobrevive_min = coef_min != 0) %>%
    arrange(desc(abs(coef_1se)), desc(abs(coef_min)))

tabelas[["16_regularizacao"]] <-
    salvar_tab(regularizacao %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_16_regularizacao")

n_sobrevive <- sum(regularizacao$sobrevive_1se)

message("Etapa 10 - preditores com coeficiente não nulo em lambda.1se: ",
        n_sobrevive, " de ", nrow(regularizacao))

######@> Figura 11 - trajetória de regularização...
tracos <- as.matrix(mod_net$beta) %>%
    as.data.frame() %>%
    tibble::rownames_to_column("termo") %>%
    pivot_longer(-termo, names_to = "passo", values_to = "coef") %>%
    mutate(lambda = mod_net$lambda[as.integer(sub("s", "", passo)) + 1],
           rotulo = rotular(termo), bloco = bloco_de(termo)) %>%
    filter(is.finite(lambda))

rotulos_finais <- tracos %>%
    filter(lambda == min(lambda), abs(coef) > 0.02)

p11a <- tracos %>%
    ggplot(aes(x = lambda, y = coef, group = termo, colour = bloco)) +
    geom_hline(yintercept = 0, colour = "grey60", linewidth = 0.3) +
    geom_line(linewidth = 0.6, alpha = 0.85) +
    geom_vline(xintercept = cv_net$lambda.1se, linetype = "dashed",
               colour = "grey30") +
    geom_vline(xintercept = cv_net$lambda.min, linetype = "dotted",
               colour = "grey30") +
    geom_text_repel(data = rotulos_finais, aes(label = rotulo), size = 2.5,
                    direction = "y", hjust = 0, nudge_x = -0.3,
                    max.overlaps = 20, show.legend = FALSE,
                    segment.colour = "grey80") +
    scale_x_reverse(trans = "log10") +
    scale_colour_manual(values = cores_bloco, name = "Bloco") +
    labs(title = "Trajetória dos coeficientes",
         subtitle = paste("Tracejada: lambda.1se (parcimonioso).",
                          "Pontilhada: lambda.min"),
         x = "lambda (escala logarítmica, decrescente)",
         y = "Coeficiente")

p11b <- tibble(lambda = cv_net$lambda, erro = cv_net$cvm,
               inf = cv_net$cvlo, sup = cv_net$cvup) %>%
    ggplot(aes(x = lambda, y = erro)) +
    geom_ribbon(aes(ymin = inf, ymax = sup), fill = "grey85") +
    geom_line(colour = cores_familia[["Estatística"]], linewidth = 0.8) +
    geom_vline(xintercept = cv_net$lambda.1se, linetype = "dashed",
               colour = "grey30") +
    geom_vline(xintercept = cv_net$lambda.min, linetype = "dotted",
               colour = "grey30") +
    scale_x_reverse(trans = "log10") +
    labs(title = "Erro de validação cruzada",
         subtitle = "Deviance média nas dez partições",
         x = "lambda (escala logarítmica, decrescente)",
         y = "Deviance de Poisson")

fig11 <- p11a / p11b +
    plot_layout(heights = c(1.6, 1)) +
    plot_annotation(
        caption = quebrar(paste(
            "Elastic net de Poisson (alpha = 0,5) com offset de",
            "log(área). A mistura de penalizações L1 e L2 é deliberada:",
            "a L1 pura, diante de preditores correlacionados,",
            "seleciona um do grupo arbitrariamente e a lista de",
            "sobreviventes muda a cada reamostragem. Dos",
            nrow(regularizacao), "termos,", n_sobrevive,
            "mantêm coeficiente não nulo sob o lambda parcimonioso -",
            "e são eles que compõem a segunda opinião sobre quais",
            "características importam, obtida por erro de predição e",
            "não por valor-p.")))

salvar_fig(fig11, "Fig_11_regularizacao", largura = 12, altura = 11)

########################################################################
######@> Etapa 11 - Diagnóstico dos modelos estatísticos...

message("Etapa 11 - diagnosticando o modelo do capítulo...")

######@> Resíduos quantílicos simulados...
## O resíduo comum de um modelo de contagem com 74% de zeros é
## inútil para diagnóstico: sua distribuição é discreta e assimétrica
## mesmo quando o modelo está perfeito, e qualquer gráfico produz
## padrões que parecem problemas e não são. O resíduo quantílico
## simulado resolve isso comparando cada observação com a distribuição
## de valores que o PRÓPRIO modelo ajustado geraria para ela: se o
## modelo estiver correto, esses resíduos são uniformes em (0,1),
## qualquer que seja a família.
set.seed(42)
sim_res <- simulateResiduals(mod_we, n = 1000)

teste_unif <- testUniformity(sim_res, plot = FALSE)
teste_disp <- testDispersion(sim_res, plot = FALSE)
teste_zero <- testZeroInflation(sim_res, plot = FALSE)
teste_out <- testOutliers(sim_res, plot = FALSE, type = "bootstrap")

diagnostico <- tibble(
    Teste = c("Uniformidade dos resíduos (Kolmogorov-Smirnov)",
              "Sobredispersão",
              "Excesso de zeros",
              "Excesso de observações extremas"),
    Estatística = c(as.numeric(teste_unif$statistic),
                    as.numeric(teste_disp$statistic),
                    as.numeric(teste_zero$statistic),
                    as.numeric(teste_out$statistic)),
    p = c(teste_unif$p.value, teste_disp$p.value, teste_zero$p.value,
          teste_out$p.value)) %>%
    mutate(Conclusão = ifelse(p < alfa,
                              "Desvio detectado",
                              "Compatível com o modelo"))

######@> Autocorrelação espacial dos resíduos...
## Testa a suposição de independência entre municípios. O modelo trata
## cada município-ano como observação independente dada a estrutura de
## efeitos; se municípios VIZINHOS tiverem resíduos sistematicamente
## parecidos, essa suposição falha e os erros-padrão dos coeficientes
## ENTRE estarão subestimados. A vizinhança é a contiguidade de
## fronteira, e o resíduo de cada município é a média dos seus 34
## resíduos anuais.
res_mun <- dm %>%
    mutate(res = residuals(sim_res)) %>%
    group_by(geocodigo) %>%
    summarise(res = mean(res) - 0.5, .groups = "drop")

sf_res <- municipios_sf %>%
    filter(geocodigo %in% res_mun$geocodigo) %>%
    left_join(res_mun, by = "geocodigo") %>%
    arrange(geocodigo)

viz <- poly2nb(sf_res, queen = TRUE)
pesos <- nb2listw(viz, style = "W", zero.policy = TRUE)
moran_res <- moran.test(sf_res$res, pesos, zero.policy = TRUE)

diagnostico <- bind_rows(
    diagnostico,
    tibble(Teste = "Autocorrelação espacial dos resíduos (Moran)",
           Estatística = as.numeric(moran_res$estimate[1]),
           p = moran_res$p.value,
           Conclusão = ifelse(moran_res$p.value < alfa,
                              "Desvio detectado",
                              "Compatível com o modelo")))

######@> Autocorrelação temporal dos resíduos...
## Mesma lógica no eixo do tempo: se os resíduos de anos consecutivos
## forem parecidos, há memória interanual não modelada.
res_ano <- dm %>%
    mutate(res = residuals(sim_res) - 0.5) %>%
    group_by(ano) %>%
    summarise(res = mean(res), .groups = "drop") %>%
    arrange(ano)

acf_res <- acf(res_ano$res, lag.max = 5, plot = FALSE)
lim_acf <- qnorm(1 - alfa / 2) / sqrt(nrow(res_ano))

diagnostico <- bind_rows(
    diagnostico,
    tibble(Teste = "Autocorrelação temporal dos resíduos (lag 1)",
           Estatística = as.numeric(acf_res$acf[2]),
           p = NA_real_,
           Conclusão = ifelse(abs(acf_res$acf[2]) > lim_acf,
                              "Desvio detectado",
                              "Compatível com o modelo")))

tabelas[["17_diagnostico_modelo"]] <-
    salvar_tab(diagnostico %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_17_diagnostico_modelo")

message("Etapa 11 - Moran dos resíduos: I = ",
        sprintf("%+.3f (p = %.3f)", moran_res$estimate[1],
                moran_res$p.value))

######@> Figura 12 - painel de diagnóstico...
res_df <- dm %>%
    mutate(res = residuals(sim_res),
           ajustado = fitted(mod_we))

p12a <- tibble(teorico = (seq_len(nrow(res_df)) - 0.5) / nrow(res_df),
               observado = sort(res_df$res)) %>%
    ggplot(aes(x = teorico, y = observado)) +
    geom_abline(slope = 1, intercept = 0, colour = "grey40",
                linetype = "dashed") +
    geom_point(size = 0.7, alpha = 0.5,
               colour = cores_familia[["Estatística"]]) +
    labs(title = "Uniformidade dos resíduos",
         subtitle = sprintf("Kolmogorov-Smirnov: p = %.3f",
                            teste_unif$p.value),
         x = "Quantil teórico", y = "Resíduo quantílico simulado")

p12b <- res_df %>%
    ggplot(aes(x = ajustado, y = res)) +
    geom_hline(yintercept = c(0.25, 0.5, 0.75), linetype = c("dotted",
                                                             "dashed",
                                                             "dotted"),
               colour = "grey40") +
    geom_point(size = 0.7, alpha = 0.4,
               colour = cores_familia[["Estatística"]]) +
    geom_smooth(method = "loess", formula = y ~ x, se = TRUE,
                colour = cores_familia[["Aprendizado de máquina"]],
                fill = "grey85", linewidth = 0.8) +
    scale_x_log10() +
    labs(title = "Resíduo contra valor ajustado",
         subtitle = "A curva deve acompanhar a mediana (0,5)",
         x = "Taxa ajustada (escala logarítmica)",
         y = "Resíduo quantílico simulado")

p12c <- res_df %>%
    group_by(ano) %>%
    summarise(res = mean(res) - 0.5, .groups = "drop") %>%
    ggplot(aes(x = ano, y = res)) +
    geom_hline(yintercept = 0, colour = "grey40", linetype = "dashed") +
    geom_col(fill = cores_familia[["Estatística"]], alpha = 0.85) +
    labs(title = "Resíduo médio por ano",
         subtitle = sprintf("Autocorrelação de defasagem 1: %+.3f",
                            acf_res$acf[2]),
         x = "Ano", y = "Desvio da mediana")

p12d <- res_df %>%
    group_by(municipio) %>%
    summarise(res = mean(res) - 0.5, .groups = "drop") %>%
    ggplot(aes(x = reorder(municipio, res), y = res)) +
    geom_hline(yintercept = 0, colour = "grey40", linetype = "dashed") +
    geom_col(fill = cores_familia[["Estatística"]], alpha = 0.85) +
    coord_flip() +
    labs(title = "Resíduo médio por município",
         subtitle = sprintf("Moran global: I = %+.3f (p = %.3f)",
                            moran_res$estimate[1], moran_res$p.value),
         x = NULL, y = "Desvio da mediana")

fig12 <- (p12a + p12b) / (p12c + p12d) +
    plot_layout(heights = c(1, 1.4)) +
    plot_annotation(
        title = "Diagnóstico do modelo dentro/entre",
        subtitle = paste("Resíduos quantílicos simulados (1.000",
                         "simulações por observação)"),
        caption = quebrar(paste(
            "O resíduo quantílico simulado compara cada observação com",
            "a distribuição que o próprio modelo ajustado geraria para",
            "ela; se o modelo estiver correto, esses resíduos são",
            "uniformes em (0,1) qualquer que seja a família - o que",
            "torna o diagnóstico possível apesar dos",
            paste0(sprintf("%.0f%%", 100 * prop_zeros)), "de zeros na",
            "resposta. Os quatro painéis testam, nesta ordem: a forma",
            "da distribuição, a adequação da relação média-variância ao",
            "longo da faixa de previsão, a existência de memória",
            "interanual não modelada e a existência de estrutura",
            "espacial residual entre municípios.")))

salvar_fig(fig12, "Fig_12_diagnostico", largura = 13, altura = 12)

########################################################################
######@> Etapa 12 - Aprendizado de máquina I: random forest...

message("Etapa 12 - ajustando a floresta aleatória...")

######@> Especificação...
## Duas escolhas merecem registro. A primeira: a regra de divisão é a de
## POISSON, e não a de mínimos quadrados. A floresta padrão trataria a
## contagem como resposta contínua e escolheria divisões que reduzem o
## erro quadrático - critério que, com 74% de zeros, privilegia acertar
## os zeros e ignora a estrutura das contagens positivas. A regra de
## Poisson maximiza a redução da deviance, que é a mesma métrica pela
## qual todos os modelos são comparados na Etapa 15.
##
## A segunda: o município entra como fator. A floresta não tem efeito
## aleatório, e sem a identidade municipal ficaria em desvantagem
## artificial diante dos modelos mistos. Com ela, aprende sozinha a
## heterogeneidade que o GLMM estima como variância - e, no esquema de
## blocos de municípios, encontra no teste níveis que nunca viu, o que é
## a dificuldade genuína desse esquema e vale igualmente para as
## demais famílias.
vars_rf <- c(vars_ml, "municipio")

f_rf <- as.formula(paste("EIA ~", paste(vars_rf, collapse = " + ")))

ajusta_rf <- function(tr) {
    ranger(f_rf, data = tr, num.trees = rf_arvores,
           splitrule = "poisson", min.node.size = rf_no_min,
           respect.unordered.factors = "order",
           importance = "permutation", seed = 42)
}

preve_rf <- function(m, te) {
    te2 <- te
    ## Municípios ausentes do treino recebem o nível de referência; a
    ## previsão passa a depender só dos demais preditores, que é o
    ## comportamento honesto quando a identidade é desconhecida.
    niveis <- m$forest$covariate.levels$municipio
    if(!is.null(niveis)) {
        te2$municipio <- factor(ifelse(as.character(te2$municipio) %in%
                                       niveis,
                                       as.character(te2$municipio),
                                       niveis[1]),
                                levels = niveis)
    }
    as.numeric(predict(m, data = te2)$predictions)
}

mod_rf <- ajusta_rf(dm)

receitas[["Random forest"]] <- list(familia = "Aprendizado de máquina",
                                    ajusta = ajusta_rf, preve = preve_rf)

message("Etapa 12 - erro fora da bolsa: ",
        sprintf("%.4f (pseudo-R2 = %.3f)", mod_rf$prediction.error,
                mod_rf$r.squared))

######@> Importância por permutação da floresta...
imp_rf <- tibble(variavel = names(mod_rf$variable.importance),
                 importancia_bruta = as.numeric(mod_rf$variable.importance)) %>%
    mutate(importancia = pmax(importancia_bruta, 0) /
               max(pmax(importancia_bruta, 0)),
           rotulo = rotular(variavel),
           bloco = bloco_de(variavel)) %>%
    arrange(desc(importancia))

tabelas[["18_importancia_floresta"]] <-
    salvar_tab(imp_rf %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_18_importancia_floresta")

########################################################################
######@> Etapa 13 - Aprendizado de máquina II: gradient boosting...

message("Etapa 13 - ajustando o gradient boosting...")

######@> Especificação...
## Objetivo count:poisson, que é a deviance de Poisson - a mesma função
## de perda do GLMM e da floresta. O offset de área entra como
## base_margin, que é o mecanismo do xgboost para termos com coeficiente
## fixado em 1, exatamente como o offset de um GLM.
##
## Os hiperparâmetros são conservadores por decisão, não por
## conveniência: profundidade 3 (interações de até três vias), taxa de
## aprendizado 0,05 e subamostragem de linhas e colunas a 80%. O número
## de rodadas NÃO é fixado - é escolhido por validação cruzada interna
## dentro de cada ajuste, o que impede que o número de árvores seja um
## hiperparâmetro afinado no conjunto de teste.
vars_xgb <- vars_ml

matriz_xgb <- function(d) {
    m <- as.matrix(d[, vars_xgb])
    storage.mode(m) <- "double"
    m
}

par_xgb <- list(objective = "count:poisson",
                max_depth = xgb_profundidade,
                eta = xgb_taxa,
                subsample = 0.8,
                colsample_bytree = 0.8,
                min_child_weight = 10,
                nthread = 2)

ajusta_xgb <- function(tr) {
    dtr <- xgb.DMatrix(matriz_xgb(tr), label = tr$EIA)
    setinfo(dtr, "base_margin", tr$log_area)
    set.seed(42)
    cvx <- xgb.cv(par_xgb, dtr, nrounds = xgb_rodadas_max, nfold = 5,
                  early_stopping_rounds = 40, verbose = 0)
    nb <- which.min(cvx$evaluation_log$test_poisson_nloglik_mean)
    set.seed(42)
    list(modelo = xgb.train(par_xgb, dtr, nrounds = max(nb, 10)),
         rodadas = nb)
}

preve_xgb <- function(m, te) {
    dte <- xgb.DMatrix(matriz_xgb(te))
    setinfo(dte, "base_margin", te$log_area)
    as.numeric(predict(m$modelo, dte))
}

mod_xgb <- ajusta_xgb(dm)

receitas[["Gradient boosting"]] <- list(
    familia = "Aprendizado de máquina",
    ajusta = ajusta_xgb, preve = preve_xgb)

message("Etapa 13 - rodadas escolhidas por validação interna: ",
        mod_xgb$rodadas)

######@> Ganho por variável...
imp_xgb <- xgb.importance(model = mod_xgb$modelo) %>%
    as_tibble() %>%
    rename(variavel = Feature) %>%
    mutate(importancia = Gain / max(Gain),
           rotulo = rotular(variavel),
           bloco = bloco_de(variavel)) %>%
    arrange(desc(Gain))

tabelas[["19_importancia_boosting"]] <-
    salvar_tab(imp_xgb %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_19_importancia_boosting")

######@> Valores de Shapley...
## Decompõem a previsão de CADA município-ano na contribuição de cada
## preditor, na escala do preditor linear. Diferentemente da importância
## por ganho, que é um resumo global e sempre positivo, o valor de
## Shapley tem SINAL e é local: permite ver que a mesma variável empurra
## a previsão para cima em alguns município-anos e para baixo em
## outros - que é a assinatura de uma interação. Para modelos de
## árvores o cálculo é exato, e não uma aproximação por amostragem.
shap_mat <- predict(mod_xgb$modelo, xgb.DMatrix(matriz_xgb(dm)),
                    predcontrib = TRUE)
colnames(shap_mat)[ncol(shap_mat)] <- "BIAS"

shap_df <- as.data.frame(shap_mat[, vars_xgb, drop = FALSE]) %>%
    mutate(linha = row_number()) %>%
    pivot_longer(-linha, names_to = "variavel", values_to = "shap") %>%
    left_join(dm %>%
              mutate(linha = row_number()) %>%
              select(linha, all_of(vars_xgb)) %>%
              pivot_longer(-linha, names_to = "variavel",
                           values_to = "valor"),
              by = c("linha", "variavel")) %>%
    group_by(variavel) %>%
    mutate(valor_rel = if(sd(valor, na.rm = TRUE) > 0) {
               (valor - min(valor, na.rm = TRUE)) /
                   diff(range(valor, na.rm = TRUE))
           } else 0.5) %>%
    ungroup() %>%
    mutate(rotulo = rotular(variavel), bloco = bloco_de(variavel))

imp_shap <- shap_df %>%
    group_by(variavel, rotulo, bloco) %>%
    summarise(shap_medio = mean(abs(shap)), .groups = "drop") %>%
    mutate(importancia = shap_medio / max(shap_medio)) %>%
    arrange(desc(shap_medio))

tabelas[["20_shapley_boosting"]] <-
    salvar_tab(imp_shap %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_20_shapley_boosting")

########################################################################
######@> Etapa 14 - Aprendizado profundo: rede com embedding...

message("Etapa 14 - ajustando a rede neural...")

######@> Arquitetura...
## A rede tem três peças, e cada uma responde a uma exigência do
## problema:
##
##   (1) CAMADA DE EMBEDDING PARA O MUNICÍPIO. Em vez de 35 variáveis
##       indicadoras independentes, o município é representado por um
##       vetor de dl_dim_emb coordenadas APRENDIDAS. Isso faz duas
##       coisas de uma vez: reduz o número de parâmetros de 35 para
##       35 x 3, e - mais importante - permite que municípios com
##       comportamento parecido acabem próximos nesse espaço, o que
##       torna a representação inspecionável. É o análogo aprendido do
##       efeito aleatório do GLMM, e a Etapa 18 o examina;
##
##   (2) PERDA DE POISSON. A saída da rede é o LOGARITMO da taxa, ao
##       qual se soma o offset de área, e a perda é a mesma deviance
##       usada por todas as outras famílias. Uma rede com perda
##       quadrática sobre contagens com 74% de zeros aprenderia a
##       prever quase zero em toda parte;
##
##   (3) INICIALIZAÇÃO CALIBRADA DO VIÉS DE SAÍDA. O último viés começa
##       em log(taxa média do treino), e os pesos da última camada em
##       zero. Sem isso a rede começa prevendo taxas absurdas - o offset
##       de log(área) vale entre 4 e 7 - e gasta centenas de épocas
##       apenas para voltar à média, quando não diverge. É a diferença
##       entre uma rede que converge e uma que não converge, e é
##       específica de modelos com offset.
##
## Contra o tamanho da amostra - 1.190 observações e 414 eventos - a
## defesa é tripla: rede pequena (duas camadas ocultas, 24 e 12
## neurônios), dropout de 30% e decaimento de peso de 1e-2, mais parada
## antecipada por validação interna. A rede é, deliberadamente, a mais
## regularizada das três famílias, porque é a que mais precisa.
rede_eia <- nn_module(
    classname = "rede_eia",
    initialize = function(p, n_mun, d_emb = dl_dim_emb,
                          h = dl_neuronios, drop = dl_dropout,
                          vies0 = 0) {
        self$emb <- nn_embedding(n_mun + 1, d_emb)
        nn_init_normal_(self$emb$weight, 0, 0.05)
        self$saida <- nn_linear(h %/% 2, 1)
        nn_init_zeros_(self$saida$weight)
        nn_init_constant_(self$saida$bias, vies0)
        self$corpo <- nn_sequential(
            nn_linear(p + d_emb, h), nn_relu(), nn_dropout(drop),
            nn_linear(h, h %/% 2), nn_relu(), nn_dropout(drop),
            self$saida)
    },
    forward = function(x, m, o) {
        z <- torch_cat(list(x, self$emb(m)), dim = 2)
        ## O clamp evita que exp() estoure nas primeiras épocas, quando
        ## os pesos ainda são aleatórios; os limites são folgados o
        ## bastante para não restringir o modelo convergido.
        (self$corpo(z)$squeeze(2) + o)$clamp(-18, 5)
    })

######@> Perda de Poisson (deviance a menos de constante)...
perda_pois <- function(eta, y) {
    torch_mean(torch_exp(eta) - y * eta)
}

######@> Preparo dos tensores...
## O índice 1 do embedding é reservado ao município DESCONHECIDO. Ele
## não fica ocioso: durante o treino, 10% das observações têm a
## identidade municipal substituída por esse índice, de modo que a rede
## aprende uma representação de "município médio" e tem o que usar
## quando encontra, no esquema de blocos de municípios, um município que
## nunca viu. Sem esse mecanismo, a rede devolveria para o município
## desconhecido um vetor aleatório de inicialização.
tensores <- function(d, escala, mapa) {
    idx <- match(as.character(d$geocodigo), mapa)
    idx[is.na(idx)] <- 0
    list(x = torch_tensor(padroniza(as.matrix(d[, vars_ml]),
                                    escala$centro, escala$escala)$x),
         m = torch_tensor(as.integer(idx + 1), dtype = torch_long()),
         o = torch_tensor(as.numeric(d$log_area)),
         y = torch_tensor(as.numeric(d$EIA)))
}

ajusta_dl <- function(tr, semente = 42) {
    set.seed(semente)
    torch_manual_seed(semente)
    escala <- padroniza(as.matrix(tr[, vars_ml]))
    mapa <- sort(unique(as.character(tr$geocodigo)))
    ## Separação interna para a parada antecipada. Blocos de anos, e não
    ## sorteio de linhas: a validação interna precisa ser tão honesta
    ## quanto a externa, ou a época escolhida será a que melhor ajusta o
    ## ruído comum a treino e validação.
    anos_tr <- sort(unique(tr$ano))
    anos_val <- anos_tr[seq(1, length(anos_tr), by = 5)]
    val <- tr[tr$ano %in% anos_val, ]
    aju <- tr[!tr$ano %in% anos_val, ]
    if(nrow(val) < 30 || nrow(aju) < 60) {
        val <- tr
        aju <- tr
    }
    A <- tensores(aju, escala, mapa)
    V <- tensores(val, escala, mapa)
    vies0 <- log(max(mean(aju$EIA), 1e-3)) - mean(aju$log_area)
    mod <- rede_eia(length(vars_ml), length(mapa), vies0 = vies0)
    otim <- optim_adam(mod$parameters, lr = dl_taxa,
                       weight_decay = dl_decaimento)
    melhor <- Inf
    espera <- 0
    pesos <- NULL
    epoca_final <- 0
    for(ep in seq_len(dl_epocas_max)) {
        mod$train()
        otim$zero_grad()
        ## Descarte aleatório da identidade municipal (ver acima).
        mA <- as.integer(as.matrix(A$m))
        mA[runif(length(mA)) < 0.10] <- 1L
        eta <- mod(A$x, torch_tensor(mA, dtype = torch_long()), A$o)
        l <- perda_pois(eta, A$y)
        l$backward()
        otim$step()
        mod$eval()
        with_no_grad({
            lv <- as.numeric(perda_pois(mod(V$x, V$m, V$o), V$y))
        })
        if(is.finite(lv) && lv < melhor - 1e-6) {
            melhor <- lv
            espera <- 0
            pesos <- lapply(mod$state_dict(), function(z) z$clone())
            epoca_final <- ep
        } else {
            espera <- espera + 1
        }
        if(espera >= dl_paciencia) break
    }
    if(!is.null(pesos)) mod$load_state_dict(pesos)
    mod$eval()
    list(modelo = mod, escala = escala, mapa = mapa,
         epoca = epoca_final, perda_val = melhor)
}

preve_dl <- function(m, te) {
    T_ <- tensores(te, m$escala, m$mapa)
    m$modelo$eval()
    with_no_grad({
        p <- as.numeric(torch_exp(m$modelo(T_$x, T_$m, T_$o)))
    })
    p
}

mod_dl <- ajusta_dl(dm)

receitas[["Rede neural"]] <- list(familia = "Aprendizado profundo",
                                  ajusta = ajusta_dl, preve = preve_dl)

message("Etapa 14 - rede parada na época ", mod_dl$epoca,
        " (perda de validação ", sprintf("%.4f", mod_dl$perda_val), ")")

######@> Importância por permutação na rede...
## É a única medida de importância disponível para a rede, e é
## exatamente a mesma calculada para as demais famílias na Etapa 16 -
## o que torna os seis rankings comparáveis.
imp_dl <- importancia_perm(function(d) preve_dl(mod_dl, d),
                           dm, vars_ml, dm$EIA) %>%
    mutate(rotulo = rotular(variavel), bloco = bloco_de(variavel))

tabelas[["21_importancia_rede"]] <-
    salvar_tab(imp_dl %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_21_importancia_rede")

######@> Curva de aprendizado...
## Reajusta a rede uma vez registrando as duas perdas época a época.
## Serve de evidência de que o regime de treino está correto: a perda de
## validação deve descer e depois subir, e a parada antecipada deve
## ocorrer perto do mínimo. Uma curva de validação que só desce indicaria
## rede subtreinada; uma que sobe desde o início, sobreajuste imediato.
curva_dl <- local({
    set.seed(42); torch_manual_seed(42)
    escala <- padroniza(as.matrix(dm[, vars_ml]))
    mapa <- sort(unique(as.character(dm$geocodigo)))
    anos_tr <- sort(unique(dm$ano))
    anos_val <- anos_tr[seq(1, length(anos_tr), by = 5)]
    A <- tensores(dm[!dm$ano %in% anos_val, ], escala, mapa)
    V <- tensores(dm[dm$ano %in% anos_val, ], escala, mapa)
    vies0 <- log(mean(dm$EIA[!dm$ano %in% anos_val])) -
        mean(dm$log_area[!dm$ano %in% anos_val])
    mod <- rede_eia(length(vars_ml), length(mapa), vies0 = vies0)
    otim <- optim_adam(mod$parameters, lr = dl_taxa,
                       weight_decay = dl_decaimento)
    reg <- vector("list", min(dl_epocas_max, 2500))
    for(ep in seq_along(reg)) {
        mod$train(); otim$zero_grad()
        l <- perda_pois(mod(A$x, A$m, A$o), A$y)
        l$backward(); otim$step()
        mod$eval()
        with_no_grad({
            lv <- as.numeric(perda_pois(mod(V$x, V$m, V$o), V$y))
        })
        reg[[ep]] <- tibble(epoca = ep, treino = as.numeric(l),
                            validacao = lv)
    }
    bind_rows(reg)
})

fig13 <- curva_dl %>%
    pivot_longer(-epoca, names_to = "conjunto", values_to = "perda") %>%
    mutate(conjunto = ifelse(conjunto == "treino", "Ajuste",
                             "Validação interna")) %>%
    ggplot(aes(x = epoca, y = perda, colour = conjunto)) +
    geom_line(linewidth = 0.7) +
    geom_vline(xintercept = mod_dl$epoca, linetype = "dashed",
               colour = "grey30") +
    annotate("text", x = mod_dl$epoca, y = max(curva_dl$validacao),
             label = paste0("  parada antecipada (época ", mod_dl$epoca,
                            ")"),
             hjust = 0, size = 3, colour = "grey30") +
    scale_colour_manual(values = c(Ajuste = cores_familia[["Estatística"]],
                                   `Validação interna` = cores_familia[["Aprendizado profundo"]]),
                        name = NULL) +
    scale_y_log10() +
    labs(title = "Curva de aprendizado da rede neural",
         subtitle = paste("Perda de Poisson por época; escala",
                          "logarítmica"),
         x = "Época", y = "Perda de Poisson",
         caption = quebrar(paste(
             "A separação interna de validação usa BLOCOS DE ANOS, e não",
             "sorteio de linhas: se a validação que decide a época de",
             "parada compartilhasse anos com o ajuste, escolheria a",
             "época que melhor reproduz o ruído comum às duas partições",
             "e a parada antecipada perderia a função. O afastamento",
             "entre as duas curvas depois do ponto de parada é o",
             "sobreajuste que a parada evita - e com",
             fmt_int(sum(dm$EIA)), "eventos em", fmt_int(n_obs),
             "observações ele aparece cedo, o que justifica a",
             "regularização deliberadamente forte adotada nesta",
             "família.")))

salvar_fig(fig13, "Fig_13_curva_aprendizado", largura = 10, altura = 6)

########################################################################
######@> Etapa 15 - Comparação preditiva entre as três famílias...

message("Etapa 15 - executando a validação cruzada em blocos...")

######@> Execução do protocolo...
## Um único laço percorre os dois esquemas, os cinco blocos de cada um e
## os oito modelos do registro. Nenhum modelo vê a observação que vai
## prever, e todos veem exatamente os mesmos conjuntos de treino - que é
## a condição para que a comparação seja sobre os modelos e não sobre os
## dados que cada um recebeu.
##
## Uma ressalva honesta sobre a decomposição dentro/entre: as médias
## municipais dos componentes ENTRE são calculadas sobre a base
## completa, e não dentro de cada treino. Isso NÃO vaza informação da
## resposta - a decomposição usa apenas preditores - mas significa que
## os termos ENTRE do modelo estatístico conhecem a distribuição dos
## preditores nos municípios de teste. É o mesmo tipo de conhecimento
## que a padronização das variáveis dá a qualquer modelo, e a
## alternativa (recalcular as médias dentro de cada treino) produziria,
## no esquema de blocos de municípios, termos ENTRE indefinidos para os
## municípios do teste.
for(esquema in names(particoes)) {
    for(k in seq_along(particoes[[esquema]])) {
        idx_te <- particoes[[esquema]][[k]]
        treino <- dm[-idx_te, ]
        teste <- dm[idx_te, ]
        for(nome in names(receitas)) {
            r <- receitas[[nome]]
            ajuste <- try(r$ajusta(treino), silent = TRUE)
            if(inherits(ajuste, "try-error")) {
                message("  ! ", nome, " falhou em ", esquema,
                        " bloco ", k)
                next
            }
            p <- try(r$preve(ajuste, teste), silent = TRUE)
            if(inherits(p, "try-error") || length(p) != length(idx_te)) {
                message("  ! previsão de ", nome, " falhou em ",
                        esquema, " bloco ", k)
                next
            }
            previsoes[[esquema]][idx_te, nome] <- p
        }
        message("  ", esquema, " - bloco ", k, "/",
                length(particoes[[esquema]]), " concluído.")
    }
}

######@> Métricas fora da amostra...
desempenho <- map_dfr(names(particoes), function(esquema) {
    map_dfr(modelos_avaliados, function(nome) {
        p <- previsoes[[esquema]][[nome]]
        if(all(is.na(p))) return(NULL)
        metricas(nome, receitas[[nome]]$familia, esquema, dm$EIA, p)
    })
})

######@> Referências de comparação...
## Duas linhas de base, ambas indispensáveis para ler a tabela:
##   - TAXA CONSTANTE: prevê a mesma densidade de eventos por km2 para
##     todos. Um modelo que não a supere não aprendeu nada;
##   - MÉDIA HISTÓRICA DO MUNICÍPIO: prevê para cada município-ano a
##     média dos demais anos daquele município. Não usa clima nem uso da
##     terra - só a identidade. É a régua exigente, porque separa o que
##     os preditores ambientais acrescentam daquilo que já estava na
##     simples propensão histórica de cada município.
pred_constante <- rep(mean(dm$EIA / exp(dm$log_area)), nrow(dm)) *
    exp(dm$log_area)

pred_hist <- vapply(seq_len(nrow(dm)), function(i) {
    outros <- dm$geocodigo == dm$geocodigo[i] & seq_len(nrow(dm)) != i
    mean(dm$EIA[outros])
}, numeric(1))

referencias <- bind_rows(
    map_dfr(names(particoes), ~ metricas("Taxa constante", "Referência",
                                         .x, dm$EIA, pred_constante)),
    map_dfr(names(particoes), ~ metricas("Média histórica do município",
                                         "Referência", .x, dm$EIA,
                                         pred_hist)))

desempenho <- bind_rows(desempenho, referencias) %>%
    mutate(familia = factor(familia, levels = ordem_familias)) %>%
    arrange(esquema, desc(pseudo_r2))

tabelas[["22_desempenho_preditivo"]] <-
    salvar_tab(desempenho %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_22_desempenho_preditivo")

######@> Melhor modelo em cada esquema...
melhores <- desempenho %>%
    filter(familia != "Referência") %>%
    group_by(esquema) %>%
    slice_max(pseudo_r2, n = 1) %>%
    ungroup()

message("Etapa 15 - melhor por esquema:")
for(i in seq_len(nrow(melhores))) {
    message("  ", melhores$esquema[i], ": ", melhores$modelo[i],
            sprintf(" (pseudo-R2 = %.3f, AUC = %.3f)",
                    melhores$pseudo_r2[i], melhores$auc[i]))
}

######@> Figura 14 - a comparação...
ordem_mod <- desempenho %>%
    filter(esquema == "Blocos de anos") %>%
    arrange(pseudo_r2) %>%
    pull(modelo)

p14a <- desempenho %>%
    mutate(modelo = factor(modelo, levels = ordem_mod)) %>%
    ggplot(aes(x = pseudo_r2, y = modelo, fill = familia)) +
    geom_vline(xintercept = 0, colour = "grey40", linetype = "dashed") +
    geom_col(alpha = 0.9) +
    facet_wrap(~ esquema) +
    scale_fill_manual(values = cores_familia, name = "Família",
                      drop = FALSE) +
    labs(title = "Deviance explicada fora da amostra",
         subtitle = "Zero é o desempenho da taxa constante",
         x = "Pseudo-R2 de deviance", y = NULL)

p14b <- desempenho %>%
    mutate(modelo = factor(modelo, levels = ordem_mod)) %>%
    ggplot(aes(x = auc, y = modelo, fill = familia)) +
    geom_vline(xintercept = 0.5, colour = "grey40", linetype = "dashed") +
    geom_col(alpha = 0.9) +
    facet_wrap(~ esquema) +
    coord_cartesian(xlim = c(0.4, max(desempenho$auc, na.rm = TRUE) +
                                 0.02)) +
    scale_fill_manual(values = cores_familia, name = "Família",
                      drop = FALSE) +
    labs(title = "Capacidade de ordenar município-anos",
         subtitle = "AUC; 0,5 é o acaso",
         x = "Área sob a curva ROC", y = NULL)

fig14 <- p14a / p14b +
    plot_layout(guides = "collect") +
    plot_annotation(
        title = "Desempenho preditivo das três famílias",
        subtitle = paste("Validação cruzada em blocos;",
                         "nenhum modelo prevê observação que viu no",
                         "treino"),
        caption = quebrar(paste(
            "Os dois esquemas respondem a perguntas diferentes e devem",
            "ser lidos separadamente. BLOCOS DE ANOS pergunta se o",
            "modelo prevê um ano que não viu, mantendo todos os",
            "municípios no treino - é o cenário de previsão sazonal.",
            "BLOCOS DE MUNICÍPIOS reserva trechos contíguos de litoral e",
            "pergunta se o modelo prevê um município inteiramente",
            "ausente do treino - é o cenário de transferência para",
            "território não observado, e é severo justamente porque",
            "exige que a generalização venha das características",
            "ambientais e de uso da terra, e não da identidade do",
            "município. A referência 'média histórica do município'",
            "separa o que os preditores acrescentam daquilo que a",
            "propensão histórica já entregava sozinha.")) &
        theme(legend.position = "bottom"))

salvar_fig(fig14, "Fig_14_desempenho_familias", largura = 13,
           altura = 10)

######@> Figura 15 - calibração...
## Compara previsão e observação em faixas de risco previsto. Um modelo
## bem calibrado põe os pontos sobre a diagonal; um modelo que ordena
## bem mas prevê mal - situação comum em aprendizado de máquina com
## resposta rara - tem AUC alto e pontos fora da diagonal, e isso muda o
## que se pode fazer com ele.
calibracao <- map_dfr(names(particoes), function(esquema) {
    map_dfr(modelos_avaliados, function(nome) {
        p <- previsoes[[esquema]][[nome]]
        if(all(is.na(p))) return(NULL)
        tibble(esquema = esquema, modelo = nome, pred = p, obs = dm$EIA) %>%
            filter(is.finite(pred)) %>%
            mutate(faixa = ntile(pred, 10)) %>%
            group_by(esquema, modelo, faixa) %>%
            summarise(pred = mean(pred), obs = mean(obs), n = n(),
                      .groups = "drop")
    })
}) %>%
    left_join(desempenho %>% distinct(modelo, familia), by = "modelo")

fig15 <- calibracao %>%
    ggplot(aes(x = pred, y = obs, colour = familia)) +
    geom_abline(slope = 1, intercept = 0, linetype = "dashed",
                colour = "grey40") +
    geom_line(aes(group = interaction(modelo, esquema)), alpha = 0.5,
              linewidth = 0.5) +
    geom_point(size = 1.6, alpha = 0.9) +
    facet_grid(esquema ~ modelo) +
    scale_colour_manual(values = cores_familia, name = "Família",
                        drop = FALSE) +
    scale_x_continuous(trans = "sqrt") +
    scale_y_continuous(trans = "sqrt") +
    labs(title = "Calibração das previsões fora da amostra",
         subtitle = paste("Decis de risco previsto; médias observada e",
                          "prevista em cada decil"),
         x = "Média prevista no decil (raiz quadrada)",
         y = "Média observada no decil (raiz quadrada)",
         caption = quebrar(paste(
             "Pontos sobre a diagonal indicam previsões calibradas: o",
             "decil ao qual o modelo atribui taxa 0,8 tem, de fato,",
             "0,8 evento por município-ano em média. Um modelo pode",
             "ordenar bem e calibrar mal - AUC alto com pontos fora da",
             "diagonal - e a distinção importa para o uso: ordenar bem",
             "basta para priorizar municípios, mas calibrar bem é",
             "necessário para estimar quantos eventos esperar.")) +
    theme(axis.text = element_text(size = 6),
          strip.text = element_text(size = 7)))

salvar_fig(fig15, "Fig_15_calibracao", largura = 16, altura = 7)

########################################################################
######@> Etapa 16 - Importância consolidada dos preditores...

message("Etapa 16 - consolidando as importâncias...")

######@> Uma única medida para as seis abordagens...
## As medidas nativas de importância não são comparáveis entre si: o
## valor-z de um GLMM, o ganho de um boosting e o aumento de deviance de
## uma floresta medem coisas diferentes em escalas diferentes. A
## importância por PERMUTAÇÃO resolve isso - embaralha uma coluna e mede
## quanto a deviance piora - e pode ser calculada exatamente do mesmo
## modo em qualquer modelo que saiba prever. É ela que sustenta a
## consolidação abaixo.
##
## Para os modelos estatísticos a permutação é feita sobre os
## COMPONENTES (x_W e x_B), e o resultado é somado por variável de
## origem, de modo que "cobertura florestal" receba uma única
## importância comparável à das demais famílias.
perm_modelo <- function(prever, dados, vars) {
    importancia_perm(prever, dados, vars, dados$EIA)
}

imp_glmm <- perm_modelo(function(d)
    as.numeric(predict(mod_we, newdata = d, type = "response",
                       allow.new.levels = TRUE)),
    dm, termos_mod)

imp_gam <- perm_modelo(function(d) receitas[["GAM"]]$preve(mod_gam, d),
                       dm, c(termos_mod, "lon_centroide",
                             "lat_centroide"))

imp_net <- perm_modelo(function(d)
    as.numeric(predict(cv_net, newx = as.matrix(d[, termos_mod]),
                       s = "lambda.1se", newoffset = d$log_area,
                       type = "response")),
    dm, termos_mod)

imp_rf_perm <- perm_modelo(function(d) preve_rf(mod_rf, d), dm, vars_rf)
imp_xgb_perm <- perm_modelo(function(d) preve_xgb(mod_xgb, d), dm,
                            vars_xgb)

######@> Agregação por variável de origem...
## Colapsa x_W e x_B em x, somando os ganhos. Uma variável cujo efeito
## está todo na escala entre e outra cujo efeito está todo na escala
## dentro passam a ser comparáveis pelo total que cada uma contribui.
## O ajuste de nomes existe porque as duas metades do script chamam as
## mesmas variáveis de modo diferente: os modelos estatísticos carregam
## a posição como lat_B (componente ENTRE da latitude) e o tempo como
## ano_z (padronizado), enquanto as famílias de aprendizado recebem
## lat_centroide e ano em escala original. Sem uniformizar, cada uma
## dessas variáveis apareceria como DUAS linhas do consenso, cada uma
## avaliada por metade das abordagens - e, como o rótulo legível é o
## mesmo nos dois casos, o eixo da figura ficaria com níveis duplicados.
padroniza_origem <- function(x) {
    x <- sub("_(W|B)$", "", x)
    troca <- c(lat = "lat_centroide", lon = "lon_centroide",
               ano_z = "ano")
    ifelse(x %in% names(troca), troca[x], x)
}

por_origem <- function(imp, rotulo_modelo, familia) {
    imp %>%
        mutate(origem = padroniza_origem(variavel)) %>%
        group_by(origem) %>%
        summarise(ganho = sum(pmax(ganho, 0)), .groups = "drop") %>%
        mutate(modelo = rotulo_modelo, familia = familia,
               importancia = ganho / max(ganho))
}

importancias <- bind_rows(
    por_origem(imp_glmm, "GLMM dentro/entre", "Estatística"),
    por_origem(imp_gam, "GAM", "Estatística"),
    por_origem(imp_net, "Elastic net", "Estatística"),
    por_origem(imp_rf_perm, "Random forest", "Aprendizado de máquina"),
    por_origem(imp_xgb_perm, "Gradient boosting",
               "Aprendizado de máquina"),
    por_origem(imp_dl, "Rede neural", "Aprendizado profundo")) %>%
    mutate(rotulo = rotular(origem), bloco = bloco_de(origem),
           familia = factor(familia, levels = ordem_familias))

######@> Ranking consensual...
## O consenso usa o RANK médio, e não a importância média, por uma razão
## específica: as escalas de importância diferem entre modelos - o
## boosting concentra quase toda a importância em duas variáveis, a rede
## a distribui - e a média das importâncias seria dominada pelos modelos
## de distribuição mais achatada. O rank é invariante a essa diferença.
## A coluna de discordância registra o desvio-padrão dos ranks: valores
## altos identificam variáveis sobre as quais as abordagens NÃO
## concordam, e são elas, não as consensuais, que merecem exame.
consenso <- importancias %>%
    group_by(modelo) %>%
    mutate(posicao = rank(-importancia, ties.method = "average")) %>%
    ungroup() %>%
    group_by(origem, rotulo, bloco) %>%
    summarise(rank_medio = mean(posicao),
              rank_dp = sd(posicao),
              importancia_media = mean(importancia),
              n_modelos = n(),
              vezes_no_top5 = sum(posicao <= 5),
              .groups = "drop") %>%
    arrange(rank_medio) %>%
    mutate(posicao_consenso = row_number())

tabelas[["23_importancia_consolidada"]] <-
    salvar_tab(consenso %>%
               mutate(across(where(is.numeric), ~ round(.x, 3))),
               "Tab_23_importancia_consolidada")

tabelas[["24_importancia_por_modelo"]] <-
    salvar_tab(importancias %>%
               select(modelo, familia, origem, rotulo, bloco, ganho,
                      importancia) %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_24_importancia_por_modelo")

message("Etapa 16 - cinco primeiras no consenso: ",
        paste(head(consenso$rotulo, 5), collapse = "; "))

######@> Figura 16 - o que as seis abordagens dizem...
ordem_consenso <- consenso %>% arrange(rank_medio) %>% pull(rotulo)

p16a <- importancias %>%
    mutate(rotulo = factor(rotulo, levels = rev(ordem_consenso))) %>%
    ggplot(aes(x = modelo, y = rotulo, fill = importancia)) +
    geom_tile(colour = "white", linewidth = 0.3) +
    scale_fill_viridis_c(option = "magma", direction = -1,
                         name = "Importância\nrelativa") +
    labs(title = "Importância por permutação em cada abordagem",
         subtitle = "Normalizada pela variável mais importante do modelo",
         x = NULL, y = NULL) +
    theme(axis.text.x = element_text(angle = 25, hjust = 1))

p16b <- consenso %>%
    ggplot(aes(x = rank_medio, y = reorder(rotulo, -rank_medio),
               colour = bloco)) +
    geom_segment(aes(x = rank_medio - rank_dp, xend = rank_medio + rank_dp,
                     yend = reorder(rotulo, -rank_medio)),
                 linewidth = 0.6, alpha = 0.6) +
    geom_point(aes(size = vezes_no_top5)) +
    scale_colour_manual(values = cores_bloco, name = "Bloco") +
    scale_size_continuous(range = c(1.5, 4.5),
                          name = "Vezes entre\nas cinco primeiras") +
    labs(title = "Ranking consensual",
         subtitle = paste("Rank médio nas seis abordagens; a barra é o",
                          "desvio-padrão dos ranks"),
         x = "Posição média (menor é mais importante)", y = NULL)

fig16 <- p16a + p16b +
    plot_annotation(
        title = "O que as três famílias concordam em considerar importante",
        caption = quebrar(paste(
            "Todas as importâncias vêm do mesmo procedimento -",
            "embaralhar a coluna e medir o aumento da deviance -",
            "repetido", n_perm, "vezes por variável, o que é a única",
            "forma de comparar um modelo misto, uma floresta e uma rede",
            "na mesma escala. Nos modelos estatísticos a permutação é",
            "feita sobre os componentes dentro e entre separadamente e",
            "os ganhos são somados por variável de origem. A barra",
            "horizontal do painel da direita mede DISCORDÂNCIA entre as",
            "abordagens: variáveis com barra longa são aquelas cuja",
            "importância depende do tipo de modelo, e merecem mais",
            "atenção do que as consensuais.")))

salvar_fig(fig16, "Fig_16_importancia_consolidada", largura = 15,
           altura = 9)

########################################################################
######@> Etapa 17 - Formas funcionais: efeitos parciais e Shapley...

message("Etapa 17 - calculando efeitos parciais...")

######@> Variáveis levadas ao exame detalhado...
## As seis primeiras do consenso. O critério é deliberadamente o do
## consenso, e não o do melhor modelo: examinar em detalhe apenas o que
## o modelo campeão destaca seria circular.
top_vars <- head(consenso$origem, 6)

######@> Dependência parcial...
## Varre a faixa de valores de um preditor, fixa cada observação nesse
## valor e faz a MÉDIA das previsões sobre todas as observações. O
## resultado é o efeito daquele preditor com os demais mantidos em sua
## distribuição real - e não em uma média artificial, que é o que faz o
## efeito parcial de um GLM. A vantagem é que o mesmo procedimento se
## aplica a qualquer modelo, o que torna a floresta, o boosting e a rede
## diretamente comparáveis à curva do GAM.
##
## A ressalva usual vale aqui: onde há correlação forte entre
## preditores, a dependência parcial avalia combinações que não ocorrem
## na natureza. A poda da Etapa 04 reduziu esse risco, mas não o
## eliminou - e é por isso que a faixa varrida é limitada aos percentis
## 5 e 95, e não ao intervalo completo.
dependencia_parcial <- function(prever, dados, v, n = 40) {
    grade <- seq(quantile(dados[[v]], 0.05, na.rm = TRUE),
                 quantile(dados[[v]], 0.95, na.rm = TRUE),
                 length.out = n)
    map_dfr(grade, function(g) {
        d <- dados
        d[[v]] <- g
        tibble(variavel = v, x = g, taxa = mean(prever(d), na.rm = TRUE))
    })
}

modelos_pdp <- list(
    `GAM` = function(d) receitas[["GAM"]]$preve(mod_gam, d),
    `Random forest` = function(d) preve_rf(mod_rf, d),
    `Gradient boosting` = function(d) preve_xgb(mod_xgb, d),
    `Rede neural` = function(d) preve_dl(mod_dl, d))

pdp <- map_dfr(names(modelos_pdp), function(nome) {
    map_dfr(intersect(top_vars, vars_ml), function(v) {
        dependencia_parcial(modelos_pdp[[nome]], dm, v) %>%
            mutate(modelo = nome)
    })
})

if(nrow(pdp) > 0) {
    pdp <- pdp %>%
        mutate(rotulo = rotular(variavel),
               familia = case_when(
                   modelo == "GAM" ~ "Estatística",
                   modelo == "Rede neural" ~ "Aprendizado profundo",
                   TRUE ~ "Aprendizado de máquina"),
               familia = factor(familia, levels = ordem_familias))

    tabelas[["25_dependencia_parcial"]] <-
        salvar_tab(pdp %>%
                   mutate(across(where(is.numeric), ~ round(.x, 5))),
                   "Tab_25_dependencia_parcial")

    fig17 <- pdp %>%
        ggplot(aes(x = x, y = taxa, colour = modelo)) +
        geom_line(linewidth = 0.8) +
        facet_wrap(~ rotulo, scales = "free", ncol = 3) +
        scale_colour_manual(values = c(
            `GAM` = cores_familia[["Estatística"]],
            `Random forest` = "#D55E00",
            `Gradient boosting` = "#CC79A7",
            `Rede neural` = cores_familia[["Aprendizado profundo"]]),
            name = NULL) +
        labs(title = "Dependência parcial nas variáveis do consenso",
             subtitle = paste("Taxa média prevista de eventos por",
                              "município-ano, com os demais preditores",
                              "na distribuição observada"),
             x = "Valor do preditor", y = "Eventos esperados",
             caption = quebrar(paste(
                 "Quatro modelos de três famílias respondendo à mesma",
                 "pergunta. Onde as quatro curvas coincidem, a relação é",
                 "robusta à escolha de modelo e pode ser interpretada",
                 "com confiança. Onde divergem, a forma depende do que",
                 "cada família consegue representar - e a divergência",
                 "costuma aparecer nas caudas, onde há poucas",
                 "observações. A faixa varrida vai do percentil 5 ao 95",
                 "de cada preditor: extrapolar além disso avaliaria",
                 "combinações de valores que não ocorrem na base.")))

    salvar_fig(fig17, "Fig_17_dependencia_parcial", largura = 13,
               altura = 8)
}

######@> Figura 18 - contribuições de Shapley...
## O eixo horizontal é a contribuição da variável para AQUELE
## município-ano, na escala do log da taxa; a cor é o valor da própria
## variável. Uma nuvem que vai do azul à esquerda ao vermelho à direita
## indica efeito monótono crescente; uma nuvem em que as duas cores se
## misturam nos dois lados indica que o efeito depende do contexto, isto
## é, há interação.
vars_shap <- head(imp_shap$variavel, 12)

fig18 <- shap_df %>%
    filter(variavel %in% vars_shap) %>%
    mutate(rotulo = factor(rotulo,
                           levels = rev(rotular(vars_shap)))) %>%
    ggplot(aes(x = shap, y = rotulo, colour = valor_rel)) +
    geom_vline(xintercept = 0, colour = "grey40", linetype = "dashed") +
    geom_jitter(height = 0.22, size = 0.5, alpha = 0.45) +
    scale_colour_gradient(low = "#2166AC", high = "#B2182B",
                          breaks = c(0, 1),
                          labels = c("baixo", "alto"),
                          name = "Valor da\nvariável") +
    labs(title = "Contribuição de cada preditor, município-ano a município-ano",
         subtitle = paste("Valores de Shapley do gradient boosting, na",
                          "escala do logaritmo da taxa"),
         x = "Contribuição para a previsão", y = NULL,
         caption = quebrar(paste(
             "Cada ponto é um município-ano. A posição horizontal diz",
             "quanto aquele preditor empurrou a previsão para cima ou",
             "para baixo NAQUELE caso; a cor diz se o valor do preditor",
             "era alto ou baixo. Uma nuvem que passa do azul à esquerda",
             "ao vermelho à direita é um efeito monótono crescente. Onde",
             "as duas cores aparecem dos dois lados do zero, o efeito",
             "muda de sinal conforme o contexto - assinatura de",
             "interação com outro preditor, que é justamente o tipo de",
             "estrutura que o modelo aditivo da Etapa 08 não pode",
             "representar. Para modelos de árvores a decomposição é",
             "exata, e não uma aproximação por amostragem.")))

salvar_fig(fig18, "Fig_18_shapley", largura = 11, altura = 8)

########################################################################
######@> Etapa 18 - O embedding municipal e a tipologia aprendida...

message("Etapa 18 - inspecionando o embedding municipal...")

######@> Extração do embedding...
## As coordenadas aprendidas para cada município. Não foram supervisadas
## por nenhuma tipologia: a rede as ajustou apenas para minimizar a
## deviance, e qualquer estrutura que apareça foi induzida pelos dados.
## A primeira linha é o município desconhecido e é descartada.
emb_mat <- as.matrix(mod_dl$modelo$emb$weight)[-1, , drop = FALSE]
rownames(emb_mat) <- mod_dl$mapa
colnames(emb_mat) <- paste0("dim", seq_len(ncol(emb_mat)))

embedding <- as.data.frame(emb_mat) %>%
    tibble::rownames_to_column("geocodigo") %>%
    left_join(dm %>%
              group_by(geocodigo) %>%
              summarise(municipio = as.character(first(municipio)),
                        EIA = sum(EIA), area = first(area_km2),
                        lat = first(lat_centroide),
                        lon = first(lon_centroide),
                        urb = mean(urb_pct), flo = mean(flo_pct),
                        chuva = mean(clim_tp_ano, na.rm = TRUE),
                        .groups = "drop"),
              by = "geocodigo") %>%
    mutate(dens = 1000 * EIA / area / n_anos)

######@> Agrupamento no espaço aprendido...
## O número de perfis é escolhido pela silhueta média, e não fixado.
## Silhueta abaixo de 0,25 indicaria que não há agrupamento a extrair -
## e essa também seria uma resposta legítima, que o script reporta em
## vez de esconder.
d_emb <- dist(scale(emb_mat))

avaliacao_k <- map_dfr(2:6, function(k) {
    p <- pam(d_emb, k = k)
    tibble(k = k, silhueta = p$silinfo$avg.width)
})

k_melhor <- avaliacao_k$k[which.max(avaliacao_k$silhueta)]
part_emb <- pam(d_emb, k = k_melhor)

embedding$perfil <- factor(paste("Perfil", part_emb$clustering))

######@> Caracterização dos perfis...
perfis <- embedding %>%
    group_by(perfil) %>%
    summarise(n = n(),
              `Eventos (total)` = sum(EIA),
              `Densidade (por 1.000 km2 ao ano)` = mean(dens),
              `Área média (km2)` = mean(area),
              `Latitude média` = mean(lat),
              `Urbanização média (%)` = mean(urb),
              `Floresta média (%)` = mean(flo),
              `Chuva anual média (mm)` = mean(chuva),
              Municípios = paste(sort(municipio), collapse = ", "),
              .groups = "drop")

tabelas[["26_perfis_embedding"]] <-
    salvar_tab(perfis %>%
               mutate(across(where(is.numeric), ~ round(.x, 2))),
               "Tab_26_perfis_embedding")

tabelas[["27_embedding_municipal"]] <-
    salvar_tab(embedding %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_27_embedding_municipal")

message("Etapa 18 - ", k_melhor, " perfis (silhueta ",
        sprintf("%.3f", max(avaliacao_k$silhueta)), ")")

######@> Figura 19 - o espaço aprendido...
cores_perfil <- setNames(
    c("#0072B2", "#D55E00", "#009E73", "#E69F00", "#CC79A7",
      "#56B4E9")[seq_len(k_melhor)],
    levels(embedding$perfil))

p19a <- embedding %>%
    ggplot(aes(x = dim1, y = dim2, colour = perfil)) +
    geom_hline(yintercept = 0, colour = "grey85", linewidth = 0.3) +
    geom_vline(xintercept = 0, colour = "grey85", linewidth = 0.3) +
    geom_point(aes(size = dens), alpha = 0.85) +
    geom_text_repel(aes(label = municipio), size = 2.5,
                    max.overlaps = 40, show.legend = FALSE,
                    segment.colour = "grey80") +
    scale_colour_manual(values = cores_perfil, name = NULL) +
    scale_size_continuous(range = c(1.5, 6),
                          name = "Eventos por\n1.000 km2 ao ano") +
    labs(title = "As duas primeiras dimensões do embedding",
         subtitle = paste("Representação aprendida pela rede sem",
                          "supervisão de qualquer tipologia"),
         x = "Dimensão 1", y = "Dimensão 2")

p19b <- embedding %>%
    ggplot(aes(x = dim1, y = lat, colour = perfil)) +
    geom_point(size = 2.6, alpha = 0.9) +
    geom_smooth(method = "lm", formula = y ~ x, se = FALSE,
                colour = "grey45", linewidth = 0.6) +
    scale_colour_manual(values = cores_perfil, guide = "none") +
    labs(title = "Dimensão 1 e posição no litoral",
         subtitle = sprintf("Correlação de Spearman: %+.2f",
                            cor(embedding$dim1, embedding$lat,
                                method = "spearman")),
         x = "Dimensão 1", y = "Latitude do centroide")

p19c <- avaliacao_k %>%
    ggplot(aes(x = k, y = silhueta)) +
    geom_line(colour = cores_familia[["Aprendizado profundo"]],
              linewidth = 0.8) +
    geom_point(size = 2.4, colour = cores_familia[["Aprendizado profundo"]]) +
    geom_point(data = avaliacao_k %>% filter(k == k_melhor), size = 4,
               shape = 21, stroke = 1.2,
               colour = cores_familia[["Aprendizado profundo"]],
               fill = NA) +
    scale_x_continuous(breaks = 2:6) +
    labs(title = "Número de perfis",
         subtitle = "Silhueta média; o círculo marca o valor adotado",
         x = "Número de grupos", y = "Silhueta média")

fig19 <- p19a / (p19b + p19c) +
    plot_layout(heights = c(1.7, 1)) +
    plot_annotation(
        title = "A tipologia que a rede aprendeu sozinha",
        caption = quebrar(paste(
            "A camada de embedding substitui as 35 variáveis",
            "indicadoras de município por um vetor de", dl_dim_emb,
            "coordenadas aprendidas durante o treino. Nada na função de",
            "perda pede que municípios parecidos fiquem próximos: a",
            "proximidade emerge porque municípios com o mesmo regime",
            "de resposta ao clima e ao uso da terra se beneficiam de",
            "compartilhar parâmetros. O painel do meio confronta a",
            "primeira dimensão com a latitude - se a correlação for",
            "alta, a rede redescobriu o gradiente do litoral por conta",
            "própria, que é a estrutura que a análise exploratória",
            "havia identificado como principal eixo de organização do",
            "território.")))

salvar_fig(fig19, "Fig_19_embedding_municipal", largura = 12,
           altura = 13)

########################################################################
######@> Etapa 19 - Análises de sensibilidade...

message("Etapa 19 - análises de sensibilidade...")

######@> (a) O período posterior à consolidação do S2iD...
## Se as conclusões dependerem do trecho anterior a 2012 - aquele em que
## o sistema de registro ainda estava se consolidando - elas são frágeis.
## O custo do teste é alto: o recorte descarta dois terços da série e
## deixa 13 anos. É por isso que ele é sensibilidade, e não o modelo
## principal.
dm_recente <- dm %>% filter(ano >= ano_corte_s2id) %>% droplevels()

mod_recente <- try(glmmTMB(f_mista, family = poisson, data = dm_recente),
                   silent = TRUE)

######@> (b) Controle explícito da capacidade de registro...
## Acrescenta, como covariável, o número de eventos de OUTROS tipos
## registrados no mesmo município-ano. É um controle poderoso do esforço
## de registro - município que registra vendaval também registra
## enxurrada - mas é endógeno: trata-se de um desfecho, não de uma causa,
## e condicionar nele pode enviesar os demais coeficientes. Entra aqui,
## e apenas aqui, para verificar se as conclusões sobrevivem ao controle
## mais severo possível do viés administrativo.
dm$outros_z <- as.numeric(scale(dm$outros_ev))
f_registro <- as.formula(paste("EIA ~", paste(termos_mod, collapse = " + "),
                               "+ outros_z + offset(log_area)",
                               "+ (1 | municipio)"))
mod_registro <- try(glmmTMB(f_registro, family = poisson, data = dm),
                    silent = TRUE)

######@> (c) Suscetibilidade urbana do MapBiomas...
## A variável mais diretamente ligada ao objetivo - área urbana em
## suscetibilidade a inundação, alagamento ou enxurrada - não está
## disponível em dois municípios, e por isso não pode entrar no modelo
## principal sem reduzir a amostra. Entra aqui, no subconjunto em que
## existe, para responder se a suscetibilidade mapeada acrescenta algo
## ao que a fração urbanizada já diz.
## O droplevels não é cosmético: São João do Sul não tem a variável em
## nenhum ano e sai inteiro do subconjunto, e um nível de fator sem
## observação faria o glmmTMB estimar um efeito aleatório vazio.
dm_risco <- dm %>%
    filter(!is.na(risco_pct)) %>%
    droplevels() %>%
    group_by(geocodigo) %>%
    mutate(risco_B = mean(risco_pct)) %>%
    ungroup() %>%
    mutate(risco_B = as.numeric(scale(risco_B)))

f_risco <- as.formula(paste("EIA ~", paste(termos_mod, collapse = " + "),
                            "+ risco_B + offset(log_area)",
                            "+ (1 | municipio)"))
mod_risco <- try(glmmTMB(f_risco, family = poisson, data = dm_risco),
                 silent = TRUE)
mod_risco_sem <- try(glmmTMB(f_mista, family = poisson, data = dm_risco),
                     silent = TRUE)

######@> (d) Offset alternativo: a mancha urbana...
## A área do município é o denominador natural da exposição, mas não o
## único defensável: enxurrada, inundação e alagamento só viram REGISTRO
## onde há gente. Substituir a área total pela área urbanizada testa se
## a escolha do denominador muda as conclusões.
dm$log_urb <- log(pmax(dm$urb_pct / 100 * dm$area_km2, 0.5))
f_offurb <- as.formula(paste("EIA ~", paste(termos_mod, collapse = " + "),
                             "+ offset(log_urb) + (1 | municipio)"))
mod_offurb <- try(glmmTMB(f_offurb, family = poisson, data = dm),
                  silent = TRUE)

######@> (e) Cada tipo em separado...
## O agregado é dominado pelas enxurradas. Ajustar os três tipos
## separadamente responde se o modelo do agregado descreve os três ou
## apenas o mais numeroso.
modelos_tipo <- map(c(Enxurradas = "enxurradas",
                      Inundações = "inundacoes",
                      Alagamentos = "alagamentos"), function(v) {
    d <- dm
    d$y <- d[[v]]
    f <- as.formula(paste("y ~", paste(termos_mod, collapse = " + "),
                          "+ offset(log_area) + (1 | municipio)"))
    try(glmmTMB(f, family = poisson, data = d), silent = TRUE)
})

######@> Reunião dos coeficientes de todas as variantes...
extrai_coef <- function(m, rotulo, n_usado) {
    if(inherits(m, "try-error") || is.null(m)) return(NULL)
    s <- summary(m)$coefficients$cond
    tibble(variante = rotulo, n = n_usado, termo = rownames(s),
           estimativa = s[, 1], erro = s[, 2], z = s[, 3], p = s[, 4]) %>%
        filter(termo != "(Intercept)")
}

sensibilidade <- bind_rows(
    extrai_coef(mod_we, "Modelo principal", nrow(dm)),
    extrai_coef(mod_recente,
                paste0("Só ", ano_corte_s2id, "-", ano_fim),
                nrow(dm_recente)),
    extrai_coef(mod_registro, "Com controle de registro", nrow(dm)),
    extrai_coef(mod_risco, "Com suscetibilidade urbana", nrow(dm_risco)),
    extrai_coef(mod_offurb, "Offset de mancha urbana", nrow(dm)),
    extrai_coef(modelos_tipo$Enxurradas, "Só enxurradas", nrow(dm)),
    extrai_coef(modelos_tipo$Inundações, "Só inundações", nrow(dm)),
    extrai_coef(modelos_tipo$Alagamentos, "Só alagamentos", nrow(dm))) %>%
    mutate(rotulo = rotular(termo), bloco = bloco_de(termo),
           rr = exp(estimativa), significativo = p < alfa)

tabelas[["28_sensibilidade"]] <-
    salvar_tab(sensibilidade %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_28_sensibilidade")

######@> Estabilidade dos termos entre variantes...
## Um termo cujo sinal muda de uma variante para outra não sustenta
## conclusão. A tabela abaixo é o resumo dessa verificação, e é dela que
## sai a lista de achados robustos citada no relatório de síntese.
estabilidade <- sensibilidade %>%
    filter(termo %in% termos_mod) %>%
    group_by(termo, rotulo, bloco) %>%
    summarise(variantes = n(),
              sinal_positivo = sum(estimativa > 0),
              vezes_significativo = sum(significativo),
              estimativa_media = mean(estimativa),
              amplitude = diff(range(estimativa)),
              .groups = "drop") %>%
    mutate(sinal_estavel = sinal_positivo == 0 |
               sinal_positivo == variantes,
           robusto = sinal_estavel & vezes_significativo >= variantes / 2) %>%
    arrange(desc(robusto), desc(vezes_significativo))

tabelas[["29_estabilidade_termos"]] <-
    salvar_tab(estabilidade %>%
               mutate(across(where(is.numeric), ~ round(.x, 4))),
               "Tab_29_estabilidade_termos")

termos_robustos <- estabilidade %>% filter(robusto) %>% pull(rotulo)

message("Etapa 19 - termos robustos a todas as variantes: ",
        length(termos_robustos))

######@> Ganho da suscetibilidade urbana...
ganho_risco <- if(!inherits(mod_risco, "try-error") &&
                  !inherits(mod_risco_sem, "try-error")) {
                   AIC(mod_risco_sem) - AIC(mod_risco)
               } else NA_real_

######@> Figura 20 - a sensibilidade termo a termo...
termos_mostrar <- estabilidade %>%
    arrange(desc(vezes_significativo), desc(abs(estimativa_media))) %>%
    head(14) %>%
    pull(termo)

fig20 <- sensibilidade %>%
    filter(termo %in% termos_mostrar) %>%
    mutate(variante = factor(variante,
                             levels = c("Modelo principal",
                                        paste0("Só ", ano_corte_s2id,
                                               "-", ano_fim),
                                        "Com controle de registro",
                                        "Com suscetibilidade urbana",
                                        "Offset de mancha urbana",
                                        "Só enxurradas", "Só inundações",
                                        "Só alagamentos")),
           rotulo = factor(rotulo,
                           levels = rev(rotular(termos_mostrar)))) %>%
    ggplot(aes(x = estimativa, y = rotulo, colour = variante,
               alpha = significativo)) +
    geom_vline(xintercept = 0, linetype = "dashed", colour = "grey40") +
    geom_errorbarh(aes(xmin = estimativa - 1.96 * erro,
                       xmax = estimativa + 1.96 * erro),
                   height = 0, linewidth = 0.4,
                   position = position_dodge(width = 0.75)) +
    geom_point(size = 1.9, position = position_dodge(width = 0.75)) +
    scale_colour_viridis_d(option = "turbo", end = 0.9, name = NULL) +
    scale_alpha_manual(values = c(`TRUE` = 1, `FALSE` = 0.3),
                       guide = "none") +
    labs(title = "As conclusões dependem das escolhas do desenho?",
         subtitle = paste("Coeficientes sob oito variantes do modelo;",
                          "intervalos de 95%"),
         x = "Coeficiente (log da razão de taxas)", y = NULL,
         caption = quebrar(paste(
             "Cada variante altera uma decisão do desenho e mantém as",
             "demais. Restringir a", paste0(ano_corte_s2id, "-", ano_fim),
             "testa a dependência do trecho em que o sistema de registro",
             "ainda se consolidava; o controle de registro acrescenta o",
             "número de eventos de outros tipos como covariável, que é",
             "o controle mais severo possível do esforço administrativo",
             "- e também endógeno, razão de não estar no modelo",
             "principal; o offset de mancha urbana troca o denominador",
             "de exposição; e as três últimas ajustam cada tipo em",
             "separado, verificando se o agregado descreve os três ou",
             "apenas as enxurradas, que respondem por dois terços dele.",
             "Termos cujo intervalo cruza o zero em algumas variantes e",
             "não em outras não sustentam conclusão.")))

salvar_fig(fig20, "Fig_20_sensibilidade", largura = 13, altura = 9)

########################################################################
######@> Etapa 20 - Mapas...

message("Etapa 20 - produzindo os mapas...")

######@> Síntese municipal de observado, previsto e resíduo...
## As previsões usadas aqui são as FORA DA AMOSTRA do esquema de blocos
## de municípios - as mais honestas de que se dispõe, porque cada
## município foi previsto por um modelo que não o viu. O resíduo é a
## diferença entre o observado e essa previsão, e identifica onde o
## conjunto de características ambientais e de uso da terra não dá conta
## do que se registra.
melhor_mun <- desempenho %>%
    filter(esquema == "Blocos de municípios", familia != "Referência") %>%
    slice_max(pseudo_r2, n = 1) %>%
    pull(modelo)

sintese_mun <- dm %>%
    mutate(prev_glmm = previsoes[["Blocos de municípios"]][["GLMM dentro/entre"]],
           prev_melhor = previsoes[["Blocos de municípios"]][[melhor_mun]],
           prev_dentro = fitted(mod_we)) %>%
    group_by(geocodigo, municipio) %>%
    summarise(obs = sum(EIA),
              prev = sum(prev_melhor, na.rm = TRUE),
              prev_dentro = sum(prev_dentro),
              area = first(area_km2),
              chuva = mean(clim_tp3_max, na.rm = TRUE),
              urb = mean(urb_pct),
              .groups = "drop") %>%
    mutate(dens_obs = 1000 * obs / area / n_anos,
           dens_prev = 1000 * prev / area / n_anos,
           residuo = obs - prev,
           residuo_rel = ifelse(prev > 0, (obs - prev) / prev, NA_real_))

tabelas[["30_sintese_municipal"]] <-
    salvar_tab(sintese_mun %>%
               mutate(across(where(is.numeric), ~ round(.x, 3))),
               "Tab_30_sintese_municipal")

mapa_base <- municipios_sf %>%
    left_join(sintese_mun %>% mutate(municipio = as.character(municipio)),
              by = "geocodigo") %>%
    left_join(embedding %>% select(geocodigo, perfil), by = "geocodigo") %>%
    left_join(efeitos_mun %>%
              transmute(municipio = as.character(municipio),
                        efeito_mun = efeito),
              by = "municipio")

######@> Mapa 01 - observado, previsto e resíduo...
m1a <- ggplot(mapa_base) +
    geom_sf(aes(fill = dens_obs), colour = "grey30", linewidth = 0.15) +
    scale_fill_viridis_c(option = "rocket", direction = -1, na.value = "grey92",
                         name = "Eventos por\n1.000 km2 ao ano") +
    labs(title = "Observado") +
    theme(axis.text = element_blank(), axis.ticks = element_blank())

m1b <- ggplot(mapa_base) +
    geom_sf(aes(fill = dens_prev), colour = "grey30", linewidth = 0.15) +
    scale_fill_viridis_c(option = "rocket", direction = -1, na.value = "grey92",
                         name = "Eventos por\n1.000 km2 ao ano") +
    labs(title = "Previsto fora da amostra") +
    theme(axis.text = element_blank(), axis.ticks = element_blank())

m1c <- ggplot(mapa_base) +
    geom_sf(aes(fill = residuo), colour = "grey30", linewidth = 0.15) +
    scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
                         midpoint = 0, na.value = "grey92",
                         name = "Observado -\nprevisto") +
    labs(title = "Resíduo") +
    theme(axis.text = element_blank(), axis.ticks = element_blank())

mapa01 <- m1a + m1b + m1c +
    plot_annotation(
        title = "Onde o modelo acerta e onde erra",
        subtitle = paste0("Previsões do modelo ", melhor_mun,
                          ", esquema de blocos de municípios (",
                          ano_ini, "-", ano_fim, ")"),
        caption = quebrar_mapa(paste(
            "As previsões são FORA DA AMOSTRA: cada município foi",
            "previsto por um modelo ajustado sem ele e sem seus",
            "vizinhos imediatos, a partir apenas de suas características",
            "climáticas, de uso da terra, de posição e de área. O painel",
            "do resíduo é o mais informativo dos três: em vermelho, os",
            "municípios que registram MAIS eventos do que suas",
            "características fazem prever; em azul, os que registram",
            "menos. São eles que apontam onde procurar o que a base não",
            "contém - relevo, densidade de ocupação em planície de",
            "inundação e capacidade da defesa civil local.")))

salvar_fig(mapa01, "Mapa_01_observado_previsto_residuo", largura = 15,
           altura = 8, diretorio = dir_mapa)

######@> Mapa 02 - efeito municipal, perfis e preditores dominantes...
m2a <- ggplot(mapa_base) +
    geom_sf(aes(fill = exp(efeito_mun)), colour = "grey30",
            linewidth = 0.15) +
    scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
                         midpoint = 1, trans = "log10",
                         na.value = "grey92",
                         name = "Fator sobre\na taxa") +
    labs(title = "Efeito municipal não explicado") +
    theme(axis.text = element_blank(), axis.ticks = element_blank())

m2b <- ggplot(mapa_base) +
    geom_sf(aes(fill = perfil), colour = "grey30", linewidth = 0.15) +
    scale_fill_manual(values = cores_perfil, na.value = "grey92",
                      name = NULL) +
    labs(title = "Perfis do embedding") +
    theme(axis.text = element_blank(), axis.ticks = element_blank())

m2c <- ggplot(mapa_base) +
    geom_sf(aes(fill = chuva), colour = "grey30", linewidth = 0.15) +
    scale_fill_viridis_c(option = "mako", direction = -1,
                         na.value = "grey92",
                         name = "mm no\ntrimestre") +
    labs(title = "Maior acumulado trimestral (média)") +
    theme(axis.text = element_blank(), axis.ticks = element_blank())

m2d <- ggplot(mapa_base) +
    geom_sf(aes(fill = urb), colour = "grey30", linewidth = 0.15) +
    scale_fill_viridis_c(option = "cividis", direction = -1,
                         na.value = "grey92", name = "% da área") +
    labs(title = "Área urbanizada (média)") +
    theme(axis.text = element_blank(), axis.ticks = element_blank())

mapa02 <- (m2a + m2b) / (m2c + m2d) +
    plot_annotation(
        title = "O território e o que o modelo aprendeu sobre ele",
        caption = quebrar_mapa(paste(
            "O primeiro painel traz o efeito aleatório municipal do",
            "modelo dentro/entre exponenciado - o que resta depois de",
            "controlados clima, uso da terra, posição e área. O segundo",
            "traz os perfis extraídos do embedding da rede neural, que",
            "não foram supervisionados por nenhuma classificação prévia.",
            "Os dois últimos trazem os dois preditores mais importantes",
            "do consenso, para leitura conjunta: onde os três primeiros",
            "painéis coincidem, o modelo está capturando o processo;",
            "onde divergem, há estrutura territorial que os preditores",
            "disponíveis não representam.")))

salvar_fig(mapa02, "Mapa_02_territorio_e_modelo", largura = 12,
           altura = 12, diretorio = dir_mapa)

########################################################################
######@> Etapa 21 - Exportação consolidada e relatório de síntese...

message("Etapa 21 - exportando resultados...")

######@> Modelos ajustados...
## Gravados para que as etapas seguintes do capítulo possam reaproveitá-
## los sem reajustar. A rede neural não entra no RData: objetos torch
## contêm ponteiros externos que não sobrevivem à serialização do R, e
## por isso seus pesos são gravados no formato próprio da biblioteca.
save(mod_glm, mod_glmm, mod_we, mod_gam, cv_net, mod_rf, mod_xgb,
     dm, termos_mod, termos_W, termos_B, vars_modelo, vars_ml,
     particoes, previsoes, desempenho, consenso, coeficientes,
     file = file.path(dir_mod, "Modelos_Objetivo_02.RData"))

torch_save(mod_dl$modelo, file.path(dir_mod, "rede_neural_eia.pt"))
saveRDS(list(escala = mod_dl$escala, mapa = mod_dl$mapa,
             vars = vars_ml, epoca = mod_dl$epoca),
        file.path(dir_mod, "rede_neural_eia_metadados.rds"))

######@> Planilha consolidada...
writexl::write_xlsx(tabelas,
                    file.path(dir_res, "Objetivo_02_tabelas.xlsx"))

######@> Elementos citados no relatório...
melhor_ano <- desempenho %>%
    filter(esquema == "Blocos de anos", familia != "Referência") %>%
    slice_max(pseudo_r2, n = 1)

melhor_muni <- desempenho %>%
    filter(esquema == "Blocos de municípios", familia != "Referência") %>%
    slice_max(pseudo_r2, n = 1)

ref_hist <- desempenho %>%
    filter(modelo == "Média histórica do município",
           esquema == "Blocos de anos")

glmm_ano <- desempenho %>%
    filter(modelo == "GLMM dentro/entre", esquema == "Blocos de anos")

pega_coef <- function(termo_alvo, campo = "rr") {
    linha <- coeficientes %>% filter(termo == termo_alvo)
    if(nrow(linha) == 0) return(NA_real_)
    linha[[campo]][1]
}

coef_top <- coeficientes %>%
    filter(p < alfa) %>%
    arrange(desc(abs(estimativa)))

coef_W_sig <- coef_top %>% filter(grepl("_W$", termo))
coef_B_sig <- coef_top %>% filter(grepl("_B$", termo))

######@> Relatório de síntese...
linhas <- c(
    "########################################################################",
    "## MODELAGEM DOS EVENTOS HIDROLÓGICOS - OBJETIVO 02",
    "## Enxurradas, Inundações e Alagamentos nos municípios costeiros de SC",
    "########################################################################",
    "",
    paste0("Gerado em: ", format(Sys.time(), "%d/%m/%Y %H:%M")),
    paste0("Script   : script_Objetivo_02_modelagem_ver00.R"),
    "",
    "########################################################################",
    "## 1. BASE ANALÍTICA",
    "########################################################################",
    "",
    paste0("   Janela                     : ", ano_ini, "-", ano_fim,
           " (interseção Atlas x MapBiomas)"),
    paste0("   Unidade                    : município-ano"),
    paste0("   Observações                : ", fmt_int(n_obs),
           " (", n_mun, " municípios x ", n_anos, " anos)"),
    paste0("   Eventos                    : ", fmt_int(sum(dm$EIA)),
           " (", sprintf("%.0f%%", composicao$Percentual[1]),
           " enxurradas, ",
           sprintf("%.0f%%", composicao$Percentual[2]), " inundações, ",
           sprintf("%.0f%%", composicao$Percentual[3]), " alagamentos)"),
    paste0("   Município-anos com evento  : ",
           fmt_int(sum(dm$EIA > 0)), " (",
           sprintf("%.1f%%", 100 * mean(dm$EIA > 0)), ")"),
    paste0("   Razão variância/média      : ",
           sprintf("%.2f", var_eia / media_eia)),
    paste0("   Preditores candidatos      : ", length(vars_candidatas)),
    paste0("   Preditores após as podas   : ", length(vars_modelo),
           " (", length(termos_W), " componentes DENTRO, ",
           length(termos_B), " ENTRE)"),
    "",
    "########################################################################",
    "## 2. FAMÍLIA DE CONTAGEM",
    "########################################################################",
    "",
    paste0("   ", format(comparacao_familia$Modelo, width = 44),
           sprintf("AIC = %8.1f | dispersão = %.2f | zeros prev. = %5.0f",
                   comparacao_familia$AIC,
                   comparacao_familia$`Dispersão de Pearson`,
                   comparacao_familia$`Zeros previstos`)),
    paste0("   Zeros observados: ", fmt_int(sum(dm$EIA == 0))),
    "",
    paste0("   Família selecionada: ", familia_escolhida, "."),
    paste0("   A dispersão de Pearson cai de ",
           sprintf("%.2f", disp_sem_mun), " para ",
           sprintf("%.2f", disp_com_mun),
           " com a entrada do termo"),
    "   municipal: a sobredispersão aparente era heterogeneidade ENTRE",
    "   municípios, não variabilidade extra do processo. O binomial",
    "   negativo não acrescenta ajuste e a inflação de zeros não é",
    "   necessária - resultado que replica, na escala anual e para os",
    "   três tipos hidrológicos, o da análise exploratória integrada.",
    "",
    "########################################################################",
    "## 3. O QUE EXPLICA OS EVENTOS - MODELO DENTRO/ENTRE",
    "########################################################################",
    "",
    "   3.1 GATILHO - o que faz um ANO ser pior que outro no mesmo",
    "       município (componentes DENTRO, significativos a 5%):",
    "",
    if(nrow(coef_W_sig) > 0) {
        paste0("       ", format(sub(" \\(dentro\\)$", "",
                                     coef_W_sig$rotulo), width = 38),
               sprintf("RR = %.2f [%.2f-%.2f] | %+.0f%%",
                       coef_W_sig$rr, coef_W_sig$rr_inf,
                       coef_W_sig$rr_sup, coef_W_sig$efeito_pct))
    } else "       (nenhum componente DENTRO significativo)",
    "",
    "   3.2 PREDISPOSIÇÃO - o que faz um MUNICÍPIO ser pior que outro",
    "       (componentes ENTRE, significativos a 5%):",
    "",
    if(nrow(coef_B_sig) > 0) {
        paste0("       ", format(sub(" \\(entre\\)$", "",
                                     coef_B_sig$rotulo), width = 38),
               sprintf("RR = %.2f [%.2f-%.2f] | %+.0f%%",
                       coef_B_sig$rr, coef_B_sig$rr_inf,
                       coef_B_sig$rr_sup, coef_B_sig$efeito_pct))
    } else "       (nenhum componente ENTRE significativo)",
    "",
    paste0("   Razões de taxa por desvio-padrão do componente. A",
           " variância do efeito"),
    paste0("   municipal cai de ", sprintf("%.3f", var_mun_glmm),
           " no modelo sem decomposição para ",
           sprintf("%.3f", var_mun_we), " com ela:"),
    "   os termos ENTRE absorveram a heterogeneidade que antes era",
    "   atribuída à identidade do município.",
    "",
    "########################################################################",
    "## 4. NÃO-LINEARIDADE E ESTRUTURA ESPACIAL (GAM)",
    "########################################################################",
    "",
    paste0("   Deviance explicada         : ",
           sprintf("%.1f%%", 100 * resumo_gam$dev.expl)),
    paste0("   Termos suaves significativos: ",
           sum(suaves$significativo), " de ", nrow(suaves)),
    "",
    paste0("   ", format(suaves$rotulo, width = 38),
           sprintf("edf = %5.2f | %s", suaves$edf, suaves$forma)),
    "",
    "########################################################################",
    "## 5. DESEMPENHO PREDITIVO FORA DA AMOSTRA",
    "########################################################################",
    "",
    "   BLOCOS DE ANOS (prever um ano não visto):",
    "",
    paste0("   ", format(desempenho$modelo[desempenho$esquema ==
                                           "Blocos de anos"], width = 32),
           sprintf("pseudo-R2 = %+.3f | AUC = %.3f | viés = %+.0f%%",
                   desempenho$pseudo_r2[desempenho$esquema ==
                                        "Blocos de anos"],
                   desempenho$auc[desempenho$esquema ==
                                  "Blocos de anos"],
                   desempenho$vies_pct[desempenho$esquema ==
                                       "Blocos de anos"])),
    "",
    "   BLOCOS DE MUNICÍPIOS (prever um trecho de litoral não visto):",
    "",
    paste0("   ", format(desempenho$modelo[desempenho$esquema ==
                                           "Blocos de municípios"],
                         width = 32),
           sprintf("pseudo-R2 = %+.3f | AUC = %.3f | viés = %+.0f%%",
                   desempenho$pseudo_r2[desempenho$esquema ==
                                        "Blocos de municípios"],
                   desempenho$auc[desempenho$esquema ==
                                  "Blocos de municípios"],
                   desempenho$vies_pct[desempenho$esquema ==
                                       "Blocos de municípios"])),
    "",
    "########################################################################",
    "## 6. IMPORTÂNCIA CONSOLIDADA (seis abordagens, mesma métrica)",
    "########################################################################",
    "",
    paste0("   ", format(sprintf("%2d.", head(consenso$posicao_consenso,
                                              12)), width = 4),
           format(head(consenso$rotulo, 12), width = 38),
           sprintf("rank médio = %4.1f (dp %4.1f) | top-5 em %d/6",
                   head(consenso$rank_medio, 12),
                   head(consenso$rank_dp, 12),
                   head(consenso$vezes_no_top5, 12))),
    "",
    "########################################################################",
    "## 7. DIAGNÓSTICO DO MODELO",
    "########################################################################",
    "",
    paste0("   ", format(diagnostico$Teste, width = 48),
           sprintf("est. = %+.3f | %s", diagnostico$Estatística,
                   diagnostico$Conclusão)),
    "",
    "########################################################################",
    "## 8. TIPOLOGIA APRENDIDA PELA REDE",
    "########################################################################",
    "",
    paste0("   Perfis extraídos do embedding : ", k_melhor,
           " (silhueta ", sprintf("%.3f", max(avaliacao_k$silhueta)),
           ")"),
    paste0("   Correlação dimensão 1 x latitude: ",
           sprintf("%+.2f", cor(embedding$dim1, embedding$lat,
                                method = "spearman"))),
    "",
    paste0("   ", format(as.character(perfis$perfil), width = 12),
           sprintf("n = %2d | densidade = %5.2f | urb = %4.1f%% | ",
                   perfis$n,
                   perfis$`Densidade (por 1.000 km2 ao ano)`,
                   perfis$`Urbanização média (%)`),
           substr(perfis$Municípios, 1, 70)),
    "",
    "########################################################################",
    "## 9. SENSIBILIDADE",
    "########################################################################",
    "",
    paste0("   Variantes examinadas        : ",
           n_distinct(sensibilidade$variante)),
    paste0("   Termos de sinal estável     : ",
           sum(estabilidade$sinal_estavel), " de ", nrow(estabilidade)),
    paste0("   Termos robustos             : ", length(termos_robustos)),
    "",
    if(length(termos_robustos) > 0) {
        paste0("       - ", termos_robustos)
    } else "       (nenhum termo atende ao critério de robustez)",
    "",
    paste0("   Ganho de AIC ao acrescentar a suscetibilidade urbana: ",
           ifelse(is.na(ganho_risco), "não estimado",
                  sprintf("%+.1f", ganho_risco))),
    "",
    "########################################################################",
    "## 10. LEITURA DOS RESULTADOS",
    "########################################################################",
    "",
    "   (a) O GATILHO É A CHUVA ACUMULADA, NÃO A CHUVA TOTAL",
    "       Entre os componentes DENTRO, os descritores de intensidade e",
    "       de acumulação superam sistematicamente o total anual. É",
    "       coerente com o processo: enxurrada e inundação respondem à",
    "       saturação do solo e ao enchimento da bacia, que se constroem",
    "       ao longo de semanas, e não à soma de doze meses de chuva.",
    "",
    "   (b) A PREDISPOSIÇÃO É TERRITORIAL E CLIMATOLÓGICA AO MESMO TEMPO",
    "       Entre os componentes ENTRE, a climatologia de extremos e a",
    "       fração urbanizada aparecem juntas. Não são explicações",
    "       concorrentes: o município que combina regime de chuva",
    "       extrema com ocupação urbana consolidada acumula as duas",
    "       condições, e é onde os registros se concentram.",
    "",
    "   (c) A DECOMPOSIÇÃO NÃO É REFINAMENTO, É NECESSIDADE",
    "       Vários preditores têm coeficientes de sinal ou magnitude",
    "       diferentes nas duas escalas. Um modelo que não os separasse",
    "       reportaria um único número intermediário, que não descreve",
    "       corretamente nem a variação interanual nem a diferença entre",
    "       municípios - e foi exatamente esse o mecanismo da correlação",
    "       espúria com a cobertura florestal identificada na análise",
    "       exploratória.",
    "",
    "   (d) AS TRÊS FAMÍLIAS CONVERGEM, E ISSO É UM RESULTADO",
    paste0("       O melhor modelo no esquema de blocos de anos é ",
           melhor_ano$modelo, " (pseudo-R2"),
    paste0("       ", sprintf("%.3f", melhor_ano$pseudo_r2),
           "); no de blocos de municípios, ", melhor_muni$modelo,
           " (", sprintf("%.3f", melhor_muni$pseudo_r2), "). A"),
    "       distância entre as famílias é pequena diante da distância",
    "       de todas elas para as referências, o que significa que a",
    "       especificação paramétrica NÃO está deixando estrutura",
    "       relevante de fora: não há não-linearidade nem interação de",
    "       ordem alta que os modelos flexíveis encontrem e o modelo",
    "       interpretável perca. Os coeficientes da seção 3 podem ser",
    "       lidos como a melhor descrição disponível do processo.",
    "",
    "   (e) O TETO DE PREVISIBILIDADE É BAIXO, E TEM EXPLICAÇÃO",
    "       Nenhuma família explica uma fração grande da deviance fora",
    "       da amostra. Três razões concorrem, e nenhuma delas é falha",
    "       de modelagem: a resposta é uma contagem rara e discreta; a",
    "       resolução mensal do ERA5 não resolve a chuva de três dias",
    "       que satura o solo; e o Atlas registra o que foi DECRETADO,",
    "       não o que ocorreu. O limite é da base, não do método.",
    "",
    "   (f) O QUE FICA PARA AS ETAPAS SEGUINTES",
    "       Os resíduos municipais e o efeito aleatório mapeados na",
    "       Etapa 20 identificam os municípios em que a ocorrência",
    "       excede o que clima e uso da terra explicam. São a pauta",
    "       natural para o aprofundamento: é ali que faltam relevo,",
    "       forma da bacia, densidade de ocupação em planície de",
    "       inundação e população exposta - as quatro variáveis que",
    "       esta base não contém e que a análise indica serem as mais",
    "       promissoras.",
    "",
    "########################################################################",
    "## 11. RESSALVAS",
    "########################################################################",
    "",
    "   - Nenhuma associação estimada aqui é causal. O desenho é",
    "     observacional; a decomposição dentro/entre remove o",
    "     confundimento por características municipais constantes, mas",
    "     não o confundimento por variáveis que variam no tempo.",
    "",
    "   - O Atlas é registro ADMINISTRATIVO. A ausência de registro não",
    "     é ausência de evento, e a comparação entre municípios é",
    "     também uma comparação entre capacidades de registro. O ano",
    "     entra como controle em todos os modelos e a Etapa 19 verifica",
    "     a dependência do trecho anterior à consolidação do S2iD.",
    "",
    "   - O ERA5 é reanálise, não observação; o MapBiomas é",
    "     classificação de imagem. As três incertezas de origem se",
    "     somam quando as três fontes entram no mesmo modelo.",
    "",
    "   - Nenhuma imputação foi feita. Onde faltou dado, a observação",
    "     ficou de fora, e o n efetivo de cada modelo consta das",
    "     tabelas.",
    "",
    "########################################################################")

writeLines(linhas,
           file.path(dir_res, "Objetivo_02_relatorio_sintese.txt"))

######@> Resumo final do processamento...
n_figs <- length(list.files(dir_fig, pattern = "\\.png$"))
n_mapas <- length(list.files(dir_mapa, pattern = "\\.png$"))
n_tabs <- length(list.files(dir_tab, pattern = "\\.csv$"))

message("\n=== Modelagem do Objetivo 02 concluída ===")
message("Observações modeladas  : ", fmt_int(n_obs))
message("Eventos                : ", fmt_int(sum(dm$EIA)))
message("Modelos comparados     : ", length(receitas), " em 3 famílias")
message("Figuras                : ", n_figs)
message("Mapas                  : ", n_mapas)
message("Tabelas (CSV)          : ", n_tabs, " + 1 XLSX consolidado")
message("Relatório de síntese   : Objetivo_02_relatorio_sintese.txt")
message("Saídas em              : ", normalizePath(dir_res))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
