########################################################################
## Description: Recorte e extração dos dados ERA5 (monthly means) por
##              município costeiro de Santa Catarina, preservando a
##              informação em nível de pixel...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: seg ago 18 09:00:00 2026 (-0300)
## Version: 0.1.0
##
## URL:
## Doc URL:
##
## Database info: Copernicus ERA5 - reanalysis-era5-single-levels-
##                monthly-means (1940-2026), grade regular de 0.25 graus,
##                recortada para a janela [-23, -52, -30, -46]
##                (Norte, Oeste, Sul, Leste), baixada pelo script
##                script_ERA5_copernicus_ver00.R.
##
### Commentary:
##
## Este script realiza o recorte espacial dos dados do Copernicus ERA5
## para cada município costeiro de Santa Catarina, definido pelo
## shapefile de abrangência do PMCAP-SC.
##
## DIFERENÇA EM RELAÇÃO À VERSÃO 0.0.1:
##
## A versão anterior entregava APENAS a média ponderada pela área por
## município, o que descartava a variabilidade espacial interna. Esta
## versão preserva a informação completa, gerando DOIS níveis de saída:
##
##   (a) NÍVEL PIXEL (fidelidade total) - todos os pixels ERA5 que
##       intersectam cada município, com seu valor original, a fração
##       de área coberta e as coordenadas do centro do pixel. Nada é
##       descartado: permite recalcular qualquer estatística a
##       posteriori (mediana, quantis, tendências por pixel, etc.);
##
##   (b) NÍVEL MUNICIPAL (agregado) - uma série temporal por município,
##       acompanhada de MEDIDAS DE DISPERSÃO (desvio-padrão ponderado,
##       mínimo, máximo e número de pixels), de modo que a perda de
##       informação da agregação seja mensurável, e não invisível.
##
## O agregado (b) é calculado A PARTIR de (a), garantindo coerência
## numérica exata entre os dois níveis.
##
## Fluxo geral do processamento:
##
##   01) Leitura e padronização do shapefile (datum WGS84 / EPSG:4326)
##       e dissolução das feições por município;
##   02) Construção da TABELA DE PESOS município x pixel, uma única vez;
##   03) Leitura dos arquivos anuais do ERA5 (que, apesar da extensão
##       ".nc", são arquivos ZIP contendo 4 NetCDFs internos);
##   04) Extração dos valores originais dos pixels e concatenação
##       temporal de toda a série (1940-2026);
##   05) Agregação municipal ponderada, com dispersão;
##   06) Exportação dos dois níveis em formato Parquet e RData.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Leitura/manipulação de dados vetoriais
library(terra)          ## Leitura/manipulação de dados raster (NetCDF)
library(ncdf4)          ## Inspeção da estrutura interna dos NetCDFs
library(exactextractr)  ## Intersecção exata polígono x pixel
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem (formato longo <-> largo)
library(purrr)          ## Programação funcional (map/reduce)
library(stringi)        ## Transliteração de acentos (nomes de arquivo)
library(arrow)          ## Escrita de arquivos Parquet

######@> Opções globais...
## Evita que strings sejam convertidas em fatores e desliga a notação
## científica, o que facilita a leitura dos códigos de município (IBGE).
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente (garante reprodutibilidade de qualquer etapa
######@> eventualmente estocástica)...
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
## O script assume que está sendo executado a partir da pasta R_Work,
## portanto todos os caminhos são relativos a ela.
dir_dados <- "../Dados"
dir_era5 <- file.path(dir_dados, "Compilacao_01", "Copernicus_ERA5")
dir_shape <- file.path(dir_dados, "Shapefiles")

######@> Diretórios de saída...
## Cada formato recebe duas subpastas, uma por nível de agregação, para
## que não haja qualquer ambiguidade sobre o que cada arquivo contém.
dir_out <- file.path(dir_dados, "Outputs")
dir_pq <- file.path(dir_out, "Parquet")
dir_rd <- file.path(dir_out, "RData")
dir_pq_mun <- file.path(dir_pq, "Municipal")
dir_pq_pix <- file.path(dir_pq, "Pixel")
dir_rd_mun <- file.path(dir_rd, "Municipal")
dir_rd_pix <- file.path(dir_rd, "Pixel")

######@> Criação da estrutura de saída (recursive = TRUE cria os níveis
######@> intermediários; showWarnings = FALSE evita aviso caso já
######@> exista)...
for(d in c(dir_out, dir_pq, dir_rd, dir_pq_mun, dir_pq_pix,
           dir_rd_mun, dir_rd_pix)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> Arquivo do shapefile de municípios costeiros...
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Datum/CRS de referência do projeto...
## EPSG:4326 = WGS84 em coordenadas geográficas (graus decimais). É o
## mesmo referencial nativo do ERA5, o que evita reamostragem do raster
## e mantém a extração no sistema original do dado climático.
crs_projeto <- 4326

######@> CRS auxiliar para cálculo de áreas...
## EPSG:5880 = SIRGAS 2000 / Brazil Polyconic. Projeção equivalente
## (preserva área), usada APENAS para calcular a área dos municípios em
## km2 - nunca para a extração em si.
crs_area <- 5880

######@> Variáveis categóricas do ERA5...
## Estas variáveis são códigos da tabela GRIB 4.234 e não grandezas
## contínuas: identificam o TIPO de vegetação (ex.: 19 = "Interrupted
## forest"). Uma média aritmética entre códigos não tem significado
## físico (a média entre os tipos 1 e 17 não é o tipo 9), portanto no
## agregado municipal elas recebem tratamento por MODA PONDERADA - a
## categoria que predomina em área dentro do município. No nível pixel
## o código original é preservado sem qualquer transformação.
vars_categoricas <- c("tvh",    ## Tipo de vegetação alta (tab. 4.234)
                      "tvl")    ## Tipo de vegetação baixa (tab. 4.234)

######@> Observação sobre a variável "ptype" (tipo de precipitação)...
## Na documentação do ERA5, ptype é um código categórico (tabela 4.201:
## 0 = sem precipitação, 1 = chuva, 5 = neve, etc.). PORÉM, no produto
## "monthly averaged reanalysis" utilizado aqui, o próprio ECMWF já
## calculou a média temporal desse código ao longo do mês, de modo que
## os valores chegam FRACIONÁRIOS (verificado: milhares de valores
## distintos na faixa 0.13-0.97, e não os inteiros da tabela). Ou seja,
## neste produto ptype já é, na prática, um índice contínuo que expressa
## a predominância de precipitação líquida no mês. Por esse motivo ele é
## tratado como variável CONTÍNUA, em coerência com as demais.

######@> Variáveis auxiliares dos NetCDFs que não são dados climáticos e
######@> devem ser descartadas na extração...
vars_ignorar <- c("number",     ## Id do membro do ensemble (sempre 0)
                  "expver",     ## Versão do experimento (ERA5/ERA5T)
                  "latitude", "longitude", "valid_time")

########################################################################
######@> Funções auxiliares...

######@> Função para transliterar nomes em nomes seguros de arquivo...
## Remove acentos (stri_trans_general), troca qualquer caractere não
## alfanumérico por "_" e elimina underscores duplicados/terminais.
## Necessária porque os nomes dos municípios possuem acentuação
## (ex.: "Balneário Camboriú" -> "Balneario_Camboriu").
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Função para listar as variáveis de dados de um NetCDF...
## Abre o arquivo apenas para ler os metadados (nomes das variáveis) e
## o fecha imediatamente, devolvendo somente as variáveis climáticas.
listar_variaveis <- function(arquivo) {
    nc <- nc_open(arquivo)
    on.exit(nc_close(nc), add = TRUE)          ## Garante o fechamento
    vars <- names(nc$var)
    vars <- setdiff(vars, vars_ignorar)
    return(vars)
}

######@> Função para abrir uma variável de um NetCDF já padronizada...
abrir_variavel <- function(arquivo, variavel) {
    ## 1. Leitura da variável como SpatRaster multicamadas ------------
    ##    Cada camada corresponde a um mês do ano contido no arquivo.
    r <- rast(arquivo, subds = variavel)
    ## 2. Correção da convenção de longitude ---------------------------
    ##    O NetCDF interno "stepType-avg" (variável ptype) vem com
    ##    longitudes na convenção 0-360 graus, enquanto os demais vêm em
    ##    -180/180. terra::rotate() converte 0-360 -> -180/180. Sem esta
    ##    correção o raster não intersecta o shapefile e a extração
    ##    retornaria apenas NA - uma falha silenciosa.
    if(xmax(r) > 180) {
        r <- rotate(r)
    }
    ## 3. Atribuição explícita do CRS ----------------------------------
    ##    O ERA5 é distribuído em coordenadas geográficas WGS84, mas
    ##    alguns NetCDFs não trazem a definição formal do CRS. Definimos
    ##    explicitamente para assegurar o alinhamento com o shapefile já
    ##    padronizado em EPSG:4326.
    if(is.na(crs(r)) || crs(r) == "") {
        crs(r) <- paste0("EPSG:", crs_projeto)
    }
    return(r)
}

######@> Função que extrai os valores originais dos pixels de interesse
######@> para UMA variável de UM NetCDF...
## Diferentemente da versão 0.0.1, esta função NÃO calcula estatística
## alguma: ela devolve o valor CRU de cada pixel, para cada mês. A
## agregação, se desejada, é feita depois, a partir destes valores.
extrair_pixels <- function(arquivo, variavel, celulas) {
    r <- abrir_variavel(arquivo, variavel)
    ## Indexação direta das células de interesse ------------------------
    ## Como todos os NetCDFs compartilham exatamente a mesma grade
    ## (verificado: 725 células, mesma extensão e resolução), os
    ## identificadores de célula são válidos para todas as variáveis.
    ## Extraímos apenas as ~40 células que tocam algum município, em vez
    ## das 725 da janela completa.
    valores <- as.matrix(r[celulas])
    ## Recuperação dos carimbos temporais --------------------------------
    ## A ORDEM das colunas corresponde à ordem das camadas do raster,
    ## portanto casa posicionalmente com time(r). Não se deve ordenar as
    ## colunas pelo nome, pois o sufixo numérico ("_1", "_10", "_2"...)
    ## ordena alfabeticamente de forma incorreta.
    datas <- time(r)
    ## Montagem da tabela em formato longo -------------------------------
    res <- expand.grid(idx_cel = seq_along(celulas),
                       idx_tempo = seq_len(ncol(valores)),
                       KEEP.OUT.ATTRS = FALSE)
    res$celula <- celulas[res$idx_cel]
    ## Normalização temporal ---------------------------------------------
    ## Os quatro NetCDFs internos usam carimbos de tempo DIFERENTES para
    ## o mesmo mês (ex.: 1940-01-01 00:00, 1940-01-01 06:00 e
    ## 1940-01-31 23:00), pois cada stepType tem convenção própria. Para
    ## poder unir as variáveis, reduzimos todos ao par ano/mês, que é a
    ## real resolução temporal do produto "monthly means".
    res$ano <- as.integer(format(datas[res$idx_tempo], "%Y"))
    res$mes <- as.integer(format(datas[res$idx_tempo], "%m"))
    res$variavel <- variavel
    res$valor <- valores[cbind(res$idx_cel, res$idx_tempo)]
    res <- res[, c("celula", "ano", "mes", "variavel", "valor")]
    return(res)
}

######@> Função que processa UM arquivo anual completo (o ZIP)...
extrair_ano <- function(arquivo_zip, celulas) {
    ## 1. Descompactação em diretório temporário -------------------------
    ##    Os arquivos possuem extensão ".nc" mas são, de fato, arquivos
    ##    ZIP (o CDS entregou o pacote compactado apesar do pedido por
    ##    "download_format = unarchived"). Cada ZIP contém 4 NetCDFs, um
    ##    por "stepType", que agrupam as variáveis conforme o tipo de
    ##    acumulação temporal:
    ##      - stepType-avgua : variáveis instantâneas (u10, v10, t2m...)
    ##      - stepType-avgad : variáveis acumuladas diárias (tp, ssr...)
    ##      - stepType-avgid : taxas instantâneas diárias (lsrr)
    ##      - stepType-avg   : tipo de precipitação (ptype)
    ##    Usamos um diretório temporário por ano, removido ao final, para
    ##    não poluir a pasta de dados originais.
    dir_tmp <- file.path(tempdir(), paste0("era5_", basename(arquivo_zip)))
    dir.create(dir_tmp, recursive = TRUE, showWarnings = FALSE)
    on.exit(unlink(dir_tmp, recursive = TRUE), add = TRUE)
    unzip(arquivo_zip, exdir = dir_tmp)
    ## 2. Listagem dos NetCDFs internos -----------------------------------
    arqs_nc <- list.files(dir_tmp, pattern = "\\.nc$", full.names = TRUE)
    ## 3. Extração de todas as variáveis de todos os NetCDFs -------------
    res <- map_dfr(arqs_nc, function(arq) {
        vars <- listar_variaveis(arq)
        map_dfr(vars, ~ extrair_pixels(arq, .x, celulas))
    })
    return(res)
}

######@> Função de moda ponderada pela área...
## Devolve a categoria que ocupa a MAIOR ÁREA dentro do município. Usada
## apenas para as variáveis categóricas (tvh, tvl).
moda_ponderada <- function(valor, peso) {
    if(all(is.na(valor))) return(NA_real_)
    agr <- tapply(peso, valor, sum, na.rm = TRUE)
    return(as.numeric(names(agr)[which.max(agr)]))
}

########################################################################
######@> Etapa 01 - Leitura e padronização do shapefile...

######@> Leitura do shapefile de municípios costeiros...
message("Lendo shapefile de municípios costeiros...")
shape_bruto <- st_read(arq_shape, quiet = TRUE)

######@> Correção de geometrias inválidas...
## O shapefile possui polígonos com ordem de rotação (winding order)
## incorreta e 2 geometrias inválidas. st_make_valid() corrige esses
## problemas, que de outro modo provocariam erro ou áreas negativas na
## intersecção com a grade.
shape_bruto <- st_make_valid(shape_bruto)

######@> Padronização do datum para WGS84...
## O shapefile já se encontra em GCS_WGS_1984, mas o arquivo .prj usa a
## nomenclatura antiga do ESRI ("D_WGS_1984"), sem código EPSG
## explícito. st_transform() para EPSG:4326 formaliza o CRS e garante
## que qualquer arquivo futuro em outro datum seja reprojetado
## corretamente antes da extração.
shape_bruto <- st_transform(shape_bruto, crs_projeto)

######@> Consolidação dos atributos de identificação do município...
## O shapefile resultou da união de três camadas distintas e, por isso,
## possui 29 colunas com TRÊS blocos redundantes de atributos
## ("nome"/"codigo_ibg", "MUNICIPIO"/"GEOCODIGO" e
## "MUNICIPIO_"/"GEOCODIGO_"). Cada feição preenche apenas um dos
## blocos, deixando os demais como NA. coalesce() percorre os blocos na
## ordem e assume o primeiro valor não-nulo, recuperando nome e código
## IBGE para as 81 feições sem nenhum NA.
atributos <- st_drop_geometry(shape_bruto)
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))

######@> Dissolução das feições por município...
## As 81 feições originais correspondem a apenas 37 municípios (há
## polígonos repetidos e municípios fragmentados em várias partes, como
## ilhas). O agrupamento por geocódigo + nome, seguido de summarise(),
## dissolve as partes em uma única geometria (MULTIPOLYGON) por
## município, evitando duplicação de linhas na extração.
municipios <- shape_bruto %>%
    group_by(geocodigo, municipio) %>%
    summarise(.groups = "drop") %>%
    st_make_valid() %>%
    arrange(municipio)

######@> Cálculo da área municipal (km2)...
## Calculada em projeção equivalente (EPSG:5880). Serve de metadado e
## permite avaliar a razão entre o tamanho do município e o pixel do
## ERA5 (~700 km2), que é a chave para interpretar a representatividade
## do dado (ver Etapa 02).
municipios$area_km2 <-
    as.numeric(st_area(st_transform(municipios, crs_area))) / 1e6

######@> Coordenadas do centroide do município (WGS84)...
## Úteis como metadado descritivo de posição. st_centroid() emite aviso
## sobre coordenadas geográficas; suppressWarnings() o silencia, pois o
## uso aqui é meramente descritivo.
centroides <- suppressWarnings(st_coordinates(st_centroid(municipios)))
municipios$lon_centroide <- centroides[, "X"]
municipios$lat_centroide <- centroides[, "Y"]

######@> Conferência da padronização...
message("Municípios prontos para extração: ", nrow(municipios))
message("CRS de trabalho: EPSG:", st_crs(municipios)$epsg)

########################################################################
######@> Etapa 02 - Construção da tabela de pesos município x pixel...

######@> Listagem dos arquivos anuais do ERA5...
## sort() garante a ordem cronológica dos arquivos (1940 -> 2026).
arqs_era5 <- sort(list.files(dir_era5, pattern = "^era5_sul_brasil_.*\\.nc$",
                             full.names = TRUE))
message("Arquivos anuais do ERA5 encontrados: ", length(arqs_era5))

######@> Extração de um raster-gabarito da grade...
## A grade do ERA5 é FIXA ao longo de toda a série (mesma extensão,
## resolução e número de células em todos os anos e em todos os quatro
## NetCDFs internos - verificado). Portanto a intersecção geométrica
## entre municípios e pixels precisa ser calculada UMA ÚNICA VEZ, e não
## a cada ano/variável. Isso torna o processamento mais rápido e, o que
## é mais importante, garante que os pesos sejam idênticos para todas as
## variáveis.
dir_gab <- file.path(tempdir(), "era5_gabarito")
dir.create(dir_gab, recursive = TRUE, showWarnings = FALSE)
unzip(arqs_era5[1], exdir = dir_gab)
arq_gab <- list.files(dir_gab, pattern = "avgua\\.nc$", full.names = TRUE)
raster_gabarito <- abrir_variavel(arq_gab, "t2m")[[1]]

######@> Intersecção exata polígono x pixel...
## exact_extract() com include_cell/include_xy/include_area devolve, para
## cada município, a lista COMPLETA de pixels tocados, com:
##   - cell : identificador da célula na grade (chave de junção);
##   - x, y : coordenadas do CENTRO do pixel;
##   - area : área real do pixel em m2 (calculada na esfera);
##   - coverage_fraction : fração do pixel coberta pelo polígono.
## Nenhuma estatística é calculada aqui - apenas a geometria da
## intersecção é registrada.
lista_intersec <- exact_extract(raster_gabarito, municipios,
                                include_cell = TRUE,
                                include_xy = TRUE,
                                include_area = TRUE,
                                progress = FALSE)

######@> Montagem da tabela de pesos...
tabela_pesos <- bind_rows(lapply(seq_along(lista_intersec), function(i) {
    e <- lista_intersec[[i]]
    ## Descarta pixels que apenas tangenciam o polígono (fração zero)
    e <- e[e$coverage_fraction > 0, ]
    data.frame(geocodigo = municipios$geocodigo[i],
               municipio = municipios$municipio[i],
               celula = e$cell,
               lon_pixel = e$x,
               lat_pixel = e$y,
               fracao_cobertura = e$coverage_fraction,
               ## Área da intersecção pixel x município, em km2. É este
               ## valor que serve de PESO na agregação: um pixel que
               ## cobre 40% do município pesa o dobro de um que cobre
               ## 20%.
               area_intersec_km2 = e$coverage_fraction * e$area / 1e6)
}))

######@> Células efetivamente necessárias...
## Apenas estas células serão lidas dos rasters, em vez das 725 da
## janela completa.
celulas_uso <- sort(unique(tabela_pesos$celula))

######@> Diagnóstico da representatividade espacial...
## ESTE DIAGNÓSTICO É PARTE DO RESULTADO, não um detalhe técnico. A
## grade do ERA5 tem 0.25 graus (~27 km, ~700 km2 por pixel), enquanto o
## menor município do recorte (Bombinhas) tem ~36 km2. Consequências que
## o usuário PRECISA conhecer ao interpretar os dados:
##   - municípios pequenos são MENORES que um único pixel, e portanto
##     não são resolvidos individualmente pelo ERA5;
##   - municípios vizinhos pequenos compartilham os mesmos pixels e
##     terão séries quase idênticas (correlação > 0.99);
##   - a coluna fracao_cobertura mostra o quanto de cada pixel pertence
##     de fato ao município: valores baixos indicam que o dado vem
##     majoritariamente da vizinhança (inclusive do oceano).
diagnostico <- tabela_pesos %>%
    group_by(geocodigo, municipio) %>%
    summarise(n_pixels = n(),
              ## Pixels com contribuição não desprezível (>1% do pixel)
              n_pixels_relevantes = sum(fracao_cobertura > 0.01),
              fracao_max = max(fracao_cobertura),
              .groups = "drop") %>%
    left_join(st_drop_geometry(municipios)[, c("geocodigo", "area_km2")],
              by = "geocodigo") %>%
    arrange(desc(area_km2))

message("Tabela de pesos: ", nrow(tabela_pesos),
        " pares município-pixel | ", length(celulas_uso), " pixels únicos")
message("Pixels por município: mediana = ",
        median(diagnostico$n_pixels_relevantes),
        " | máximo = ", max(diagnostico$n_pixels_relevantes))
message("Municípios contidos em <= 1 pixel relevante: ",
        sum(diagnostico$n_pixels_relevantes <= 1), " de ", nrow(diagnostico))

########################################################################
######@> Etapa 03 - Extração dos valores dos pixels...

######@> Loop de extração ano a ano...
## O processamento é feito ano a ano (e não com todos os arquivos
## carregados de uma vez) para manter o uso de memória baixo e para que
## uma eventual falha em um ano específico seja facilmente identificada.
lista_anos <- vector("list", length(arqs_era5))
names(lista_anos) <- basename(arqs_era5)

for(i in seq_along(arqs_era5)) {
    message(sprintf("[%3d/%3d] Extraindo %s ...", i, length(arqs_era5),
                    basename(arqs_era5[i])))
    lista_anos[[i]] <- extrair_ano(arqs_era5[i], celulas_uso)
}

######@> Concatenação temporal de toda a série...
## bind_rows() empilha as tabelas anuais, produzindo a série completa
## (1940-2026) em formato longo, ainda no nível do PIXEL (sem
## duplicação por município).
valores_pixel <- bind_rows(lista_anos)

message("Valores de pixel extraídos: ", nrow(valores_pixel))

########################################################################
######@> Etapa 04 - Montagem da base em nível de PIXEL...

######@> Junção dos valores com a tabela de pesos...
## Aqui os valores dos pixels são replicados para cada município que os
## intersecta. Um mesmo pixel pode pertencer a dois ou mais municípios
## (com frações diferentes), e por isso aparecerá no arquivo de cada um
## deles - o que é o comportamento correto, pois o recorte é por
## município.
pixel_longo <- tabela_pesos %>%
    left_join(valores_pixel, by = "celula", relationship = "many-to-many")

######@> Pivotagem para o formato largo...
## Converte de "uma linha por variável" para "uma linha por
## município-pixel-mês, uma coluna por variável". É aqui que as
## variáveis provenientes dos quatro NetCDFs internos (com carimbos
## temporais distintos) se unem, graças à normalização prévia para
## ano/mês.
dados_pixel <- pixel_longo %>%
    pivot_wider(id_cols = c(geocodigo, municipio, celula, lon_pixel,
                            lat_pixel, fracao_cobertura,
                            area_intersec_km2, ano, mes),
                names_from = variavel,
                values_from = valor) %>%
    mutate(data = as.Date(sprintf("%d-%02d-01", ano, mes)), .after = mes) %>%
    arrange(municipio, data, celula)

message("Base em nível de pixel: ", nrow(dados_pixel), " linhas x ",
        ncol(dados_pixel), " colunas")

########################################################################
######@> Etapa 05 - Agregação para o nível MUNICIPAL...

######@> Separação entre variáveis contínuas e categóricas...
vars_todas <- unique(pixel_longo$variavel)
vars_continuas <- setdiff(vars_todas, vars_categoricas)

######@> Agregação das variáveis contínuas...
## Para cada município-mês-variável calculamos:
##   - media : média ponderada pela área de intersecção. É o valor
##             "oficial" do município, equivalente ao da versão 0.0.1;
##   - dp    : desvio-padrão PONDERADO entre os pixels. Quantifica a
##             variabilidade espacial interna que a média esconde. Vale
##             0 quando o município é coberto por um único pixel;
##   - minimo/maximo : envelope de valores observados no município;
##   - n_pixels : número de pixels que sustentam a estimativa.
## Fornecer dp/min/max/n é o que torna a agregação AUDITÁVEL: o usuário
## consegue saber, para cada município e mês, se a média é representativa
## ou se esconde um gradiente relevante.
agregado_continuas <- pixel_longo %>%
    filter(variavel %in% vars_continuas) %>%
    group_by(geocodigo, municipio, ano, mes, variavel) %>%
    summarise(media = sum(valor * area_intersec_km2) /
                  sum(area_intersec_km2),
              ## Desvio-padrão ponderado (versão populacional)
              dp = sqrt(sum(area_intersec_km2 *
                            (valor - sum(valor * area_intersec_km2) /
                             sum(area_intersec_km2))^2) /
                        sum(area_intersec_km2)),
              minimo = min(valor),
              maximo = max(valor),
              n_pixels = n(),
              .groups = "drop")

######@> Agregação das variáveis categóricas...
## Moda ponderada pela área: a categoria que ocupa a maior porção do
## município. Média, desvio-padrão, mínimo e máximo não se aplicam a
## códigos e por isso não são calculados.
agregado_categoricas <- pixel_longo %>%
    filter(variavel %in% vars_categoricas) %>%
    group_by(geocodigo, municipio, ano, mes, variavel) %>%
    summarise(media = moda_ponderada(valor, area_intersec_km2),
              dp = NA_real_,
              minimo = min(valor),
              maximo = max(valor),
              n_pixels = n(),
              .groups = "drop")

######@> Pivotagem do agregado para o formato largo...
## A coluna "media" recebe o nome da própria variável (ex.: "t2m"),
## mantendo compatibilidade com a versão 0.0.1; as medidas de dispersão
## recebem sufixos explícitos (_dp, _min, _max).
agregado_longo <- bind_rows(agregado_continuas, agregado_categoricas)

dados_municipio_base <- agregado_longo %>%
    pivot_wider(id_cols = c(geocodigo, municipio, ano, mes),
                names_from = variavel,
                values_from = c(media, dp, minimo, maximo),
                names_glue = "{variavel}__{.value}") %>%
    rename_with(~ sub("__media$", "", .x)) %>%
    rename_with(~ sub("__dp$", "_dp", .x)) %>%
    rename_with(~ sub("__minimo$", "_min", .x)) %>%
    rename_with(~ sub("__maximo$", "_max", .x))

######@> Recuperação do número de pixels por município...
## É o mesmo para todas as variáveis e todos os meses, portanto entra
## como uma única coluna.
n_pix_mun <- agregado_longo %>%
    distinct(geocodigo, n_pixels)

######@> Junção com os metadados dos municípios...
## Recupera área e centroide, descartando a geometria (as saídas são
## tabelas, não objetos espaciais).
meta_municipios <- municipios %>%
    st_drop_geometry() %>%
    select(geocodigo, area_km2, lon_centroide, lat_centroide)

dados_municipio_base <- dados_municipio_base %>%
    left_join(meta_municipios, by = "geocodigo") %>%
    left_join(n_pix_mun, by = "geocodigo") %>%
    mutate(data = as.Date(sprintf("%d-%02d-01", ano, mes)), .after = mes)

########################################################################
######@> Etapa 06 - Variáveis derivadas em unidades de uso corrente...

######@> Função de conversão, aplicável aos dois níveis...
## As variáveis originais do ERA5 são mantidas INTACTAS; as versões
## convertidas recebem sufixo indicando a unidade. As conversões seguem
## a documentação do ERA5 para "monthly averaged reanalysis", em que os
## acumulados representam a média diária do mês:
##   - t2m: Kelvin -> graus Celsius (subtrair 273.15);
##   - tp/cp/e/pev: metros -> milímetros por dia (multiplicar por 1000);
##   - slhf/ssr: J m-2 acumulados no dia -> W m-2 (dividir por 86400 s);
##   - tcc: fração (0-1) -> percentual (multiplicar por 100);
##   - lsrr: kg m-2 s-1 -> mm por dia (multiplicar por 86400).
## Também são derivadas velocidade e direção do vento a partir das
## componentes u10/v10:
##   - velocidade: módulo do vetor (sqrt(u^2 + v^2)). O ERA5 também
##     fornece si10, mas si10 é a média das velocidades instantâneas,
##     enquanto esta é a velocidade do vento MÉDIO - as duas são
##     mantidas por serem grandezas distintas;
##   - direção meteorológica: azimute de ONDE o vento SOPRA (convenção
##     0 = Norte, 90 = Leste), obtida por atan2 e ajustada para [0, 360).
adicionar_derivadas <- function(dados) {
    dados %>%
        mutate(t2m_C = t2m - 273.15,          ## Temperatura do ar a 2 m
               tp_mm_dia = tp * 1000,         ## Precipitação total
               cp_mm_dia = cp * 1000,         ## Precipitação convectiva
               e_mm_dia = e * 1000,           ## Evaporação (neg. = perda)
               pev_mm_dia = pev * 1000,       ## Evaporação potencial
               lsrr_mm_dia = lsrr * 86400,    ## Chuva de larga escala
               slhf_W_m2 = slhf / 86400,      ## Fluxo de calor latente
               ssr_W_m2 = ssr / 86400,        ## Radiação solar líquida
               tcc_pct = tcc * 100,           ## Cobertura de nuvens
               vento_vel_m_s = sqrt(u10^2 + v10^2),
               vento_dir_graus = (270 - atan2(v10, u10) * 180 / pi) %% 360)
}

######@> Aplicação nos dois níveis...
## No nível municipal as derivadas são calculadas sobre a MÉDIA
## ponderada (colunas sem sufixo), que é o valor de referência.
dados_pixel <- adicionar_derivadas(dados_pixel)
dados_municipio_final <- adicionar_derivadas(dados_municipio_base) %>%
    arrange(municipio, data)

message("Base municipal: ", nrow(dados_municipio_final), " linhas x ",
        ncol(dados_municipio_final), " colunas")

########################################################################
######@> Etapa 07 - Exportação dos resultados...

######@> Tabela de referência das variáveis...
## Documenta o significado e a unidade de cada variável extraída,
## exportada junto às bases para assegurar a reprodutibilidade da
## interpretação dos dados.
dicionario <- tribble(
    ~variavel,         ~descricao,                                    ~unidade,
    "u10",             "Componente zonal do vento a 10 m",            "m s-1",
    "v10",             "Componente meridional do vento a 10 m",       "m s-1",
    "t2m",             "Temperatura do ar a 2 m",                     "K",
    "si10",            "Velocidade do vento a 10 m",                  "m s-1",
    "tcc",             "Cobertura total de nuvens",                   "0-1",
    "tcrw",            "Água de chuva na coluna total",               "kg m-2",
    "cvh",             "Cobertura de vegetação alta",                 "0-1",
    "cvl",             "Cobertura de vegetação baixa",                "0-1",
    "lai_hv",          "Índice de área foliar - vegetação alta",      "m2 m-2",
    "lai_lv",          "Índice de área foliar - vegetação baixa",     "m2 m-2",
    "tvh",             "Tipo de vegetação alta (moda; tab. 4.234)",   "código",
    "tvl",             "Tipo de vegetação baixa (moda; tab. 4.234)",  "código",
    "tp",              "Precipitação total",                          "m",
    "cp",              "Precipitação convectiva",                     "m",
    "e",               "Evaporação",                                  "m",
    "pev",             "Evaporação potencial",                        "m",
    "slhf",            "Fluxo de calor latente na superfície",        "J m-2",
    "ssr",             "Radiação solar líquida na superfície",        "J m-2",
    "lsrr",            "Taxa de chuva de larga escala",               "kg m-2 s-1",
    "ptype",           "Tipo de precipitação (média mensal já aplicada pelo ECMWF; ver nota no cabeçalho)", "índice 0-1",
    "t2m_C",           "Temperatura do ar a 2 m",                     "graus C",
    "tp_mm_dia",       "Precipitação total",                          "mm dia-1",
    "cp_mm_dia",       "Precipitação convectiva",                     "mm dia-1",
    "e_mm_dia",        "Evaporação (negativo = perda)",               "mm dia-1",
    "pev_mm_dia",      "Evaporação potencial",                        "mm dia-1",
    "lsrr_mm_dia",     "Taxa de chuva de larga escala",               "mm dia-1",
    "slhf_W_m2",       "Fluxo de calor latente na superfície",        "W m-2",
    "ssr_W_m2",        "Radiação solar líquida na superfície",        "W m-2",
    "tcc_pct",         "Cobertura total de nuvens",                   "%",
    "vento_vel_m_s",   "Velocidade do vento médio a 10 m",            "m s-1",
    "vento_dir_graus", "Direção do vento (de onde sopra; 0 = Norte)", "graus")

######@> Dicionário dos sufixos do nível municipal...
sufixos <- tribble(
    ~sufixo,   ~significado,
    "(nenhum)", "Média ponderada pela área de intersecção pixel-município (ou moda ponderada, para tvh/tvl)",
    "_dp",      "Desvio-padrão ponderado entre os pixels do município (0 = município coberto por 1 único pixel)",
    "_min",     "Menor valor observado entre os pixels do município",
    "_max",     "Maior valor observado entre os pixels do município")

######@> Exportação das bases consolidadas...
## Além dos arquivos por município, as bases completas são gravadas para
## permitir análises comparativas sem necessidade de reunir os 37
## arquivos individuais.
write_parquet(dados_municipio_final,
              file.path(dir_pq, "ERA5_municipal_SC_completo.parquet"))
write_parquet(dados_pixel,
              file.path(dir_pq, "ERA5_pixel_SC_completo.parquet"))
write_parquet(dicionario, file.path(dir_pq, "ERA5_dicionario_variaveis.parquet"))
write_parquet(sufixos, file.path(dir_pq, "ERA5_dicionario_sufixos.parquet"))
write_parquet(tabela_pesos, file.path(dir_pq, "ERA5_tabela_pesos.parquet"))
write_parquet(diagnostico, file.path(dir_pq, "ERA5_diagnostico_representatividade.parquet"))

save(dados_municipio_final, dados_pixel, dicionario, sufixos,
     tabela_pesos, diagnostico,
     file = file.path(dir_rd, "ERA5_SC_completo.RData"))

######@> Exportação individual por município...
## Para cada município são gerados DOIS pares de arquivos:
##   - Municipal/ : a série agregada (1 linha por mês);
##   - Pixel/     : todos os pixels que o intersectam (n pixels x meses).
## O nome combina o geocódigo do IBGE (chave estável e sem ambiguidade)
## com o nome transliterado, o que mantém os arquivos legíveis e
## ordenáveis.
message("Exportando arquivos por município...")

for(g in unique(dados_municipio_final$geocodigo)) {
    ## Subconjuntos do município corrente nos dois níveis
    dados_municipio <- dados_municipio_final %>%
        filter(geocodigo == g)
    dados_municipio_pixel <- dados_pixel %>%
        filter(geocodigo == g)
    ## Montagem do nome-base do arquivo
    nome_muni <- limpar_nome(unique(dados_municipio$municipio))
    nome_base <- paste0("ERA5_", g, "_", nome_muni)
    ## Gravação em Parquet (formato colunar, compacto e interoperável
    ## com Python/R/QGIS)
    write_parquet(dados_municipio,
                  file.path(dir_pq_mun, paste0(nome_base, ".parquet")))
    write_parquet(dados_municipio_pixel,
                  file.path(dir_pq_pix, paste0(nome_base, "_pixel.parquet")))
    ## Gravação em RData (formato nativo do R). Os objetos são sempre
    ## salvos com os nomes "dados_municipio" e "dados_municipio_pixel",
    ## garantindo previsibilidade ao carregar qualquer arquivo com load().
    save(dados_municipio,
         file = file.path(dir_rd_mun, paste0(nome_base, ".RData")))
    save(dados_municipio_pixel,
         file = file.path(dir_rd_pix, paste0(nome_base, "_pixel.RData")))
    message(sprintf("  %-45s %5d linhas (mun) | %6d linhas (pixel)",
                    nome_base, nrow(dados_municipio),
                    nrow(dados_municipio_pixel)))
}

######@> Resumo final do processamento...
message("\n=== Processamento concluído ===")
message("Municípios processados : ", length(unique(dados_municipio_final$geocodigo)))
message("Período coberto        : ",
        format(min(dados_municipio_final$data), "%Y-%m"), " a ",
        format(max(dados_municipio_final$data), "%Y-%m"))
message("Variáveis extraídas    : ", nrow(dicionario))
message("Linhas (nível pixel)   : ", nrow(dados_pixel))
message("Linhas (nível municipal): ", nrow(dados_municipio_final))
message("Saídas em              : ", normalizePath(dir_out))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
