########################################################################
## Description: Padronização, concatenação e organização das séries
##              temporais do Atlas Digital de Desastres no Brasil por
##              município costeiro de Santa Catarina...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: ter ago 19 09:00:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: Atlas Digital de Desastres no Brasil (S2iD/CEPED-UFSC
##                / MIDR) - planilha consolidada
##                ../Dados/Compilacao_01/Atlas_Digital/
##                BD_Atlas_1991_2025_v1.0_2026.04.23_Consolidado.xlsx
##                Duas abas: "Atlas Valores Corrigidos" (1.191 registros
##                de desastre x 70 colunas, 1991-2025, 35 municípios) e
##                "Grupos de Desastres" (dicionário COBRADE, 65 códigos).
##                Valores monetários JÁ CORRIGIDOS pela fonte (R$ da
##                data de consolidação: 2026-04-23); não devem ser
##                deflacionados novamente.
##
### Commentary:
##
## Este script padroniza e organiza os dados do Atlas Digital seguindo a
## MESMA arquitetura adotada para o Copernicus ERA5
## (script_ERA5_extracao_municipios_ver01.R) e para o MapBiomas
## (script_MapBiomas_extracao_municipios_ver00.R): shapefile padronizado
## em WGS84, vínculo pelo geocódigo IBGE, séries temporais concatenadas
## e saídas em Parquet e RData, em mais de um nível de agregação.
##
## Duas diferenças em relação às bases anteriores orientam o desenho:
##
##   (i) A unidade de observação do Atlas é o EVENTO (um registro por
##       protocolo S2iD), e não o município-mês (ERA5) ou o
##       município-ano (MapBiomas). Para que as três bases possam ser
##       cruzadas, o script entrega o registro de evento em sua forma
##       íntegra E as séries agregadas em GRADE COMPLETA - mensal
##       (compatível com o ERA5) e anual (compatível com o MapBiomas) -
##       nas quais os meses e anos sem desastre aparecem explicitamente
##       com zero, e não como ausência de linha. Sem essa grade, uma
##       simples contagem de linhas subestimaria sistematicamente os
##       períodos de calmaria;
##
##  (ii) O vínculo com o shapefile é feito pelo GEOCÓDIGO IBGE, que o
##       Atlas já fornece (Cod_IBGE_Mun) e que foi verificado como
##       idêntico ao geocódigo embutido no protocolo S2iD nos 1.191
##       registros. Não há, portanto, pareamento por nome - embora a
##       grafia dos nomes também tenha sido conferida contra o
##       shapefile, sem divergências.
##
## Fluxo geral do processamento:
##
##   01) Leitura e padronização do shapefile (datum WGS84 / EPSG:4326)
##       e dissolução das feições por município;
##   02) Leitura das duas abas da planilha e do dicionário COBRADE;
##   03) Padronização dos nomes de coluna, tipos e categorias, a partir
##       de uma tabela de correspondência única que também serve de
##       dicionário de variáveis das saídas;
##   04) Vínculo com o shapefile pelo geocódigo IBGE;
##   05) Variáveis derivadas e verificações de coerência interna
##       (totais, datas, escalas ordinais e valores implausíveis);
##   06) Montagem das séries temporais em grade completa: mensal e
##       anual, no total e por grupo/tipologia de desastre;
##   07) Dicionários e diagnóstico da base;
##   08) Exportação por município em Parquet e RData.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Leitura/manipulação de dados vetoriais
library(readxl)         ## Leitura de planilhas Excel (.xlsx)
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem e construção de grades completas
library(purrr)          ## Programação funcional (map/reduce)
library(stringi)        ## Transliteração de acentos (normalização)
library(arrow)          ## Escrita de arquivos Parquet

######@> Opções globais...
## Evita que strings sejam convertidas em fatores e desliga a notação
## científica, o que facilita a leitura dos códigos de município (IBGE),
## dos códigos COBRADE e dos valores monetários.
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente (garante reprodutibilidade de qualquer etapa
######@> eventualmente estocástica)...
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
## O script assume que está sendo executado a partir da pasta R_Work,
## portanto todos os caminhos são relativos a ela.
dir_dados <- "../Dados"
dir_atlas <- file.path(dir_dados, "Compilacao_01", "Atlas_Digital")
dir_shape <- file.path(dir_dados, "Shapefiles")

######@> Diretórios de saída...
## As saídas do Atlas ficam em subpasta própria dentro de Outputs, para
## não se misturarem às do ERA5 (que ocupam Outputs/Parquet e
## Outputs/RData) nem às do MapBiomas (Outputs/MapBiomas). A estrutura
## interna, porém, é a MESMA: um diretório por formato, com os arquivos
## por município em "Municipal/".
dir_out <- file.path(dir_dados, "Outputs", "Atlas_Digital")
dir_pq <- file.path(dir_out, "Parquet")
dir_rd <- file.path(dir_out, "RData")
dir_pq_mun <- file.path(dir_pq, "Municipal")
dir_rd_mun <- file.path(dir_rd, "Municipal")

######@> Criação da estrutura de saída (recursive = TRUE cria os níveis
######@> intermediários; showWarnings = FALSE evita aviso caso já
######@> exista)...
for(d in c(dir_out, dir_pq, dir_rd, dir_pq_mun, dir_rd_mun)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> Arquivos de entrada...
arq_atlas <- file.path(dir_atlas,
                       "BD_Atlas_1991_2025_v1.0_2026.04.23_Consolidado.xlsx")
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Nomes das abas da planilha...
## Fixados aqui para que qualquer renomeação futura da planilha produza
## um erro explícito, e não uma leitura silenciosamente errada.
aba_registros <- "Atlas Valores Corrigidos"
aba_cobrade <- "Grupos de Desastres"

######@> Datum/CRS de referência do projeto...
## EPSG:4326 = WGS84 em coordenadas geográficas (graus decimais). Mesmo
## referencial adotado no ERA5 e no MapBiomas, garantindo que as três
## bases sejam espacialmente compatíveis entre si.
crs_projeto <- 4326

######@> CRS auxiliar para cálculo de áreas...
## EPSG:5880 = SIRGAS 2000 / Brazil Polyconic. Projeção equivalente
## (preserva área), usada para calcular a área dos municípios em km2.
crs_area <- 5880

######@> Referência monetária dos valores...
## A aba se chama "Atlas Valores Corrigidos": os danos materiais e
## prejuízos JÁ FORAM deflacionados pela fonte. A data de referência é
## registrada aqui e propagada ao dicionário de variáveis, para que
## nenhuma análise posterior aplique uma segunda correção.
data_referencia_monetaria <- as.Date("2026-04-23")

########################################################################
######@> Funções auxiliares...

######@> Função para transliterar nomes em nomes seguros de arquivo...
## Remove acentos (stri_trans_general), troca qualquer caractere não
## alfanumérico por "_" e elimina underscores duplicados/terminais.
## Necessária porque os nomes dos municípios possuem acentuação
## (ex.: "Balneário Camboriú" -> "Balneario_Camboriu").
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Função de normalização para CONFERÊNCIA de nomes...
## Diferente de limpar_nome(): serve apenas para comparar nomes vindos
## de fontes distintas. Remove acentos, colapsa espaços e passa para
## maiúsculas. No Atlas o pareamento é feito pelo geocódigo, e não pelo
## nome; esta função é usada somente para AUDITAR a grafia contra o
## shapefile (Etapa 04).
normalizar_nome <- function(x) {
    x <- stri_trans_general(trimws(x), "Latin-ASCII")
    x <- gsub("\\s+", " ", x)
    return(toupper(x))
}

######@> Função de padronização das escalas ordinais de dano
######@> ambiental...
## As colunas DA_* não trazem valores numéricos, e sim faixas de
## população afetada. Os rótulos vêm em DUAS grafias para a mesma
## faixa - com e sem o sufixo "DA POPULAÇÃO AFETADA" (ex.: "MAIS DE 20%"
## e "MAIS DE 20% DA POPULAÇÃO AFETADA") -, o que faria a mesma
## categoria ser contada duas vezes em qualquer tabulação. A função
## reduz o rótulo à faixa e devolve a categoria padronizada; a versão
## numérica ordinal é gerada por nivel_dano_ambiental().
classe_dano_ambiental <- function(x) {
    y <- toupper(stri_trans_general(trimws(x), "Latin-ASCII"))
    y <- sub("\\s*DA POPULACAO AFETADA\\s*$", "", y)
    y <- gsub("\\s+", " ", y)
    dplyr::case_when(is.na(x) ~ NA_character_,
                     y == "DE 0% A 5%" ~ "0-5%",
                     y == "DE 5% A 10%" ~ "5-10%",
                     y == "DE 10% A 20%" ~ "10-20%",
                     y == "MAIS DE 20%" ~ ">20%",
                     TRUE ~ NA_character_)
}

######@> Versão ordinal numérica da escala de dano ambiental...
## Devolve 1 a 4 na ordem crescente de gravidade, permitindo ordenar,
## somar e comparar as faixas sem depender do rótulo textual. Rótulos
## não previstos devolvem NA - e, se existirem, aparecem no diagnóstico
## como divergência entre o número de células preenchidas e o número de
## células classificadas.
nivel_dano_ambiental <- function(x) {
    faixas <- c("0-5%" = 1L, "5-10%" = 2L, "10-20%" = 3L, ">20%" = 4L)
    return(unname(faixas[classe_dano_ambiental(x)]))
}

######@> Função para contar setores censitários de um registro...
## A coluna "Setores Censitários" traz uma lista de códigos de 15
## dígitos separados por vírgula (verificado: 28.331 códigos, todos com
## 15 dígitos e todos com prefixo igual ao geocódigo do município do
## registro). Guardar a contagem, além do texto original, permite usar a
## extensão territorial do desastre como variável sem ter que
## reprocessar a string.
contar_setores <- function(x) {
    if(is.na(x)) return(0L)
    partes <- trimws(strsplit(x, ",", fixed = TRUE)[[1]])
    return(as.integer(sum(nzchar(partes))))
}

######@> Função de verificação de coerência entre total e componentes...
## Recalcula o total a partir das colunas que o compõem e devolve uma
## linha de diagnóstico. É aplicada aos totais da planilha (Etapa 05). A
## verificação é EXECUTADA no script, e não apenas afirmada em
## comentário: se a fonte mudar, a divergência aparecerá na tabela de
## diagnóstico em vez de passar despercebida.
##
## A tolerância é de UM CENTAVO, e não de zero absoluto. Os prejuízos
## chegam a R$ 1,2 bilhão em um único registro, e a soma de parcelas em
## ponto flutuante dessa ordem de grandeza acumula erro de arredondamento
## da ordem de 1e-6 - resíduo aritmético que não tem nenhum significado
## contábil. Com tolerância zero, três verificações acusariam
## "divergência" por causa desse resíduo, escondendo as divergências
## reais no meio do ruído. Para contagens de pessoas e de unidades, um
## centavo é igualmente inofensivo, pois qualquer discrepância verdadeira
## vale no mínimo 1.
##
## O argumento "esperada" marca as verificações em que a divergência é o
## resultado previsto (caso do total de danos humanos, que por definição
## NÃO soma os outros afetados), de modo que elas não disparem alarme.
conferir_total <- function(dados, col_total, cols_componentes, rotulo,
                           esperada = FALSE, tolerancia = 0.01) {
    soma <- rowSums(as.matrix(dados[, cols_componentes]), na.rm = TRUE)
    diferenca <- abs(dados[[col_total]] - soma)
    tibble(verificacao = rotulo,
           coluna_total = col_total,
           n_componentes = length(cols_componentes),
           n_divergentes = sum(diferenca > tolerancia, na.rm = TRUE),
           dif_maxima = max(diferenca, na.rm = TRUE),
           divergencia_esperada = esperada)
}

########################################################################
######@> Etapa 01 - Leitura e padronização do shapefile...

######@> Leitura do shapefile de municípios costeiros...
message("Lendo shapefile de municípios costeiros...")
shape_bruto <- st_read(arq_shape, quiet = TRUE)

######@> Correção de geometrias inválidas...
## O shapefile possui polígonos com ordem de rotação (winding order)
## incorreta e 2 geometrias inválidas. st_make_valid() corrige esses
## problemas, que de outro modo provocariam erro no cálculo de áreas.
shape_bruto <- st_make_valid(shape_bruto)

######@> Padronização do datum para WGS84...
## O shapefile já se encontra em GCS_WGS_1984, mas o arquivo .prj usa a
## nomenclatura antiga do ESRI ("D_WGS_1984"), sem código EPSG
## explícito. st_transform() para EPSG:4326 formaliza o CRS, mantendo a
## base espacialmente compatível com o ERA5 e o MapBiomas.
shape_bruto <- st_transform(shape_bruto, crs_projeto)

######@> Consolidação dos atributos de identificação do município...
## O shapefile resultou da união de três camadas distintas e, por isso,
## possui 29 colunas com TRÊS blocos redundantes de atributos
## ("nome"/"codigo_ibg", "MUNICIPIO"/"GEOCODIGO" e
## "MUNICIPIO_"/"GEOCODIGO_"). Cada feição preenche apenas um dos
## blocos, deixando os demais como NA. coalesce() percorre os blocos na
## ordem e assume o primeiro valor não-nulo, recuperando nome e código
## IBGE para as 81 feições sem nenhum NA.
atributos <- st_drop_geometry(shape_bruto)
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))

######@> Dissolução das feições por município...
## As 81 feições originais correspondem a apenas 37 municípios (há
## polígonos repetidos e municípios fragmentados em várias partes, como
## ilhas). O agrupamento por geocódigo + nome, seguido de summarise(),
## dissolve as partes em uma única geometria por município.
municipios <- shape_bruto %>%
    group_by(geocodigo, municipio) %>%
    summarise(.groups = "drop") %>%
    st_make_valid() %>%
    arrange(municipio)

######@> Cálculo da área municipal (km2) e do centroide...
## A área é usada adiante para expressar a frequência de desastres por
## unidade de território (Etapa 07) e mantém a saída comparável às das
## demais bases, que também carregam esses atributos.
municipios$area_km2_shape <-
    as.numeric(st_area(st_transform(municipios, crs_area))) / 1e6
centroides <- suppressWarnings(st_coordinates(st_centroid(municipios)))
municipios$lon_centroide <- centroides[, "X"]
municipios$lat_centroide <- centroides[, "Y"]

######@> Tabela de metadados dos municípios (sem geometria)...
## As saídas do Atlas são tabelas, não objetos espaciais; a geometria é
## descartada aqui, mas o vínculo permanece pelo geocódigo.
meta_municipios <- municipios %>%
    st_drop_geometry() %>%
    mutate(nome_norm = normalizar_nome(municipio))

message("Municípios no shapefile: ", nrow(meta_municipios))
message("CRS de trabalho: EPSG:", st_crs(municipios)$epsg)

########################################################################
######@> Etapa 02 - Leitura da planilha do Atlas Digital...

######@> Conferência das abas esperadas...
## Falhar cedo e com mensagem clara é preferível a ler a aba errada.
abas <- excel_sheets(arq_atlas)
if(!all(c(aba_registros, aba_cobrade) %in% abas)) {
    stop("Abas esperadas não encontradas na planilha: ",
         paste(setdiff(c(aba_registros, aba_cobrade), abas),
               collapse = ", "))
}

######@> Leitura da aba de registros de desastre...
## .name_repair = "minimal" preserva os nomes ORIGINAIS das colunas
## (com acentos, espaços e parênteses), que são a chave da tabela de
## correspondência montada na Etapa 03. Deixar o readxl "consertar" os
## nomes aqui tornaria a correspondência dependente de um algoritmo
## interno do pacote, e não de um mapeamento explícito e auditável.
## Os avisos de coerção de tipo do readxl são suprimidos porque as
## colunas DA_* são de fato textuais em meio a colunas numéricas - a
## conversão correta é feita explicitamente adiante.
message("Lendo planilha do Atlas Digital...")
atlas_bruto <- suppressWarnings(
    read_excel(arq_atlas, sheet = aba_registros, .name_repair = "minimal"))

######@> Leitura do dicionário COBRADE (segunda aba)...
## Classificação e Codificação Brasileira de Desastres: relaciona o
## código COBRADE ao nome do desastre, à tipologia adotada pelo Atlas e
## ao grupo de desastre.
cobrade_bruto <- read_excel(arq_atlas, sheet = aba_cobrade,
                            .name_repair = "minimal")

message("Registros lidos: ", nrow(atlas_bruto), " x ",
        ncol(atlas_bruto), " colunas")
message("Códigos COBRADE no dicionário: ", nrow(cobrade_bruto))

########################################################################
######@> Etapa 03 - Padronização de nomes, tipos e categorias...

######@> Tabela de correspondência de colunas...
## Esta tabela é o núcleo da padronização e cumpre TRÊS papéis de uma só
## vez: (a) renomeia as colunas originais para nomes ASCII em
## snake_case, sem acentos, espaços, parênteses ou barras - que são
## exatamente os caracteres que quebram consultas em Parquet e o uso de
## `$` no R; (b) declara o tipo esperado de cada coluna; e (c) alimenta
## o dicionário de variáveis exportado junto às bases. Mantê-los em um
## único lugar evita a situação clássica em que o dicionário deixa de
## descrever a base depois de uma alteração no código.
##
## Convenção dos prefixos, herdada do próprio Atlas:
##   DH_   -> Danos Humanos (pessoas);
##   DM_   -> Danos Materiais (edificações e obras; unidades e R$);
##   DA_   -> Danos Ambientais (escalas ordinais de população afetada);
##   PEPL_ -> Prejuízos Econômicos Públicos (R$);
##   PEPR_ -> Prejuízos Econômicos Privados (R$).
mapa_colunas <- tribble(
    ~original,                        ~variavel,                     ~tipo,        ~descricao,                                                             ~unidade,
    "Protocolo_S2iD",                 "protocolo_s2id",              "texto",      "Protocolo do registro no S2iD (UF-tipo-geocódigo-COBRADE-data)",        "-",
    "Nome_Municipio",                 "municipio_atlas",             "texto",      "Nome do município conforme grafado no Atlas",                           "-",
    "Sigla_UF",                       "uf",                          "texto",      "Unidade da Federação",                                                  "-",
    "regiao",                         "regiao",                      "texto",      "Grande região do IBGE",                                                 "-",
    "Cod_IBGE_Mun",                   "geocodigo",                   "texto",      "Geocódigo IBGE do município (7 dígitos)",                               "-",
    "Data_Evento",                    "data_evento",                 "data",       "Data de ocorrência do desastre informada pelo Atlas",                   "data",
    "Data_Registro",                  "data_registro",               "data",       "Data de registro do desastre no S2iD",                                  "data",
    "Cod_Cobrade",                    "cod_cobrade",                 "texto",      "Código COBRADE do desastre (5 dígitos)",                                "-",
    "tipologia",                      "cod_tipologia",               "inteiro",    "Código da tipologia agregada adotada pelo Atlas (1 a 16)",              "-",
    "descricao_tipologia",            "tipologia",                   "texto",      "Tipologia agregada do desastre (16 categorias)",                        "-",
    "grupo_de_desastre",              "grupo_desastre",              "texto",      "Grupo de desastre (Climatológico, Hidrológico, Meteorológico, Outros)", "-",
    "Status",                         "status",                      "texto",      "Situação do registro (Registro ou Reconhecido)",                        "-",
    "Setores Censitários",            "setores_censitarios",         "texto",      "Códigos dos setores censitários atingidos, separados por vírgula",      "-",
    "DH_Descricao",                   "dh_descricao",                "texto",      "Descrição textual dos danos humanos",                                   "-",
    "DH_MORTOS",                      "dh_mortos",                   "numerico",   "Pessoas mortas",                                                        "pessoas",
    "DH_FERIDOS",                     "dh_feridos",                  "numerico",   "Pessoas feridas",                                                       "pessoas",
    "DH_ENFERMOS",                    "dh_enfermos",                 "numerico",   "Pessoas enfermas",                                                      "pessoas",
    "DH_DESABRIGADOS",                "dh_desabrigados",             "numerico",   "Pessoas desabrigadas (dependentes de abrigo público)",                  "pessoas",
    "DH_DESALOJADOS",                 "dh_desalojados",              "numerico",   "Pessoas desalojadas (sem abrigo público)",                              "pessoas",
    "DH_DESAPARECIDOS",               "dh_desaparecidos",            "numerico",   "Pessoas desaparecidas",                                                 "pessoas",
    "DH_AFETADOS_SECA_ESTIAGEM",      "dh_afetados_seca_estiagem",   "numerico",   "Pessoas afetadas especificamente por seca/estiagem",                    "pessoas",
    "DH_total_danos_humanos_diretos", "dh_total_diretos",            "numerico",   "Total de danos humanos diretos (soma das sete categorias acima)",       "pessoas",
    "DH_OUTROS AFETADOS",             "dh_outros_afetados",          "numerico",   "Outras pessoas afetadas (NÃO incluídas em dh_total_diretos)",           "pessoas",
    "DM_Descricao",                   "dm_descricao",                "texto",      "Descrição textual dos danos materiais",                                 "-",
    "DM_Uni Habita Danificadas",      "dm_habitacoes_danificadas",   "numerico",   "Unidades habitacionais danificadas",                                    "unidades",
    "DM_Uni Habita Destruidas",       "dm_habitacoes_destruidas",    "numerico",   "Unidades habitacionais destruídas",                                     "unidades",
    "DM_Uni Habita Valor",            "dm_habitacoes_valor",         "numerico",   "Valor dos danos em unidades habitacionais",                             "R$ corrigidos",
    "DM_Inst Saúde Danificadas",      "dm_saude_danificadas",        "numerico",   "Instalações de saúde danificadas",                                      "unidades",
    "DM_Inst Saúde Destruidas",       "dm_saude_destruidas",         "numerico",   "Instalações de saúde destruídas",                                       "unidades",
    "DM_Inst Saúde Valor",            "dm_saude_valor",              "numerico",   "Valor dos danos em instalações de saúde",                               "R$ corrigidos",
    "DM_Inst Ensino Danificadas",     "dm_ensino_danificadas",       "numerico",   "Instalações de ensino danificadas",                                     "unidades",
    "DM_Inst Ensino Destruidas",      "dm_ensino_destruidas",        "numerico",   "Instalações de ensino destruídas",                                      "unidades",
    "DM_Inst Ensino Valor",           "dm_ensino_valor",             "numerico",   "Valor dos danos em instalações de ensino",                              "R$ corrigidos",
    "DM_Inst Serviços Danificadas",   "dm_servicos_danificadas",     "numerico",   "Instalações de prestação de serviços danificadas",                      "unidades",
    "DM_Inst Serviços Destruidas",    "dm_servicos_destruidas",      "numerico",   "Instalações de prestação de serviços destruídas",                       "unidades",
    "DM_Inst Serviços Valor",         "dm_servicos_valor",           "numerico",   "Valor dos danos em instalações de prestação de serviços",               "R$ corrigidos",
    "DM_Inst Comuni Danificadas",     "dm_comunitarias_danificadas", "numerico",   "Instalações comunitárias danificadas",                                  "unidades",
    "DM_Inst Comuni Destruidas",      "dm_comunitarias_destruidas",  "numerico",   "Instalações comunitárias destruídas",                                   "unidades",
    "DM_Inst Comuni Valor",           "dm_comunitarias_valor",       "numerico",   "Valor dos danos em instalações comunitárias",                           "R$ corrigidos",
    "DM_Obras de Infra Danificadas",  "dm_infraestrutura_danificadas", "numerico", "Obras de infraestrutura danificadas",                                   "unidades",
    "DM_Obras de Infra Destruidas",   "dm_infraestrutura_destruidas", "numerico",  "Obras de infraestrutura destruídas",                                    "unidades",
    "DM_Obras de Infra Valor",        "dm_infraestrutura_valor",     "numerico",   "Valor dos danos em obras de infraestrutura",                            "R$ corrigidos",
    "DM_total_danos_materiais",       "dm_total_valor",              "numerico",   "Total dos danos materiais (soma dos seis valores acima)",               "R$ corrigidos",
    "DA_Descricao",                   "da_descricao",                "texto",      "Descrição textual dos danos ambientais",                                "-",
    "DA_Polui/cont da água",          "da_poluicao_agua",            "ordinal",    "Poluição/contaminação da água (faixa de população afetada)",            "faixa",
    "DA_Polui/cont do ar",            "da_poluicao_ar",              "ordinal",    "Poluição/contaminação do ar (faixa de população afetada)",              "faixa",
    "DA_Polui/cont do solo",          "da_poluicao_solo",            "ordinal",    "Poluição/contaminação do solo (faixa de população afetada)",            "faixa",
    "DA_Dimi/exauri hídrico",         "da_exaurimento_hidrico",      "ordinal",    "Diminuição/exaurimento hídrico (faixa de população afetada)",           "faixa",
    "DA_Incêndi parques/APA's/APP's", "da_incendio_areas_protegidas", "ordinal",   "Incêndio em parques, APAs e APPs (faixa de população afetada)",         "faixa",
    "PEPL_Descricao",                 "pepl_descricao",              "texto",      "Descrição textual dos prejuízos econômicos públicos",                   "-",
    "PEPL_Assis_méd e emergên(R$)",   "pepl_assistencia_medica",     "numerico",   "Prejuízo público - assistência médica e emergências",                   "R$ corrigidos",
    "PEPL_Abast de água pot(R$)",     "pepl_abastecimento_agua",     "numerico",   "Prejuízo público - abastecimento de água potável",                      "R$ corrigidos",
    "PEPL_sist de esgotos sanit(R$)", "pepl_esgoto_sanitario",       "numerico",   "Prejuízo público - sistema de esgotos sanitários",                      "R$ corrigidos",
    "PEPL_Sis limp e rec lixo (R$)",  "pepl_limpeza_residuos",       "numerico",   "Prejuízo público - limpeza urbana e resíduos sólidos",                  "R$ corrigidos",
    "PEPL_Sis cont pragas (R$)",      "pepl_controle_pragas",        "numerico",   "Prejuízo público - controle de pragas",                                 "R$ corrigidos",
    "PEPL_distrib energia (R$)",      "pepl_energia",                "numerico",   "Prejuízo público - distribuição de energia",                            "R$ corrigidos",
    "PEPL_Telecomunicações (R$)",     "pepl_telecomunicacoes",       "numerico",   "Prejuízo público - telecomunicações",                                   "R$ corrigidos",
    "PEPL_Tran loc/reg/l_curso (R$)", "pepl_transporte",             "numerico",   "Prejuízo público - transporte local, regional e de longo curso",        "R$ corrigidos",
    "PEPL_Distrib combustíveis(R$)",  "pepl_combustiveis",           "numerico",   "Prejuízo público - distribuição de combustíveis",                       "R$ corrigidos",
    "PEPL_Segurança pública (R$)",    "pepl_seguranca_publica",      "numerico",   "Prejuízo público - segurança pública",                                  "R$ corrigidos",
    "PEPL_Ensino (R$)",               "pepl_ensino",                 "numerico",   "Prejuízo público - ensino",                                             "R$ corrigidos",
    "PEPL_total_publico",             "pepl_total",                  "numerico",   "Total dos prejuízos econômicos públicos",                               "R$ corrigidos",
    "PEPR_Descricao",                 "pepr_descricao",              "texto",      "Descrição textual dos prejuízos econômicos privados",                   "-",
    "PEPR_Agricultura (R$)",          "pepr_agricultura",            "numerico",   "Prejuízo privado - agricultura",                                        "R$ corrigidos",
    "PEPR_Pecuária (R$)",             "pepr_pecuaria",               "numerico",   "Prejuízo privado - pecuária",                                           "R$ corrigidos",
    "PEPR_Indústria (R$)",            "pepr_industria",              "numerico",   "Prejuízo privado - indústria",                                          "R$ corrigidos",
    "PEPR_Comércio (R$)",             "pepr_comercio",               "numerico",   "Prejuízo privado - comércio",                                           "R$ corrigidos",
    "PEPR_Serviços (R$)",             "pepr_servicos",               "numerico",   "Prejuízo privado - serviços",                                           "R$ corrigidos",
    "PEPR_total_privado",             "pepr_total",                  "numerico",   "Total dos prejuízos econômicos privados",                               "R$ corrigidos",
    "PE_PLePR",                       "pe_total",                    "numerico",   "Prejuízo econômico total (público + privado)",                          "R$ corrigidos")

######@> Conferência da correspondência de colunas...
## Nenhuma coluna da planilha pode ficar de fora do mapeamento, e o
## mapeamento não pode citar colunas inexistentes. As duas verificações
## são feitas explicitamente para que uma mudança de layout na fonte
## interrompa o processamento em vez de gerar uma base incompleta.
faltando_no_mapa <- setdiff(names(atlas_bruto), mapa_colunas$original)
faltando_na_planilha <- setdiff(mapa_colunas$original, names(atlas_bruto))

if(length(faltando_no_mapa) > 0) {
    stop("Colunas da planilha ausentes no mapeamento: ",
         paste(faltando_no_mapa, collapse = " | "))
}
if(length(faltando_na_planilha) > 0) {
    stop("Colunas do mapeamento ausentes na planilha: ",
         paste(faltando_na_planilha, collapse = " | "))
}

######@> Aplicação do renomeio...
## O vetor nomeado inverte a tabela (novo = antigo), formato aceito por
## rename(); select() em seguida reordena as colunas na ordem do
## mapeamento, que agrupa os blocos DH/DM/DA/PEPL/PEPR.
vetor_renomeio <- setNames(mapa_colunas$original, mapa_colunas$variavel)

atlas <- atlas_bruto %>%
    rename(all_of(vetor_renomeio)) %>%
    select(all_of(mapa_colunas$variavel))

######@> Padronização dos tipos...
## Cada conversão responde a um problema concreto observado na leitura:
##   - geocodigo e cod_cobrade chegam como numéricos e voltariam a ser
##     escritos em notação científica ou com casas decimais; passam a
##     texto com largura fixa (7 e 5 dígitos), que é a forma canônica
##     dos dois códigos e a mesma usada no shapefile;
##   - as datas chegam como POSIXct (readxl assume UTC); as.Date()
##     descarta o horário, que é sempre 00:00:00 e não carrega
##     informação;
##   - as colunas textuais recebem trimws() para eliminar espaços
##     residuais que criariam categorias duplicadas em tabulações.
atlas <- atlas %>%
    mutate(geocodigo = sprintf("%07.0f", as.numeric(geocodigo)),
           cod_cobrade = sprintf("%05.0f", as.numeric(cod_cobrade)),
           cod_tipologia = as.integer(cod_tipologia),
           data_evento = as.Date(data_evento),
           data_registro = as.Date(data_registro),
           across(all_of(mapa_colunas$variavel[mapa_colunas$tipo ==
                                               "texto"]),
                  ~ trimws(as.character(.x))))

######@> Padronização das escalas ordinais de dano ambiental...
## Para cada coluna DA_* ordinal são criadas duas novas colunas: a
## categoria padronizada (sufixo _classe) e o nível ordinal 1-4 (sufixo
## _nivel). As colunas originais são MANTIDAS, para que a padronização
## seja sempre conferível contra a fonte.
cols_ordinais <- mapa_colunas$variavel[mapa_colunas$tipo == "ordinal"]

for(col in cols_ordinais) {
    atlas[[paste0(col, "_classe")]] <- classe_dano_ambiental(atlas[[col]])
    atlas[[paste0(col, "_nivel")]] <- nivel_dano_ambiental(atlas[[col]])
}

message("Colunas padronizadas: ", nrow(mapa_colunas),
        " | ordinais expandidas: ", length(cols_ordinais))

######@> Padronização do dicionário COBRADE...
## Mesmos princípios: nomes ASCII em snake_case e código como texto de
## largura fixa, para que a junção com os registros seja feita entre
## colunas do mesmo tipo.
dicionario_cobrade <- cobrade_bruto %>%
    transmute(cod_cobrade = sprintf("%05.0f", as.numeric(Cobrade)),
              desastre_cobrade = trimws(Desastre),
              tipologia = trimws(`Atlas - Descrição Tipologia`),
              cod_tipologia = as.integer(`Atlas N. Tipologia`),
              grupo_desastre = trimws(`Grupo de desastres`)) %>%
    arrange(cod_cobrade)

########################################################################
######@> Etapa 04 - Vínculo com o shapefile...

######@> Conferência dos geocódigos antes de unir...
## O geocódigo IBGE é a chave definitiva, exatamente como no ERA5 e no
## MapBiomas. Verifica-se nos dois sentidos.
geo_atlas <- sort(unique(atlas$geocodigo))
geo_shape <- sort(unique(meta_municipios$geocodigo))

sem_shape <- setdiff(geo_atlas, geo_shape)
sem_atlas <- setdiff(geo_shape, geo_atlas)

if(length(sem_shape) > 0) {
    stop("Geocódigos do Atlas sem correspondência no shapefile: ",
         paste(sem_shape, collapse = ", "))
}

######@> Municípios do shapefile SEM registros no Atlas...
## Verificado: Camboriú (4203204) e Paulo Lopes (4212304) não aparecem
## em nenhum dos 1.191 registros - os mesmos dois municípios que também
## não possuem dados do MapBiomas.
##
## Decisão metodológica: esses municípios NÃO entram nas séries
## temporais. A razão é que, com a informação disponível, não é possível
## distinguir "nenhum desastre registrado no período" de "município não
## contemplado na compilação"; as duas hipóteses levariam a séries
## opostas (zeros verdadeiros ou dados ausentes). Preencher a grade com
## zero seria, portanto, afirmar algo que a fonte não sustenta. Eles são
## registrados explicitamente em Atlas_resumo_municipios, com
## tem_registro_atlas = FALSE, para que a ausência apareça na análise em
## vez de desaparecer nela.
municipios_sem_dados <- meta_municipios %>%
    filter(geocodigo %in% sem_atlas) %>%
    select(geocodigo, municipio)

if(nrow(municipios_sem_dados) > 0) {
    message("ATENÇÃO - municípios do shapefile SEM registros no Atlas: ",
            paste(municipios_sem_dados$municipio, collapse = ", "))
}

######@> Auditoria da grafia dos nomes...
## O pareamento é pelo geocódigo, mas a grafia também é conferida: se
## Atlas e shapefile discordarem no nome de um mesmo código, isso indica
## erro de cadastro em uma das fontes e precisa ser visto.
divergencia_nomes <- atlas %>%
    distinct(geocodigo, municipio_atlas) %>%
    inner_join(meta_municipios %>% select(geocodigo, municipio),
               by = "geocodigo") %>%
    filter(normalizar_nome(municipio_atlas) != normalizar_nome(municipio))

if(nrow(divergencia_nomes) > 0) {
    warning("Divergência de grafia entre Atlas e shapefile em ",
            nrow(divergencia_nomes), " município(s)")
}

######@> Junção com os metadados dos municípios...
## O nome oficial adotado nas saídas é o do SHAPEFILE, assegurando
## grafia uniforme entre as bases Atlas, MapBiomas e ERA5. O nome
## original do Atlas é preservado em municipio_atlas.
atlas <- atlas %>%
    inner_join(meta_municipios %>%
                   select(geocodigo, municipio, area_km2_shape,
                          lon_centroide, lat_centroide),
               by = "geocodigo")

message("Registros após vínculo com o shapefile: ", nrow(atlas))

########################################################################
######@> Etapa 05 - Variáveis derivadas e coerência interna...

######@> Decomposição do protocolo S2iD...
## O protocolo tem a forma UF-tipo-geocódigo-COBRADE-AAAAMMDD e é a
## única fonte de duas informações que não existem em coluna própria:
##   - tipo_protocolo : letra que identifica o formulário de origem do
##                      registro (A, C, D, F, J, N, P, R);
##   - data_protocolo : data embutida no protocolo.
## Extrair essas partes permite AUDITAR as demais colunas contra o
## identificador do próprio registro (ver conferências adiante).
partes_protocolo <- strsplit(atlas$protocolo_s2id, "-", fixed = TRUE)

if(any(lengths(partes_protocolo) != 5)) {
    warning("Protocolos fora do padrão UF-tipo-geocódigo-COBRADE-data: ",
            sum(lengths(partes_protocolo) != 5))
}

atlas <- atlas %>%
    mutate(tipo_protocolo = map_chr(partes_protocolo,
                                    ~ as.character(.x[2])),
           geocodigo_protocolo = map_chr(partes_protocolo,
                                         ~ as.character(.x[3])),
           cod_cobrade_protocolo = map_chr(partes_protocolo,
                                           ~ as.character(.x[4])),
           data_protocolo = as.Date(map_chr(partes_protocolo,
                                            ~ as.character(.x[5])),
                                    format = "%Y%m%d"))

######@> Marcadores temporais das séries...
## A DATA DE EVENTO é a referência temporal adotada nas séries, por ser
## o campo que o Atlas define como data de ocorrência. As colunas ano,
## mes e data (primeiro dia do mês) reproduzem a mesma convenção usada
## no ERA5, o que permite unir as duas bases por geocodigo + ano + mes.
atlas <- atlas %>%
    mutate(ano = as.integer(format(data_evento, "%Y")),
           mes = as.integer(format(data_evento, "%m")),
           data = as.Date(sprintf("%d-%02d-01", ano, mes)),
           ano_registro = as.integer(format(data_registro, "%Y")),
           ## Defasagem entre a ocorrência e o registro no S2iD. Serve
           ## como medida da tempestividade do reporte e explica por que
           ## há registros datados de 2026 para eventos de 2025.
           defasagem_registro_dias = as.integer(data_registro -
                                                data_evento))

######@> Indicadores derivados de interesse analítico...
atlas <- atlas %>%
    mutate(
        ## Situação do registro como variável lógica, mais direta de usar
        ## em filtros e somas do que o texto de status.
        reconhecido = status == "Reconhecido",
        ## Total de atingidos incluindo os "outros afetados". Verificou-se
        ## que dh_total_diretos NÃO os contempla (498 registros
        ## divergiriam); a soma completa fica em coluna própria para que
        ## as duas leituras convivam sem ambiguidade.
        dh_afetados_total = dh_total_diretos + dh_outros_afetados,
        ## Óbitos e desaparecimentos, agregados por serem tratados em
        ## conjunto na literatura de mortalidade por desastres.
        dh_mortos_desaparecidos = dh_mortos + dh_desaparecidos,
        ## Edificações e obras atingidas, em unidades físicas.
        dm_total_danificadas = dm_habitacoes_danificadas +
            dm_saude_danificadas + dm_ensino_danificadas +
            dm_servicos_danificadas + dm_comunitarias_danificadas +
            dm_infraestrutura_danificadas,
        dm_total_destruidas = dm_habitacoes_destruidas +
            dm_saude_destruidas + dm_ensino_destruidas +
            dm_servicos_destruidas + dm_comunitarias_destruidas +
            dm_infraestrutura_destruidas,
        ## Impacto econômico completo: danos materiais somados aos
        ## prejuízos públicos e privados. É a medida monetária que
        ## resume o evento.
        impacto_economico_total = dm_total_valor + pe_total,
        ## Extensão territorial do desastre dentro do município.
        n_setores_censitarios = map_int(setores_censitarios,
                                        contar_setores))

######@> Conferência 01 - coerência dos totais da planilha...
## Recalcula os quatro totais a partir de seus componentes. Executado a
## cada rodada; o resultado vai para o diagnóstico exportado.
cols_dh <- c("dh_mortos", "dh_feridos", "dh_enfermos", "dh_desabrigados",
             "dh_desalojados", "dh_desaparecidos",
             "dh_afetados_seca_estiagem")
cols_dm_valor <- c("dm_habitacoes_valor", "dm_saude_valor",
                   "dm_ensino_valor", "dm_servicos_valor",
                   "dm_comunitarias_valor", "dm_infraestrutura_valor")
cols_pepl <- c("pepl_assistencia_medica", "pepl_abastecimento_agua",
               "pepl_esgoto_sanitario", "pepl_limpeza_residuos",
               "pepl_controle_pragas", "pepl_energia",
               "pepl_telecomunicacoes", "pepl_transporte",
               "pepl_combustiveis", "pepl_seguranca_publica",
               "pepl_ensino")
cols_pepr <- c("pepr_agricultura", "pepr_pecuaria", "pepr_industria",
               "pepr_comercio", "pepr_servicos")

coerencia_totais <- bind_rows(
    conferir_total(atlas, "dh_total_diretos", cols_dh,
                   "Danos humanos diretos = soma das sete categorias"),
    conferir_total(atlas, "dm_total_valor", cols_dm_valor,
                   "Danos materiais = soma dos seis valores"),
    conferir_total(atlas, "pepl_total", cols_pepl,
                   "Prejuízo público = soma das onze rubricas"),
    conferir_total(atlas, "pepr_total", cols_pepr,
                   "Prejuízo privado = soma das cinco rubricas"),
    conferir_total(atlas, "pe_total", c("pepl_total", "pepr_total"),
                   "Prejuízo total = público + privado"),
    conferir_total(atlas, "dh_total_diretos",
                   c(cols_dh, "dh_outros_afetados"),
                   paste("Danos humanos diretos INCLUIRIAM outros",
                         "afetados (espera-se divergência)"),
                   esperada = TRUE))

if(any(coerencia_totais$n_divergentes > 0 &
       !coerencia_totais$divergencia_esperada)) {
    warning("Totais da planilha inconsistentes com seus componentes; ",
            "ver objeto coerencia_totais")
}

######@> Conferência 02 - coerência dos códigos e datas...
## Cada linha compara uma coluna da planilha com a informação
## correspondente embutida no protocolo S2iD. As divergências
## encontradas NÃO são corrigidas: o Atlas é a fonte oficial e a
## correção exigiria decidir qual campo está certo, decisão que cabe à
## análise e não à padronização. Elas ficam registradas, com o número de
## casos, para que o analista as leve em conta.
coerencia_registros <- tibble(
    verificacao = c("Geocódigo da coluna == geocódigo do protocolo",
                    "COBRADE da coluna == COBRADE do protocolo",
                    "Data do evento == data do protocolo",
                    "Data do evento no mesmo mês do protocolo",
                    "Data de registro >= data do evento",
                    "Protocolo S2iD único"),
    n_registros = nrow(atlas),
    n_divergentes = c(
        sum(atlas$geocodigo != atlas$geocodigo_protocolo),
        sum(atlas$cod_cobrade != atlas$cod_cobrade_protocolo),
        sum(atlas$data_evento != atlas$data_protocolo, na.rm = TRUE),
        sum(format(atlas$data_evento, "%Y-%m") !=
            format(atlas$data_protocolo, "%Y-%m"), na.rm = TRUE),
        sum(atlas$data_registro < atlas$data_evento),
        sum(duplicated(atlas$protocolo_s2id))))

######@> Conferência 03 - coerência com o dicionário COBRADE...
## Confere se tipologia, código de tipologia e grupo de desastre
## informados em cada registro correspondem ao que o dicionário da
## segunda aba atribui àquele código COBRADE.
conferencia_cobrade <- atlas %>%
    select(cod_cobrade, tipologia, cod_tipologia, grupo_desastre) %>%
    left_join(dicionario_cobrade %>%
                  rename(tipologia_dic = tipologia,
                         cod_tipologia_dic = cod_tipologia,
                         grupo_dic = grupo_desastre),
              by = "cod_cobrade")

coerencia_registros <- bind_rows(
    coerencia_registros,
    tibble(verificacao = c("COBRADE do registro existe no dicionário",
                           "Tipologia == tipologia do dicionário",
                           "Código de tipologia == código do dicionário",
                           "Grupo de desastre == grupo do dicionário"),
           n_registros = nrow(atlas),
           n_divergentes = c(
               sum(is.na(conferencia_cobrade$desastre_cobrade)),
               sum(conferencia_cobrade$tipologia !=
                   conferencia_cobrade$tipologia_dic, na.rm = TRUE),
               sum(conferencia_cobrade$cod_tipologia !=
                   conferencia_cobrade$cod_tipologia_dic, na.rm = TRUE),
               sum(conferencia_cobrade$grupo_desastre !=
                   conferencia_cobrade$grupo_dic, na.rm = TRUE))))

######@> Incorporação do nome detalhado do desastre...
## Só depois de conferido é que o dicionário é usado para enriquecer a
## base: o nome COBRADE detalhado (ex.: "Tempestade Local/Convectiva -
## Granizo") acompanha a tipologia agregada do Atlas, permitindo
## análises em dois níveis de resolução temática.
atlas <- atlas %>%
    left_join(dicionario_cobrade %>%
                  select(cod_cobrade, desastre_cobrade),
              by = "cod_cobrade")

######@> Conferência 04 - valores implausíveis...
## Sinaliza registros em que o número de instalações DESTRUÍDAS é
## desproporcional ao porte do município (limiar de 100 unidades).
## Verificou-se, por exemplo, um registro em Itajaí com 14.182
## instalações de saúde destruídas - grandeza incompatível com a rede de
## saúde de qualquer município catarinense, e provavelmente resultante
## de preenchimento equivocado do campo na ficha original (número de
## pessoas ou de imóveis lançado no campo de instalações).
##
## Esses valores NÃO são alterados nem removidos. São listados em tabela
## própria porque afetam de modo relevante os agregados de
## dm_total_destruidas, e quem usar essa variável precisa saber onde ela
## é frágil.
limiar_implausivel <- 100

cols_destruidas_inst <- c("dm_saude_destruidas", "dm_ensino_destruidas",
                          "dm_servicos_destruidas",
                          "dm_comunitarias_destruidas")

alertas_valores <- atlas %>%
    select(geocodigo, municipio, protocolo_s2id, data_evento, tipologia,
           all_of(cols_destruidas_inst)) %>%
    pivot_longer(cols = all_of(cols_destruidas_inst),
                 names_to = "variavel", values_to = "valor") %>%
    filter(valor > limiar_implausivel) %>%
    mutate(motivo = paste0("Instalações destruídas acima de ",
                           limiar_implausivel, " unidades")) %>%
    arrange(desc(valor))

message("\n--- Conferências ---")
message("Divergências totais x componentes: ",
        sum(coerencia_totais$n_divergentes[1:5]))
message("Divergências de códigos/datas: ",
        sum(coerencia_registros$n_divergentes))
message("Registros com valores implausíveis sinalizados: ",
        nrow(alertas_valores))

######@> Ordenação final da base de eventos...
## Ordem das colunas: identificação -> tempo -> classificação do
## desastre -> danos humanos -> danos materiais -> danos ambientais ->
## prejuízos públicos -> prejuízos privados -> derivadas -> metadados
## espaciais. É a mesma lógica de blocos das demais bases do projeto.
eventos <- atlas %>%
    select(geocodigo, municipio, municipio_atlas, uf, regiao,
           protocolo_s2id, tipo_protocolo, status, reconhecido,
           data_evento, data_registro, data_protocolo, ano, mes, data,
           ano_registro, defasagem_registro_dias,
           cod_cobrade, desastre_cobrade, cod_tipologia, tipologia,
           grupo_desastre,
           all_of(cols_dh), dh_total_diretos, dh_outros_afetados,
           dh_afetados_total, dh_mortos_desaparecidos, dh_descricao,
           starts_with("dm_habitacoes"), starts_with("dm_saude"),
           starts_with("dm_ensino"), starts_with("dm_servicos"),
           starts_with("dm_comunitarias"),
           starts_with("dm_infraestrutura"),
           dm_total_danificadas, dm_total_destruidas, dm_total_valor,
           dm_descricao,
           all_of(cols_ordinais),
           all_of(paste0(cols_ordinais, "_classe")),
           all_of(paste0(cols_ordinais, "_nivel")), da_descricao,
           all_of(cols_pepl), pepl_total, pepl_descricao,
           all_of(cols_pepr), pepr_total, pepr_descricao,
           pe_total, impacto_economico_total,
           n_setores_censitarios, setores_censitarios,
           area_km2_shape, lon_centroide, lat_centroide) %>%
    arrange(municipio, data_evento, protocolo_s2id)

########################################################################
######@> Etapa 06 - Séries temporais em grade completa...

######@> Variáveis somáveis nas agregações...
## São as grandezas extensivas - contagens de pessoas, de unidades
## físicas e valores monetários -, as únicas para as quais a soma sobre
## eventos tem significado. Escalas ordinais (DA_*), descrições textuais
## e atributos do município ficam FORA da agregação por construção.
vars_soma <- c(cols_dh, "dh_total_diretos", "dh_outros_afetados",
               "dh_afetados_total", "dh_mortos_desaparecidos",
               "dm_habitacoes_danificadas", "dm_habitacoes_destruidas",
               "dm_total_danificadas", "dm_total_destruidas",
               "dm_total_valor", "pepl_total", "pepr_total", "pe_total",
               "impacto_economico_total")

######@> Municípios que compõem a grade...
## Apenas os municípios COM registros no Atlas (ver a decisão
## metodológica documentada na Etapa 04).
municipios_grade <- meta_municipios %>%
    filter(geocodigo %in% geo_atlas) %>%
    select(geocodigo, municipio, area_km2_shape, lon_centroide,
           lat_centroide)

######@> Intervalo temporal coberto pela base...
ano_min <- min(eventos$ano)
ano_max <- max(eventos$ano)

######@> Função de agregação sobre uma grade completa...
## Recebe as chaves de agrupamento e a grade correspondente, soma as
## variáveis extensivas e devolve a série com TODAS as combinações
## presentes - inclusive as de valor zero. O preenchimento com zero é
## legítimo aqui, e apenas aqui, porque a grade cobre somente
## municípios e períodos efetivamente observados pelo Atlas: nesse
## recorte, a ausência de registro significa ausência de desastre.
agregar_serie <- function(dados, grade, chaves) {
    resumo <- dados %>%
        group_by(across(all_of(chaves))) %>%
        summarise(n_eventos = n(),
                  n_reconhecidos = sum(reconhecido),
                  n_registros_simples = sum(!reconhecido),
                  ## Soma dos setores atingidos por todos os eventos
                  ## do período. NÃO é uma contagem de setores
                  ## distintos: um setor atingido em três eventos conta
                  ## três vezes. Mede exposição acumulada, e não
                  ## extensão territorial - daí o nome explícito.
                  soma_setores_censitarios =
                      sum(n_setores_censitarios),
                  across(all_of(vars_soma), ~ sum(.x, na.rm = TRUE)),
                  .groups = "drop")
    grade %>%
        left_join(resumo, by = chaves) %>%
        mutate(across(c(n_eventos, n_reconhecidos, n_registros_simples,
                        soma_setores_censitarios, all_of(vars_soma)),
                      ~ coalesce(.x, 0)))
}

######@> Série MENSAL por município (compatível com o ERA5)...
## Grade: municípios x anos x meses. É a saída pensada para o cruzamento
## direto com a base municipal do ERA5, que também é mensal e usa as
## mesmas chaves geocodigo + ano + mes.
grade_mensal <- expand_grid(municipios_grade,
                            ano = ano_min:ano_max,
                            mes = 1:12) %>%
    mutate(data = as.Date(sprintf("%d-%02d-01", ano, mes)))

serie_mensal <- agregar_serie(eventos, grade_mensal,
                              c("geocodigo", "municipio", "ano", "mes")) %>%
    arrange(municipio, ano, mes)

######@> Série ANUAL por município (compatível com o MapBiomas)...
## Grade: municípios x anos. Além das somas, traz a frequência de
## desastres por 1.000 km2, que torna comparáveis municípios de porte
## muito diferente (Joinville ~1.130 km2 vs Bombinhas ~36 km2) - mesma
## preocupação que levou ao uso de área relativa no MapBiomas.
grade_anual <- expand_grid(municipios_grade, ano = ano_min:ano_max)

serie_anual <- agregar_serie(eventos, grade_anual,
                             c("geocodigo", "municipio", "ano")) %>%
    mutate(eventos_por_mil_km2 = 1000 * n_eventos / area_km2_shape) %>%
    arrange(municipio, ano)

######@> Séries por GRUPO de desastre...
## Os quatro grupos (Climatológico, Hidrológico, Meteorológico, Outros)
## entram na grade como dimensão adicional, de modo que um grupo sem
## ocorrência no ano apareça como zero. Sem isso, séries por grupo
## teriam comprimentos diferentes entre municípios e não poderiam ser
## comparadas nem modeladas em conjunto.
grupos <- sort(unique(eventos$grupo_desastre))

grade_anual_grupo <- expand_grid(municipios_grade, ano = ano_min:ano_max,
                                 grupo_desastre = grupos)

serie_anual_grupo <- agregar_serie(
    eventos, grade_anual_grupo,
    c("geocodigo", "municipio", "ano", "grupo_desastre")) %>%
    arrange(municipio, ano, grupo_desastre)

grade_mensal_grupo <- expand_grid(municipios_grade,
                                  ano = ano_min:ano_max, mes = 1:12,
                                  grupo_desastre = grupos) %>%
    mutate(data = as.Date(sprintf("%d-%02d-01", ano, mes)))

serie_mensal_grupo <- agregar_serie(
    eventos, grade_mensal_grupo,
    c("geocodigo", "municipio", "ano", "mes", "grupo_desastre")) %>%
    arrange(municipio, ano, mes, grupo_desastre)

######@> Série anual por TIPOLOGIA de desastre...
## Resolução temática mais fina (16 tipologias). A grade completa é
## mantida pelo mesmo motivo das séries por grupo.
tipologias <- sort(unique(eventos$tipologia))

grade_anual_tipologia <- expand_grid(municipios_grade,
                                     ano = ano_min:ano_max,
                                     tipologia = tipologias)

serie_anual_tipologia <- agregar_serie(
    eventos, grade_anual_tipologia,
    c("geocodigo", "municipio", "ano", "tipologia")) %>%
    arrange(municipio, ano, tipologia)

message("\n--- Séries temporais ---")
message("Período coberto        : ", ano_min, " a ", ano_max)
message("Série mensal           : ", nrow(serie_mensal), " linhas")
message("Série anual            : ", nrow(serie_anual), " linhas")
message("Série anual por grupo  : ", nrow(serie_anual_grupo), " linhas")
message("Série anual por tipol. : ", nrow(serie_anual_tipologia),
        " linhas")

########################################################################
######@> Etapa 07 - Dicionários e diagnóstico da base...

######@> Dicionário das variáveis da base de eventos...
## Reúne o mapeamento da Etapa 03 (variáveis originais) e as variáveis
## criadas ao longo do processamento, marcando a origem de cada uma.
## Assim, quem receber apenas os arquivos exportados consegue distinguir
## o que veio da fonte do que foi derivado aqui.
dicionario_variaveis <- bind_rows(
    mapa_colunas %>%
        transmute(variavel, descricao, unidade, tipo, origem = "Atlas"),
    tribble(
        ~variavel,                      ~descricao,                                                              ~unidade,        ~tipo,
        "municipio",                    "Nome do município conforme o shapefile (grafia oficial do projeto)",    "-",             "texto",
        "tipo_protocolo",               "Letra do protocolo S2iD que identifica o formulário de origem",         "-",             "texto",
        "data_protocolo",               "Data embutida no protocolo S2iD",                                       "data",          "data",
        "ano",                          "Ano da data de evento",                                                 "ano",           "inteiro",
        "mes",                          "Mês da data de evento",                                                 "mês",           "inteiro",
        "data",                         "Primeiro dia do mês do evento (chave de junção com o ERA5)",            "data",          "data",
        "ano_registro",                 "Ano da data de registro no S2iD",                                       "ano",           "inteiro",
        "defasagem_registro_dias",      "Dias entre a ocorrência e o registro no S2iD",                          "dias",          "inteiro",
        "reconhecido",                  "Registro com reconhecimento federal (status == Reconhecido)",           "lógico",        "logico",
        "desastre_cobrade",             "Nome detalhado do desastre segundo o dicionário COBRADE",               "-",             "texto",
        "dh_afetados_total",            "Danos humanos diretos somados aos outros afetados",                     "pessoas",       "numerico",
        "dh_mortos_desaparecidos",      "Pessoas mortas somadas às desaparecidas",                               "pessoas",       "numerico",
        "dm_total_danificadas",         "Total de edificações e obras danificadas",                              "unidades",      "numerico",
        "dm_total_destruidas",          "Total de edificações e obras destruídas (ver Atlas_alertas_valores)",   "unidades",      "numerico",
        "impacto_economico_total",      "Danos materiais somados aos prejuízos públicos e privados",             "R$ corrigidos", "numerico",
        "n_setores_censitarios",        "Número de setores censitários atingidos pelo evento",                   "setores",       "inteiro",
        "soma_setores_censitarios",     "Soma dos setores atingidos no período (séries agregadas; com repetição)", "setor-eventos", "inteiro",
        "area_km2_shape",               "Área do município calculada no shapefile (EPSG:5880)",                  "km2",           "numerico",
        "lon_centroide",                "Longitude do centroide do município (WGS84)",                           "graus",         "numerico",
        "lat_centroide",                "Latitude do centroide do município (WGS84)",                            "graus",         "numerico",
        "n_eventos",                    "Número de desastres registrados no período (séries agregadas)",         "eventos",       "inteiro",
        "n_reconhecidos",               "Número de desastres com reconhecimento federal (séries agregadas)",     "eventos",       "inteiro",
        "n_registros_simples",          "Número de desastres apenas registrados, sem reconhecimento",            "eventos",       "inteiro",
        "eventos_por_mil_km2",          "Frequência de desastres por 1.000 km2 de território municipal",         "eventos/mil km2", "numerico") %>%
        mutate(origem = "Derivada"),
    ## Verbetes das colunas ordinais padronizadas, gerados a partir da
    ## própria lista de colunas DA_*. Escrevê-los à mão em vez de
    ## derivá-los abriria espaço para que o dicionário e a base
    ## divergissem caso a fonte ganhe ou perca uma categoria de dano
    ## ambiental.
    mapa_colunas %>%
        filter(tipo == "ordinal") %>%
        transmute(variavel = paste0(variavel, "_classe"),
                  descricao = paste0(sub(" \\(faixa de população afetada\\)",
                                         "", descricao),
                                     " - faixa padronizada",
                                     " (0-5%, 5-10%, 10-20%, >20%)"),
                  unidade = "faixa", tipo = "texto",
                  origem = "Derivada"),
    mapa_colunas %>%
        filter(tipo == "ordinal") %>%
        transmute(variavel = paste0(variavel, "_nivel"),
                  descricao = paste0(sub(" \\(faixa de população afetada\\)",
                                         "", descricao),
                                     " - nível ordinal da faixa (1 a 4)"),
                  unidade = "nível", tipo = "inteiro",
                  origem = "Derivada")) %>%
    ## Observação sobre a unidade monetária, propagada a todas as
    ## variáveis em R$ para que a data de referência viaje junto com os
    ## dados.
    mutate(unidade = ifelse(unidade == "R$ corrigidos",
                            paste0("R$ corrigidos (referência ",
                                   format(data_referencia_monetaria,
                                          "%d/%m/%Y"), ")"),
                            unidade))

######@> Diagnóstico consolidado das conferências...
## Reúne, em uma única tabela exportável, o resultado das verificações
## executadas na Etapa 05.
diagnostico <- bind_rows(
    coerencia_totais %>%
        transmute(bloco = "Coerência dos totais", verificacao,
                  n_registros = nrow(eventos), n_divergentes,
                  observacao = paste0("Diferença máxima: ",
                                      format(dif_maxima,
                                             scientific = FALSE),
                                      ifelse(divergencia_esperada,
                                             " (divergência esperada)",
                                             ""))),
    coerencia_registros %>%
        transmute(bloco = "Coerência de códigos, datas e classificação",
                  verificacao, n_registros, n_divergentes,
                  observacao = NA_character_),
    tibble(bloco = "Cobertura municipal",
           verificacao = "Municípios do shapefile sem registros no Atlas",
           n_registros = nrow(meta_municipios),
           n_divergentes = nrow(municipios_sem_dados),
           observacao = paste(municipios_sem_dados$municipio,
                              collapse = ", ")),
    tibble(bloco = "Valores implausíveis",
           verificacao = paste0("Instalações destruídas acima de ",
                                limiar_implausivel, " unidades"),
           n_registros = nrow(eventos),
           n_divergentes = nrow(alertas_valores),
           observacao = "Valores mantidos; ver Atlas_alertas_valores"),
    tibble(bloco = "Escalas ordinais",
           verificacao = "Células DA_* preenchidas e não classificadas",
           n_registros = sum(!is.na(as.matrix(
               eventos[, cols_ordinais]))),
           n_divergentes = sum(!is.na(as.matrix(eventos[, cols_ordinais])) &
                               is.na(as.matrix(
                                   eventos[, paste0(cols_ordinais,
                                                    "_classe")]))),
           observacao = "Rótulos fora das quatro faixas previstas"))

######@> Resumo por município...
## Uma linha por município do SHAPEFILE - inclusive os dois sem
## registros no Atlas, que aparecem com tem_registro_atlas = FALSE e
## contadores zerados. É o quadro sinótico da base.
resumo_municipios <- meta_municipios %>%
    select(geocodigo, municipio, area_km2_shape) %>%
    left_join(eventos %>%
                  group_by(geocodigo) %>%
                  summarise(n_eventos = n(),
                            n_reconhecidos = sum(reconhecido),
                            ano_primeiro = min(ano),
                            ano_ultimo = max(ano),
                            n_anos_com_evento = n_distinct(ano),
                            n_tipologias = n_distinct(tipologia),
                            grupo_predominante =
                                names(sort(table(grupo_desastre),
                                           decreasing = TRUE))[1],
                            tipologia_predominante =
                                names(sort(table(tipologia),
                                           decreasing = TRUE))[1],
                            dh_mortos = sum(dh_mortos),
                            dh_afetados_total = sum(dh_afetados_total),
                            impacto_economico_total =
                                sum(impacto_economico_total),
                            .groups = "drop"),
              by = "geocodigo") %>%
    mutate(tem_registro_atlas = !is.na(n_eventos),
           across(c(n_eventos, n_reconhecidos, n_anos_com_evento,
                    n_tipologias, dh_mortos, dh_afetados_total,
                    impacto_economico_total),
                  ~ coalesce(.x, 0)),
           ## Frequência média de desastres por década de série, medida
           ## que torna comparáveis municípios com históricos de
           ## extensão distinta.
           eventos_por_decada = 10 * n_eventos / (ano_max - ano_min + 1),
           eventos_por_mil_km2 = 1000 * n_eventos / area_km2_shape) %>%
    arrange(desc(n_eventos))

message("\n--- Diagnóstico ---")
message("Municípios com registros: ",
        sum(resumo_municipios$tem_registro_atlas), " de ",
        nrow(resumo_municipios))
message("Verificações executadas : ", nrow(diagnostico))
message("Verificações com divergência: ",
        sum(diagnostico$n_divergentes > 0))

########################################################################
######@> Etapa 08 - Exportação dos resultados...

######@> Exportação das bases consolidadas...
## Além dos arquivos por município, as bases completas são gravadas para
## permitir análises comparativas sem necessidade de reunir os 35
## arquivos individuais.
write_parquet(eventos,
              file.path(dir_pq, "Atlas_eventos_completo.parquet"))
write_parquet(serie_mensal,
              file.path(dir_pq, "Atlas_serie_mensal.parquet"))
write_parquet(serie_mensal_grupo,
              file.path(dir_pq, "Atlas_serie_mensal_grupo.parquet"))
write_parquet(serie_anual,
              file.path(dir_pq, "Atlas_serie_anual.parquet"))
write_parquet(serie_anual_grupo,
              file.path(dir_pq, "Atlas_serie_anual_grupo.parquet"))
write_parquet(serie_anual_tipologia,
              file.path(dir_pq, "Atlas_serie_anual_tipologia.parquet"))
write_parquet(dicionario_variaveis,
              file.path(dir_pq, "Atlas_dicionario_variaveis.parquet"))
write_parquet(dicionario_cobrade,
              file.path(dir_pq, "Atlas_dicionario_cobrade.parquet"))
write_parquet(diagnostico,
              file.path(dir_pq, "Atlas_diagnostico.parquet"))
write_parquet(alertas_valores,
              file.path(dir_pq, "Atlas_alertas_valores.parquet"))
write_parquet(resumo_municipios,
              file.path(dir_pq, "Atlas_resumo_municipios.parquet"))

save(eventos, serie_mensal, serie_mensal_grupo, serie_anual,
     serie_anual_grupo, serie_anual_tipologia, dicionario_variaveis,
     dicionario_cobrade, diagnostico, alertas_valores,
     resumo_municipios,
     file = file.path(dir_rd, "Atlas_SC_completo.RData"))

######@> Exportação individual por município...
## Um conjunto de arquivos por município, contendo os eventos e as duas
## séries agregadas daquele município. O nome combina o geocódigo do
## IBGE (chave estável) com o nome transliterado, seguindo exatamente a
## convenção adotada no ERA5 e no MapBiomas.
message("\nExportando arquivos por município...")

for(g in sort(unique(eventos$geocodigo))) {
    ## Subconjuntos do município corrente
    dados_municipio <- eventos %>%
        filter(geocodigo == g)
    dados_municipio_mensal <- serie_mensal %>%
        filter(geocodigo == g)
    dados_municipio_anual <- serie_anual %>%
        filter(geocodigo == g)
    ## Montagem do nome-base do arquivo
    nome_muni <- limpar_nome(unique(dados_municipio$municipio))
    nome_base <- paste0("Atlas_", g, "_", nome_muni)
    ## Gravação em Parquet (formato colunar, compacto e interoperável)
    write_parquet(dados_municipio,
                  file.path(dir_pq_mun, paste0(nome_base, ".parquet")))
    write_parquet(dados_municipio_mensal,
                  file.path(dir_pq_mun,
                            paste0(nome_base, "_mensal.parquet")))
    write_parquet(dados_municipio_anual,
                  file.path(dir_pq_mun,
                            paste0(nome_base, "_anual.parquet")))
    ## Gravação em RData (formato nativo do R). Os objetos são sempre
    ## salvos com os nomes "dados_municipio", "dados_municipio_mensal" e
    ## "dados_municipio_anual", garantindo previsibilidade ao carregar
    ## qualquer arquivo com load().
    save(dados_municipio, dados_municipio_mensal, dados_municipio_anual,
         file = file.path(dir_rd_mun, paste0(nome_base, ".RData")))
    message(sprintf("  %-46s %4d eventos | %5d meses | %3d anos",
                    nome_base, nrow(dados_municipio),
                    nrow(dados_municipio_mensal),
                    nrow(dados_municipio_anual)))
}

######@> Resumo final do processamento...
message("\n=== Processamento concluído ===")
message("Municípios exportados  : ", length(unique(eventos$geocodigo)))
message("Eventos padronizados   : ", nrow(eventos))
message("Período das séries     : ", ano_min, " a ", ano_max)
message("Grupos de desastre     : ",
        paste(grupos, collapse = " | "))
message("Tipologias             : ", length(tipologias))
message("Mortos no período      : ", sum(eventos$dh_mortos))
message("Afetados no período    : ", sum(eventos$dh_afetados_total))
message("Impacto econômico (R$) : ",
        format(sum(eventos$impacto_economico_total), big.mark = ".",
               decimal.mark = ",", nsmall = 2))
message("Saídas em              : ", normalizePath(dir_out))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
