########################################################################
## Description: Análise exploratória integrada da base consolidada -
##              eventos de desastre (Atlas Digital) em função dos
##              descritores climáticos (ERA5) e de uso e cobertura da
##              terra (MapBiomas) nos municípios costeiros de Santa
##              Catarina...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: qui ago 20 17:00:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: Base consolidada pelo
##                script_Consolidacao_bases_ver00.R:
##                  - base_mensal : município x ano x mês
##                                  (38.443 linhas, 216 colunas,
##                                   37 municípios, 01/1940 a 07/2026)
##                  - base_anual  : município x ano
##                                  (3.219 linhas, 234 colunas)
##                  - dicionario_variaveis, dicionario_anual
##                  - municipios, diagnostico_cobertura
##                Três fontes identificadas por prefixo: era5_ (clima
##                mensal), atlas_ (desastres, 1991-2025, 35 municípios)
##                e mapb_ (uso da terra, valor anual repetido nos meses,
##                1985-2024). Complementada pelo shapefile de
##                municípios.
##
### Commentary:
##
## Esta é a análise exploratória que fecha a fase descritiva do capítulo
## e prepara a modelagem. As três AEDs anteriores examinaram cada fonte
## em separado; esta examina o que só aparece quando elas estão juntas:
## a RELAÇÃO entre a ocorrência de desastres e os descritores climáticos
## e territoriais que podem explicá-la.
##
## Seu propósito não é responder às perguntas da dissertação, e sim
## estabelecer O QUE OS DADOS PERMITEM PERGUNTAR - e, principalmente, o
## que eles NÃO permitem. Dez achados estruturam o documento, e cada um
## deles descarta ou reorienta uma análise que pareceria natural. Todos
## os números citados abaixo são produzidos pelo próprio script e
## constam das tabelas e do relatório de síntese exportados:
##
##    (i) A RESPOSTA É RARA, DISCRETA E ASSIMÉTRICA. Em 14.700
##        município-meses com cobertura do Atlas, apenas 1.061 (7,2%)
##        registram ao menos um desastre; 92,8% são zeros. A razão
##        variância/média é 1,23 na escala mensal municipal, 2,55 na
##        anual municipal e 29,8 na anual do litoral - ou seja, a
##        sobredispersão CRESCE com a agregação, e a escolha da escala
##        de análise é também uma escolha de família de distribuição. Um
##        modelo gaussiano sobre contagens com 93% de zeros não é uma
##        aproximação grosseira: é um modelo errado;
##
##   (ii) A TENDÊNCIA DOS REGISTROS NÃO É CLIMÁTICA. Este é o achado
##        mais consequente de toda a análise. A contagem anual de
##        desastres no litoral cresce de 8 eventos em 1991 para 119 em
##        2022, e sua correlação de Spearman com o ano é de +0,82. A
##        frequência de meses de precipitação extrema, no entanto, NÃO
##        cresce: correlação com o ano de +0,02, e correlação com a
##        contagem de eventos de apenas +0,21 - nenhuma das duas
##        significativa. Entre 1991-2011 e 2012-2025 a média
##        anual salta de 18,7 para 57,1 eventos - coincidindo com a
##        digitalização do S2iD e com a ampliação do reconhecimento
##        federal, não com mudança do clima. A série de desastres mede,
##        em boa parte, a evolução do SISTEMA DE REGISTRO. Qualquer
##        modelo que use o tempo como preditor estará estimando
##        burocracia; qualquer tendência climática atribuída a essa
##        série será espúria. A Etapa 04 é dedicada inteiramente a isso;
##
##  (iii) CADA GRUPO DE DESASTRE TEM SEU PRÓPRIO MOTOR CLIMÁTICO, E ELES
##        NÃO SÃO O MESMO. Agregar os 1.191 eventos em uma única
##        contagem mistura processos distintos e às vezes OPOSTOS:
##          - HIDROLÓGICO (732 eventos, 61,5%): a probabilidade de
##            ocorrência sobe de 1,4% no quartil inferior de chuva para
##            17,0% acima do percentil 95 - fator de 12;
##          - METEOROLÓGICO (337, 28,3%): responde ao VENTO (1,2% para
##            3,7% entre o quartil inferior e o percentil 95) e é
##            INSENSÍVEL à chuva. O maior mês da série - julho de 2020,
##            com 30 registros - teve vento no percentil 90 e chuva na
##            mediana: foi o ciclone, não a enxurrada;
##          - CLIMATOLÓGICO (42, 3,5%): responde à FALTA de chuva, com
##            dose-resposta INVERTIDA - a probabilidade cai de 0,6% no
##            quartil mais seco de chuva acumulada em três meses para
##            zero no quartil mais úmido.
##        Modelar "desastres" como um todo é somar três respostas com
##        sinais diferentes para a mesma variável;
##
##   (iv) A ASSOCIAÇÃO É CONTEMPORÂNEA, NÃO DEFASADA. A correlação
##        cruzada entre precipitação e contagem de eventos no litoral é
##        máxima em DEFASAGEM ZERO (0,366) e cai para 0,12 ou menos em
##        todas as defasagens de um a seis meses, em ambas as direções.
##        Na escala mensal não há memória a explorar: o mês é a unidade
##        temporal correta, e termos defasados de precipitação não
##        encontram respaldo nos dados. Isso não exclui processos de
##        acumulação em escala sub-mensal - que ESTA base não resolve,
##        porque o ERA5 aqui está agregado por mês;
##
##    (v) DEPOIS DE REMOVIDAS SAZONALIDADE E TENDÊNCIA, QUASE NÃO SOBRA
##        MEMÓRIA. A ACF da série mensal bruta do litoral tem 0,312 no
##        lag 1 e permanece entre 0,16 e 0,36 até o lag 12 - o que
##        pareceria memória longa. Removida a sazonalidade e, sobretudo,
##        a tendência de registro do achado (ii), a ACF de lag 1 cai
##        para 0,156 e as demais defasagens tornam-se indistinguíveis de
##        zero. A estrutura temporal aparente da série de desastres é,
##        quase toda, a tendência administrativa;
##
##   (vi) OS EXTREMOS IMPORTAM, MAS NÃO DOMINAM. Meses de precipitação
##        acima do percentil 95 têm probabilidade de desastre três vezes
##        maior (19,6% contra 6,5%), mas concentram apenas 16% dos
##        eventos. A maior parte dos desastres ocorre em meses de chuva
##        ORDINÁRIA - o que significa que um modelo restrito a extremos
##        explicaria uma fração pequena do fenômeno, e que a
##        vulnerabilidade do território é tão determinante quanto o
##        gatilho meteorológico;
##
##  (vii) ENTRE MUNICÍPIOS, A LATITUDE CONFUNDE QUASE TUDO. A correlação
##        bruta entre número de eventos e cobertura florestal é de 0,53,
##        o que sugeriria que floresta causa desastre - absurdo que se
##        desfaz ao controlar a posição no litoral: a correlação parcial
##        cai para 0,15. O litoral norte concentra simultaneamente mais
##        floresta, mais relevo, mais chuva e mais registros. O que
##        SOBREVIVE ao controle é (a) a ÁREA do município (parcial 0,40)
##        - argumento direto para um termo de exposição ou offset - e
##        (b) a fração urbanizada, que fica NEGATIVA (-0,30): os
##        balneários pequenos e muito urbanizados registram MENOS
##        desastres que os municípios grandes e mistos;
##
## (viii) OS DESCRITORES CLIMÁTICOS SÃO REDUNDANTES ENTRE SI. O fluxo de
##        calor latente e a evaporação são a MESMA variável em unidades
##        diferentes (correlação 1,000); precipitação total, chuva de
##        larga escala, chuva convectiva e água de chuva na coluna
##        correlacionam-se acima de 0,82. Selecionar uma variável por
##        bloco é obrigatório: um modelo com todas elas teria
##        coeficientes instáveis e sem interpretação individual;
##
##    (x) A SOBREDISPERSÃO NÃO É DO PROCESSO, É DOS MUNICÍPIOS. Os
##        ensaios diagnósticos da Etapa 15 respondem à pergunta que
##        organiza o desenho do modelo definitivo. Ajustada ao conjunto
##        agrupado, a Poisson fica sobredispersa (dispersão de Pearson
##        1,92) e o binomial negativo a supera em AIC - o que levaria à
##        conclusão apressada de que o processo é intrinsecamente mais
##        variável que Poisson. Não é: ao entrar o efeito de município,
##        a dispersão volta a 0,99, a Poisson reproduz a distribuição
##        inteira das contagens quase exatamente e o binomial negativo
##        deixa de acrescentar ajuste (delta AIC de apenas +0,3). A
##        variância extra era heterogeneidade ENTRE MUNICÍPIOS, e o
##        remédio é o termo municipal, não a mudança de família. Não há,
##        em nenhuma especificação, excesso de zeros a modelar;
##
##   (ix) A JANELA ÚTIL É MENOR QUE A BASE. A base consolidada tem 1.039
##        meses, mas o Atlas cobre 420 deles (1991-2025) e o MapBiomas
##        vai até 2024. Análises que exijam as três fontes dispõem de
##        1991-2024: 34 anos, 35 municípios, 14.280 município-meses. O
##        ERA5 anterior a 1991 permanece útil para estabelecer a
##        climatologia de referência, e é assim que este script o usa.
##
## Cinco escolhas metodológicas atravessam o documento:
##
##   - as anomalias e os percentis climáticos são calculados DENTRO de
##     cada município e de cada mês do ano. Isso remove, de uma só vez,
##     o clima local (um mês de 200 mm é ordinário em Joinville e
##     extremo em Passo de Torres) e a sazonalidade (200 mm em janeiro
##     não é o mesmo que em julho). Sem essa dupla padronização, a
##     dose-resposta mediria geografia, não anomalia;
##
##   - a dose-resposta usa a PROBABILIDADE DE OCORRÊNCIA (P(N >= 1)) e
##     não a média de contagens. Com 7% de meses positivos, a média é
##     dominada por uns poucos meses de contagem alta, enquanto a
##     probabilidade é estável e diretamente interpretável;
##
##   - as comparações entre municípios usam correlação de Spearman e
##     correlação PARCIAL controlando latitude e área, pelo motivo
##     exposto no achado (vii);
##
##   - a Etapa 15 ajusta modelos de contagem (Poisson, binomial
##     negativo, inflado de zeros) com propósito DIAGNÓSTICO: não são a
##     modelagem do capítulo, e sim a verificação de qual família e qual
##     estrutura a base exige. Os coeficientes não devem ser citados
##     como resultado;
##
##   - nenhuma imputação é feita em ponto algum. Onde falta dado, falta.
##
## Fluxo geral da análise:
##
##   01) Leitura da base consolidada e preparação dos objetos;
##   02) Panorama: cobertura efetiva e tamanho amostral;
##   03) A variável resposta: composição, zeros e sobredispersão;
##   04) O viés de registro: a tendência que não é climática;
##   05) Sazonalidade conjunta de desastres e clima, por grupo;
##   06) Dose-resposta: probabilidade de evento por percentil climático;
##   07) Extremos climáticos e desastres;
##   08) Estrutura temporal: ACF, PACF e correlação cruzada;
##   09) Tendência: Mann-Kendall e Sen, desastres e clima lado a lado;
##   10) Padrões municipais e tamanho amostral por município;
##   11) Uso da terra e exposição: correlações brutas e parciais;
##   12) Painéis diagnósticos por município;
##   13) Estrutura multivariada: redundância, PCA e colinearidade;
##   14) Padrões espaciais: mapas e autocorrelação espacial;
##   15) Ensaios diagnósticos de modelos de contagem;
##   16) Agrupamento de municípios por regime desastre-clima;
##   17) Exportação consolidada e síntese.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Dados vetoriais e mapas
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem e grades
library(purrr)          ## Programação funcional
library(stringi)        ## Transliteração de acentos
library(ggplot2)        ## Gráficos
library(patchwork)      ## Composição de painéis
library(scales)         ## Escalas e formatação de eixos
library(MASS)           ## Binomial negativo (glm.nb)
library(pscl)           ## Modelos inflados de zeros (diagnóstico)
library(tseries)        ## Testes de estacionariedade (ADF, KPSS)
library(spdep)          ## Autocorrelação espacial (Moran)
library(writexl)        ## Exportação consolidada em XLSX

######@> Resolução de conflitos de nomes...
## MASS::select mascara dplyr::select, e o erro resultante seria
## silencioso e difícil de rastrear (seleção de colunas devolvendo
## objeto de outro tipo). A fixação explícita é a mesma dos demais
## scripts do projeto, aqui com uma razão adicional.
select <- dplyr::select
filter <- dplyr::filter

######@> Opções globais...
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente...
## Fixada porque a Etapa 15 reamostra para avaliar o ajuste dos modelos
## de contagem e a Etapa 16 avalia partições de agrupamento.
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
dir_dados <- "../Dados"
dir_cons <- file.path(dir_dados, "Outputs", "Consolidado")
dir_shape <- file.path(dir_dados, "Shapefiles")

arq_base <- file.path(dir_cons, "RData", "Consolidado_SC.RData")
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Diretórios de saída...
## A AED gera três famílias de produto, que ficam em subpastas próprias
## para que o material possa ser localizado pelo tipo: tabelas (insumo
## de texto e de análises posteriores), figuras (séries, dose-resposta e
## diagnósticos) e mapas (recorte espacial).
dir_res <- "../Results/AED_Completo"
dir_tab <- file.path(dir_res, "Tabelas")
dir_fig <- file.path(dir_res, "Figuras")
dir_fig_mun <- file.path(dir_fig, "Municipios")
dir_mapa <- file.path(dir_res, "Mapas")

for(d in c(dir_res, dir_tab, dir_fig, dir_fig_mun, dir_mapa)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> CRS de referência...
crs_projeto <- 4326      ## WGS84, mesmo das demais bases
crs_area <- 5880         ## SIRGAS 2000 / Brazil Polyconic (distâncias)

######@> Parâmetros da análise...
## ano_ini/ano_fim_atlas : janela de cobertura do Atlas, que define o
##                         recorte de toda análise desastre-clima;
## ano_fim_terra         : último ano do MapBiomas, limite das análises
##                         que envolvem uso da terra;
## ref_ini/ref_fim       : normal climatológica de referência (padrão
##                         OMM), usada para as anomalias;
## lag_max_mensal        : 24 meses cobrem dois ciclos anuais,
##                         suficiente para revelar (ou descartar)
##                         periodicidade na série de desastres;
## lag_ccf               : defasagens examinadas na correlação cruzada
##                         entre clima e desastre;
## percentis_dose        : cortes da dose-resposta. A cauda superior é
##                         detalhada porque é onde a resposta muda;
## limiar_extremo        : percentil que define mês climaticamente
##                         extremo;
## alfa                  : nível de significância adotado nos testes.
ano_ini_atlas <- 1991
ano_fim_atlas <- 2025
ano_fim_terra <- 2024
ref_ini <- 1991
ref_fim <- 2020
lag_max_mensal <- 24
lag_ccf <- 12
percentis_dose <- c(0, 0.25, 0.50, 0.75, 0.90, 0.95, 1)
limiar_extremo <- 0.95
alfa <- 0.05

######@> Paleta dos grupos de desastre...
## Paleta Okabe-Ito, segura para daltonismo, atribuída com apoio
## semântico: azul para o hidrológico (água), vermelho-alaranjado para o
## meteorológico (vento e tempestade), amarelo-ouro para o climatológico
## (seca) e cinza para o resíduo.
cores_grupo <- c("Hidrológico"   = "#0072B2",
                 "Meteorológico" = "#D55E00",
                 "Climatológico" = "#E69F00",
                 "Outros"        = "#999999")

ordem_grupos <- names(cores_grupo)

######@> Paleta das fontes de dado...
cores_fonte <- c("Atlas (desastres)" = "#D55E00",
                 "ERA5 (clima)"      = "#0072B2",
                 "MapBiomas (terra)" = "#009E73")

######@> Nomes dos meses (rótulos dos eixos)...
meses_abrev <- c("Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
                 "Jul", "Ago", "Set", "Out", "Nov", "Dez")

######@> Estações do ano (hemisfério sul)...
ordem_estacoes <- c("Verão", "Outono", "Inverno", "Primavera")

########################################################################
######@> Funções auxiliares...

######@> Tema gráfico do documento...
## Centralizar o tema garante que as dezenas de figuras produzidas
## tenham a mesma aparência, o que é requisito para que possam ser
## usadas lado a lado no texto da dissertação.
tema_aed <- function(base = 11) {
    theme_bw(base_size = base) +
        theme(panel.grid.minor = element_blank(),
              panel.grid.major = element_line(linewidth = 0.25,
                                              colour = "grey88"),
              strip.background = element_rect(fill = "grey92",
                                              colour = "grey70"),
              strip.text = element_text(face = "bold", size = base - 1),
              plot.title = element_text(face = "bold", size = base + 2),
              plot.subtitle = element_text(colour = "grey30",
                                           size = base - 1),
              plot.caption = element_text(colour = "grey45",
                                          size = base - 3, hjust = 0),
              legend.position = "bottom",
              legend.title = element_text(face = "bold", size = base - 1))
}

theme_set(tema_aed())

######@> Quebra de linha em legendas longas...
## O ggplot NÃO quebra automaticamente o texto de caption: legendas
## longas são simplesmente cortadas na borda direita da figura. Esta
## função insere as quebras antes da plotagem.
quebrar <- function(texto, largura = 105) {
    paste(strwrap(paste(texto, collapse = " "), width = largura),
          collapse = "\n")
}

######@> Quebra de linha para legendas de mapa...
quebrar_mapa <- function(texto) {
    quebrar(texto, largura = 78)
}

######@> Quebra de rótulos de eixo em várias linhas...
quebrar_rotulo <- function(x, largura = 16) {
    vapply(as.character(x), function(z)
        paste(strwrap(z, width = largura), collapse = "\n"),
        character(1), USE.NAMES = FALSE)
}

######@> Função de gravação de figuras...
salvar_fig <- function(plot, arquivo, largura = 10, altura = 6,
                       diretorio = dir_fig) {
    ggsave(filename = file.path(diretorio, paste0(arquivo, ".png")),
           plot = plot, width = largura, height = altura, dpi = 300,
           bg = "white")
    invisible(NULL)
}

######@> Função de gravação de tabelas...
## Grava em CSV com separador ";" e decimal "," (padrão brasileiro) e
## devolve a tabela para que também seja acumulada no XLSX consolidado.
salvar_tab <- function(dados, arquivo) {
    write.table(dados, file.path(dir_tab, paste0(arquivo, ".csv")),
                sep = ";", dec = ",", row.names = FALSE,
                fileEncoding = "UTF-8")
    invisible(dados)
}

######@> Formatação de inteiros com separador de milhar...
fmt_int <- function(x) {
    formatC(x, format = "f", digits = 0, big.mark = ".",
            decimal.mark = ",")
}

######@> Transliteração de nomes em nomes seguros de arquivo...
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Máximo tolerante a séries inteiramente ausentes...
max_seguro <- function(x) {
    if(all(is.na(x))) return(NA_real_)
    max(x, na.rm = TRUE)
}

######@> Teste de tendência de Mann-Kendall...
## Implementado no próprio script, e não importado de pacote, por duas
## razões: mantém o script executável sem dependências além das já
## utilizadas no projeto, e torna explícita a correção para empates -
## que aqui NÃO é detalhe, porque as séries de contagem de desastres têm
## muitos anos com o mesmo valor.
mann_kendall <- function(x) {
    x <- as.numeric(x[!is.na(x)])
    n <- length(x)
    if(n < 4) {
        return(tibble(S = NA_real_, tau = NA_real_, z = NA_real_,
                      p_valor = NA_real_))
    }
    dif <- outer(x, x, "-")
    S <- sum(sign(dif[lower.tri(dif)]))
    empates <- as.numeric(table(x))
    var_S <- (n * (n - 1) * (2 * n + 5) -
              sum(empates * (empates - 1) * (2 * empates + 5))) / 18
    if(var_S <= 0) {
        return(tibble(S = S, tau = NA_real_, z = NA_real_,
                      p_valor = NA_real_))
    }
    z <- if(S > 0) (S - 1) / sqrt(var_S) else
         if(S < 0) (S + 1) / sqrt(var_S) else 0
    tau <- S / (n * (n - 1) / 2)
    tibble(S = S, tau = tau, z = z, p_valor = 2 * pnorm(-abs(z)))
}

######@> Declividade de Sen (Theil-Sen)...
declividade_sen <- function(y, x) {
    ok <- !is.na(y) & !is.na(x)
    y <- y[ok]; x <- x[ok]
    if(length(y) < 4) return(NA_real_)
    dy <- outer(y, y, "-")
    dx <- outer(x, x, "-")
    decl <- (dy / dx)[lower.tri(dy)]
    return(median(decl[is.finite(decl)], na.rm = TRUE))
}

######@> Cálculo de ACF/PACF em formato de tabela...
calcular_correlograma <- function(x, lag_max = lag_max_mensal,
                                  tipo = c("ACF", "PACF")) {
    tipo <- match.arg(tipo)
    x <- as.numeric(x)
    x <- x[!is.na(x)]
    n <- length(x)
    ## Série constante - caso de municípios sem nenhum evento em um
    ## recorte - não admite autocorrelação: devolve tabela vazia em vez
    ## de propagar NaN para dentro dos gráficos.
    if(n < 12 || var(x) == 0) {
        return(tibble(lag = integer(), valor = numeric(),
                      ic = numeric(), tipo = character()))
    }
    lag_max <- min(lag_max, floor(n / 3))
    if(tipo == "ACF") {
        obj <- acf(x, lag.max = lag_max, plot = FALSE,
                   na.action = na.pass)
        valores <- as.numeric(obj$acf)[-1]
    } else {
        obj <- pacf(x, lag.max = lag_max, plot = FALSE,
                    na.action = na.pass)
        valores <- as.numeric(obj$acf)
    }
    tibble(lag = seq_along(valores), valor = valores,
           ic = qnorm(1 - alfa / 2) / sqrt(n), tipo = tipo)
}

######@> Gráfico de correlograma em ggplot...
grafico_correlograma <- function(tabela, titulo = NULL,
                                 subtitulo = NULL) {
    if(nrow(tabela) == 0) {
        return(ggplot() +
               annotate("text", x = 0, y = 0,
                        label = paste("Série sem variabilidade",
                                      "\n(correlograma não definido)"),
                        size = 3, colour = "grey40") +
               labs(title = titulo, subtitle = subtitulo) +
               theme_void())
    }
    ic <- tabela$ic[1]
    ggplot(tabela, aes(x = lag, y = valor)) +
        geom_hline(yintercept = 0, colour = "grey40") +
        geom_hline(yintercept = c(-ic, ic), linetype = "dashed",
                   colour = "#0072B2", linewidth = 0.4) +
        geom_segment(aes(xend = lag, yend = 0), linewidth = 0.6,
                     colour = "grey25") +
        geom_point(size = 1.1, colour = "grey15") +
        scale_x_continuous(breaks = pretty_breaks(6)) +
        labs(title = titulo, subtitle = subtitulo,
             x = "Defasagem (meses)", y = tabela$tipo[1])
}

######@> Correlação cruzada em formato de tabela...
## Responde à pergunta que a ACF não responde: o clima de um mês informa
## sobre o desastre de qual mês? Defasagem positiva significa que a
## variável climática ANTECEDE a contagem de eventos.
correlacao_cruzada <- function(x, y, lag_max = lag_ccf,
                               rotulo = NULL) {
    ok <- !is.na(x) & !is.na(y)
    x <- x[ok]; y <- y[ok]
    if(length(x) < 24 || var(x) == 0 || var(y) == 0) {
        return(tibble(lag = integer(), valor = numeric(),
                      ic = numeric(), serie = character()))
    }
    obj <- ccf(x, y, lag.max = lag_max, plot = FALSE)
    tibble(lag = as.numeric(obj$lag),
           valor = as.numeric(obj$acf),
           ic = qnorm(1 - alfa / 2) / sqrt(length(x)),
           serie = ifelse(is.null(rotulo), "série", rotulo))
}

######@> Bateria de diagnósticos de uma série temporal...
## ADF e KPSS têm hipóteses nulas OPOSTAS - o ADF testa H0: raiz
## unitária e o KPSS testa H0: estacionariedade -, e por isso são
## reportados juntos: concordância é evidência forte; discordância
## indica série com tendência determinística, que é o caso esperado da
## série de desastres pelo achado (ii).
diagnosticar_serie <- function(x, lag_teste = 24) {
    x <- as.numeric(x)
    x <- x[!is.na(x)]
    n <- length(x)
    res <- tibble(n = n, media = mean(x), dp = sd(x),
                  razao_var_media = NA_real_, prop_zeros = mean(x == 0),
                  acf1 = NA_real_, acf_sazonal = NA_real_,
                  ljung_box_p = NA_real_, adf_p = NA_real_,
                  kpss_p = NA_real_, estacionaria = NA_character_)
    if(n < 24 || var(x) == 0) return(res)
    res$razao_var_media <- ifelse(mean(x) > 0, var(x) / mean(x),
                                  NA_real_)
    ac <- acf(x, lag.max = 12, plot = FALSE)$acf
    res$acf1 <- as.numeric(ac[2])
    if(length(ac) > 12) res$acf_sazonal <- as.numeric(ac[13])
    lag_teste <- min(lag_teste, floor(n / 4))
    res$ljung_box_p <- tryCatch(
        Box.test(x, lag = lag_teste, type = "Ljung-Box")$p.value,
        error = function(e) NA_real_)
    res$adf_p <- tryCatch(suppressWarnings(adf.test(x)$p.value),
                          error = function(e) NA_real_)
    res$kpss_p <- tryCatch(suppressWarnings(kpss.test(x)$p.value),
                           error = function(e) NA_real_)
    res$estacionaria <- dplyr::case_when(
        is.na(res$adf_p) | is.na(res$kpss_p) ~ NA_character_,
        res$adf_p < alfa & res$kpss_p > alfa ~ "Estacionária",
        res$adf_p >= alfa & res$kpss_p <= alfa ~ "Não estacionária",
        res$adf_p < alfa & res$kpss_p <= alfa ~
            "Tendência determinística",
        TRUE ~ "Indefinida")
    return(res)
}

######@> Intervalo de confiança de Wilson para proporções...
## Usado em todas as curvas de dose-resposta. O intervalo normal
## (Wald) é inadequado aqui: com probabilidades da ordem de 2% e faixas
## de poucas centenas de observações, ele produz limites negativos e
## cobertura ruim. O de Wilson é bem comportado justamente nesse regime.
ic_wilson <- function(sucessos, n, nivel = 1 - alfa) {
    z <- qnorm(1 - (1 - nivel) / 2)
    p <- sucessos / n
    centro <- (p + z^2 / (2 * n)) / (1 + z^2 / n)
    margem <- z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2)) /
        (1 + z^2 / n)
    tibble(p = p, ic_inf = pmax(0, centro - margem),
           ic_sup = pmin(1, centro + margem))
}

######@> Curva de dose-resposta...
## Para uma variável climática expressa em PERCENTIL LOCAL (calculado
## dentro do município e do mês do ano), devolve a probabilidade de
## ocorrência de desastre em cada faixa, com intervalo de confiança.
##
## A escolha de P(N >= 1) em vez da média de contagens está explicada na
## abertura: com 7% de meses positivos, a média é instável e dominada
## por poucos meses extremos.
dose_resposta <- function(dados, coluna_percentil, coluna_resposta,
                          cortes = percentis_dose, rotulo = NULL) {
    d <- dados %>%
        mutate(faixa = cut(.data[[coluna_percentil]], breaks = cortes,
                           include.lowest = TRUE,
                           labels = paste0(
                               round(100 * head(cortes, -1)), "-",
                               round(100 * tail(cortes, -1))))) %>%
        filter(!is.na(faixa)) %>%
        group_by(faixa) %>%
        summarise(n = n(),
                  ocorrencias = sum(.data[[coluna_resposta]] > 0),
                  eventos = sum(.data[[coluna_resposta]]),
                  .groups = "drop")
    bind_cols(d, ic_wilson(d$ocorrencias, d$n)) %>%
        mutate(variavel = ifelse(is.null(rotulo), coluna_percentil,
                                 rotulo),
               resposta = coluna_resposta,
               razao_vs_mediana = p / p[1])
}

######@> Correlação parcial de Spearman...
## Calculada pelos resíduos: correlaciona-se o que sobra de cada
## variável depois de removida a parte explicada pelos controles. É a
## ferramenta central da Etapa 11, onde a latitude confunde quase todas
## as associações entre municípios.
correlacao_parcial <- function(y, x, controles) {
    ok <- complete.cases(y, x, controles)
    y <- y[ok]; x <- x[ok]
    controles <- as.matrix(controles)[ok, , drop = FALSE]
    ry <- residuals(lm(rank(y) ~ controles))
    rx <- residuals(lm(rank(x) ~ controles))
    cor(rx, ry)
}

######@> Fator de inflação da variância (VIF)...
## Implementado diretamente - VIF de uma variável é 1/(1 - R2) da
## regressão dela contra as demais - para não acrescentar dependência de
## pacote apenas por esta métrica. Valores acima de 10 indicam
## colinearidade severa; acima de 5, preocupante.
calcular_vif <- function(dados) {
    dados <- dados %>% select(where(is.numeric)) %>% na.omit()
    nomes <- names(dados)
    map_dfr(nomes, function(v) {
        outros <- setdiff(nomes, v)
        formula_vif <- as.formula(
            paste0("`", v, "` ~ ",
                   paste0("`", outros, "`", collapse = " + ")))
        r2 <- summary(lm(formula_vif, data = dados))$r.squared
        tibble(variavel = v, r2 = r2,
               vif = ifelse(r2 < 1, 1 / (1 - r2), Inf))
    }) %>%
        arrange(desc(vif))
}

######@> Silhueta média de uma partição...
silhueta_media <- function(matriz_dist, grupos) {
    m <- as.matrix(matriz_dist)
    unicos <- unique(grupos)
    if(length(unicos) < 2) return(NA_real_)
    valores <- vapply(seq_along(grupos), function(i) {
        proprio <- grupos == grupos[i]
        proprio[i] <- FALSE
        if(!any(proprio)) return(0)
        a <- mean(m[i, proprio])
        b <- min(vapply(setdiff(unicos, grupos[i]), function(g)
            mean(m[i, grupos == g]), numeric(1)))
        (b - a) / max(a, b)
    }, numeric(1))
    mean(valores)
}

######@> Extração dos segmentos do dendrograma...
segmentos_dendrograma <- function(h) {
    posicoes <- order(order(h$order))
    coord_x <- numeric(nrow(h$merge))
    coord_y <- numeric(nrow(h$merge))
    segs <- list()
    for(k in seq_len(nrow(h$merge))) {
        filhos <- h$merge[k, ]
        xs <- numeric(2); ys <- numeric(2)
        for(j in 1:2) {
            if(filhos[j] < 0) {
                xs[j] <- posicoes[-filhos[j]]
                ys[j] <- 0
            } else {
                xs[j] <- coord_x[filhos[j]]
                ys[j] <- coord_y[filhos[j]]
            }
        }
        coord_x[k] <- mean(xs)
        coord_y[k] <- h$height[k]
        segs[[k]] <- data.frame(
            x = c(xs[1], xs[1], xs[2]),
            y = c(ys[1], h$height[k], h$height[k]),
            xend = c(xs[1], xs[2], xs[2]),
            yend = c(h$height[k], h$height[k], ys[2]))
    }
    do.call(rbind, segs)
}

########################################################################
######@> Etapa 01 - Leitura da base consolidada e preparação...

message("=== AED integrada - início ===")
message("Lendo base consolidada...")

if(!file.exists(arq_base)) {
    stop("Base consolidada não encontrada. Execute antes ",
         "script_Consolidacao_bases_ver00.R")
}

load(arq_base)

######@> Conferência de integridade antes de analisar...
stopifnot(all(c("base_mensal", "base_anual", "dicionario_variaveis",
                "municipios") %in% ls()),
          nrow(base_mensal) ==
              nrow(distinct(base_mensal, geocodigo, ano, mes)))

message("Base mensal            : ", fmt_int(nrow(base_mensal)),
        " linhas x ", ncol(base_mensal), " colunas")

######@> Variáveis climáticas de trabalho...
## Das 93 colunas do ERA5 na base consolidada, esta tabela seleciona as
## que entram na análise de relação com desastres, com rótulo e domínio.
## A seleção NÃO é definitiva - a Etapa 13 mede a redundância entre elas
## e recomenda um subconjunto -, mas exclui de saída: os campos
## estáticos (cvh, cvl, tvh, tvl, lai_hv, lai_lv), que a AED do ERA5
## mostrou não serem séries; e os sufixos _dp, _min e _max, que
## descrevem dispersão ENTRE PIXELS e não extremo temporal.
dic_clima <- tribble(
    ~variavel,            ~rotulo,                        ~unidade,   ~dominio,
    "era5_tp_mm_mes",     "Precipitação total",           "mm/mês",   "Hídrico",
    "era5_cp_mm_dia",     "Precipitação convectiva",      "mm/dia",   "Hídrico",
    "era5_lsrr_mm_dia",   "Chuva de larga escala",        "mm/dia",   "Hídrico",
    "era5_tcrw",          "Água de chuva na coluna",      "kg/m²",    "Hídrico",
    "era5_e_mm_dia",      "Evaporação",                   "mm/dia",   "Hídrico",
    "era5_pev_mm_dia",    "Evaporação potencial",         "mm/dia",   "Hídrico",
    "balanco_hidrico",    "Balanço hídrico (P - E)",      "mm/dia",   "Hídrico",
    "tp_3m",              "Precipitação em 3 meses",      "mm",       "Hídrico",
    "era5_t2m_C",         "Temperatura do ar",            "°C",       "Térmico",
    "era5_ssr_W_m2",      "Radiação solar na superfície", "W/m²",     "Radiativo",
    "era5_tcc_pct",       "Cobertura de nuvens",          "%",        "Nebulosidade",
    "era5_si10",          "Velocidade do vento",          "m/s",      "Vento",
    "era5_u10",           "Componente zonal do vento",    "m/s",      "Vento",
    "era5_v10",           "Componente meridional",        "m/s",      "Vento",
    "fracao_convectiva",  "Fração convectiva da chuva",   "0-1",      "Hídrico")

######@> Construção das variáveis derivadas...
## balanco_hidrico  : e_mm_dia é NEGATIVO na convenção do ERA5 (perda de
##                    água pela superfície), de modo que a SOMA com a
##                    precipitação já é o balanço - a mesma definição
##                    adotada na AED do ERA5, mantida aqui para que os
##                    dois documentos falem da mesma variável;
## fracao_convectiva: participação da chuva convectiva no total. Valores
##                    altos indicam instabilidade local (tempestade de
##                    verão); baixos, chuva frontal;
## tp_3m            : precipitação acumulada em três meses, incluindo o
##                    corrente. É a janela mínima em que faz sentido
##                    falar de ESTIAGEM - o grupo climatológico responde
##                    a déficit acumulado, não à chuva de um mês.
base_trabalho <- base_mensal %>%
    arrange(geocodigo, data) %>%
    group_by(geocodigo) %>%
    mutate(balanco_hidrico = era5_tp_mm_dia + era5_e_mm_dia,
           fracao_convectiva = ifelse(era5_tp_mm_dia > 0,
                                      era5_cp_mm_dia / era5_tp_mm_dia,
                                      NA_real_),
           tp_3m = era5_tp_mm_mes + lag(era5_tp_mm_mes, 1) +
               lag(era5_tp_mm_mes, 2)) %>%
    ungroup()

######@> Climatologia de referência...
## Calculada sobre a normal 1991-2020 (padrão OMM), que está contida na
## janela do Atlas - de modo que as anomalias ficam centradas no mesmo
## período em que existem registros de desastre para acoplar. É a mesma
## referência da AED do ERA5.
clima_referencia <- base_trabalho %>%
    filter(ano >= ref_ini, ano <= ref_fim) %>%
    group_by(geocodigo, mes) %>%
    summarise(across(all_of(dic_clima$variavel),
                     ~ mean(.x, na.rm = TRUE),
                     .names = "{.col}_normal"),
              .groups = "drop")

######@> Recorte analítico: a janela do Atlas...
## Toda análise desastre-clima ocorre em 1991-2025, porque fora dela não
## há resposta. Os 51 anos anteriores de ERA5 permanecem na base e são
## usados apenas para compor a climatologia de referência e para as
## comparações de tendência de longo prazo da Etapa 09.
mensal <- base_trabalho %>%
    filter(tem_atlas, ano >= ano_ini_atlas, ano <= ano_fim_atlas) %>%
    left_join(clima_referencia, by = c("geocodigo", "mes")) %>%
    mutate(estacao = factor(as.character(estacao),
                            levels = ordem_estacoes),
           mes_nome = factor(meses_abrev[mes], levels = meses_abrev),
           decada = (ano %/% 10) * 10,
           ocorrencia = as.integer(atlas_n_eventos > 0))

######@> Anomalias e percentis locais...
## As duas padronizações que tornam os municípios comparáveis:
##
##   - ANOMALIA: valor menos a normal 1991-2020 daquele município
##     naquele mês do ano. Remove clima local e sazonalidade, e preserva
##     a unidade original;
##
##   - PERCENTIL LOCAL: posição do valor dentro da distribuição daquele
##     município naquele mês do ano, ao longo dos 35 anos da janela.
##     Remove clima local, sazonalidade E escala - o que permite somar
##     municípios com regimes de chuva muito diferentes na mesma curva
##     de dose-resposta.
##
## Sem essa dupla padronização, a dose-resposta mediria geografia: os
## meses "de muita chuva" seriam sempre os do litoral norte, e a curva
## resultante confundiria exposição com anomalia.
mensal <- mensal %>%
    group_by(geocodigo, mes) %>%
    mutate(across(all_of(dic_clima$variavel),
                  ~ .x - get(paste0(cur_column(), "_normal")),
                  .names = "{.col}_anom"),
           across(all_of(dic_clima$variavel),
                  ~ rank(.x, na.last = "keep") / sum(!is.na(.x)),
                  .names = "{.col}_p")) %>%
    ungroup()

message("Janela analítica       : ", ano_ini_atlas, "-", ano_fim_atlas,
        " | ", fmt_int(nrow(mensal)), " município-meses | ",
        n_distinct(mensal$geocodigo), " municípios")

######@> Eventos por grupo em formato longo...
## Os quatro grupos do Atlas em formato longo, que é o formato natural
## para as figuras com facetas e para as dose-respostas por grupo.
colunas_grupo <- c("Climatológico" = "atlas_n_eventos_climatologico",
                   "Hidrológico"   = "atlas_n_eventos_hidrologico",
                   "Meteorológico" = "atlas_n_eventos_meteorologico",
                   "Outros"        = "atlas_n_eventos_outros")

eventos_grupo <- mensal %>%
    select(geocodigo, municipio, ano, mes, data, estacao,
           all_of(unname(colunas_grupo))) %>%
    pivot_longer(all_of(unname(colunas_grupo)),
                 names_to = "coluna", values_to = "n_eventos") %>%
    mutate(grupo = factor(names(colunas_grupo)[
               match(coluna, colunas_grupo)], levels = ordem_grupos)) %>%
    select(-coluna)

######@> Séries agregadas do litoral...
## Somam os 35 municípios. É a escala em que a estrutura temporal
## aparece com menos ruído amostral - e, como mostra a Etapa 03, também
## a escala em que a sobredispersão é maior.
litoral_mensal <- mensal %>%
    group_by(ano, mes, data) %>%
    summarise(n_eventos = sum(atlas_n_eventos),
              municipios_com_evento = sum(atlas_n_eventos > 0),
              across(all_of(dic_clima$variavel),
                     ~ mean(.x, na.rm = TRUE)),
              .groups = "drop") %>%
    arrange(data)

litoral_mensal_grupo <- eventos_grupo %>%
    group_by(ano, mes, data, grupo) %>%
    summarise(n_eventos = sum(n_eventos), .groups = "drop")

litoral_anual <- mensal %>%
    group_by(ano) %>%
    summarise(n_eventos = sum(atlas_n_eventos),
              n_meses_com_evento = sum(atlas_n_eventos > 0),
              municipios_com_evento = n_distinct(
                  geocodigo[atlas_n_eventos > 0]),
              across(all_of(dic_clima$variavel),
                     ~ mean(.x, na.rm = TRUE)),
              .groups = "drop")

######@> Séries municipais anuais...
anual <- base_anual %>%
    filter(tem_atlas, ano >= ano_ini_atlas, ano <= ano_fim_atlas)

######@> Leitura e preparo do shapefile para os mapas...
message("Lendo shapefile...")
shape_bruto <- st_read(arq_shape, quiet = TRUE) %>% st_make_valid()
shape_bruto <- st_transform(shape_bruto, crs_projeto)

atributos <- st_drop_geometry(shape_bruto)
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))

municipios_sf <- shape_bruto %>%
    group_by(geocodigo, municipio) %>%
    summarise(.groups = "drop") %>%
    st_make_valid() %>%
    mutate(tem_atlas = geocodigo %in% unique(mensal$geocodigo))

######@> Vetores de referência...
municipios_nomes <- sort(unique(mensal$municipio))
n_municipios <- length(municipios_nomes)
anos <- sort(unique(mensal$ano))
n_anos <- length(anos)
n_meses <- nrow(mensal) / n_municipios

ordem_norte_sul <- municipios %>%
    filter(geocodigo %in% unique(mensal$geocodigo)) %>%
    arrange(desc(lat_centroide)) %>%
    pull(municipio)

######@> Lista acumuladora das tabelas exportadas...
tabelas <- list()

########################################################################
######@> Etapa 02 - Panorama: cobertura efetiva e tamanho amostral...

######@> Ficha da análise...
panorama <- tibble(
    Indicador = c("Janela da base consolidada",
                  "Janela do Atlas (resposta)",
                  "Janela do MapBiomas (uso da terra)",
                  "Janela com as três fontes",
                  "Municípios com resposta",
                  "Município-meses analisados",
                  "Município-anos analisados",
                  "Eventos de desastre",
                  "Município-meses com evento",
                  "Variáveis climáticas examinadas",
                  "Variáveis de uso da terra na base",
                  "Normal climatológica de referência"),
    Valor = c(paste0(format(min(base_mensal$data), "%m/%Y"), " a ",
                     format(max(base_mensal$data), "%m/%Y")),
              paste0(ano_ini_atlas, "-", ano_fim_atlas, " (", n_anos,
                     " anos, ", n_meses, " meses)"),
              paste0(min(base_anual$ano[base_anual$tem_mapbiomas]), "-",
                     ano_fim_terra),
              paste0(ano_ini_atlas, "-", ano_fim_terra, " (",
                     ano_fim_terra - ano_ini_atlas + 1, " anos)"),
              as.character(n_municipios),
              fmt_int(nrow(mensal)),
              fmt_int(nrow(anual)),
              fmt_int(sum(mensal$atlas_n_eventos)),
              paste0(fmt_int(sum(mensal$ocorrencia)), " (",
                     sprintf("%.1f%%", 100 * mean(mensal$ocorrencia)),
                     ")"),
              as.character(nrow(dic_clima)),
              as.character(sum(grepl("^mapb_",
                                     names(base_mensal)))),
              paste0(ref_ini, "-", ref_fim)))

tabelas[["Tab_01_panorama"]] <- salvar_tab(panorama,
                                           "Tab_01_panorama_da_analise")

message("\n--- Panorama da análise ---")
print(as.data.frame(panorama), right = FALSE)

######@> Cobertura das três fontes ao longo do tempo...
cobertura_fontes <- base_mensal %>%
    group_by(ano) %>%
    summarise(`Atlas (desastres)` = n_distinct(geocodigo[tem_atlas]),
              `ERA5 (clima)` = n_distinct(geocodigo[tem_era5]),
              `MapBiomas (terra)` = n_distinct(geocodigo[tem_mapbiomas]),
              .groups = "drop") %>%
    pivot_longer(-ano, names_to = "fonte", values_to = "municipios") %>%
    mutate(fonte = factor(fonte, levels = names(cores_fonte)))

tabelas[["Tab_02_cobertura_fontes"]] <- salvar_tab(
    cobertura_fontes %>%
        pivot_wider(names_from = fonte, values_from = municipios),
    "Tab_02_cobertura_das_fontes")

######@> Figura 01 - a janela útil da análise...
f01 <- ggplot(cobertura_fontes, aes(x = ano, y = municipios,
                                    colour = fonte, fill = fonte)) +
    geom_area(alpha = 0.25, position = "identity",
              linewidth = 0.8) +
    geom_vline(xintercept = c(ano_ini_atlas - 0.5,
                              ano_fim_terra + 0.5),
               linetype = "dashed", colour = "grey30") +
    annotate("rect", xmin = ano_ini_atlas - 0.5,
             xmax = ano_fim_terra + 0.5, ymin = 0, ymax = 38,
             alpha = 0.06, fill = "#009E73") +
    annotate("text", x = (ano_ini_atlas + ano_fim_terra) / 2, y = 36,
             label = paste0("Janela com as três fontes\n",
                            ano_ini_atlas, "-", ano_fim_terra),
             size = 3.2, colour = "grey20") +
    scale_colour_manual(values = cores_fonte, name = NULL) +
    scale_fill_manual(values = cores_fonte, name = NULL) +
    scale_x_continuous(breaks = seq(1940, 2030, 10)) +
    scale_y_continuous(limits = c(0, 38), expand = c(0, 0)) +
    labs(title = "A base é longa, mas a janela útil é menor",
         subtitle = paste("Municípios cobertos por cada fonte em cada",
                          "ano da base consolidada"),
         x = NULL, y = "Municípios com dado",
         caption = quebrar(paste(
             "O ERA5 cobre os 37 municípios desde 1940, mas a variável",
             "resposta - o registro de desastre - só existe a partir de",
             "1991, e o uso da terra termina em 2024. Qualquer análise",
             "que exija as três fontes dispõe de 34 anos e 35",
             "municípios. Os 51 anos anteriores de clima seguem úteis",
             "para estabelecer a climatologia de referência, e é assim",
             "que este script os utiliza.")))

salvar_fig(f01, "Fig_01_janela_util", 11, 6)

########################################################################
######@> Etapa 03 - A variável resposta: composição e distribuição...

######@> Composição por grupo de desastre...
## A primeira decisão analítica do capítulo está aqui: tratar
## "desastre" como um fenômeno único ou separá-lo por grupo. A tabela
## mostra os pesos; a Etapa 06 mostra por que a separação é obrigatória.
composicao_grupo <- eventos_grupo %>%
    group_by(grupo) %>%
    summarise(eventos = sum(n_eventos),
              meses_com_evento = sum(n_eventos > 0),
              municipios_atingidos = n_distinct(
                  geocodigo[n_eventos > 0]),
              .groups = "drop") %>%
    mutate(pct_eventos = 100 * eventos / sum(eventos),
           pct_meses = 100 * meses_com_evento / nrow(mensal)) %>%
    arrange(desc(eventos))

tabelas[["Tab_03_composicao_grupo"]] <- salvar_tab(
    composicao_grupo, "Tab_03_composicao_por_grupo")

message("\n--- Composição dos eventos por grupo ---")
print(as.data.frame(composicao_grupo %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 2)))), right = FALSE)

######@> Composição por tipologia...
## O recorte mais fino que o Atlas oferece - e que só existe em escala
## anual, razão pela qual entra aqui como descrição e não como resposta
## das análises mensais.
composicao_tipologia <- anual %>%
    select(starts_with("atlas_n_eventos_tip_")) %>%
    summarise(across(everything(), ~ sum(.x, na.rm = TRUE))) %>%
    pivot_longer(everything(), names_to = "tipologia",
                 values_to = "eventos") %>%
    mutate(tipologia = gsub("_", " ",
                            sub("^atlas_n_eventos_tip_", "",
                                tipologia)),
           tipologia = paste0(toupper(substr(tipologia, 1, 1)),
                              substr(tipologia, 2, nchar(tipologia))),
           pct = 100 * eventos / sum(eventos)) %>%
    filter(eventos > 0) %>%
    arrange(desc(eventos))

tabelas[["Tab_04_composicao_tipologia"]] <- salvar_tab(
    composicao_tipologia, "Tab_04_composicao_por_tipologia")

######@> Figura 02 - do que são feitos os 1.191 registros...
g02a <- composicao_grupo %>%
    mutate(grupo = factor(grupo, levels = rev(ordem_grupos))) %>%
    ggplot(aes(x = eventos, y = grupo, fill = grupo)) +
    geom_col(width = 0.72) +
    geom_text(aes(label = paste0(eventos, " (",
                                 sprintf("%.1f%%", pct_eventos), ")")),
              hjust = -0.08, size = 3, colour = "grey25") +
    scale_fill_manual(values = cores_grupo, guide = "none") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.25))) +
    labs(subtitle = "Por grupo (COBRADE)", x = "Eventos", y = NULL)

g02b <- composicao_tipologia %>%
    slice_head(n = 12) %>%
    mutate(tipologia = factor(tipologia, levels = rev(tipologia))) %>%
    ggplot(aes(x = eventos, y = tipologia)) +
    geom_col(fill = "grey45", width = 0.72) +
    geom_text(aes(label = eventos), hjust = -0.15, size = 2.8,
              colour = "grey25") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.2))) +
    labs(subtitle = "Por tipologia (12 maiores)", x = "Eventos",
         y = NULL) +
    theme(axis.text.y = element_text(size = 8))

f02 <- (g02a | g02b) +
    plot_layout(widths = c(1, 1.1)) +
    plot_annotation(
        title = "A resposta não é um fenômeno único",
        subtitle = paste0(fmt_int(sum(mensal$atlas_n_eventos)),
                          " registros de desastre em ", n_municipios,
                          " municípios, ", ano_ini_atlas, "-",
                          ano_fim_atlas),
        caption = quebrar(paste(
            "Dois grupos concentram 90% dos registros - o hidrológico",
            "(enxurradas, inundações, alagamentos) e o meteorológico",
            "(vendavais, ciclones, granizo) -, e a Etapa 06 mostra que",
            "eles respondem a variáveis climáticas DIFERENTES. O grupo",
            "climatológico (estiagem e seca) é pequeno em número, mas",
            "tem o motor mais nítido de todos, e com sinal invertido.")))

salvar_fig(f02, "Fig_02_composicao_dos_registros", 12, 6)

######@> Distribuição das contagens em três escalas...
## A pergunta é de família de distribuição: as contagens de desastre são
## compatíveis com Poisson? A razão variância/média responde - vale 1
## sob Poisson, e cresce com a sobredispersão.
##
## Os zeros esperados são calculados sob Poisson e sob binomial
## negativo, ambos ajustados apenas com a média (e a dispersão, no
## segundo caso) observadas. Se o binomial negativo reproduzir os zeros
## observados, não há excesso de zeros a modelar: a sobredispersão dá
## conta deles.
escalas <- list(
    "Mensal, município" = mensal$atlas_n_eventos,
    "Anual, município" = anual$atlas_n_eventos,
    "Mensal, litoral" = litoral_mensal$n_eventos,
    "Anual, litoral" = litoral_anual$n_eventos)

distribuicao_escalas <- map_dfr(names(escalas), function(nome) {
    x <- escalas[[nome]]
    media <- mean(x)
    variancia <- var(x)
    ## Parâmetro de dispersão do binomial negativo pelo método dos
    ## momentos: var = mu + mu^2 / theta
    theta <- ifelse(variancia > media,
                    media^2 / (variancia - media), NA_real_)
    tibble(escala = nome,
           n = length(x),
           media = media,
           variancia = variancia,
           razao_var_media = variancia / media,
           maximo = max(x),
           zeros_observados = sum(x == 0),
           pct_zeros = 100 * mean(x == 0),
           zeros_poisson = sum(dpois(0, media)) * length(x),
           zeros_binom_neg = ifelse(
               is.na(theta), NA_real_,
               length(x) * dnbinom(0, size = theta, mu = media)))
}) %>%
    mutate(excesso_vs_poisson = zeros_observados / zeros_poisson,
           excesso_vs_binom_neg = zeros_observados / zeros_binom_neg)

tabelas[["Tab_05_distribuicao"]] <- salvar_tab(
    distribuicao_escalas, "Tab_05_distribuicao_das_contagens")

message("\n--- Distribuição das contagens ---")
print(as.data.frame(distribuicao_escalas %>%
                    select(escala, n, media, razao_var_media,
                           pct_zeros, zeros_observados, zeros_poisson,
                           zeros_binom_neg) %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 2)))), right = FALSE)

######@> Figura 03 - a resposta é rara, discreta e sobredispersa...
dados_f03a <- tibble(
    escala = rep(c("Mensal, município", "Anual, município"),
                 c(length(mensal$atlas_n_eventos),
                   length(anual$atlas_n_eventos))),
    n_eventos = c(mensal$atlas_n_eventos, anual$atlas_n_eventos)) %>%
    mutate(escala = factor(escala, levels = c("Mensal, município",
                                              "Anual, município")),
           faixa = pmin(n_eventos, 8)) %>%
    count(escala, faixa) %>%
    group_by(escala) %>%
    mutate(pct = 100 * n / sum(n)) %>%
    ungroup()

g03a <- ggplot(dados_f03a, aes(x = factor(faixa), y = pct,
                               fill = escala)) +
    geom_col(position = position_dodge(width = 0.8), width = 0.72) +
    scale_fill_manual(values = c("Mensal, município" = "#0072B2",
                                 "Anual, município" = "#D55E00"),
                      name = NULL) +
    scale_x_discrete(labels = function(x)
        ifelse(x == "8", "8+", x)) +
    labs(subtitle = "Distribuição das contagens",
         x = "Eventos na unidade de observação", y = "% das unidades")

g03b <- distribuicao_escalas %>%
    mutate(escala = factor(escala, levels = rev(escala))) %>%
    ggplot(aes(x = razao_var_media, y = escala)) +
    geom_vline(xintercept = 1, linetype = "dashed",
               colour = "#D55E00") +
    geom_segment(aes(xend = 1, yend = escala), colour = "grey70",
                 linewidth = 0.5) +
    geom_point(size = 3, colour = "#0072B2") +
    geom_text(aes(label = sprintf("%.1f", razao_var_media)),
              vjust = -1, size = 3, colour = "grey25") +
    scale_x_continuous(trans = "log10",
                       breaks = c(1, 2, 5, 10, 30)) +
    labs(subtitle = "Razão variância/média por escala",
         x = "Razão (escala logarítmica; 1 = Poisson)", y = NULL)

f03 <- (g03a / g03b) +
    plot_layout(heights = c(1.2, 1)) +
    plot_annotation(
        title = "A escala de análise decide a família de distribuição",
        subtitle = paste("Contagens de desastre em quatro escalas de",
                         "agregação"),
        caption = quebrar(paste(
            "A sobredispersão CRESCE com a agregação: é modesta na",
            "escala mensal municipal (razão 1,2), moderada na anual",
            "municipal (2,6) e severa no agregado anual do litoral",
            "(29,8) - porque somar municípios soma também a",
            "correlação espacial entre eles. A escolha da escala não é",
            "apenas de conveniência: define se um modelo de Poisson é",
            "admissível ou se é preciso um binomial negativo.")))

salvar_fig(f03, "Fig_03_distribuicao_da_resposta", 11, 8)

########################################################################
######@> Etapa 04 - O viés de registro: a tendência que não é clima...

######@> A comparação decisiva...
## Se o crescimento dos registros fosse climático, a frequência de meses
## climaticamente extremos deveria crescer junto. Esta etapa testa
## exatamente isso, e a resposta é negativa - o que reorienta toda a
## modelagem posterior.
##
## O mês extremo é definido pelo percentil LOCAL de precipitação
## (percentil 95 dentro do município e do mês do ano), de modo que a
## contagem anual de extremos não seja dominada pelos municípios mais
## chuvosos nem pelos meses de verão.
mensal <- mensal %>%
    mutate(mes_extremo_chuva = era5_tp_mm_mes_p > limiar_extremo,
           mes_extremo_vento = era5_si10_p > limiar_extremo,
           mes_extremo_seco = era5_tp_mm_mes_p < (1 - limiar_extremo))

serie_registro <- mensal %>%
    group_by(ano) %>%
    summarise(eventos = sum(atlas_n_eventos),
              reconhecidos = sum(atlas_n_reconhecidos),
              municipios_registrantes = n_distinct(
                  geocodigo[atlas_n_eventos > 0]),
              meses_extremos_chuva = sum(mes_extremo_chuva),
              meses_extremos_vento = sum(mes_extremo_vento),
              precipitacao_media = mean(era5_tp_mm_mes),
              .groups = "drop") %>%
    mutate(eventos_por_registrante = eventos /
               pmax(1, municipios_registrantes),
           taxa_reconhecimento = 100 * reconhecidos /
               pmax(1, eventos))

tabelas[["Tab_06_serie_registro"]] <- salvar_tab(
    serie_registro, "Tab_06_serie_de_registro")

######@> As correlações que separam clima de burocracia...
correlacoes_registro <- tribble(
    ~relacao, ~rho, ~p_valor,
    "Eventos x ano", NA_real_, NA_real_,
    "Meses extremos de chuva x ano", NA_real_, NA_real_,
    "Meses extremos de vento x ano", NA_real_, NA_real_,
    "Precipitação média x ano", NA_real_, NA_real_,
    "Eventos x meses extremos de chuva", NA_real_, NA_real_,
    "Eventos x precipitação média", NA_real_, NA_real_,
    "Municípios registrantes x ano", NA_real_, NA_real_)

pares_correlacao <- list(
    c("eventos", "ano"), c("meses_extremos_chuva", "ano"),
    c("meses_extremos_vento", "ano"), c("precipitacao_media", "ano"),
    c("eventos", "meses_extremos_chuva"),
    c("eventos", "precipitacao_media"),
    c("municipios_registrantes", "ano"))

correlacoes_registro <- map_dfr(seq_along(pares_correlacao),
                                function(i) {
    par <- pares_correlacao[[i]]
    teste <- suppressWarnings(cor.test(serie_registro[[par[1]]],
                                       serie_registro[[par[2]]],
                                       method = "spearman"))
    tibble(relacao = correlacoes_registro$relacao[i],
           rho = as.numeric(teste$estimate),
           p_valor = teste$p.value,
           resultado = ifelse(teste$p.value < alfa,
                              "Associação significativa",
                              "Sem associação detectada"))
})

tabelas[["Tab_07_correlacoes_registro"]] <- salvar_tab(
    correlacoes_registro, "Tab_07_correlacoes_do_registro")

message("\n--- Clima ou burocracia? ---")
print(as.data.frame(correlacoes_registro %>%
                    mutate(rho = round(rho, 3),
                           p_valor = signif(p_valor, 3))),
      right = FALSE)

######@> A quebra de 2012...
## O S2iD foi digitalizado em 2012, e a partir daí o registro passou a
## ser feito em sistema eletrônico com prazo e formulário padronizados.
## A comparação entre os dois períodos mede o tamanho do degrau.
quebra_registro <- mensal %>%
    mutate(periodo = ifelse(ano < 2012,
                            paste0(ano_ini_atlas, "-2011"),
                            paste0("2012-", ano_fim_atlas))) %>%
    group_by(periodo) %>%
    summarise(anos = n_distinct(ano),
              eventos = sum(atlas_n_eventos),
              eventos_por_ano = sum(atlas_n_eventos) / n_distinct(ano),
              municipios_registrantes = n_distinct(
                  geocodigo[atlas_n_eventos > 0]),
              pct_meses_com_evento = 100 * mean(atlas_n_eventos > 0),
              meses_extremos_por_ano = sum(mes_extremo_chuva) /
                  n_distinct(ano),
              precipitacao_media = mean(era5_tp_mm_mes),
              .groups = "drop")

tabelas[["Tab_08_quebra_2012"]] <- salvar_tab(
    quebra_registro, "Tab_08_quebra_do_registro_2012")

razao_periodos <- quebra_registro$eventos_por_ano[2] /
    quebra_registro$eventos_por_ano[1]
razao_extremos <- quebra_registro$meses_extremos_por_ano[2] /
    quebra_registro$meses_extremos_por_ano[1]

message("\nEventos por ano        : ",
        sprintf("%.1f", quebra_registro$eventos_por_ano[1]), " (",
        quebra_registro$periodo[1], ") -> ",
        sprintf("%.1f", quebra_registro$eventos_por_ano[2]), " (",
        quebra_registro$periodo[2], ") | razão ",
        sprintf("%.2f", razao_periodos))
message("Meses extremos por ano : ",
        sprintf("%.1f", quebra_registro$meses_extremos_por_ano[1]),
        " -> ",
        sprintf("%.1f", quebra_registro$meses_extremos_por_ano[2]),
        " | razão ", sprintf("%.2f", razao_extremos))

######@> Figura 04 - a tendência que o clima não explica...
dados_f04 <- serie_registro %>%
    select(ano, eventos, meses_extremos_chuva, precipitacao_media) %>%
    pivot_longer(-ano, names_to = "serie", values_to = "valor") %>%
    mutate(serie = recode(serie,
                          eventos = "Registros de desastre",
                          meses_extremos_chuva =
                              "Município-meses de chuva extrema (> p95)",
                          precipitacao_media =
                              "Precipitação média (mm/mês)"),
           serie = factor(serie,
                          levels = c("Registros de desastre",
                                     "Município-meses de chuva extrema (> p95)",
                                     "Precipitação média (mm/mês)")))

f04 <- ggplot(dados_f04, aes(x = ano, y = valor, colour = serie)) +
    geom_line(linewidth = 0.8) +
    geom_point(size = 1.1) +
    geom_smooth(method = "lm", formula = y ~ x, se = FALSE,
                linetype = "dashed", linewidth = 0.6,
                colour = "grey35") +
    geom_vline(xintercept = 2011.5, linetype = "dotted",
               colour = "grey30") +
    annotate("text", x = 2011.8, y = Inf, label = "S2iD digital (2012)",
             hjust = 0, vjust = 1.6, size = 2.9, colour = "grey30") +
    facet_wrap(~ serie, ncol = 1, scales = "free_y") +
    scale_colour_manual(values = c("#D55E00", "#0072B2", "#009E73"),
                        guide = "none") +
    scale_x_continuous(breaks = seq(1990, 2025, 5)) +
    labs(title = "A alta dos registros não tem contrapartida climática",
         subtitle = paste0("Séries anuais do litoral, ", ano_ini_atlas,
                           "-", ano_fim_atlas,
                           "; tracejado: ajuste linear"),
         x = NULL, y = NULL,
         caption = quebrar(paste0(
             "Os registros de desastre crescem de forma acentuada",
             " (rho = ",
             sprintf("%.2f", correlacoes_registro$rho[
                 correlacoes_registro$relacao == "Eventos x ano"]),
             " com o ano), enquanto a frequência de meses de chuva",
             " extrema não muda (rho = ",
             sprintf("%.2f", correlacoes_registro$rho[
                 correlacoes_registro$relacao ==
                 "Meses extremos de chuva x ano"]),
             ") e a precipitação média tampouco. A média anual salta de ",
             sprintf("%.1f", quebra_registro$eventos_por_ano[1]),
             " para ",
             sprintf("%.1f", quebra_registro$eventos_por_ano[2]),
             " eventos entre os dois períodos - um fator de ",
             sprintf("%.1f", razao_periodos),
             " -, coincidindo com a digitalização do S2iD e com a",
             " ampliação do reconhecimento federal. A série de",
             " desastres mede, em parte, o sistema que a produz.")))

salvar_fig(f04, "Fig_04_tendencia_do_registro", 11, 9)

######@> Onde está o crescimento: em mais municípios ou em mais
######@> eventos por município?
## Decompor o crescimento responde a que tipo de mudança ocorreu. Se o
## número de municípios que registram cresce, é AMPLIAÇÃO DE COBERTURA
## do sistema; se cresce o número de eventos por município registrante,
## é intensificação - climática ou de propensão a declarar.
f05 <- serie_registro %>%
    select(ano, municipios_registrantes, eventos_por_registrante,
           taxa_reconhecimento) %>%
    pivot_longer(-ano, names_to = "medida", values_to = "valor") %>%
    mutate(medida = recode(
               medida,
               municipios_registrantes = "Municípios que registram",
               eventos_por_registrante = "Eventos por município registrante",
               taxa_reconhecimento = "Reconhecimento federal (% dos eventos)"),
           medida = factor(medida,
                           levels = c("Municípios que registram",
                                      "Eventos por município registrante",
                                      "Reconhecimento federal (% dos eventos)"))) %>%
    ggplot(aes(x = ano, y = valor)) +
    geom_line(colour = "grey40", linewidth = 0.7) +
    geom_point(size = 1, colour = "grey25") +
    geom_smooth(method = "loess", formula = y ~ x, se = FALSE,
                colour = "#D55E00", linewidth = 0.7, span = 0.7) +
    geom_vline(xintercept = 2011.5, linetype = "dotted",
               colour = "grey30") +
    facet_wrap(~ medida, ncol = 3, scales = "free_y") +
    scale_x_continuous(breaks = seq(1990, 2025, 10)) +
    labs(title = "O crescimento é de cobertura, não só de intensidade",
         subtitle = paste("Decomposição do aumento dos registros;",
                          "linha pontilhada: digitalização do S2iD"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "O número de municípios que registram ao menos um desastre",
             "por ano cresce e depois satura próximo do total, enquanto",
             "o número de eventos por município registrante cresce de",
             "modo mais contido. A taxa de reconhecimento federal - a",
             "fração dos registros que vira reconhecimento de situação",
             "de emergência ou calamidade - é a terceira peça do",
             "sistema, e também varia no tempo. Nenhuma das três é",
             "variável climática.")))

salvar_fig(f05, "Fig_05_decomposicao_do_registro", 13, 5)

######@> Consequência para a modelagem...
## Registrada em objeto próprio porque é a recomendação mais importante
## desta AED e precisa aparecer no relatório de síntese com seus
## números.
consequencia_registro <- tibble(
    achado = c("Correlação eventos x ano",
               "Correlação extremos x ano",
               "Correlação eventos x extremos",
               "Razão entre períodos (eventos/ano)",
               "Razão entre períodos (extremos/ano)"),
    valor = c(sprintf("%.3f", correlacoes_registro$rho[1]),
              sprintf("%.3f", correlacoes_registro$rho[2]),
              sprintf("%.3f", correlacoes_registro$rho[5]),
              sprintf("%.2f", razao_periodos),
              sprintf("%.2f", razao_extremos)),
    leitura = c("A série de desastres cresce fortemente",
                "A frequência de extremos climáticos não cresce",
                "A associação entre as duas é fraca no agregado anual",
                "O registro quase triplicou entre os dois períodos",
                "Os extremos climáticos permaneceram estáveis"))

tabelas[["Tab_09_consequencia_registro"]] <- salvar_tab(
    consequencia_registro, "Tab_09_consequencia_do_vies_de_registro")

########################################################################
######@> Etapa 05 - Sazonalidade conjunta de desastres e clima...

######@> Ciclo anual dos eventos, por grupo...
## O índice de sazonalidade é a razão entre a contagem do mês e a
## contagem média mensal do grupo: vale 1 quando o mês está na média,
## 2 quando concentra o dobro do esperado. É adimensional, e por isso
## permite comparar grupos com números de eventos muito diferentes.
ciclo_grupo <- eventos_grupo %>%
    group_by(grupo, mes) %>%
    summarise(eventos = sum(n_eventos), .groups = "drop") %>%
    group_by(grupo) %>%
    mutate(indice_sazonal = eventos / mean(eventos),
           mes_nome = factor(meses_abrev[mes], levels = meses_abrev)) %>%
    ungroup()

######@> Ciclo anual das variáveis climáticas...
ciclo_clima <- mensal %>%
    group_by(mes) %>%
    summarise(across(all_of(dic_clima$variavel),
                     ~ mean(.x, na.rm = TRUE)), .groups = "drop") %>%
    pivot_longer(-mes, names_to = "variavel", values_to = "valor") %>%
    left_join(dic_clima, by = "variavel") %>%
    group_by(variavel) %>%
    mutate(valor_padronizado = (valor - mean(valor)) / sd(valor)) %>%
    ungroup()

######@> Mês de pico e concordância entre ciclos...
## A pergunta que a tabela responde: o pico de cada grupo de desastre
## coincide com o pico de qual variável climática? A correlação é
## calculada entre os DOZE valores do ciclo médio - não entre as séries
## completas -, e mede portanto a concordância de FORMA sazonal.
concordancia_sazonal <- expand_grid(
    grupo = ordem_grupos,
    variavel = dic_clima$variavel) %>%
    mutate(correlacao = map2_dbl(grupo, variavel, function(g, v) {
        ev <- ciclo_grupo$eventos[ciclo_grupo$grupo == g][
            order(ciclo_grupo$mes[ciclo_grupo$grupo == g])]
        cl <- ciclo_clima$valor[ciclo_clima$variavel == v][
            order(ciclo_clima$mes[ciclo_clima$variavel == v])]
        if(sd(ev) == 0 || sd(cl) == 0) return(NA_real_)
        cor(ev, cl)
    })) %>%
    left_join(dic_clima %>% select(variavel, rotulo, dominio),
              by = "variavel") %>%
    mutate(grupo = factor(grupo, levels = ordem_grupos))

pico_grupo <- ciclo_grupo %>%
    group_by(grupo) %>%
    summarise(mes_pico = meses_abrev[mes[which.max(eventos)]],
              indice_pico = max(indice_sazonal),
              mes_minimo = meses_abrev[mes[which.min(eventos)]],
              indice_minimo = min(indice_sazonal),
              amplitude = max(indice_sazonal) - min(indice_sazonal),
              .groups = "drop")

tabelas[["Tab_10_sazonalidade_grupo"]] <- salvar_tab(
    ciclo_grupo %>% select(grupo, mes, eventos, indice_sazonal),
    "Tab_10_sazonalidade_por_grupo")
tabelas[["Tab_11_pico_sazonal"]] <- salvar_tab(
    pico_grupo, "Tab_11_pico_sazonal_por_grupo")
tabelas[["Tab_12_concordancia_sazonal"]] <- salvar_tab(
    concordancia_sazonal %>%
        select(grupo, variavel, rotulo, dominio, correlacao) %>%
        arrange(grupo, desc(abs(correlacao))),
    "Tab_12_concordancia_sazonal")

message("\n--- Sazonalidade por grupo ---")
print(as.data.frame(pico_grupo %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 2)))), right = FALSE)

######@> Figura 06 - dois grupos, duas estações...
g06a <- ggplot(ciclo_grupo, aes(x = mes_nome, y = eventos,
                                fill = grupo)) +
    geom_col(width = 0.78) +
    facet_wrap(~ grupo, ncol = 4, scales = "free_y") +
    scale_fill_manual(values = cores_grupo, guide = "none") +
    labs(subtitle = "Eventos por mês do ano, em cada grupo",
         x = NULL, y = "Eventos") +
    theme(axis.text.x = element_text(size = 7, angle = 90,
                                     hjust = 1, vjust = 0.5))

dados_f06b <- ciclo_clima %>%
    filter(variavel %in% c("era5_tp_mm_mes", "era5_si10",
                           "era5_t2m_C", "era5_tcrw")) %>%
    mutate(rotulo = factor(rotulo, levels = unique(rotulo)))

g06b <- ggplot(dados_f06b, aes(x = mes, y = valor_padronizado,
                               colour = rotulo)) +
    geom_hline(yintercept = 0, colour = "grey70", linewidth = 0.3) +
    geom_line(linewidth = 0.9) +
    geom_point(size = 1.2) +
    scale_colour_manual(values = c("#0072B2", "#D55E00", "#CC79A7",
                                   "#56B4E9"), name = NULL) +
    scale_x_continuous(breaks = 1:12, labels = meses_abrev) +
    guides(colour = guide_legend(nrow = 1)) +
    labs(subtitle = paste("Ciclo climático médio, padronizado",
                          "(z do ciclo)"),
         x = NULL, y = "Desvios-padrão")

f06 <- (g06a / g06b) +
    plot_annotation(
        title = "Grupos de desastre com estações opostas",
        subtitle = paste("Ciclo anual dos registros e das variáveis",
                         "climáticas no litoral catarinense"),
        caption = quebrar(paste0(
            "O grupo hidrológico tem pico em ",
            pico_grupo$mes_pico[pico_grupo$grupo == "Hidrológico"],
            ", acompanhando a precipitação de verão; o meteorológico",
            " tem pico em ",
            pico_grupo$mes_pico[pico_grupo$grupo == "Meteorológico"],
            ", acompanhando o vento de inverno e primavera. São dois",
            " regimes distintos dentro da mesma base, e agregá-los em",
            " uma única série de 'desastres' produz um ciclo sazonal",
            " que não descreve nenhum dos dois. O grupo climatológico,",
            " com 42 registros, tem sazonalidade menos definida - o",
            " que é esperado de um fenômeno de acumulação, e não de",
            " gatilho.")))

salvar_fig(f06, "Fig_06_sazonalidade_conjunta", 12, 8)

######@> Figura 07 - mapa de calor mês x ano...
dados_f07 <- litoral_mensal %>%
    select(ano, mes, n_eventos) %>%
    mutate(mes_nome = factor(meses_abrev[mes], levels = meses_abrev))

f07 <- ggplot(dados_f07, aes(x = ano, y = mes_nome, fill = n_eventos)) +
    geom_tile(colour = "white", linewidth = 0.25) +
    scale_fill_gradientn(colours = c("grey96", "#FDD49E", "#FC8D59",
                                     "#D7301F", "#7F0000"),
                         values = c(0, 0.08, 0.25, 0.6, 1),
                         name = "Eventos no mês") +
    scale_x_continuous(breaks = seq(1990, 2025, 5), expand = c(0, 0)) +
    scale_y_discrete(limits = rev(meses_abrev), expand = c(0, 0)) +
    labs(title = "Quando os desastres aconteceram",
         subtitle = paste("Registros no conjunto do litoral, por mês e",
                          "ano"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "A leitura vertical mostra a sazonalidade; a horizontal,",
             "a intensificação do registro ao longo do tempo. Os meses",
             "mais escuros correspondem a episódios reconhecíveis - o",
             "desastre do Vale do Itajaí em novembro de 2008, o ciclone",
             "de julho de 2020, as chuvas de outubro de 2023 -,",
             "mas a metade direita do painel é sistematicamente mais",
             "carregada que a esquerda, e a Etapa 04 mostra que isso",
             "não é clima."))) +
    theme(legend.key.width = unit(1.6, "cm"))

salvar_fig(f07, "Fig_07_heatmap_mes_ano", 12, 6)

########################################################################
######@> Etapa 06 - Dose-resposta: clima e probabilidade de desastre...

######@> Construção das curvas...
## Para cada combinação de grupo de desastre e variável climática,
## calcula-se a probabilidade de ocorrência em cada faixa de percentil
## local. É a análise central desta AED: ela responde, sem modelo, se
## existe relação entre clima e desastre e qual é sua forma.
##
## O percentil local já removeu município e mês do ano (Etapa 01), de
## modo que a curva mede ANOMALIA - não geografia nem estação.
combinacoes_dose <- expand_grid(
    grupo = c("Todos", ordem_grupos),
    variavel = dic_clima$variavel)

dose_todas <- pmap_dfr(combinacoes_dose, function(grupo, variavel) {
    coluna_resposta <- if(grupo == "Todos") "atlas_n_eventos" else
        unname(colunas_grupo[grupo])
    dados <- mensal %>%
        select(percentil = paste0(variavel, "_p"),
               resposta = all_of(coluna_resposta)) %>%
        filter(!is.na(percentil))
    dose_resposta(dados, "percentil", "resposta",
                  rotulo = variavel) %>%
        mutate(grupo = grupo, .before = 1)
}) %>%
    left_join(dic_clima %>% select(variavel, rotulo, unidade, dominio),
              by = "variavel") %>%
    mutate(grupo = factor(grupo, levels = c("Todos", ordem_grupos)))

tabelas[["Tab_13_dose_resposta"]] <- salvar_tab(
    dose_todas %>%
        select(grupo, variavel, rotulo, faixa, n, ocorrencias, eventos,
               p, ic_inf, ic_sup, razao_vs_mediana),
    "Tab_13_dose_resposta_completa")

######@> Força da relação: razão entre a cauda e a base...
## Resume cada curva em um número: quantas vezes a probabilidade de
## desastre na faixa mais extrema supera a da faixa de referência (o
## quartil inferior). É a medida usada na triagem da Figura 09.
forca_dose <- dose_todas %>%
    group_by(grupo, variavel, rotulo, dominio) %>%
    summarise(p_base = p[1],
              p_extremo = p[n()],
              razao_extremo = p[n()] / pmax(p[1], 1e-6),
              p_extremo_inferior = ic_inf[n()],
              p_base_superior = ic_sup[1],
              separado = ic_inf[n()] > ic_sup[1],
              .groups = "drop") %>%
    arrange(grupo, desc(razao_extremo))

tabelas[["Tab_14_forca_dose"]] <- salvar_tab(
    forca_dose, "Tab_14_forca_da_dose_resposta")

message("\n--- Dose-resposta: relações mais fortes por grupo ---")
print(as.data.frame(forca_dose %>%
                    filter(separado) %>%
                    group_by(grupo) %>%
                    slice_max(razao_extremo, n = 3) %>%
                    ungroup() %>%
                    mutate(p_base = round(100 * p_base, 2),
                           p_extremo = round(100 * p_extremo, 2),
                           razao_extremo = round(razao_extremo, 1)) %>%
                    select(grupo, rotulo, p_base, p_extremo,
                           razao_extremo)), right = FALSE)

######@> Figura 08 - as três curvas que estruturam a análise...
## Uma curva por grupo, com a variável climática que a sondagem
## identificou como seu motor: precipitação para o hidrológico, vento
## para o meteorológico e precipitação acumulada em três meses para o
## climatológico - este último com a curva DESCENDENTE, porque o motor
## é a falta de chuva.
pares_destaque <- tribble(
    ~grupo,          ~variavel,
    "Hidrológico",   "era5_tp_mm_mes",
    "Meteorológico", "era5_si10",
    "Climatológico", "tp_3m")

dados_f08 <- dose_todas %>%
    inner_join(pares_destaque, by = c("grupo", "variavel")) %>%
    mutate(painel = paste0(grupo, "\n(", rotulo, ")"),
           painel = factor(painel, levels = unique(painel)))

f08 <- ggplot(dados_f08, aes(x = faixa, y = 100 * p, group = grupo,
                             colour = grupo, fill = grupo)) +
    geom_ribbon(aes(ymin = 100 * ic_inf, ymax = 100 * ic_sup),
                alpha = 0.18, colour = NA) +
    geom_line(linewidth = 0.9) +
    geom_point(size = 2.2) +
    geom_text(aes(label = sprintf("%.1f", 100 * p)), vjust = -1.1,
              size = 2.7, colour = "grey25", show.legend = FALSE) +
    facet_wrap(~ painel, ncol = 3, scales = "free_y") +
    scale_colour_manual(values = cores_grupo, guide = "none") +
    scale_fill_manual(values = cores_grupo, guide = "none") +
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.18))) +
    labs(title = "Cada grupo de desastre responde a um motor distinto",
         subtitle = paste("Probabilidade de ao menos um registro no",
                          "mês, por faixa de percentil climático local"),
         x = "Faixa de percentil local da variável climática",
         y = "Probabilidade de ocorrência (%)",
         caption = quebrar(paste(
             "A faixa sombreada é o intervalo de confiança de Wilson a",
             "95%. O percentil é calculado DENTRO de cada município e",
             "de cada mês do ano, de modo que a curva mede anomalia e",
             "não geografia. O grupo climatológico aparece com a",
             "precipitação acumulada em três meses porque estiagem é",
             "fenômeno de acumulação: sua curva é DESCENDENTE - a",
             "probabilidade cai quando chove -, e é o único grupo com",
             "essa direção.")))

salvar_fig(f08, "Fig_08_dose_resposta_por_grupo", 13, 6)

######@> Figura 09 - triagem: que variável importa para que grupo...
dados_f09 <- forca_dose %>%
    filter(grupo != "Todos") %>%
    ## O piso e o teto existem apenas para a ESCALA DE COR: a razão
    ## vale zero quando não há um único evento na faixa extrema (caso
    ## de vários pares sem relação), e o logaritmo de zero é infinito.
    ## O rótulo impresso continua sendo o valor real.
    mutate(rotulo = factor(rotulo, levels = rev(dic_clima$rotulo)),
           razao_limitada = pmin(pmax(razao_extremo, 0.05), 25),
           marcador = ifelse(separado, "*", ""))

f09 <- ggplot(dados_f09, aes(x = grupo, y = rotulo,
                             fill = razao_limitada)) +
    geom_tile(colour = "white", linewidth = 0.4) +
    geom_text(aes(label = paste0(sprintf("%.1f", razao_extremo),
                                 marcador)),
              size = 2.9, colour = "grey15") +
    scale_fill_gradientn(colours = c("grey96", "#FDD49E", "#FC8D59",
                                     "#D7301F"),
                         trans = "log10",
                         name = "Razão de probabilidade\n(extremo / base)") +
    labs(title = "Triagem: qual variável importa para qual grupo",
         subtitle = paste("Razão entre a probabilidade na faixa",
                          "superior de percentil e na faixa de",
                          "referência"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "O asterisco marca as relações em que os intervalos de",
             "confiança das duas faixas não se sobrepõem - o critério",
             "conservador adotado aqui para dizer que a relação existe.",
             "Valores próximos de 1 indicam ausência de relação;",
             "valores abaixo de 1 indicam relação INVERSA, caso das",
             "variáveis hídricas no grupo climatológico. A leitura por",
             "coluna dá o conjunto de candidatos a preditor de cada",
             "grupo."))) +
    theme(axis.text.y = element_text(size = 8),
          legend.key.width = unit(1.4, "cm"))

salvar_fig(f09, "Fig_09_triagem_dose_resposta", 10, 7)

######@> Figura 10 - a forma contínua da relação...
## As faixas da Figura 08 são um resumo; esta figura mostra a relação
## sem discretizar, ajustando uma regressão logística sobre o percentil.
## As duas leituras precisam concordar - e concordam.
dados_f10 <- mensal %>%
    select(era5_tp_mm_mes_p, era5_si10_p, tp_3m_p,
           atlas_n_eventos_hidrologico, atlas_n_eventos_meteorologico,
           atlas_n_eventos_climatologico) %>%
    transmute(`Hidrológico ~ precipitação` = era5_tp_mm_mes_p,
              `Meteorológico ~ vento` = era5_si10_p,
              `Climatológico ~ chuva de 3 meses` = tp_3m_p,
              hid = as.integer(atlas_n_eventos_hidrologico > 0),
              met = as.integer(atlas_n_eventos_meteorologico > 0),
              cli = as.integer(atlas_n_eventos_climatologico > 0)) %>%
    pivot_longer(1:3, names_to = "relacao", values_to = "percentil") %>%
    mutate(ocorrencia = case_when(
               relacao == "Hidrológico ~ precipitação" ~ hid,
               relacao == "Meteorológico ~ vento" ~ met,
               TRUE ~ cli),
           grupo = case_when(
               relacao == "Hidrológico ~ precipitação" ~ "Hidrológico",
               relacao == "Meteorológico ~ vento" ~ "Meteorológico",
               TRUE ~ "Climatológico"),
           grupo = factor(grupo, levels = ordem_grupos)) %>%
    filter(!is.na(percentil))

## A resposta entra no ajuste em 0/1 - exigência da família binomial -
## e é o EIXO que converte para percentual; multiplicar a resposta por
## 100 antes do ajuste faria o modelo recusar os dados.
f10 <- ggplot(dados_f10, aes(x = percentil, y = ocorrencia,
                             colour = grupo, fill = grupo)) +
    geom_smooth(method = "glm", formula = y ~ x,
                method.args = list(family = "quasibinomial"),
                se = TRUE, alpha = 0.18, linewidth = 0.9) +
    facet_wrap(~ relacao, ncol = 3, scales = "free_y") +
    scale_colour_manual(values = cores_grupo, guide = "none") +
    scale_fill_manual(values = cores_grupo, guide = "none") +
    scale_x_continuous(labels = percent_format(accuracy = 1)) +
    scale_y_continuous(labels = percent_format(accuracy = 1)) +
    labs(title = "A relação também aparece sem discretizar",
         subtitle = paste("Regressão logística da ocorrência sobre o",
                          "percentil climático local"),
         x = "Percentil local da variável climática",
         y = "Probabilidade ajustada (%)",
         caption = quebrar(paste(
             "As curvas usam família quase-binomial, que acomoda a",
             "dispersão extra das ocorrências raras. A concordância com",
             "a Figura 08 - construída por faixas, sem qualquer",
             "modelo - é o que autoriza tratar a relação como real e",
             "não como artefato do agrupamento em faixas.")))

salvar_fig(f10, "Fig_10_dose_resposta_continua", 12, 5)

########################################################################
######@> Etapa 07 - Extremos climáticos e desastres...

######@> Taxa condicional em meses extremos...
## A dose-resposta da Etapa 06 mostrou que a probabilidade sobe com o
## percentil. Esta etapa responde à pergunta complementar, e mais
## importante para a gestão: dos desastres que efetivamente ocorreram,
## quantos aconteceram em meses climaticamente extremos?
##
## As duas respostas não são a mesma. Uma condição pode multiplicar por
## três o risco e ainda assim responder por uma fração pequena dos
## eventos, se for rara - que é exatamente o caso aqui.
tipos_extremo <- tribble(
    ~tipo,                    ~coluna,
    "Chuva extrema (> p95)",  "mes_extremo_chuva",
    "Vento extremo (> p95)",  "mes_extremo_vento",
    "Seca extrema (< p5)",    "mes_extremo_seco")

extremos_resumo <- pmap_dfr(tipos_extremo, function(tipo, coluna) {
    d <- mensal %>% mutate(extremo = .data[[coluna]])
    total_eventos <- sum(d$atlas_n_eventos)
    d %>%
        group_by(extremo) %>%
        summarise(meses = n(),
                  ocorrencias = sum(atlas_n_eventos > 0),
                  eventos = sum(atlas_n_eventos),
                  .groups = "drop") %>%
        mutate(tipo = tipo,
               p_ocorrencia = 100 * ocorrencias / meses,
               pct_dos_eventos = 100 * eventos / total_eventos)
})

extremos_sintese <- extremos_resumo %>%
    group_by(tipo) %>%
    summarise(meses_extremos = meses[extremo],
              pct_meses = 100 * meses[extremo] / sum(meses),
              p_com_extremo = p_ocorrencia[extremo],
              p_sem_extremo = p_ocorrencia[!extremo],
              razao = p_ocorrencia[extremo] / p_ocorrencia[!extremo],
              pct_eventos_no_extremo = pct_dos_eventos[extremo],
              .groups = "drop")

tabelas[["Tab_15_extremos"]] <- salvar_tab(
    extremos_sintese, "Tab_15_extremos_e_desastres")

message("\n--- Extremos climáticos e desastres ---")
print(as.data.frame(extremos_sintese %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 2)))), right = FALSE)

######@> Meses compostos: chuva e vento extremos ao mesmo tempo...
## Eventos compostos são o objeto de uma literatura própria em clima e
## desastres, e a base permite uma primeira medida: a probabilidade de
## desastre quando as duas condições ocorrem juntas é maior do que a
## soma do que cada uma produz isoladamente?
compostos <- mensal %>%
    mutate(condicao = case_when(
               mes_extremo_chuva & mes_extremo_vento ~
                   "Chuva e vento extremos",
               mes_extremo_chuva ~ "Só chuva extrema",
               mes_extremo_vento ~ "Só vento extremo",
               TRUE ~ "Nenhum extremo"),
           condicao = factor(condicao,
                             levels = c("Nenhum extremo",
                                        "Só vento extremo",
                                        "Só chuva extrema",
                                        "Chuva e vento extremos"))) %>%
    group_by(condicao) %>%
    summarise(meses = n(),
              ocorrencias = sum(atlas_n_eventos > 0),
              eventos = sum(atlas_n_eventos),
              hidrologicos = sum(atlas_n_eventos_hidrologico),
              meteorologicos = sum(atlas_n_eventos_meteorologico),
              .groups = "drop") %>%
    bind_cols(ic_wilson(.$ocorrencias, .$meses)) %>%
    mutate(razao_vs_base = p / p[1])

tabelas[["Tab_16_compostos"]] <- salvar_tab(
    compostos, "Tab_16_extremos_compostos")

######@> Figura 11 - extremos: risco alto, frequência baixa...
g11a <- extremos_sintese %>%
    mutate(tipo = factor(tipo, levels = rev(tipo))) %>%
    select(tipo, `Em meses extremos` = p_com_extremo,
           `Nos demais meses` = p_sem_extremo) %>%
    pivot_longer(-tipo, names_to = "condicao", values_to = "p") %>%
    ggplot(aes(x = p, y = tipo, fill = condicao)) +
    geom_col(position = position_dodge(width = 0.75), width = 0.68) +
    geom_text(aes(label = sprintf("%.1f%%", p)),
              position = position_dodge(width = 0.75), hjust = -0.15,
              size = 2.8, colour = "grey25") +
    scale_fill_manual(values = c("Em meses extremos" = "#D55E00",
                                 "Nos demais meses" = "grey70"),
                      name = NULL) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.22))) +
    labs(subtitle = "Probabilidade de desastre no mês",
         x = "% dos meses com ao menos um registro", y = NULL)

g11b <- extremos_sintese %>%
    mutate(tipo = factor(tipo, levels = rev(tipo))) %>%
    ggplot(aes(x = pct_eventos_no_extremo, y = tipo)) +
    geom_col(fill = "#0072B2", width = 0.68) +
    geom_text(aes(label = sprintf("%.1f%%", pct_eventos_no_extremo)),
              hjust = -0.15, size = 2.8, colour = "grey25") +
    scale_x_continuous(expand = expansion(mult = c(0, 0.25))) +
    labs(subtitle = "Participação no total de desastres",
         x = "% dos eventos ocorridos nesses meses", y = NULL) +
    theme(axis.text.y = element_blank(), axis.ticks.y = element_blank())

f11 <- (g11a | g11b) +
    plot_layout(widths = c(1.35, 1)) +
    plot_annotation(
        title = "Os extremos multiplicam o risco, mas não explicam o total",
        subtitle = paste("Meses climaticamente extremos definidos pelo",
                         "percentil local (5% mais extremos)"),
        caption = quebrar(paste0(
            "Um mês de chuva extrema tem probabilidade de desastre ",
            sprintf("%.1f", extremos_sintese$razao[1]),
            " vezes maior que os demais - mas, por serem apenas 5% dos",
            " meses, esses episódios concentram somente ",
            sprintf("%.0f%%", extremos_sintese$pct_eventos_no_extremo[1]),
            " dos registros. A maior parte dos desastres ocorre em",
            " meses de chuva ORDINÁRIA, o que desloca parte da",
            " explicação do gatilho meteorológico para a",
            " vulnerabilidade do território.")))

salvar_fig(f11, "Fig_11_extremos_e_desastres", 12, 5)

######@> Figura 12 - efeito composto...
f12 <- ggplot(compostos, aes(x = condicao, y = 100 * p)) +
    geom_col(aes(fill = condicao), width = 0.7) +
    geom_errorbar(aes(ymin = 100 * ic_inf, ymax = 100 * ic_sup),
                  width = 0.15, colour = "grey30") +
    geom_text(aes(label = paste0(sprintf("%.1f%%", 100 * p), "\n(n = ",
                                 fmt_int(meses), ")")),
              vjust = -0.45, size = 2.9, colour = "grey25") +
    scale_fill_manual(values = c("Nenhum extremo" = "grey75",
                                 "Só vento extremo" = "#E69F00",
                                 "Só chuva extrema" = "#0072B2",
                                 "Chuva e vento extremos" = "#D55E00"),
                      guide = "none") +
    scale_y_continuous(expand = expansion(mult = c(0, 0.28))) +
    labs(title = "Quando chuva e vento extremos coincidem",
         subtitle = paste("Probabilidade de ao menos um registro de",
                          "desastre no mês, por condição climática"),
         x = NULL, y = "Probabilidade de ocorrência (%)",
         caption = quebrar(paste(
             "As barras de erro são intervalos de Wilson a 95%. A",
             "coincidência das duas condições é rara - poucas dezenas",
             "de município-meses em 14.700 -, e por isso seu intervalo",
             "é largo; a leitura correta é de INDICAÇÃO de efeito",
             "composto, não de estimativa precisa. A comparação",
             "informativa é entre as barras intermediárias: chuva",
             "extrema isolada eleva mais o risco do que vento extremo",
             "isolado, coerente com o predomínio dos registros",
             "hidrológicos.")))

salvar_fig(f12, "Fig_12_extremos_compostos", 10, 6)

########################################################################
######@> Etapa 08 - Estrutura temporal: ACF, PACF e defasagens...

######@> As três versões da série do litoral...
## A série bruta, a série sem sazonalidade e a série sem sazonalidade e
## sem tendência. Comparar as três é o que separa memória verdadeira de
## ciclo anual e de tendência de registro - e, neste caso, mostra que
## quase toda a estrutura aparente é a segunda e a terceira.
serie_litoral <- litoral_mensal %>%
    arrange(data) %>%
    group_by(mes) %>%
    mutate(sem_sazonalidade = n_eventos - mean(n_eventos)) %>%
    ungroup() %>%
    mutate(tempo = row_number(),
           sem_tendencia = residuals(lm(sem_sazonalidade ~ tempo)))

versoes_serie <- list(
    "Série bruta" = serie_litoral$n_eventos,
    "Sem sazonalidade" = serie_litoral$sem_sazonalidade,
    "Sem sazonalidade e sem tendência" = serie_litoral$sem_tendencia)

diagnostico_temporal <- map_dfr(names(versoes_serie), function(nome) {
    diagnosticar_serie(versoes_serie[[nome]]) %>%
        mutate(versao = nome, .before = 1)
})

tabelas[["Tab_17_diagnostico_temporal"]] <- salvar_tab(
    diagnostico_temporal, "Tab_17_diagnostico_da_serie_de_desastres")

message("\n--- Estrutura temporal da série do litoral ---")
print(as.data.frame(diagnostico_temporal %>%
                    select(versao, acf1, acf_sazonal, ljung_box_p,
                           estacionaria) %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 3)))), right = FALSE)

######@> Correlogramas das três versões...
correlogramas <- map_dfr(names(versoes_serie), function(nome) {
    bind_rows(
        calcular_correlograma(versoes_serie[[nome]], lag_max_mensal,
                              "ACF"),
        calcular_correlograma(versoes_serie[[nome]], lag_max_mensal,
                              "PACF")) %>%
        mutate(versao = factor(nome, levels = names(versoes_serie)))
})

tabelas[["Tab_18_correlogramas"]] <- salvar_tab(
    correlogramas %>% select(versao, tipo, lag, valor, ic),
    "Tab_18_correlogramas_da_serie")

######@> Figura 13 - a memória aparente é sazonalidade e tendência...
f13 <- ggplot(correlogramas, aes(x = lag, y = valor)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_hline(aes(yintercept = ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_hline(aes(yintercept = -ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_segment(aes(xend = lag, yend = 0), linewidth = 0.55,
                 colour = "grey25") +
    geom_point(size = 0.9, colour = "grey15") +
    facet_grid(tipo ~ versao) +
    scale_x_continuous(breaks = seq(0, lag_max_mensal, 6)) +
    labs(title = "Quase toda a estrutura temporal é sazonalidade e registro",
         subtitle = paste("Correlogramas da contagem mensal de",
                          "desastres no litoral"),
         x = "Defasagem (meses)", y = NULL,
         caption = quebrar(paste0(
             "Na série bruta a ACF de lag 1 é ",
             sprintf("%.3f", diagnostico_temporal$acf1[1]),
             " e permanece positiva em todas as defasagens até 24",
             " meses, o que sugeriria memória longa. Removida a",
             " sazonalidade e, sobretudo, a tendência de registro",
             " documentada na Etapa 04, ela cai para ",
             sprintf("%.3f", diagnostico_temporal$acf1[3]),
             " e as demais defasagens tornam-se indistinguíveis de",
             " zero. Não há memória relevante a modelar na série de",
             " desastres: o que existia era artefato.")))

salvar_fig(f13, "Fig_13_correlogramas_da_resposta", 12, 7)

######@> Correlação cruzada entre clima e desastres...
## A pergunta: o clima de um mês informa sobre o desastre de qual mês?
## Defasagem NEGATIVA significa que a variável climática ANTECEDE a
## contagem de eventos; defasagem zero, que são contemporâneos.
##
## A convenção de sinal de ccf() é a fonte de erro mais comum nesta
## análise, e por isso está declarada aqui: em ccf(x, y), o coeficiente
## na defasagem k é a correlação entre x[t + k] e y[t]. Um pico em k
## negativo significa que x precede y.
vars_ccf <- c("era5_tp_mm_mes", "era5_si10", "era5_t2m_C", "tp_3m")

ccf_litoral <- map_dfr(vars_ccf, function(v) {
    correlacao_cruzada(litoral_mensal[[v]], litoral_mensal$n_eventos,
                       lag_ccf, rotulo = v)
}) %>%
    left_join(dic_clima %>% select(variavel, rotulo),
              by = c("serie" = "variavel")) %>%
    mutate(rotulo = factor(rotulo, levels = dic_clima$rotulo[
               match(vars_ccf, dic_clima$variavel)]))

ccf_grupo <- map_dfr(ordem_grupos, function(g) {
    serie_g <- litoral_mensal_grupo %>%
        filter(grupo == g) %>%
        arrange(data)
    map_dfr(c("era5_tp_mm_mes", "era5_si10"), function(v) {
        correlacao_cruzada(litoral_mensal[[v]], serie_g$n_eventos,
                           lag_ccf, rotulo = v) %>%
            mutate(grupo = g)
    })
}) %>%
    mutate(grupo = factor(grupo, levels = ordem_grupos),
           rotulo = ifelse(serie == "era5_tp_mm_mes", "Precipitação",
                           "Vento"))

pico_ccf <- ccf_litoral %>%
    group_by(rotulo) %>%
    slice_max(abs(valor), n = 1) %>%
    ungroup() %>%
    select(rotulo, lag_pico = lag, correlacao = valor, ic)

tabelas[["Tab_19_ccf"]] <- salvar_tab(
    ccf_litoral %>% select(serie, rotulo, lag, valor, ic),
    "Tab_19_correlacao_cruzada")
tabelas[["Tab_20_pico_ccf"]] <- salvar_tab(
    pico_ccf, "Tab_20_pico_da_correlacao_cruzada")

message("\nPico da correlação cruzada (clima x desastres):")
print(as.data.frame(pico_ccf %>%
                    mutate(correlacao = round(correlacao, 3))),
      right = FALSE)

######@> Figura 14 - a relação é contemporânea...
f14 <- ggplot(ccf_litoral, aes(x = lag, y = valor)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_hline(aes(yintercept = ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_hline(aes(yintercept = -ic), linetype = "dashed",
               colour = "#0072B2", linewidth = 0.35) +
    geom_vline(xintercept = 0, colour = "#D55E00", linewidth = 0.4) +
    geom_segment(aes(xend = lag, yend = 0), linewidth = 0.6,
                 colour = "grey25") +
    geom_point(size = 1.1, colour = "grey15") +
    facet_wrap(~ rotulo, ncol = 2) +
    scale_x_continuous(breaks = seq(-lag_ccf, lag_ccf, 4)) +
    labs(title = "O clima e o desastre são contemporâneos",
         subtitle = paste("Correlação cruzada entre a variável",
                          "climática e a contagem mensal de eventos"),
         x = "Defasagem (meses; negativa = clima antecede o desastre)",
         y = "Correlação cruzada",
         caption = quebrar(paste0(
             "A linha vertical marca a defasagem zero. A precipitação",
             " tem pico exatamente ali (",
             sprintf("%.3f", pico_ccf$correlacao[
                 pico_ccf$rotulo == "Precipitação total"]),
             "), e todas as defasagens de um a doze meses ficam",
             " próximas do limite de significância. Na escala mensal",
             " não há memória a explorar: o mês é a unidade temporal",
             " correta e termos defasados de precipitação não",
             " encontram respaldo. Processos de acumulação",
             " sub-mensais - três dias de chuva que saturam o solo -",
             " existem, mas ESTA base, agregada por mês, não os",
             " resolve.")))

salvar_fig(f14, "Fig_14_correlacao_cruzada", 11, 7)

######@> Figura 15 - a defasagem por grupo...
f15 <- ggplot(ccf_grupo, aes(x = lag, y = valor, colour = grupo)) +
    geom_hline(yintercept = 0, colour = "grey40") +
    geom_hline(aes(yintercept = ic), linetype = "dashed",
               colour = "grey60", linewidth = 0.3) +
    geom_hline(aes(yintercept = -ic), linetype = "dashed",
               colour = "grey60", linewidth = 0.3) +
    geom_vline(xintercept = 0, colour = "grey30", linewidth = 0.3) +
    geom_line(linewidth = 0.8) +
    geom_point(size = 1) +
    facet_grid(rotulo ~ grupo) +
    scale_colour_manual(values = cores_grupo, guide = "none") +
    scale_x_continuous(breaks = seq(-lag_ccf, lag_ccf, 6)) +
    labs(title = "Cada grupo responde à sua variável, e no mesmo mês",
         subtitle = paste("Correlação cruzada por grupo de desastre e",
                          "variável climática"),
         x = "Defasagem (meses)", y = "Correlação cruzada",
         caption = quebrar(paste(
             "A leitura por linha confirma a triagem da Etapa 06: o",
             "grupo hidrológico responde à precipitação e o",
             "meteorológico ao vento, ambos em defasagem zero. Onde a",
             "curva permanece dentro das linhas tracejadas não há",
             "associação detectável em nenhuma defasagem - caso da",
             "precipitação no grupo meteorológico.")))

salvar_fig(f15, "Fig_15_ccf_por_grupo", 12, 6)

########################################################################
######@> Etapa 09 - Tendência: desastres e clima lado a lado...

######@> Séries anuais candidatas...
## O teste é o mesmo aplicado nas AEDs anteriores - Mann-Kendall com
## declividade de Sen -, mas a leitura aqui é COMPARATIVA: o objetivo
## não é saber se os desastres aumentaram, e sim se o que aumentou nos
## desastres tem contrapartida no clima.
series_tendencia <- bind_rows(
    tibble(serie = "Registros de desastre (total)",
           bloco = "Desastres", ano = litoral_anual$ano,
           valor = litoral_anual$n_eventos),
    litoral_mensal_grupo %>%
        group_by(grupo, ano) %>%
        summarise(valor = sum(n_eventos), .groups = "drop") %>%
        transmute(serie = paste0("Registros - ", grupo),
                  bloco = "Desastres", ano, valor),
    tibble(serie = "Município-meses de chuva extrema",
           bloco = "Extremos", ano = serie_registro$ano,
           valor = serie_registro$meses_extremos_chuva),
    tibble(serie = "Município-meses de vento extremo",
           bloco = "Extremos", ano = serie_registro$ano,
           valor = serie_registro$meses_extremos_vento),
    litoral_anual %>%
        select(ano, all_of(dic_clima$variavel)) %>%
        pivot_longer(-ano, names_to = "variavel", values_to = "valor") %>%
        left_join(dic_clima, by = "variavel") %>%
        transmute(serie = rotulo, bloco = "Clima", ano, valor))

tendencias <- series_tendencia %>%
    group_by(serie, bloco) %>%
    group_modify(~ {
        mk <- mann_kendall(.x$valor)
        tibble(tau = mk$tau, p_valor = mk$p_valor,
               sen_por_decada = 10 * declividade_sen(.x$valor, .x$ano),
               valor_inicial = .x$valor[which.min(.x$ano)],
               valor_final = .x$valor[which.max(.x$ano)])
    }) %>%
    ungroup() %>%
    mutate(resultado = case_when(
               is.na(p_valor) ~ "Indefinido",
               p_valor >= alfa ~ "Sem tendência detectada",
               tau > 0 ~ "Crescente",
               TRUE ~ "Decrescente"),
           bloco = factor(bloco, levels = c("Desastres", "Extremos",
                                            "Clima"))) %>%
    arrange(bloco, desc(tau))

tabelas[["Tab_21_tendencias"]] <- salvar_tab(
    tendencias, "Tab_21_tendencias_comparadas")

message("\n--- Tendências: desastres x extremos x clima ---")
print(as.data.frame(tendencias %>%
                    select(bloco, serie, tau, p_valor, resultado) %>%
                    mutate(tau = round(tau, 3),
                           p_valor = signif(p_valor, 3))),
      right = FALSE)

######@> Figura 16 - o contraste que organiza a leitura...
f16 <- tendencias %>%
    mutate(serie = factor(serie, levels = rev(serie))) %>%
    ggplot(aes(x = tau, y = serie, fill = resultado)) +
    geom_col(width = 0.72) +
    geom_vline(xintercept = 0, colour = "grey30") +
    geom_text(aes(label = ifelse(p_valor < alfa, "*", "")),
              hjust = ifelse(tendencias$tau > 0, -0.4, 1.4),
              size = 4, colour = "grey25") +
    facet_grid(bloco ~ ., scales = "free_y", space = "free_y") +
    scale_fill_manual(values = c("Crescente" = "#D55E00",
                                 "Decrescente" = "#0072B2",
                                 "Sem tendência detectada" = "grey72"),
                      name = NULL) +
    scale_x_continuous(limits = c(-1, 1)) +
    labs(title = "O que cresce é o registro, não o gatilho climático",
         subtitle = paste0("Tau de Mann-Kendall das séries anuais do ",
                           "litoral, ", ano_ini_atlas, "-",
                           ano_fim_atlas, "; * = p < 0,05"),
         x = "Tau de Kendall", y = NULL,
         caption = quebrar(paste(
             "Os três blocos usam o mesmo teste e a mesma janela. As",
             "séries de desastre sobem de modo consistente; as de",
             "extremos climáticos não sobem; entre as variáveis",
             "climáticas, a tendência significativa é térmica e",
             "radiativa - coerente com a AED do ERA5 -, e não hídrica.",
             "Atribuir o crescimento dos registros à intensificação da",
             "chuva não encontra respaldo nesta base.")))

salvar_fig(f16, "Fig_16_tendencias_comparadas", 11, 9)

########################################################################
######@> Etapa 10 - Padrões municipais e tamanho amostral...

######@> Perfil de cada município...
perfil_municipio <- mensal %>%
    group_by(geocodigo, municipio) %>%
    summarise(eventos = sum(atlas_n_eventos),
              meses_com_evento = sum(atlas_n_eventos > 0),
              pct_meses_com_evento = 100 * mean(atlas_n_eventos > 0),
              anos_com_evento = n_distinct(ano[atlas_n_eventos > 0]),
              mortos = sum(atlas_dh_mortos),
              afetados = sum(atlas_dh_afetados_total),
              impacto = sum(atlas_impacto_economico_total),
              hidrologicos = sum(atlas_n_eventos_hidrologico),
              meteorologicos = sum(atlas_n_eventos_meteorologico),
              climatologicos = sum(atlas_n_eventos_climatologico),
              precipitacao_media = mean(era5_tp_mm_mes),
              vento_medio = mean(era5_si10),
              temperatura_media = mean(era5_t2m_C),
              .groups = "drop") %>%
    left_join(municipios %>%
                  select(geocodigo, area_km2 = area_km2_shape,
                         latitude = lat_centroide,
                         longitude = lon_centroide),
              by = "geocodigo") %>%
    left_join(anual %>%
                  filter(ano == ano_fim_terra) %>%
                  select(geocodigo,
                         urbano_ha = mapb_urb_area_ha,
                         urbano_pct = mapb_urb_pct_area,
                         floresta_pct = mapb_cob_n1_floresta_pct,
                         nao_vegetada_pct =
                             mapb_cob_n1_area_nao_vegetada_pct,
                         risco_ha = mapb_risco_total_ha),
              by = "geocodigo") %>%
    mutate(eventos_por_decada = eventos / (n_anos / 10),
           eventos_por_mil_km2 = 1000 * eventos / area_km2,
           grupo_predominante = case_when(
               hidrologicos >= meteorologicos &
               hidrologicos >= climatologicos ~ "Hidrológico",
               meteorologicos >= climatologicos ~ "Meteorológico",
               TRUE ~ "Climatológico"),
           pct_hidrologico = 100 * hidrologicos / eventos,
           risco_pct_urbano = 100 * risco_ha / pmax(urbano_ha, 1))

######@> Tendência municipal dos registros...
tendencia_municipal <- anual %>%
    group_by(geocodigo, municipio) %>%
    group_modify(~ {
        mk <- mann_kendall(.x$atlas_n_eventos)
        tibble(tau = mk$tau, p_valor = mk$p_valor,
               sen_por_decada = 10 * declividade_sen(
                   .x$atlas_n_eventos, .x$ano))
    }) %>%
    ungroup() %>%
    mutate(resultado = case_when(
               is.na(p_valor) ~ "Indefinido",
               p_valor >= alfa ~ "Sem tendência detectada",
               tau > 0 ~ "Crescente",
               TRUE ~ "Decrescente"))

perfil_municipio <- perfil_municipio %>%
    left_join(tendencia_municipal %>%
                  select(geocodigo, tau_registro = tau,
                         p_registro = p_valor,
                         sen_registro = sen_por_decada,
                         tendencia_registro = resultado),
              by = "geocodigo")

tabelas[["Tab_22_perfil_municipal"]] <- salvar_tab(
    perfil_municipio %>% arrange(desc(eventos)),
    "Tab_22_perfil_municipal")

message("\n--- Tamanho amostral por município ---")
message("Eventos por município  : mínimo ", min(perfil_municipio$eventos),
        ", mediana ", median(perfil_municipio$eventos), ", máximo ",
        max(perfil_municipio$eventos))
message("Municípios com < 20 eventos: ",
        sum(perfil_municipio$eventos < 20), " de ", n_municipios)
message("Municípios com tendência crescente significativa: ",
        sum(perfil_municipio$tendencia_registro == "Crescente"),
        " de ", n_municipios)

######@> Figura 17 - quanto cada município registra...
ordem_f17 <- perfil_municipio %>%
    arrange(eventos) %>%
    pull(municipio)

g17a <- perfil_municipio %>%
    mutate(municipio = factor(municipio, levels = ordem_f17)) %>%
    ggplot(aes(x = eventos, y = municipio)) +
    geom_col(fill = "#D55E00", width = 0.72) +
    geom_vline(xintercept = median(perfil_municipio$eventos),
               linetype = "dashed", colour = "grey35") +
    labs(subtitle = "Registros no período", x = "Eventos", y = NULL) +
    theme(axis.text.y = element_text(size = 7))

g17b <- perfil_municipio %>%
    mutate(municipio = factor(municipio, levels = ordem_f17)) %>%
    ggplot(aes(x = eventos_por_mil_km2, y = municipio)) +
    geom_col(fill = "#0072B2", width = 0.72) +
    labs(subtitle = "Registros por mil km²",
         x = "Eventos / mil km²", y = NULL) +
    theme(axis.text.y = element_blank(), axis.ticks.y = element_blank())

f17 <- (g17a | g17b) +
    plot_layout(widths = c(1.25, 1)) +
    plot_annotation(
        title = "O volume de registros e a densidade contam histórias diferentes",
        subtitle = paste("Municípios ordenados pelo total de registros;",
                         "linha tracejada: mediana"),
        caption = quebrar(paste(
            "Municípios grandes acumulam mais registros simplesmente",
            "por serem grandes - o que a Etapa 11 confirma como o efeito",
            "que sobrevive a todos os controles. Normalizar pela área",
            "inverte parte da ordenação e traz os balneários pequenos",
            "para o topo. Qual das duas leituras é a certa depende da",
            "pergunta: risco por território pede a segunda; carga",
            "administrativa sobre o município, a primeira.")))

salvar_fig(f17, "Fig_17_ranking_municipal", 12, 9)

######@> Figura 18 - composição por grupo em cada município...
dados_f18 <- perfil_municipio %>%
    select(municipio, Hidrológico = hidrologicos,
           Meteorológico = meteorologicos,
           Climatológico = climatologicos) %>%
    mutate(Outros = perfil_municipio$eventos - Hidrológico -
               Meteorológico - Climatológico) %>%
    pivot_longer(-municipio, names_to = "grupo",
                 values_to = "eventos") %>%
    mutate(grupo = factor(grupo, levels = ordem_grupos),
           municipio = factor(municipio,
                              levels = rev(ordem_norte_sul))) %>%
    group_by(municipio) %>%
    mutate(pct = 100 * eventos / sum(eventos)) %>%
    ungroup()

f18 <- ggplot(dados_f18, aes(x = pct, y = municipio, fill = grupo)) +
    geom_col(width = 0.8) +
    scale_fill_manual(values = cores_grupo, name = NULL) +
    scale_x_continuous(expand = c(0, 0)) +
    guides(fill = guide_legend(nrow = 1)) +
    labs(title = "Composição dos registros em cada município",
         subtitle = "Municípios ordenados de norte (topo) a sul",
         x = "% dos registros do município", y = NULL,
         caption = quebrar(paste(
             "O predomínio hidrológico é geral, mas sua participação",
             "varia de menos de metade a mais de três quartos dos",
             "registros. Municípios com participação alta do grupo",
             "meteorológico são candidatos a responder mais ao vento",
             "que à chuva - o que a Etapa 06 já mostrou serem",
             "processos distintos, e que a modelagem precisa separar."))) +
    theme(axis.text.y = element_text(size = 7))

salvar_fig(f18, "Fig_18_composicao_municipal", 10, 9)

########################################################################
######@> Etapa 11 - Uso da terra, exposição e o confundimento espacial...

######@> Correlações brutas e parciais entre municípios...
## A pergunta desta etapa é a mais próxima da pergunta de pesquisa: o
## território explica o desastre? E a resposta exige cuidado, porque no
## litoral catarinense quase tudo se organiza de norte a sul - relevo,
## chuva, floresta, tamanho de município - e uma correlação bruta entre
## dois desses atributos pode ser apenas o gradiente latitudinal visto
## duas vezes.
##
## Cada associação é, por isso, reportada em três versões: bruta,
## controlada por latitude, e controlada por latitude E área.
descritores_municipais <- tribble(
    ~coluna,             ~rotulo,                       ~bloco,
    "floresta_pct",      "Cobertura florestal (%)",     "Uso da terra",
    "urbano_pct",        "Mancha urbana (% da área)",   "Uso da terra",
    "urbano_ha",         "Mancha urbana (ha)",          "Uso da terra",
    "nao_vegetada_pct",  "Área não vegetada (%)",       "Uso da terra",
    "risco_ha",          "Área urbana suscetível (ha)", "Exposição",
    "risco_pct_urbano",  "Fração urbana suscetível (%)", "Exposição",
    "area_km2",          "Área do município (km²)",     "Território",
    "precipitacao_media", "Precipitação média (mm/mês)", "Clima",
    "vento_medio",       "Vento médio (m/s)",           "Clima",
    "temperatura_media", "Temperatura média (°C)",      "Clima",
    "latitude",          "Latitude do centroide",       "Território")

associacoes <- map_dfr(seq_len(nrow(descritores_municipais)),
                       function(i) {
    coluna <- descritores_municipais$coluna[i]
    d <- perfil_municipio %>%
        select(eventos, all_of(coluna), latitude, area_km2) %>%
        na.omit()
    bruta <- cor(d$eventos, d[[coluna]], method = "spearman")
    parcial_lat <- if(coluna == "latitude") NA_real_ else
        correlacao_parcial(d$eventos, d[[coluna]],
                           d %>% select(latitude))
    parcial_lat_area <- if(coluna %in% c("latitude", "area_km2"))
        NA_real_ else
        correlacao_parcial(d$eventos, d[[coluna]],
                           d %>% select(latitude, area_km2))
    tibble(coluna = coluna,
           rotulo = descritores_municipais$rotulo[i],
           bloco = descritores_municipais$bloco[i],
           n = nrow(d),
           correlacao_bruta = bruta,
           parcial_latitude = parcial_lat,
           parcial_latitude_area = parcial_lat_area,
           reducao = abs(bruta) - abs(parcial_lat))
})

tabelas[["Tab_23_associacoes"]] <- salvar_tab(
    associacoes, "Tab_23_associacoes_municipais")

message("\n--- Associações entre municípios (bruta x parcial) ---")
print(as.data.frame(associacoes %>%
                    select(rotulo, correlacao_bruta, parcial_latitude,
                           parcial_latitude_area) %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 3)))), right = FALSE)

######@> Figura 19 - o que sobrevive ao controle da latitude...
dados_f19 <- associacoes %>%
    filter(!is.na(parcial_latitude)) %>%
    mutate(rotulo = factor(rotulo,
                           levels = rev(rotulo[order(correlacao_bruta)])))

f19 <- ggplot(dados_f19) +
    geom_vline(xintercept = 0, colour = "grey40") +
    geom_segment(aes(x = correlacao_bruta, xend = parcial_latitude,
                     y = rotulo, yend = rotulo),
                 colour = "grey65", linewidth = 0.8) +
    geom_point(aes(x = correlacao_bruta, y = rotulo,
                   colour = "Correlação bruta"), size = 2.8) +
    geom_point(aes(x = parcial_latitude, y = rotulo,
                   colour = "Controlada pela latitude"), size = 2.8) +
    ## A área não pode ser controlada por ela mesma: a linha do próprio
    ## descritor territorial fica de fora desta camada, e o filtro
    ## explícito evita um aviso de ponto omitido que pareceria falha.
    geom_point(data = dados_f19 %>% filter(!is.na(parcial_latitude_area)),
               aes(x = parcial_latitude_area, y = rotulo,
                   colour = "Controlada por latitude e área"),
               size = 2.2, shape = 17) +
    scale_colour_manual(values = c("Correlação bruta" = "#D55E00",
                                   "Controlada pela latitude" = "#0072B2",
                                   "Controlada por latitude e área" =
                                       "#009E73"),
                        name = NULL) +
    guides(colour = guide_legend(nrow = 1)) +
    labs(title = "A latitude confunde quase todas as associações",
         subtitle = paste("Correlação de Spearman com o número de",
                          "registros de desastre por município"),
         x = "Correlação", y = NULL,
         caption = quebrar(paste0(
             "A cobertura florestal aparece associada a desastres com",
             " correlação bruta de ",
             sprintf("%.2f", associacoes$correlacao_bruta[
                 associacoes$coluna == "floresta_pct"]),
             " - o que seria absurdo interpretar como causa. Ao",
             " controlar a posição no litoral, a associação cai para ",
             sprintf("%.2f", associacoes$parcial_latitude[
                 associacoes$coluna == "floresta_pct"]),
             ": o litoral norte concentra simultaneamente mais",
             " floresta, mais relevo, mais chuva e mais registros. O",
             " que sobrevive aos controles é a ÁREA do município e,",
             " com sinal NEGATIVO, a fração urbanizada.")))

salvar_fig(f19, "Fig_19_associacoes_municipais", 11, 7)

######@> Figura 20 - o efeito de exposição...
## A relação mais robusta da etapa merece figura própria, porque tem
## consequência direta de modelagem: se o número de registros cresce
## com o tamanho do município, o modelo precisa de um termo de
## exposição - offset de área ou de população - para não confundir
## território com risco.
ajuste_area <- lm(log10(eventos) ~ log10(area_km2),
                  data = perfil_municipio)

f20 <- ggplot(perfil_municipio, aes(x = area_km2, y = eventos)) +
    geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
                colour = "#D55E00", fill = "#D55E00", alpha = 0.12,
                linewidth = 0.7) +
    geom_point(aes(size = urbano_pct, colour = latitude), alpha = 0.85) +
    geom_text(aes(label = municipio), size = 2.3, vjust = -1.1,
              colour = "grey35", check_overlap = TRUE) +
    scale_x_continuous(trans = "log10", labels = fmt_int) +
    scale_y_continuous(trans = "log10") +
    scale_colour_viridis_c(option = "viridis", name = "Latitude") +
    scale_size_continuous(name = "Urbanizado (%)", range = c(1.5, 5)) +
    labs(title = "Municípios maiores registram mais desastres",
         subtitle = paste0("Escalas logarítmicas; inclinação = ",
                           sprintf("%.2f",
                                   coef(ajuste_area)[2]),
                           " (R² = ",
                           sprintf("%.2f",
                                   summary(ajuste_area)$r.squared),
                           ")"),
         x = "Área do município (km²)",
         y = "Registros de desastre",
         caption = quebrar(paste(
             "A inclinação abaixo de 1 em escala log-log indica",
             "retorno decrescente: dobrar a área não dobra o número de",
             "registros. A consequência prática é direta - modelos de",
             "contagem sobre estes dados precisam de um termo de",
             "exposição (offset de área, de população ou de mancha",
             "urbana), sob pena de atribuir a municípios grandes um",
             "risco que é apenas tamanho.")))

salvar_fig(f20, "Fig_20_efeito_de_exposicao", 11, 7)

########################################################################
######@> Etapa 12 - Painéis diagnósticos por município...

######@> Construção de um painel por município...
## Cada arquivo reúne, para um município: (a) a série anual de
## registros por grupo; (b) a série mensal com os meses climaticamente
## extremos assinalados; (c) a dose-resposta local; (d) a ACF e (e) a
## PACF da série mensal. É o material de consulta individual - 35
## arquivos, um por município.
##
## Ressalva que atravessa todos eles: com mediana de 28 eventos em 420
## meses, as curvas municipais são ruidosas. Devem ser lidas como
## verificação de que o padrão agregado não é produzido por poucos
## municípios, e não como estimativa municipal confiável.
message("\nGerando painéis por município...")

diagnostico_municipal <- vector("list", n_municipios)

for(i in seq_along(municipios_nomes)) {
    mun <- municipios_nomes[i]
    dados_mun <- mensal %>% filter(municipio == mun) %>% arrange(data)
    dados_ano <- anual %>% filter(municipio == mun) %>% arrange(ano)
    dados_grupo <- eventos_grupo %>%
        filter(municipio == mun) %>%
        group_by(ano, grupo) %>%
        summarise(n_eventos = sum(n_eventos), .groups = "drop")
    geo <- unique(dados_mun$geocodigo)
    perfil_mun <- perfil_municipio %>% filter(geocodigo == geo)

    ## (a) Série anual por grupo
    g1 <- ggplot(dados_grupo, aes(x = ano, y = n_eventos,
                                  fill = grupo)) +
        geom_col(width = 0.85) +
        scale_fill_manual(values = cores_grupo, name = NULL,
                          drop = FALSE) +
        scale_x_continuous(breaks = seq(ano_ini_atlas, ano_fim_atlas,
                                        5)) +
        labs(subtitle = "Registros por ano e grupo", x = NULL,
             y = "Eventos")

    ## (b) Série mensal com os meses extremos assinalados
    g2 <- ggplot(dados_mun, aes(x = data, y = atlas_n_eventos)) +
        geom_col(aes(fill = mes_extremo_chuva), width = 25) +
        scale_fill_manual(values = c("FALSE" = "grey55",
                                     "TRUE" = "#0072B2"),
                          labels = c("Mês comum",
                                     "Chuva extrema (> p95)"),
                          name = NULL) +
        scale_x_date(date_breaks = "5 years", date_labels = "%Y") +
        labs(subtitle = "Registros por mês", x = NULL, y = "Eventos")

    ## (c) Dose-resposta local
    dose_mun <- dose_resposta(
        dados_mun %>%
            select(percentil = era5_tp_mm_mes_p,
                   resposta = atlas_n_eventos) %>%
            filter(!is.na(percentil)),
        "percentil", "resposta")

    g3 <- ggplot(dose_mun, aes(x = faixa, y = 100 * p, group = 1)) +
        geom_ribbon(aes(ymin = 100 * ic_inf, ymax = 100 * ic_sup),
                    alpha = 0.18, fill = "#0072B2") +
        geom_line(colour = "#0072B2", linewidth = 0.8) +
        geom_point(colour = "#0072B2", size = 1.8) +
        labs(subtitle = "Dose-resposta local (precipitação)",
             x = "Faixa de percentil local",
             y = "P(evento) (%)")

    ## (d) e (e) Correlogramas da série mensal
    acf_mun <- calcular_correlograma(dados_mun$atlas_n_eventos,
                                     lag_max_mensal, "ACF")
    pacf_mun <- calcular_correlograma(dados_mun$atlas_n_eventos,
                                      lag_max_mensal, "PACF")
    g4 <- grafico_correlograma(acf_mun, subtitulo = "ACF da série mensal")
    g5 <- grafico_correlograma(pacf_mun,
                               subtitulo = "PACF da série mensal")

    ## Composição do painel
    painel <- (g1 / g2 / g3 / (g4 | g5)) +
        plot_layout(heights = c(1, 1, 1, 1)) +
        plot_annotation(
            title = paste0(mun, " (", geo, ")"),
            subtitle = sprintf(paste("%d registros | %.1f%% dos meses",
                                     "com evento | %s predominante |",
                                     "%.0f mm/mês | %.0f km²"),
                               perfil_mun$eventos,
                               perfil_mun$pct_meses_com_evento,
                               perfil_mun$grupo_predominante,
                               perfil_mun$precipitacao_media,
                               perfil_mun$area_km2),
            caption = quebrar(paste(
                "AED integrada | Barras azuis no painel mensal: meses",
                "de precipitação acima do percentil 95 local.",
                "Correlogramas da série bruta; linhas tracejadas:",
                "limite de significância a 5%. Séries municipais são",
                "ruidosas - ver ressalva na Etapa 12."))) &
        theme(legend.position = "bottom")

    salvar_fig(painel, paste0("Painel_", geo, "_", limpar_nome(mun)),
               10, 14, diretorio = dir_fig_mun)

    ## Diagnóstico numérico do município
    diag_mensal <- diagnosticar_serie(dados_mun$atlas_n_eventos)
    dose_local <- forca <- NA_real_
    if(nrow(dose_mun) > 1) {
        forca <- dose_mun$p[nrow(dose_mun)] / pmax(dose_mun$p[1], 1e-6)
    }
    ccf_mun <- correlacao_cruzada(dados_mun$era5_tp_mm_mes,
                                  dados_mun$atlas_n_eventos, 6)

    diagnostico_municipal[[i]] <- tibble(
        geocodigo = geo, municipio = mun,
        eventos = perfil_mun$eventos,
        pct_meses_com_evento = perfil_mun$pct_meses_com_evento,
        razao_var_media = diag_mensal$razao_var_media,
        acf1 = diag_mensal$acf1,
        ljung_box_p = diag_mensal$ljung_box_p,
        estacionaria = diag_mensal$estacionaria,
        dose_razao_extremo_base = forca,
        cor_contemporanea_chuva = if(nrow(ccf_mun) > 0)
            ccf_mun$valor[ccf_mun$lag == 0] else NA_real_,
        lag_pico_chuva = if(nrow(ccf_mun) > 0)
            ccf_mun$lag[which.max(abs(ccf_mun$valor))] else NA_real_,
        tau_registro = perfil_mun$tau_registro,
        tendencia_registro = perfil_mun$tendencia_registro)
}

diagnostico_municipal <- bind_rows(diagnostico_municipal) %>%
    arrange(desc(eventos))

tabelas[["Tab_24_diag_municipal"]] <- salvar_tab(
    diagnostico_municipal, "Tab_24_diagnostico_municipal")

message("Painéis gerados        : ", n_municipios)
message("Municípios com correlação contemporânea positiva com a chuva: ",
        sum(diagnostico_municipal$cor_contemporanea_chuva > 0,
            na.rm = TRUE), " de ", n_municipios)
message("Municípios com defasagem de pico igual a zero: ",
        sum(diagnostico_municipal$lag_pico_chuva == 0, na.rm = TRUE),
        " de ", n_municipios)

######@> Figura 21 - o padrão agregado vale município a município?
## A verificação de que o resultado central desta AED - relação
## contemporânea entre chuva e desastre - não é produto da agregação.
f21 <- diagnostico_municipal %>%
    mutate(municipio = factor(municipio,
                              levels = municipio[
                                  order(cor_contemporanea_chuva)])) %>%
    ggplot(aes(x = cor_contemporanea_chuva, y = municipio)) +
    geom_vline(xintercept = 0, colour = "grey40") +
    geom_segment(aes(xend = 0, yend = municipio), colour = "grey70",
                 linewidth = 0.4) +
    geom_point(aes(colour = lag_pico_chuva == 0, size = eventos)) +
    scale_colour_manual(values = c("FALSE" = "grey60",
                                   "TRUE" = "#0072B2"),
                        labels = c("Pico em outra defasagem",
                                   "Pico em defasagem zero"),
                        name = NULL) +
    scale_size_continuous(name = "Eventos", range = c(1.2, 4)) +
    labs(title = "A relação contemporânea aparece na maioria dos municípios",
         subtitle = paste("Correlação entre precipitação e contagem de",
                          "eventos no mesmo mês"),
         x = "Correlação contemporânea", y = NULL,
         caption = quebrar(paste(
             "Cada ponto é um município; o tamanho indica quantos",
             "eventos sustentam a estimativa. A concentração à direita",
             "do zero mostra que a associação contemporânea não é",
             "artefato da agregação do litoral. Municípios com poucos",
             "eventos aparecem dispersos - ruído amostral, e não",
             "evidência de comportamento distinto."))) +
    theme(axis.text.y = element_text(size = 7))

salvar_fig(f21, "Fig_21_relacao_por_municipio", 10, 9)

########################################################################
######@> Etapa 13 - Estrutura multivariada e redundância...

######@> Matriz de correlação entre os descritores mensais...
## Sobre as anomalias, e não sobre os valores brutos: a correlação entre
## valores brutos é dominada pela sazonalidade comum - temperatura e
## radiação sobem juntas todo verão -, o que produziria uma matriz que
## descreve o calendário, não a covariação de anomalias.
matriz_anomalias <- mensal %>%
    select(all_of(paste0(dic_clima$variavel, "_anom"))) %>%
    rename_with(~ sub("_anom$", "", .x)) %>%
    select(where(~ sum(!is.na(.x)) > 0))

nomes_matriz <- dic_clima$rotulo[
    match(names(matriz_anomalias), dic_clima$variavel)]

cor_anomalias <- cor(matriz_anomalias, use = "pairwise.complete.obs")
dimnames(cor_anomalias) <- list(nomes_matriz, nomes_matriz)

ordem_cor <- hclust(as.dist(1 - abs(cor_anomalias)),
                    method = "average")$order

dados_f22 <- as.data.frame(as.table(cor_anomalias)) %>%
    setNames(c("var_a", "var_b", "correlacao")) %>%
    mutate(var_a = factor(var_a, levels = nomes_matriz[ordem_cor]),
           var_b = factor(var_b,
                          levels = rev(nomes_matriz[ordem_cor])))

tabelas[["Tab_25_correlacao_clima"]] <- salvar_tab(
    dados_f22 %>% filter(as.integer(var_a) < as.integer(var_b)) %>%
        arrange(desc(abs(correlacao))),
    "Tab_25_correlacao_entre_descritores")

######@> Figura 22 - a redundância entre os descritores climáticos...
f22 <- ggplot(dados_f22, aes(x = var_a, y = var_b, fill = correlacao)) +
    geom_tile(colour = "white", linewidth = 0.4) +
    geom_text(aes(label = sprintf("%.2f", correlacao)), size = 2.4,
              colour = "grey15") +
    scale_fill_gradient2(low = "#B2182B", mid = "grey96",
                         high = "#2166AC", midpoint = 0,
                         limits = c(-1, 1), name = "Correlação") +
    scale_x_discrete(labels = quebrar_rotulo) +
    scale_y_discrete(labels = quebrar_rotulo) +
    labs(title = "Os descritores climáticos são redundantes entre si",
         subtitle = paste("Correlação entre anomalias mensais,",
                          "variáveis ordenadas por similaridade"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "Blocos escuros ao longo da diagonal são conjuntos de",
             "variáveis que carregam a mesma informação: evaporação e",
             "fluxo de calor latente são a MESMA grandeza em unidades",
             "diferentes; precipitação total, chuva convectiva, chuva",
             "de larga escala e água de chuva na coluna medem faces do",
             "mesmo processo. Selecionar uma variável por bloco é",
             "obrigatório antes de qualquer modelo."))) +
    theme(axis.text.x = element_text(size = 7, angle = 45, hjust = 1),
          axis.text.y = element_text(size = 7),
          legend.key.width = unit(1.4, "cm"))

salvar_fig(f22, "Fig_22_correlacao_entre_descritores", 12, 10)

######@> Fator de inflação da variância...
## Mede a colinearidade do conjunto INTEIRO, e não par a par: uma
## variável pode ter correlação modesta com cada uma das demais e ainda
## assim ser quase perfeitamente predita pela combinação delas.
vif_completo <- calcular_vif(matriz_anomalias) %>%
    mutate(rotulo = dic_clima$rotulo[match(variavel,
                                           dic_clima$variavel)],
           situacao = case_when(vif >= 10 ~ "Colinearidade severa",
                                vif >= 5 ~ "Colinearidade preocupante",
                                TRUE ~ "Aceitável"))

######@> Conjunto reduzido sugerido...
## Uma variável por bloco temático, escolhida pela interpretabilidade e
## pela força da dose-resposta da Etapa 06, e não por critério
## automático. O VIF do conjunto reduzido é recalculado para mostrar que
## o problema desaparece.
vars_reduzidas <- c("era5_tp_mm_mes", "era5_si10", "era5_t2m_C",
                    "era5_tcc_pct", "tp_3m")

vif_reduzido <- calcular_vif(
    mensal %>%
        select(all_of(paste0(vars_reduzidas, "_anom"))) %>%
        rename_with(~ sub("_anom$", "", .x))) %>%
    mutate(rotulo = dic_clima$rotulo[match(variavel,
                                           dic_clima$variavel)],
           situacao = case_when(vif >= 10 ~ "Colinearidade severa",
                                vif >= 5 ~ "Colinearidade preocupante",
                                TRUE ~ "Aceitável"))

tabelas[["Tab_26_vif_completo"]] <- salvar_tab(
    vif_completo, "Tab_26_vif_conjunto_completo")
tabelas[["Tab_27_vif_reduzido"]] <- salvar_tab(
    vif_reduzido, "Tab_27_vif_conjunto_reduzido")

message("\n--- Colinearidade ---")
message("Conjunto completo (", nrow(vif_completo), " variáveis): VIF ",
        "máximo = ", sprintf("%.1f", max(vif_completo$vif)),
        " | com VIF >= 10: ", sum(vif_completo$vif >= 10))
message("Conjunto reduzido (", nrow(vif_reduzido), " variáveis): VIF ",
        "máximo = ", sprintf("%.1f", max(vif_reduzido$vif)))

######@> Figura 23 - antes e depois da seleção...
dados_f23 <- bind_rows(
    vif_completo %>% mutate(conjunto = paste0("Completo (",
                                              nrow(vif_completo),
                                              " variáveis)")),
    vif_reduzido %>% mutate(conjunto = paste0("Reduzido (",
                                              nrow(vif_reduzido),
                                              " variáveis)"))) %>%
    mutate(conjunto = factor(conjunto, levels = unique(conjunto)),
           rotulo = ifelse(is.na(rotulo), variavel, rotulo))

f23 <- ggplot(dados_f23, aes(x = pmin(vif, 1000),
                             y = reorder(rotulo, vif),
                             fill = situacao)) +
    geom_col(width = 0.7) +
    geom_vline(xintercept = 5, linetype = "dashed",
               colour = "#E69F00") +
    geom_vline(xintercept = 10, linetype = "dashed",
               colour = "#D55E00") +
    facet_wrap(~ conjunto, scales = "free", ncol = 2) +
    scale_fill_manual(values = c("Aceitável" = "#009E73",
                                 "Colinearidade preocupante" = "#E69F00",
                                 "Colinearidade severa" = "#D55E00"),
                      name = NULL) +
    scale_x_continuous(trans = "log10") +
    labs(title = "A seleção de uma variável por bloco resolve a colinearidade",
         subtitle = paste("Fator de inflação da variância; linhas",
                          "tracejadas em 5 e 10"),
         x = "VIF (escala logarítmica)", y = NULL,
         caption = quebrar(paste(
             "No conjunto completo, várias variáveis têm VIF acima de",
             "100 - são combinações lineares quase exatas das demais, e",
             "seus coeficientes em um modelo conjunto não teriam",
             "interpretação individual. O conjunto reduzido mantém uma",
             "variável por bloco temático (chuva, vento, temperatura,",
             "nebulosidade e acumulação hídrica) e elimina o",
             "problema."))) +
    theme(axis.text.y = element_text(size = 7))

salvar_fig(f23, "Fig_23_colinearidade", 13, 6)

########################################################################
######@> Etapa 14 - Padrões espaciais: mapas e autocorrelação...

######@> Junção dos indicadores ao shapefile...
mapa_dados <- municipios_sf %>%
    left_join(perfil_municipio %>%
                  select(geocodigo, eventos, eventos_por_mil_km2,
                         pct_meses_com_evento, grupo_predominante,
                         pct_hidrologico, urbano_pct, floresta_pct,
                         risco_pct_urbano, precipitacao_media,
                         tau_registro),
              by = "geocodigo") %>%
    left_join(diagnostico_municipal %>%
                  select(geocodigo, cor_contemporanea_chuva,
                         dose_razao_extremo_base),
              by = "geocodigo")

######@> Função de mapa coroplético contínuo...
mapa_base <- function(dados, variavel, titulo, subtitulo, legenda,
                      paleta = "viridis", direcao = -1,
                      caption = NULL, transformacao = "identity") {
    ggplot(dados) +
        geom_sf(aes(fill = .data[[variavel]]), colour = "grey30",
                linewidth = 0.2) +
        scale_fill_viridis_c(option = paleta, direction = direcao,
                             name = legenda, na.value = "grey85",
                             trans = transformacao) +
        labs(title = titulo, subtitle = subtitulo, caption = caption) +
        theme_void(base_size = 11) +
        theme(plot.title = element_text(face = "bold", size = 13),
              plot.subtitle = element_text(colour = "grey30", size = 10),
              plot.caption = element_text(colour = "grey45", size = 8,
                                          hjust = 0),
              legend.position = "right")
}

######@> Mapa 01 - volume de registros...
m1 <- mapa_base(mapa_dados, "eventos",
                "Registros de desastre",
                paste0("Total acumulado, ", ano_ini_atlas, "-",
                       ano_fim_atlas),
                "Eventos", paleta = "inferno",
                caption = quebrar_mapa(paste(
                    "Em cinza: Camboriú e Paulo Lopes, sem registro no",
                    "Atlas. O volume acompanha o tamanho do município e",
                    "a posição no litoral - dois efeitos que a Etapa 11",
                    "separa e que o Mapa 02 controla.")))

salvar_fig(m1, "Mapa_01_registros", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 02 - densidade de registros...
m2 <- mapa_base(mapa_dados, "eventos_por_mil_km2",
                "Densidade de registros",
                "Eventos por mil km² de território",
                "Eventos / mil km²", paleta = "inferno",
                caption = quebrar_mapa(paste(
                    "Normalizar pela área muda a leitura: os balneários",
                    "pequenos, que no Mapa 01 aparecem discretos,",
                    "passam a liderar. É a diferença entre carga",
                    "administrativa e risco por unidade de",
                    "território.")))

salvar_fig(m2, "Mapa_02_densidade_de_registros", largura = 8,
           altura = 9, diretorio = dir_mapa)

######@> Mapa 03 - grupo predominante...
m3 <- ggplot(mapa_dados) +
    geom_sf(aes(fill = grupo_predominante), colour = "grey30",
            linewidth = 0.2) +
    scale_fill_manual(values = cores_grupo, na.value = "grey85",
                      name = "Grupo predominante") +
    labs(title = "Grupo de desastre predominante",
         subtitle = paste0("Grupo com mais registros em cada município, ",
                           ano_ini_atlas, "-", ano_fim_atlas),
         caption = quebrar_mapa(paste(
             "O predomínio hidrológico é quase universal no litoral",
             "catarinense. Os municípios em que o meteorológico",
             "predomina são candidatos naturais a um modelo com o vento",
             "como preditor principal - ver a triagem da Etapa 06."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m3, "Mapa_03_grupo_predominante", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 04 - onde a chuva explica melhor o desastre...
m4 <- mapa_base(mapa_dados, "cor_contemporanea_chuva",
                "Acoplamento entre chuva e desastre",
                "Correlação contemporânea, por município",
                "Correlação", paleta = "mako",
                caption = quebrar_mapa(paste(
                    "Municípios com correlação alta são aqueles em que a",
                    "precipitação mensal explica melhor a ocorrência de",
                    "registros. Onde ela é baixa, ou o município tem",
                    "poucos eventos - e a estimativa é ruidosa - ou seus",
                    "desastres são predominantemente de origem",
                    "meteorológica, que responde ao vento.")))

salvar_fig(m4, "Mapa_04_acoplamento_chuva_desastre", largura = 8,
           altura = 9, diretorio = dir_mapa)

######@> Mapa 05 - exposição urbana à suscetibilidade...
m5 <- mapa_base(mapa_dados, "risco_pct_urbano",
                "Exposição urbana a inundação",
                paste0("Percentual da mancha urbana em área suscetível, ",
                       ano_fim_terra),
                "% da mancha urbana", paleta = "rocket",
                caption = quebrar_mapa(paste(
                    "Indicador do MapBiomas, e o mais diretamente",
                    "comparável às séries de desastre entre os",
                    "descritores territoriais. Em cinza, além dos dois",
                    "municípios sem Atlas, São João do Sul - que o tema",
                    "de risco climático não cobre.")))

salvar_fig(m5, "Mapa_05_exposicao_urbana", largura = 8, altura = 9,
           diretorio = dir_mapa)

######@> Mapa 06 - tendência do registro...
limite_tau <- max(abs(mapa_dados$tau_registro), na.rm = TRUE)

m6 <- ggplot(mapa_dados) +
    geom_sf(aes(fill = tau_registro), colour = "grey30",
            linewidth = 0.2) +
    scale_fill_gradient2(low = "#2166AC", mid = "grey96",
                         high = "#B2182B", midpoint = 0,
                         limits = c(-limite_tau, limite_tau),
                         name = "Tau de Kendall", na.value = "grey85") +
    labs(title = "Tendência dos registros por município",
         subtitle = paste0("Mann-Kendall da série anual, ",
                           ano_ini_atlas, "-", ano_fim_atlas),
         caption = quebrar_mapa(paste(
             "A alta é praticamente generalizada, e o Mapa não",
             "distingue trechos do litoral - padrão esperado se a causa",
             "for administrativa e não climática, já que a mudança no",
             "sistema de registro atingiu todos os municípios ao mesmo",
             "tempo (Etapa 04)."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m6, "Mapa_06_tendencia_do_registro", largura = 8,
           altura = 9, diretorio = dir_mapa)

######@> Autocorrelação espacial...
## A pergunta: municípios vizinhos registram números parecidos? Uma
## resposta afirmativa significa que as observações não são
## independentes no espaço, e que um modelo que as trate como tal
## subestima os erros-padrão.
##
## Como o litoral é uma FAIXA e não uma malha, a exclusão de Camboriú e
## Paulo Lopes rompe elos da cadeia e pode partir o grafo de
## contiguidade. Por isso o índice é calculado também sob um esquema de
## k vizinhos mais próximos, sempre conexo - a mesma precaução adotada
## nas AEDs anteriores.
mapa_analise <- mapa_dados %>% filter(tem_atlas)

vizinhanca <- poly2nb(mapa_analise, queen = TRUE)
componentes <- n.comp.nb(vizinhanca)$nc

coords_mun <- suppressWarnings(st_coordinates(st_centroid(mapa_analise)))
vizinhanca_knn <- knn2nb(knearneigh(coords_mun, k = 4))

pesos <- nb2listw(vizinhanca, style = "W", zero.policy = TRUE)
pesos_knn <- nb2listw(vizinhanca_knn, style = "W")

message("\nVizinhança espacial    : ",
        sprintf("%.2f vizinhos em média, %d componente(s)",
                mean(card(vizinhanca)), componentes))

indicadores_moran <- list(
    c("eventos", "Registros de desastre"),
    c("eventos_por_mil_km2", "Registros por mil km²"),
    c("pct_hidrologico", "Participação do grupo hidrológico (%)"),
    c("cor_contemporanea_chuva", "Acoplamento chuva-desastre"),
    c("tau_registro", "Tendência do registro (tau)"),
    c("risco_pct_urbano", "Exposição urbana suscetível (%)"))

testar_moran <- function(x, listw, rotulo, esquema) {
    if(all(is.na(x)) || var(x, na.rm = TRUE) == 0) return(NULL)
    ok <- !is.na(x)
    ## Municípios sem o indicador recebem a média, o que preserva a
    ## estrutura de vizinhança sem inventar padrão espacial - remover a
    ## unidade partiria o grafo em mais trechos.
    x[!ok] <- mean(x, na.rm = TRUE)
    teste <- moran.test(x, listw, zero.policy = TRUE)
    tibble(indicador = rotulo, esquema = esquema,
           moran_i = as.numeric(teste$estimate[1]),
           esperado = as.numeric(teste$estimate[2]),
           p_valor = teste$p.value,
           n_substituidos = sum(!ok))
}

moran_global <- map_dfr(indicadores_moran, function(par) {
    x <- mapa_analise[[par[1]]]
    bind_rows(testar_moran(x, pesos, par[2], "Contiguidade"),
              testar_moran(x, pesos_knn, par[2], "kNN (k = 4)"))
}) %>%
    mutate(resultado = case_when(
               p_valor >= alfa ~ "Sem autocorrelação detectada",
               moran_i > 0 ~ "Agrupamento espacial",
               TRUE ~ "Dispersão espacial"))

tabelas[["Tab_28_moran"]] <- salvar_tab(moran_global,
                                        "Tab_28_moran_global")

message("Moran global           : ",
        sum(moran_global$resultado != "Sem autocorrelação detectada"),
        " de ", nrow(moran_global), " testes significativos")

######@> Moran local sobre a densidade de registros...
x_lisa <- mapa_analise$eventos_por_mil_km2
lisa <- localmoran(x_lisa, pesos, zero.policy = TRUE)
x_padrao <- as.numeric(scale(x_lisa))
defasagem <- lag.listw(pesos, x_padrao, zero.policy = TRUE)

mapa_analise <- mapa_analise %>%
    mutate(lisa_p = lisa[, ncol(lisa)],
           agrupamento = case_when(
               lisa_p >= alfa ~ "Não significativo",
               x_padrao > 0 & defasagem > 0 ~ "Alto junto a alto",
               x_padrao < 0 & defasagem < 0 ~ "Baixo junto a baixo",
               x_padrao > 0 & defasagem < 0 ~ "Alto junto a baixo",
               TRUE ~ "Baixo junto a alto"))

tabelas[["Tab_29_lisa"]] <- salvar_tab(
    mapa_analise %>%
        st_drop_geometry() %>%
        select(geocodigo, municipio, eventos_por_mil_km2, lisa_p,
               agrupamento) %>%
        arrange(lisa_p),
    "Tab_29_moran_local")

cores_lisa <- c("Alto junto a alto" = "#B2182B",
                "Baixo junto a baixo" = "#2166AC",
                "Alto junto a baixo" = "#F4A582",
                "Baixo junto a alto" = "#92C5DE",
                "Não significativo" = "grey88")

m7 <- ggplot(mapa_dados) +
    geom_sf(fill = "grey85", colour = "grey30", linewidth = 0.2) +
    geom_sf(data = mapa_analise, aes(fill = agrupamento),
            colour = "grey30", linewidth = 0.2) +
    scale_fill_manual(values = cores_lisa, name = "Agrupamento LISA") +
    labs(title = "Agrupamentos espaciais da densidade de registros",
         subtitle = "Moran local, significância a 5%",
         caption = quebrar_mapa(paste(
             "Agrupamentos significativos indicam trechos do litoral com",
             "densidade de registros sistematicamente parecida entre",
             "vizinhos. Onde não há agrupamento, a variação é local e um",
             "modelo com efeito espacial suave teria pouco a capturar."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m7, "Mapa_07_lisa_densidade", largura = 8, altura = 9,
           diretorio = dir_mapa)

########################################################################
######@> Etapa 15 - Ensaios diagnósticos de modelos de contagem...

######@> Propósito e limites desta etapa...
## Os modelos ajustados aqui NÃO são a modelagem do capítulo. São
## diagnósticos: servem para responder três perguntas de estrutura que
## a análise descritiva deixa em aberto e que decidem o desenho do
## modelo definitivo:
##
##   1. Poisson basta, ou é preciso binomial negativo?
##   2. Há excesso de zeros ALÉM do que a sobredispersão explica - isto
##      é, é preciso um modelo inflado de zeros?
##   3. Os municípios diferem entre si além do que a área e o clima
##      explicam - isto é, é preciso efeito de município?
##
## Os coeficientes não devem ser citados como resultado: o conjunto de
## preditores é deliberadamente mínimo e o viés de registro da Etapa 04
## não está tratado.
message("\nAjustando modelos diagnósticos de contagem...")

dados_modelo <- mensal %>%
    left_join(perfil_municipio %>% select(geocodigo, area_km2),
              by = "geocodigo") %>%
    transmute(geocodigo, municipio = factor(municipio),
              ano, mes,
              n_total = atlas_n_eventos,
              n_hidrologico = atlas_n_eventos_hidrologico,
              chuva_p = era5_tp_mm_mes_p,
              vento_p = era5_si10_p,
              ## Harmônicos anuais: representam a sazonalidade com dois
              ## parâmetros em vez de onze indicadores mensais, o que
              ## importa quando a resposta tem 7% de meses positivos e
              ## cada parâmetro extra custa graus de liberdade.
              seno = sin(2 * pi * mes / 12),
              cosseno = cos(2 * pi * mes / 12),
              periodo = factor(ifelse(ano < 2012,
                                      paste0(ano_ini_atlas, "-2011"),
                                      paste0("2012-", ano_fim_atlas))),
              log_area = log(area_km2)) %>%
    na.omit()

######@> Especificações comparadas...
## Seis especificações, todas com offset de log-área: sem ele, o modelo
## atribuiria a municípios grandes um risco que é apenas tamanho - o
## efeito que a Etapa 11 identificou como o único a sobreviver a todos
## os controles.
##
## A comparação é desenhada para separar duas explicações concorrentes
## da sobredispersão: um processo intrinsecamente mais variável que o
## Poisson (que pediria binomial negativo) ou heterogeneidade ENTRE
## MUNICÍPIOS (que pediria efeito de município). Por isso as duas
## famílias aparecem com e sem o termo municipal.
formula_clima <- n_hidrologico ~ chuva_p + vento_p +
    offset(log_area)
formula_completa <- n_hidrologico ~ chuva_p + vento_p + seno +
    cosseno + periodo + offset(log_area)
formula_municipio <- n_hidrologico ~ chuva_p + vento_p + seno +
    cosseno + periodo + municipio + offset(log_area)

ajustes <- list()
ajustes[["Poisson - nulo"]] <-
    glm(n_hidrologico ~ 1 + offset(log_area), family = poisson,
        data = dados_modelo)
ajustes[["Poisson - clima"]] <-
    glm(formula_clima, family = poisson, data = dados_modelo)
ajustes[["Poisson - completo"]] <-
    glm(formula_completa, family = poisson, data = dados_modelo)
ajustes[["Binomial negativo - completo"]] <-
    glm.nb(formula_completa, data = dados_modelo)
ajustes[["Poisson + efeito de município"]] <-
    glm(formula_municipio, family = poisson, data = dados_modelo)
ajustes[["Binomial negativo + efeito de município"]] <-
    glm.nb(formula_municipio, data = dados_modelo)
ajustes[["Inflado de zeros (binomial negativo)"]] <-
    zeroinfl(n_hidrologico ~ chuva_p + vento_p + seno + cosseno +
                 periodo + offset(log_area) | 1,
             dist = "negbin", data = dados_modelo)

######@> Comparação dos ajustes...
## Três medidas, cada uma respondendo a uma das perguntas: o AIC ordena
## os modelos; a razão de dispersão de Pearson diz se a variância
## observada excede a prevista; e a contagem de zeros previstos diz se
## sobra excesso de zeros depois de acomodada a dispersão.
zeros_previstos <- function(ajuste) {
    if(inherits(ajuste, "zeroinfl")) {
        return(sum(predict(ajuste, type = "prob")[, 1]))
    }
    mu <- fitted(ajuste)
    if(inherits(ajuste, "negbin")) {
        return(sum(dnbinom(0, size = ajuste$theta, mu = mu)))
    }
    return(sum(dpois(0, mu)))
}

dispersao_pearson <- function(ajuste) {
    if(inherits(ajuste, "zeroinfl")) {
        residuos <- residuals(ajuste, type = "pearson")
        return(sum(residuos^2) / ajuste$df.residual)
    }
    sum(residuals(ajuste, type = "pearson")^2) / ajuste$df.residual
}

zeros_observados <- sum(dados_modelo$n_hidrologico == 0)

comparacao_modelos <- map_dfr(names(ajustes), function(nome) {
    ajuste <- ajustes[[nome]]
    tibble(modelo = nome,
           parametros = length(coef(ajuste)) +
               ifelse(inherits(ajuste, c("negbin", "zeroinfl")), 1, 0),
           log_verossimilhanca = as.numeric(logLik(ajuste)),
           aic = AIC(ajuste),
           dispersao_pearson = dispersao_pearson(ajuste),
           zeros_previstos = zeros_previstos(ajuste),
           theta = ifelse(inherits(ajuste, "negbin"), ajuste$theta,
                          ifelse(inherits(ajuste, "zeroinfl"),
                                 ajuste$theta, NA_real_)))
}) %>%
    mutate(delta_aic = aic - min(aic),
           razao_zeros = zeros_previstos / zeros_observados) %>%
    arrange(aic)

tabelas[["Tab_30_comparacao_modelos"]] <- salvar_tab(
    comparacao_modelos, "Tab_30_comparacao_de_modelos")

message("\n--- Modelos diagnósticos (resposta: grupo hidrológico) ---")
print(as.data.frame(comparacao_modelos %>%
                    select(modelo, parametros, aic, delta_aic,
                           dispersao_pearson, zeros_previstos) %>%
                    mutate(across(where(is.numeric),
                                  ~ round(.x, 2)))), right = FALSE)
message("Zeros observados       : ", fmt_int(zeros_observados),
        " de ", fmt_int(nrow(dados_modelo)))

######@> Atalhos para as comparações citadas adiante...
pega_modelo <- function(nome, coluna) {
    comparacao_modelos[[coluna]][comparacao_modelos$modelo == nome]
}

disp_poisson_agrupado <- pega_modelo("Poisson - completo",
                                     "dispersao_pearson")
disp_poisson_municipio <- pega_modelo("Poisson + efeito de município",
                                      "dispersao_pearson")
aic_poisson_agrupado <- pega_modelo("Poisson - completo", "aic")
aic_nb_agrupado <- pega_modelo("Binomial negativo - completo", "aic")
aic_poisson_municipio <- pega_modelo("Poisson + efeito de município",
                                     "aic")
aic_nb_municipio <- pega_modelo("Binomial negativo + efeito de município",
                                "aic")
aic_zinb <- pega_modelo("Inflado de zeros (binomial negativo)", "aic")

######@> Figura 24 - qual especificação reproduz a distribuição...
## Compara a distribuição observada das contagens com a prevista por
## cada especificação. É a versão tabular do rootograma: se o modelo
## estiver bem especificado, as duas coincidem em TODAS as contagens, e
## não apenas na média.
prever_distribuicao <- function(ajuste, nome, maximo = 4) {
    if(inherits(ajuste, "zeroinfl")) {
        probs <- predict(ajuste, type = "prob")
        colunas <- min(ncol(probs), maximo + 1)
        previsto <- colSums(probs[, seq_len(colunas), drop = FALSE])
    } else {
        mu <- fitted(ajuste)
        previsto <- vapply(0:maximo, function(k) {
            if(inherits(ajuste, "negbin")) {
                sum(dnbinom(k, size = ajuste$theta, mu = mu))
            } else {
                sum(dpois(k, mu))
            }
        }, numeric(1))
    }
    tibble(modelo = nome, contagem = seq_along(previsto) - 1,
           previsto = as.numeric(previsto))
}

modelos_figura <- c("Poisson - completo",
                    "Binomial negativo - completo",
                    "Poisson + efeito de município")

distribuicao_prevista <- map_dfr(modelos_figura, function(nome) {
    prever_distribuicao(ajustes[[nome]], nome)
})

distribuicao_observada <- dados_modelo %>%
    mutate(contagem = pmin(n_hidrologico, 4)) %>%
    count(contagem, name = "observado")

dados_f24 <- distribuicao_prevista %>%
    left_join(distribuicao_observada, by = "contagem") %>%
    mutate(modelo = factor(modelo, levels = modelos_figura),
           diferenca = previsto - observado)

f24 <- ggplot(dados_f24, aes(x = factor(contagem))) +
    geom_col(aes(y = observado, fill = "Observado"), width = 0.68) +
    geom_point(aes(y = previsto, colour = "Previsto pelo modelo"),
               size = 2.6) +
    geom_text(aes(y = previsto, label = sprintf("%+.0f", diferenca)),
              vjust = -1.1, size = 2.7, colour = "#D55E00") +
    facet_wrap(~ modelo, ncol = 3) +
    scale_y_continuous(trans = "sqrt", labels = fmt_int,
                       expand = expansion(mult = c(0.02, 0.12))) +
    scale_fill_manual(values = c("Observado" = "grey72"), name = NULL) +
    scale_colour_manual(values = c("Previsto pelo modelo" = "#D55E00"),
                        name = NULL) +
    labs(title = "A sobredispersão é heterogeneidade entre municípios",
         subtitle = paste("Distribuição das contagens mensais do grupo",
                          "hidrológico, observada e prevista"),
         x = "Eventos no município-mês (4 = 4 ou mais)",
         y = "Município-meses (escala em raiz quadrada)",
         caption = quebrar(paste(
             "O rótulo mostra a diferença entre previsto e observado.",
             "O binomial negativo AGRUPADO acomoda a dispersão inflando",
             "a cauda - prevê quase o dobro de meses com dois eventos",
             "do que se observou -, o que resolve o sintoma e não a",
             "causa. Ao entrar o efeito de município, uma Poisson",
             "simples reproduz a distribuição inteira quase",
             "exatamente: a variância extra não era do processo, e sim",
             "das diferenças entre municípios que o modelo agrupado",
             "ignorava.")))

salvar_fig(f24, "Fig_24_ajuste_das_familias", 13, 5)

######@> Figura 25 - efeitos ajustados do modelo diagnóstico...
## Apresentados como razão de taxas (exponencial do coeficiente), que é
## a escala interpretável de um modelo de contagem: 1,5 significa 50% a
## mais de eventos esperados. O modelo de referência é o que a
## comparação selecionou - Poisson com efeito de município -, e os
## coeficientes municipais são omitidos da figura por serem 34.
modelo_referencia <- ajustes[["Poisson + efeito de município"]]

efeitos <- {
    coeficientes <- summary(modelo_referencia)$coefficients
    tibble(termo = rownames(coeficientes),
           estimativa = coeficientes[, 1],
           erro_padrao = coeficientes[, 2],
           p_valor = coeficientes[, 4])
} %>%
    filter(termo != "(Intercept)", !grepl("^municipio", termo)) %>%
    mutate(razao_taxa = exp(estimativa),
           ic_inf = exp(estimativa - 1.96 * erro_padrao),
           ic_sup = exp(estimativa + 1.96 * erro_padrao),
           rotulo = recode(termo,
                           chuva_p = "Percentil de precipitação",
                           vento_p = "Percentil de vento",
                           seno = "Sazonalidade (seno)",
                           cosseno = "Sazonalidade (cosseno)",
                           .default = termo),
           rotulo = ifelse(grepl("^periodo", rotulo),
                           "Período 2012-2025 (vs. 1991-2011)", rotulo),
           significativo = p_valor < alfa)

tabelas[["Tab_31_efeitos"]] <- salvar_tab(
    efeitos, "Tab_31_efeitos_do_modelo_diagnostico")

f25 <- ggplot(efeitos, aes(x = razao_taxa,
                           y = reorder(rotulo, razao_taxa),
                           colour = significativo)) +
    geom_vline(xintercept = 1, linetype = "dashed",
               colour = "grey40") +
    geom_errorbar(aes(xmin = ic_inf, xmax = ic_sup), width = 0.18,
                  linewidth = 0.6, orientation = "y") +
    geom_point(size = 3) +
    scale_colour_manual(values = c("TRUE" = "#D55E00",
                                   "FALSE" = "grey60"),
                        labels = c("Não significativo",
                                   "Significativo a 5%"),
                        name = NULL) +
    scale_x_continuous(trans = "log10") +
    labs(title = "Efeitos do modelo diagnóstico (não são resultado final)",
         subtitle = paste("Razões de taxa da Poisson com efeito de",
                          "município, resposta: registros hidrológicos"),
         x = "Razão de taxa (escala logarítmica)", y = NULL,
         caption = quebrar(paste(
             "O efeito do percentil de precipitação é o maior do",
             "modelo, coerente com a dose-resposta da Etapa 06. O termo",
             "de PERÍODO também é grande e significativo - e mede o",
             "degrau de registro documentado na Etapa 04, não clima. É",
             "justamente por isso que precisa estar no modelo: omiti-lo",
             "transferiria o degrau administrativo para os coeficientes",
             "climáticos. Os 34 coeficientes municipais foram omitidos",
             "da figura e constam da Tab_31.")))

salvar_fig(f25, "Fig_25_efeitos_diagnosticos", 10, 5)

######@> Respostas às três perguntas de estrutura...
respostas_estrutura <- tibble(
    pergunta = c("Poisson basta?",
                 "Há excesso de zeros além da sobredispersão?",
                 "É preciso efeito de município?"),
    evidencia = c(
        paste0("Dispersão de Pearson: ",
               sprintf("%.2f", disp_poisson_agrupado),
               " na Poisson agrupada e ",
               sprintf("%.2f", disp_poisson_municipio),
               " na Poisson com efeito de município"),
        paste0("AIC do inflado de zeros = ", sprintf("%.1f", aic_zinb),
               " contra ", sprintf("%.1f", aic_nb_agrupado),
               " do binomial negativo de mesma estrutura; zeros",
               " observados = ", fmt_int(zeros_observados),
               ", previstos = ",
               fmt_int(round(pega_modelo(
                   "Binomial negativo - completo",
                   "zeros_previstos")))),
        paste0("AIC cai de ", sprintf("%.1f", aic_poisson_agrupado),
               " para ", sprintf("%.1f", aic_poisson_municipio),
               " ao incluir o município (delta = ",
               sprintf("%.1f", aic_poisson_municipio -
                       aic_poisson_agrupado), ")")),
    resposta = c(
        paste0("Sim, DESDE QUE o município entre no modelo. Agrupada,",
               " a Poisson fica sobredispersa; com efeito de",
               " município, a dispersão volta a ", 
               sprintf("%.2f", disp_poisson_municipio),
               " e o binomial negativo deixa de acrescentar ajuste",
               " (delta AIC = ",
               sprintf("%+.1f", aic_nb_municipio -
                       aic_poisson_municipio), ")"),
        "Não - o excesso de zeros não existe; o inflado de zeros apenas paga o preço do parâmetro extra",
        "Sim - é o termo que mais melhora o ajuste, e é ele que explica a sobredispersão aparente"))

tabelas[["Tab_32_respostas_estrutura"]] <- salvar_tab(
    respostas_estrutura, "Tab_32_respostas_de_estrutura")

message("\n--- Respostas às perguntas de estrutura ---")
print(as.data.frame(respostas_estrutura %>%
                    select(pergunta, resposta)), right = FALSE)

########################################################################
######@> Etapa 16 - Agrupamento por regime desastre-clima...

######@> Construção da matriz de perfis...
## As variáveis descrevem o município em quatro dimensões: quanto
## registra, de que tipo, quão acoplado ao clima e como é seu
## território. A latitude fica DE FORA de propósito: se entrasse, o
## agrupamento reproduziria o gradiente norte-sul por construção, e a
## pergunta é justamente se os regimes se organizam geograficamente ou
## não.
vars_perfil <- c("eventos_por_mil_km2", "pct_meses_com_evento",
                 "pct_hidrologico", "cor_contemporanea_chuva",
                 "precipitacao_media", "vento_medio", "urbano_pct",
                 "floresta_pct", "risco_pct_urbano")

perfil_matriz <- perfil_municipio %>%
    left_join(diagnostico_municipal %>%
                  select(geocodigo, cor_contemporanea_chuva),
              by = "geocodigo") %>%
    select(geocodigo, municipio, all_of(vars_perfil))

######@> Tratamento das lacunas...
## São João do Sul não tem o tema de risco climático do MapBiomas. Em
## vez de excluir o município - o que abriria um vazio no litoral -, a
## coluna recebe a MEDIANA das demais, e a substituição é registrada.
lacunas_perfil <- perfil_matriz %>%
    filter(if_any(all_of(vars_perfil), is.na)) %>%
    pull(municipio)

perfil_matriz <- perfil_matriz %>%
    mutate(across(all_of(vars_perfil),
                  ~ ifelse(is.na(.x), median(.x, na.rm = TRUE), .x)))

if(length(lacunas_perfil) > 0) {
    message("\nPerfil com valor imputado: ",
            paste(lacunas_perfil, collapse = ", "),
            " (mediana das demais)")
}

matriz_z <- perfil_matriz %>%
    select(all_of(vars_perfil)) %>%
    scale()

rownames(matriz_z) <- perfil_matriz$municipio

######@> Agrupamento hierárquico...
## Distância euclidiana sobre as variáveis padronizadas e ligação de
## Ward, que tende a formar grupos de tamanho equilibrado - preferível
## aqui, onde o objetivo é descrever tipologias e não isolar valores
## extremos.
distancias <- dist(matriz_z, method = "euclidean")
agrupamento <- hclust(distancias, method = "ward.D2")

######@> Escolha do número de grupos pela silhueta média...
## Regra de parcimônia declarada: o MENOR k cuja silhueta esteja a menos
## de uma tolerância do melhor valor observado. Sem essa regra, e com
## municípios distribuídos ao longo de um gradiente contínuo, o "máximo"
## seria apenas o maior k testado.
tolerancia_silhueta <- 0.02

avaliacao_k <- tibble(k = 2:6) %>%
    mutate(silhueta = vapply(k, function(kk)
        silhueta_media(distancias, cutree(agrupamento, k = kk)),
        numeric(1)),
        distancia_do_melhor = max(silhueta) - silhueta,
        aceitavel = distancia_do_melhor <= tolerancia_silhueta)

n_clusters <- min(avaliacao_k$k[avaliacao_k$aceitavel])
grupos_cluster <- cutree(agrupamento, k = n_clusters)

perfil_matriz <- perfil_matriz %>%
    mutate(perfil = paste0("Perfil ",
                           grupos_cluster[match(municipio,
                                                names(grupos_cluster))]))

caracterizacao <- perfil_matriz %>%
    group_by(perfil) %>%
    summarise(n_municipios = n(),
              municipios = paste(municipio, collapse = ", "),
              across(all_of(vars_perfil), mean),
              .groups = "drop")

tabelas[["Tab_33_escolha_k"]] <- salvar_tab(
    avaliacao_k, "Tab_33_escolha_do_numero_de_perfis")
tabelas[["Tab_34_perfis"]] <- salvar_tab(
    perfil_matriz, "Tab_34_perfis_dos_municipios")
tabelas[["Tab_35_caracterizacao"]] <- salvar_tab(
    caracterizacao, "Tab_35_caracterizacao_dos_perfis")

message("Número de perfis       : ", n_clusters, " (silhueta ",
        sprintf("%.3f", avaliacao_k$silhueta[avaliacao_k$k ==
                                             n_clusters]), ")")
message("Composição             : ",
        paste(caracterizacao$perfil, " (n = ",
              caracterizacao$n_municipios, ")", sep = "",
              collapse = " | "))

######@> Figura 26 - dendrograma dos perfis...
ordem_dend <- agrupamento$labels[agrupamento$order]
altura_corte <- mean(rev(sort(agrupamento$height))[c(n_clusters - 1,
                                                     n_clusters)])

f26 <- ggplot() +
    geom_segment(data = segmentos_dendrograma(agrupamento),
                 aes(x = x, y = y, xend = xend, yend = yend),
                 colour = "grey35", linewidth = 0.4) +
    geom_hline(yintercept = altura_corte, linetype = "dashed",
               colour = "#D55E00") +
    scale_x_continuous(breaks = seq_along(ordem_dend),
                       labels = ordem_dend, expand = c(0.02, 0.02)) +
    labs(title = "Agrupamento dos municípios por regime desastre-clima",
         subtitle = paste0("Ligação de Ward sobre ", length(vars_perfil),
                           " variáveis padronizadas de registro,",
                           " acoplamento e território"),
         x = NULL, y = "Distância",
         caption = quebrar(paste0(
             "Linha tracejada: corte adotado, em ", n_clusters,
             " perfis. A latitude NÃO entra na matriz: se os perfis",
             " resultarem geograficamente contíguos (Mapa 08), isso é",
             " achado, e não construção. A tipologia é DESCRITIVA -",
             " serve para organizar a leitura dos ", n_municipios,
             " municípios, não para substituir o efeito municipal que a",
             " Etapa 15 mostrou ser necessário."))) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5,
                                     size = 8))

salvar_fig(f26, "Fig_26_dendrograma_perfis", 12, 7)

######@> Figura 27 - assinatura de cada perfil...
rotulos_perfil <- c(eventos_por_mil_km2 = "Registros por mil km²",
                    pct_meses_com_evento = "Meses com evento (%)",
                    pct_hidrologico = "Participação hidrológica (%)",
                    cor_contemporanea_chuva = "Acoplamento com a chuva",
                    precipitacao_media = "Precipitação média",
                    vento_medio = "Vento médio",
                    urbano_pct = "Mancha urbana (%)",
                    floresta_pct = "Cobertura florestal (%)",
                    risco_pct_urbano = "Exposição urbana (%)")

assinatura <- as_tibble(matriz_z) %>%
    mutate(perfil = perfil_matriz$perfil) %>%
    group_by(perfil) %>%
    summarise(across(everything(), mean), .groups = "drop") %>%
    pivot_longer(-perfil, names_to = "variavel", values_to = "z") %>%
    mutate(rotulo = rotulos_perfil[variavel],
           rotulo = factor(rotulo, levels = rev(rotulos_perfil)))

limite_z <- max(abs(assinatura$z))

f27 <- ggplot(assinatura, aes(x = perfil, y = rotulo, fill = z)) +
    geom_tile(colour = "white", linewidth = 0.5) +
    geom_text(aes(label = sprintf("%+.1f", z)), size = 3,
              colour = "grey15") +
    scale_fill_gradient2(low = "#2166AC", mid = "grey96",
                         high = "#B2182B", midpoint = 0,
                         limits = c(-limite_z, limite_z),
                         name = "Desvios-padrão") +
    labs(title = "Assinatura de cada perfil",
         subtitle = paste("Afastamento médio em relação ao conjunto,",
                          "em desvios-padrão"),
         x = NULL, y = NULL,
         caption = quebrar(paste(
             "A leitura conjunta das linhas nomeia o perfil: um grupo",
             "com muitos registros por km², alta participação",
             "hidrológica e forte acoplamento com a chuva descreve o",
             "município cujo risco é essencialmente pluvial; um grupo",
             "com participação hidrológica baixa e vento alto descreve",
             "o município de risco predominantemente meteorológico - e",
             "os dois pedem preditores diferentes."))) +
    theme(legend.key.width = unit(1.4, "cm"))

salvar_fig(f27, "Fig_27_assinatura_dos_perfis", 10, 7)

######@> Mapa 08 - distribuição espacial dos perfis...
cores_perfil <- c("#0072B2", "#D55E00", "#009E73", "#CC79A7",
                  "#E69F00", "#56B4E9")[seq_len(n_clusters)]
names(cores_perfil) <- sort(unique(perfil_matriz$perfil))

m8 <- mapa_dados %>%
    left_join(perfil_matriz %>% select(geocodigo, perfil),
              by = "geocodigo") %>%
    ggplot() +
    geom_sf(aes(fill = perfil), colour = "grey30", linewidth = 0.2) +
    scale_fill_manual(values = cores_perfil, na.value = "grey85",
                      name = "Perfil") +
    labs(title = "Tipologia de regime desastre-clima",
         subtitle = paste(n_clusters, "perfis, obtidos sem usar a",
                          "posição geográfica"),
         caption = quebrar_mapa(paste(
             "Em cinza: municípios sem registro no Atlas. Como a",
             "latitude não entrou na construção dos perfis, qualquer",
             "contiguidade observada no mapa é resultado - indica que",
             "regime de desastre e território variam juntos ao longo do",
             "litoral."))) +
    theme_void(base_size = 11) +
    theme(plot.title = element_text(face = "bold", size = 13),
          plot.subtitle = element_text(colour = "grey30", size = 10),
          plot.caption = element_text(colour = "grey45", size = 8,
                                      hjust = 0),
          legend.position = "right")

salvar_fig(m8, "Mapa_08_perfis_desastre_clima", largura = 8,
           altura = 9, diretorio = dir_mapa)

########################################################################
######@> Etapa 17 - Exportação consolidada e síntese...

######@> Arquivo XLSX com todas as tabelas...
## Nomes de aba limitados a 31 caracteres pela especificação do formato.
nomes_abas <- substr(names(tabelas), 1, 31)
names(tabelas) <- nomes_abas

write_xlsx(map(tabelas, as.data.frame),
           file.path(dir_tab, "AED_Completo_todas_as_tabelas.xlsx"))

######@> Atalhos para os números citados no relatório...
pega_dose <- function(g, v, coluna) {
    forca_dose[[coluna]][forca_dose$grupo == g &
                         forca_dose$variavel == v]
}

dose_hidrologico <- pega_dose("Hidrológico", "era5_tp_mm_mes",
                              "razao_extremo")
dose_meteorologico <- pega_dose("Meteorológico", "era5_si10",
                                "razao_extremo")
dose_climatologico <- pega_dose("Climatológico", "tp_3m",
                                "razao_extremo")

rho_eventos_ano <- correlacoes_registro$rho[
    correlacoes_registro$relacao == "Eventos x ano"]
rho_extremos_ano <- correlacoes_registro$rho[
    correlacoes_registro$relacao == "Meses extremos de chuva x ano"]

cor_chuva_contemporanea <- pico_ccf$correlacao[
    pico_ccf$rotulo == "Precipitação total"]

######@> Relatório de síntese em texto...
linhas_relatorio <- c(
    "########################################################################",
    "## ANÁLISE EXPLORATÓRIA INTEGRADA - DESASTRES, CLIMA E USO DA TERRA",
    paste0("## Litoral de Santa Catarina | ", ano_ini_atlas, "-",
           ano_fim_atlas),
    paste0("## Gerado em ", format(Sys.time(), "%d/%m/%Y %H:%M")),
    "########################################################################",
    "",
    "1. COBERTURA E TAMANHO AMOSTRAL",
    paste0("   Municípios com resposta    : ", n_municipios),
    paste0("   Município-meses analisados : ", fmt_int(nrow(mensal)),
           " (", n_anos, " anos x ", n_meses, " meses)"),
    paste0("   Registros de desastre      : ",
           fmt_int(sum(mensal$atlas_n_eventos)), " em ",
           fmt_int(sum(mensal$ocorrencia)), " município-meses (",
           sprintf("%.1f%%", 100 * mean(mensal$ocorrencia)), ")"),
    paste0("   Eventos por município      : mínimo ",
           min(perfil_municipio$eventos), ", mediana ",
           median(perfil_municipio$eventos), ", máximo ",
           max(perfil_municipio$eventos)),
    paste0("   Janela com as três fontes  : ", ano_ini_atlas, "-",
           ano_fim_terra),
    "",
    "2. A VARIÁVEL RESPOSTA",
    paste0("   ", format(as.character(composicao_grupo$grupo),
                         width = 15),
           sprintf("%4d eventos (%5.1f%%) | %2d municípios atingidos",
                   composicao_grupo$eventos,
                   composicao_grupo$pct_eventos,
                   composicao_grupo$municipios_atingidos)),
    paste0("   Razão variância/média      : ",
           paste0(distribuicao_escalas$escala, " = ",
                  sprintf("%.2f", distribuicao_escalas$razao_var_media),
                  collapse = " | ")),
    "",
    "3. O VIÉS DE REGISTRO (achado central)",
    paste0("   Eventos x ano              : rho = ",
           sprintf("%+.3f", rho_eventos_ano)),
    paste0("   Meses extremos x ano       : rho = ",
           sprintf("%+.3f", rho_extremos_ano)),
    paste0("   Eventos por ano            : ",
           sprintf("%.1f", quebra_registro$eventos_por_ano[1]), " (",
           quebra_registro$periodo[1], ") -> ",
           sprintf("%.1f", quebra_registro$eventos_por_ano[2]), " (",
           quebra_registro$periodo[2], "), fator ",
           sprintf("%.1f", razao_periodos)),
    paste0("   Extremos por ano           : ",
           sprintf("%.1f", quebra_registro$meses_extremos_por_ano[1]),
           " -> ",
           sprintf("%.1f", quebra_registro$meses_extremos_por_ano[2]),
           ", fator ", sprintf("%.2f", razao_extremos)),
    "   Leitura: a série de desastres mede, em parte, a evolução do",
    "   sistema de registro. Modelos que usem o tempo como preditor",
    "   estarão estimando burocracia.",
    "",
    "4. SAZONALIDADE",
    paste0("   ", format(as.character(pico_grupo$grupo), width = 15),
           "pico em ", format(pico_grupo$mes_pico, width = 4),
           sprintf("(índice %.2f)", pico_grupo$indice_pico),
           " | mínimo em ", pico_grupo$mes_minimo),
    "",
    "5. DOSE-RESPOSTA (probabilidade de evento por percentil local)",
    paste0("   Hidrológico x precipitação : ",
           sprintf("%.1f%% -> %.1f%%",
                   100 * pega_dose("Hidrológico", "era5_tp_mm_mes",
                                   "p_base"),
                   100 * pega_dose("Hidrológico", "era5_tp_mm_mes",
                                   "p_extremo")),
           " (fator ", sprintf("%.1f", dose_hidrologico), ")"),
    paste0("   Meteorológico x vento      : ",
           sprintf("%.1f%% -> %.1f%%",
                   100 * pega_dose("Meteorológico", "era5_si10",
                                   "p_base"),
                   100 * pega_dose("Meteorológico", "era5_si10",
                                   "p_extremo")),
           " (fator ", sprintf("%.1f", dose_meteorologico), ")"),
    paste0("   Climatológico x chuva 3 m  : ",
           sprintf("%.2f%% -> %.2f%%",
                   100 * pega_dose("Climatológico", "tp_3m", "p_base"),
                   100 * pega_dose("Climatológico", "tp_3m",
                                   "p_extremo")),
           " (relação INVERSA)"),
    "",
    "6. EXTREMOS CLIMÁTICOS",
    paste0("   ", format(extremos_sintese$tipo, width = 24),
           sprintf("P(evento) %5.2f%% vs %5.2f%% (fator %4.1f) | %4.1f%% dos eventos",
                   extremos_sintese$p_com_extremo,
                   extremos_sintese$p_sem_extremo,
                   extremos_sintese$razao,
                   extremos_sintese$pct_eventos_no_extremo)),
    "",
    "7. ESTRUTURA TEMPORAL",
    paste0("   ", format(diagnostico_temporal$versao, width = 34),
           sprintf("ACF(1) = %+.3f | %s", diagnostico_temporal$acf1,
                   diagnostico_temporal$estacionaria)),
    paste0("   Correlação cruzada máxima  : ",
           sprintf("%.3f", cor_chuva_contemporanea),
           " na defasagem ",
           pico_ccf$lag_pico[pico_ccf$rotulo == "Precipitação total"],
           " (contemporânea)"),
    paste0("   Municípios com pico em defasagem zero: ",
           sum(diagnostico_municipal$lag_pico_chuva == 0,
               na.rm = TRUE), " de ", n_municipios),
    "",
    "8. TENDÊNCIAS COMPARADAS",
    paste0("   ", format(tendencias$serie[tendencias$bloco !=
                                          "Clima"], width = 34),
           sprintf("tau = %+.3f | %s",
                   tendencias$tau[tendencias$bloco != "Clima"],
                   tendencias$resultado[tendencias$bloco != "Clima"])),
    "",
    "9. USO DA TERRA E EXPOSIÇÃO (correlação bruta -> parcial)",
    paste0("   ", format(associacoes$rotulo, width = 30),
           sprintf("%+.3f -> %+.3f",
                   associacoes$correlacao_bruta,
                   associacoes$parcial_latitude)),
    "",
    "10. REDUNDÂNCIA ENTRE DESCRITORES",
    paste0("   VIF máximo no conjunto completo (",
           nrow(vif_completo), " variáveis): ",
           sprintf("%.1f", max(vif_completo$vif))),
    paste0("   VIF máximo no conjunto reduzido (",
           nrow(vif_reduzido), " variáveis): ",
           sprintf("%.1f", max(vif_reduzido$vif))),
    paste0("   Conjunto reduzido sugerido : ",
           paste(dic_clima$rotulo[match(vars_reduzidas,
                                        dic_clima$variavel)],
                 collapse = ", ")),
    "",
    "11. PADRÕES ESPACIAIS",
    paste0("   ", format(moran_global$indicador[
        moran_global$esquema == "Contiguidade"], width = 38),
        sprintf("I = %+.3f | %s",
                moran_global$moran_i[moran_global$esquema ==
                                     "Contiguidade"],
                moran_global$resultado[moran_global$esquema ==
                                       "Contiguidade"])),
    "",
    "12. ESTRUTURA DE MODELO (ensaios diagnósticos)",
    paste0("   ", format(comparacao_modelos$modelo, width = 40),
           sprintf("AIC = %8.1f | dispersão = %.2f",
                   comparacao_modelos$aic,
                   comparacao_modelos$dispersao_pearson)),
    paste0("   Zeros observados = ", fmt_int(zeros_observados),
           " | previstos pela Poisson com município = ",
           fmt_int(round(pega_modelo("Poisson + efeito de município",
                                     "zeros_previstos")))),
    "",
    "13. TIPOLOGIA DOS MUNICÍPIOS",
    paste0("   Perfis adotados            : ", n_clusters,
           " (silhueta ",
           sprintf("%.3f", avaliacao_k$silhueta[avaliacao_k$k ==
                                                n_clusters]), ")"),
    paste0("   ", format(caracterizacao$perfil, width = 12),
           sprintf("n = %2d | ", caracterizacao$n_municipios),
           substr(caracterizacao$municipios, 1, 88)),
    "",
    "########################################################################",
    "## IMPLICAÇÕES PARA A MODELAGEM",
    "########################################################################",
    "",
    "   (a) UNIDADE E FAMÍLIA",
    "       O município-mês é a unidade adequada, e a resposta é uma",
    "       CONTAGEM com 93% de zeros. A comparação de modelos mostrou",
    paste0("       que uma Poisson com efeito de município é suficiente ",
           "(dispersão ", sprintf("%.2f", disp_poisson_municipio), "):"),
    "       o binomial negativo não acrescenta ajuste quando o município",
    "       entra, e a inflação de zeros não é necessária em nenhum caso.",
    "",
    "   (b) SEPARAR OS GRUPOS É OBRIGATÓRIO",
    "       Hidrológico responde à chuva, meteorológico ao vento e",
    "       climatológico à FALTA de chuva. Um modelo único sobre o total",
    "       soma respostas de sinais opostos para a mesma variável e",
    "       diluiria todos os efeitos.",
    "",
    "   (c) O VIÉS DE REGISTRO PRECISA ENTRAR NO MODELO",
    "       Um termo de período (ou de tendência administrativa) é",
    "       obrigatório. Sem ele, o degrau de 2012 é absorvido pelos",
    "       coeficientes climáticos e produz efeito climático espúrio.",
    "       A alternativa mais conservadora é restringir a análise a",
    "       2012-2025, ao custo de dois terços da série.",
    "",
    "   (d) PREDITORES: UM POR BLOCO, EM PERCENTIL LOCAL, SEM DEFASAGEM",
    paste0("       O VIF cai de ", sprintf("%.0f", max(vif_completo$vif)),
           " para ", sprintf("%.1f", max(vif_reduzido$vif)),
           " ao reduzir o conjunto. O percentil"),
    "       local remove clima e sazonalidade de uma vez, e a relação é",
    "       contemporânea - termos defasados não encontram respaldo.",
    "",
    "   (e) EXPOSIÇÃO",
    "       O número de registros cresce com a área do município, e esse",
    "       é o único efeito territorial que sobrevive ao controle da",
    "       latitude. Offset de área (ou de mancha urbana, ou de",
    "       população) é necessário para não confundir tamanho com risco.",
    "",
    "   (f) EXTREMOS NÃO BASTAM",
    paste0("       Meses acima do percentil 95 de chuva concentram apenas ",
           sprintf("%.0f%%", extremos_sintese$pct_eventos_no_extremo[1]),
           " dos"),
    "       eventos. Restringir a análise a extremos descartaria a maior",
    "       parte do fenômeno; a vulnerabilidade do território pesa tanto",
    "       quanto o gatilho meteorológico.",
    "",
    "   (g) ESPAÇO",
    "       Há autocorrelação espacial em vários indicadores municipais.",
    "       O efeito de município já absorve boa parte dela; um termo",
    "       espacial explícito só se justifica se o objetivo for",
    "       predição para municípios não observados.",
    "",
    "   (h) USO DA TERRA COM CAUTELA",
    "       As associações brutas entre uso da terra e desastres são",
    "       dominadas pelo gradiente latitudinal. Só devem entrar em",
    "       modelo com controle explícito de posição e tamanho, e a",
    "       fração urbana suscetível é o descritor mais defensável.",
    "",
    "   (i) O QUE ESTA BASE NÃO RESOLVE",
    "       Acumulação sub-mensal (a chuva de três dias que satura o",
    "       solo), intensidade do dano por evento além do registrado no",
    "       Atlas, e população exposta - que a base não contém e que",
    "       seria o denominador natural de qualquer taxa de risco.",
    "",
    "   (j) RESSALVAS DE ORIGEM QUE ATRAVESSAM TUDO",
    "       ERA5 é reanálise, não observação; o Atlas é registro",
    "       ADMINISTRATIVO, e sua ausência não significa ausência de",
    "       desastre; o MapBiomas é classificação de imagem. As três",
    "       incertezas se somam quando as três fontes entram no mesmo",
    "       modelo.",
    "",
    "########################################################################")

writeLines(linhas_relatorio,
           file.path(dir_res, "AED_Completo_relatorio_sintese.txt"))

######@> Resumo final do processamento...
n_figs <- length(list.files(dir_fig, pattern = "\\.png$"))
n_figs_mun <- length(list.files(dir_fig_mun, pattern = "\\.png$"))
n_mapas <- length(list.files(dir_mapa, pattern = "\\.png$"))
n_tabs <- length(list.files(dir_tab, pattern = "\\.csv$"))

message("\n=== AED integrada concluída ===")
message("Figuras gerais         : ", n_figs)
message("Painéis por município  : ", n_figs_mun)
message("Mapas                  : ", n_mapas)
message("Tabelas (CSV)          : ", n_tabs, " + 1 XLSX consolidado")
message("Relatório de síntese   : AED_Completo_relatorio_sintese.txt")
message("Saídas em              : ", normalizePath(dir_res))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
