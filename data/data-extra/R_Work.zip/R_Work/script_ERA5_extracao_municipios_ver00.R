########################################################################
## Description: Recorte e extração dos dados ERA5 (monthly means) por
##              município costeiro de Santa Catarina...
##
## Maintainer: UNIVALI / EP / LEMA - PPG-CA
## Author: Rodrigo Sant'Ana
## Created: seg ago 18 09:00:00 2026 (-0300)
## Version: 0.0.1
##
## URL:
## Doc URL:
##
## Database info: Copernicus ERA5 - reanalysis-era5-single-levels-
##                monthly-means (1940-2026), grade regular de 0.25 graus,
##                recortada para a janela [-23, -52, -30, -46]
##                (Norte, Oeste, Sul, Leste), baixada pelo script
##                script_ERA5_copernicus_ver00.R.
##
### Commentary:
##
## Este script realiza o recorte espacial (zonal statistics) dos dados
## do Copernicus ERA5 para cada município costeiro de Santa Catarina,
## definido pelo shapefile de abrangência do PMCAP-SC.
##
## Fluxo geral do processamento:
##
##   01) Leitura e padronização do shapefile de municípios (datum
##       WGS84 / EPSG:4326) e dissolução das feições por município;
##   02) Leitura dos arquivos anuais do ERA5 (que, apesar da extensão
##       ".nc", são arquivos ZIP contendo 4 NetCDFs internos);
##   03) Extração das médias ponderadas pela área de intersecção
##       (exactextractr) de cada variável, para cada município e mês;
##   04) Concatenação temporal de toda a série (1940-2026);
##   05) Cálculo de variáveis derivadas em unidades de uso corrente;
##   06) Exportação por município em formato Parquet e RData.
##
### Code:
########################################################################

########################################################################
######@> Setup R...

######@> Pacotes R...
library(sf)             ## Leitura/manipulação de dados vetoriais
library(terra)          ## Leitura/manipulação de dados raster (NetCDF)
library(ncdf4)          ## Inspeção da estrutura interna dos NetCDFs
library(exactextractr)  ## Estatísticas zonais ponderadas pela área
library(dplyr)          ## Manipulação de tabelas
library(tidyr)          ## Pivotagem (formato longo <-> largo)
library(purrr)          ## Programação funcional (map/reduce)
library(stringi)        ## Transliteração de acentos (nomes de arquivo)
library(arrow)          ## Escrita de arquivos Parquet

######@> Opções globais...
## Evita que strings sejam convertidas em fatores e desliga a notação
## científica, o que facilita a leitura dos códigos de município (IBGE).
options(stringsAsFactors = FALSE, scipen = 999)

######@> Semente (garante reprodutibilidade de qualquer etapa
######@> eventualmente estocástica)...
set.seed(42)

########################################################################
######@> Definição de diretórios e parâmetros...

######@> Diretórios de entrada...
## O script assume que está sendo executado a partir da pasta R_Work,
## portanto todos os caminhos são relativos a ela.
dir_dados <- "../Dados"
dir_era5 <- file.path(dir_dados, "Compilacao_01", "Copernicus_ERA5")
dir_shape <- file.path(dir_dados, "Shapefiles")

######@> Diretórios de saída...
## A pasta Outputs recebe duas subpastas, uma por formato solicitado.
dir_out <- file.path(dir_dados, "Outputs")
dir_out_parquet <- file.path(dir_out, "Parquet")
dir_out_rdata <- file.path(dir_out, "RData")

######@> Criação da estrutura de saída (recursive = TRUE cria os níveis
######@> intermediários; showWarnings = FALSE evita aviso caso já
######@> exista)...
for(d in c(dir_out, dir_out_parquet, dir_out_rdata)) {
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

######@> Arquivo do shapefile de municípios costeiros...
arq_shape <- file.path(dir_shape, "municipio_abrangencia_PMCAP-SC.shp")

######@> Datum/CRS de referência do projeto...
## EPSG:4326 = WGS84 em coordenadas geográficas (graus decimais). É o
## mesmo referencial nativo do ERA5, o que evita reamostragem do raster
## e mantém a extração no sistema original do dado climático.
crs_projeto <- 4326

######@> CRS auxiliar para cálculo de áreas...
## EPSG:5880 = SIRGAS 2000 / Brazil Polyconic. Projeção equivalente
## (preserva área), usada APENAS para calcular a área dos municípios em
## km2 - nunca para a extração em si.
crs_area <- 5880

######@> Variáveis categóricas do ERA5...
## Estas variáveis são códigos da tabela GRIB 4.234 e não grandezas
## contínuas: identificam o TIPO de vegetação (ex.: 19 = "Interrupted
## forest"). Uma média aritmética entre códigos não tem significado
## físico (a média entre os tipos 1 e 17 não é o tipo 9), portanto elas
## recebem tratamento por MODA - a categoria que predomina em área
## dentro do município. Verificou-se que ambas assumem poucos valores
## inteiros e constantes no recorte (tvh = 19; tvl = 1, 2 ou 17), o que
## confirma a natureza categórica.
vars_categoricas <- c("tvh",    ## Tipo de vegetação alta (tab. 4.234)
                      "tvl")    ## Tipo de vegetação baixa (tab. 4.234)

######@> Observação sobre a variável "ptype" (tipo de precipitação)...
## Na documentação do ERA5, ptype é um código categórico (tabela 4.201:
## 0 = sem precipitação, 1 = chuva, 5 = neve, etc.). PORÉM, no produto
## "monthly averaged reanalysis" utilizado aqui, o próprio ECMWF já
## calculou a média temporal desse código ao longo do mês, de modo que
## os valores chegam FRACIONÁRIOS (verificado: 1434 valores distintos,
## na faixa 0.13-0.97, e não os inteiros da tabela). Ou seja, neste
## produto ptype já é, na prática, um índice contínuo que expressa a
## predominância de precipitação líquida no mês. Por esse motivo ele é
## tratado como variável CONTÍNUA (média ponderada pela área), em
## coerência com as demais - aplicar moda aqui devolveria o valor de um
## único pixel, descartando a ponderação espacial.

######@> Variáveis auxiliares dos NetCDFs que não são dados climáticos e
######@> devem ser descartadas na extração...
vars_ignorar <- c("number",     ## Id do membro do ensemble (sempre 0)
                  "expver",     ## Versão do experimento (ERA5/ERA5T)
                  "latitude", "longitude", "valid_time")

########################################################################
######@> Funções auxiliares...

######@> Função para transliterar nomes em nomes seguros de arquivo...
## Remove acentos (stri_trans_general), troca qualquer caractere não
## alfanumérico por "_" e elimina underscores duplicados/terminais.
## Necessária porque os nomes dos municípios possuem acentuação
## (ex.: "Balneário Camboriú" -> "Balneario_Camboriu").
limpar_nome <- function(x) {
    x <- stri_trans_general(x, "Latin-ASCII")
    x <- gsub("[^A-Za-z0-9]+", "_", x)
    x <- gsub("^_+|_+$", "", x)
    return(x)
}

######@> Função para listar as variáveis de dados de um NetCDF...
## Abre o arquivo apenas para ler os metadados (nomes das variáveis) e
## o fecha imediatamente, devolvendo somente as variáveis climáticas.
listar_variaveis <- function(arquivo) {
    nc <- nc_open(arquivo)
    on.exit(nc_close(nc), add = TRUE)          ## Garante o fechamento
    vars <- names(nc$var)
    vars <- setdiff(vars, vars_ignorar)
    return(vars)
}

######@> Função que extrai UMA variável de UM NetCDF para TODOS os
######@> municípios e TODOS os meses contidos no arquivo...
extrair_variavel <- function(arquivo, variavel, municipios) {
    ## 1. Leitura da variável como SpatRaster multicamadas ------------
    ##    Cada camada corresponde a um mês do ano contido no arquivo.
    r <- rast(arquivo, subds = variavel)
    ## 2. Correção da convenção de longitude ---------------------------
    ##    O NetCDF interno "stepType-avg" (variável ptype) vem com
    ##    longitudes na convenção 0-360 graus, enquanto os demais vêm em
    ##    -180/180. terra::rotate() converte 0-360 -> -180/180. Sem esta
    ##    correção o raster não intersecta o shapefile e a extração
    ##    retornaria apenas NA.
    if(xmax(r) > 180) {
        r <- rotate(r)
    }
    ## 3. Atribuição explícita do CRS ----------------------------------
    ##    O ERA5 é distribuído em coordenadas geográficas WGS84, mas
    ##    alguns NetCDFs não trazem a definição formal do CRS. Definimos
    ##    explicitamente para assegurar o alinhamento com o shapefile já
    ##    padronizado em EPSG:4326.
    if(is.na(crs(r)) || crs(r) == "") {
        crs(r) <- paste0("EPSG:", crs_projeto)
    }
    ## 4. Definição da estatística zonal --------------------------------
    ##    - "mean": média ponderada pela fração de área de cada pixel
    ##      coberta pelo polígono do município (variáveis contínuas);
    ##    - "mode": categoria predominante em área (variáveis de código).
    estat <- if(variavel %in% vars_categoricas) "mode" else "mean"
    ## 5. Extração zonal -------------------------------------------------
    ##    IMPORTANTE: a grade do ERA5 tem 0.25 graus (~27 km, ~700 km2
    ##    por pixel), enquanto o menor município do recorte (Bombinhas)
    ##    possui ~36 km2. Nenhum município é maior que um punhado de
    ##    pixels e vários são MENORES que um único pixel. Por isso a
    ##    extração é feita com exactextractr, que pondera pela fração de
    ##    área efetivamente coberta, em vez de usar o centroide do pixel
    ##    (que devolveria NA para os municípios pequenos).
    ##
    ##    coverage_area = TRUE faz a ponderação pela ÁREA REAL (m2) de
    ##    cada fração de pixel, e não pela fração em graus, corrigindo a
    ##    distorção do sistema geográfico.
    valores <- exact_extract(r, municipios, estat,
                             coverage_area = TRUE,
                             progress = FALSE)
    ## 6. Padronização do retorno ----------------------------------------
    ##    exact_extract devolve vetor quando há 1 camada e data.frame
    ##    quando há várias; as.matrix uniformiza os dois casos.
    valores <- as.matrix(valores)
    ## 7. Recuperação dos carimbos temporais ------------------------------
    ##    A ORDEM das colunas devolvidas por exact_extract corresponde à
    ##    ordem das camadas do raster, portanto casa posicionalmente com
    ##    time(r). Não se deve ordenar as colunas pelo nome, pois o
    ##    sufixo numérico ("_1", "_10", "_2"...) ordena alfabeticamente
    ##    de forma incorreta.
    datas <- time(r)
    ## 8. Montagem da tabela em formato longo -------------------------------
    ##    Cada linha = 1 município x 1 mês.
    res <- expand.grid(idx_mun = seq_len(nrow(valores)),
                       idx_tempo = seq_len(ncol(valores)),
                       KEEP.OUT.ATTRS = FALSE)
    res$geocodigo <- municipios$geocodigo[res$idx_mun]
    ## 9. Normalização temporal -------------------------------------------
    ##    Os quatro NetCDFs internos usam carimbos de tempo DIFERENTES
    ##    para o mesmo mês (ex.: 1940-01-01 00:00, 1940-01-01 06:00 e
    ##    1940-01-31 23:00), pois cada stepType tem convenção própria.
    ##    Para poder unir as variáveis, reduzimos todos ao par
    ##    ano/mês, que é a real resolução temporal do produto
    ##    "monthly means".
    res$ano <- as.integer(format(datas[res$idx_tempo], "%Y"))
    res$mes <- as.integer(format(datas[res$idx_tempo], "%m"))
    res$variavel <- variavel
    res$valor <- valores[cbind(res$idx_mun, res$idx_tempo)]
    res <- res[, c("geocodigo", "ano", "mes", "variavel", "valor")]
    return(res)
}

######@> Função que processa UM arquivo anual completo (o ZIP)...
extrair_ano <- function(arquivo_zip, municipios) {
    ## 1. Descompactação em diretório temporário -------------------------
    ##    Os arquivos possuem extensão ".nc" mas são, de fato, arquivos
    ##    ZIP (o CDS entregou "download_format = zip" apesar do pedido
    ##    por "unarchived"). Cada ZIP contém 4 NetCDFs, um por
    ##    "stepType", que agrupam as variáveis conforme o tipo de
    ##    acumulação temporal:
    ##      - stepType-avgua : variáveis instantâneas (u10, v10, t2m...)
    ##      - stepType-avgad : variáveis acumuladas diárias (tp, ssr...)
    ##      - stepType-avgid : taxas instantâneas diárias (lsrr)
    ##      - stepType-avg   : tipo de precipitação (ptype)
    ##    Usamos um diretório temporário por ano, removido ao final, para
    ##    não poluir a pasta de dados originais.
    dir_tmp <- file.path(tempdir(), paste0("era5_", basename(arquivo_zip)))
    dir.create(dir_tmp, recursive = TRUE, showWarnings = FALSE)
    on.exit(unlink(dir_tmp, recursive = TRUE), add = TRUE)
    unzip(arquivo_zip, exdir = dir_tmp)
    ## 2. Listagem dos NetCDFs internos -----------------------------------
    arqs_nc <- list.files(dir_tmp, pattern = "\\.nc$", full.names = TRUE)
    ## 3. Extração de todas as variáveis de todos os NetCDFs -------------
    ##    map_dfr percorre cada NetCDF, descobre suas variáveis e aplica
    ##    extrair_variavel(), empilhando tudo em uma única tabela longa.
    res <- map_dfr(arqs_nc, function(arq) {
        vars <- listar_variaveis(arq)
        map_dfr(vars, ~ extrair_variavel(arq, .x, municipios))
    })
    return(res)
}

########################################################################
######@> Etapa 01 - Leitura e padronização do shapefile...

######@> Leitura do shapefile de municípios costeiros...
message("Lendo shapefile de municípios costeiros...")
shape_bruto <- st_read(arq_shape, quiet = TRUE)

######@> Correção de geometrias inválidas...
## O shapefile possui polígonos com ordem de rotação (winding order)
## incorreta e 2 geometrias inválidas. st_make_valid() corrige esses
## problemas, que de outro modo provocariam erro ou áreas negativas na
## extração zonal.
shape_bruto <- st_make_valid(shape_bruto)

######@> Padronização do datum para WGS84...
## O shapefile já se encontra em GCS_WGS_1984, mas o arquivo .prj usa a
## nomenclatura antiga do ESRI ("D_WGS_1984"), sem código EPSG
## explícito. st_transform() para EPSG:4326 formaliza o CRS e garante
## que qualquer arquivo futuro em outro datum seja reprojetado
## corretamente antes da extração.
shape_bruto <- st_transform(shape_bruto, crs_projeto)

######@> Consolidação dos atributos de identificação do município...
## O shapefile resultou da união de três camadas distintas e, por isso,
## possui 29 colunas com TRÊS blocos redundantes de atributos
## ("nome"/"codigo_ibg", "MUNICIPIO"/"GEOCODIGO" e
## "MUNICIPIO_"/"GEOCODIGO_"). Cada feição preenche apenas um dos
## blocos, deixando os demais como NA. coalesce() percorre os blocos na
## ordem e assume o primeiro valor não-nulo, recuperando nome e código
## IBGE para as 81 feições sem nenhum NA.
atributos <- st_drop_geometry(shape_bruto)
shape_bruto$municipio <- coalesce(as.character(atributos$nome),
                                  as.character(atributos$MUNICIPIO),
                                  as.character(atributos$MUNICIPIO_))
shape_bruto$geocodigo <- coalesce(as.character(atributos$codigo_ibg),
                                  as.character(atributos$GEOCODIGO),
                                  as.character(atributos$GEOCODIGO_))

######@> Dissolução das feições por município...
## As 81 feições originais correspondem a apenas 37 municípios (há
## polígonos repetidos e municípios fragmentados em várias partes, como
## ilhas). O agrupamento por geocódigo + nome, seguido de summarise(),
## dissolve as partes em uma única geometria (MULTIPOLYGON) por
## município, evitando duplicação de linhas na extração.
municipios <- shape_bruto %>%
    group_by(geocodigo, municipio) %>%
    summarise(.groups = "drop") %>%
    st_make_valid() %>%
    arrange(municipio)

######@> Cálculo da área municipal (km2)...
## Calculada em projeção equivalente (EPSG:5880) e apenas para compor os
## metadados de saída, permitindo avaliar a razão entre o tamanho do
## município e o pixel do ERA5 (~700 km2).
municipios$area_km2 <-
    as.numeric(st_area(st_transform(municipios, crs_area))) / 1e6

######@> Coordenadas do centroide do município (WGS84)...
## Úteis como metadado descritivo de posição. st_centroid() emite aviso
## sobre coordenadas geográficas; suppressWarnings() o silencia, pois o
## uso aqui é meramente descritivo.
centroides <- suppressWarnings(st_coordinates(st_centroid(municipios)))
municipios$lon_centroide <- centroides[, "X"]
municipios$lat_centroide <- centroides[, "Y"]

######@> Conferência da padronização...
message("Municípios prontos para extração: ", nrow(municipios))
message("CRS de trabalho: EPSG:", st_crs(municipios)$epsg)

########################################################################
######@> Etapa 02 - Extração dos dados ERA5 por município...

######@> Listagem dos arquivos anuais do ERA5...
## sort() garante a ordem cronológica dos arquivos (1940 -> 2026).
arqs_era5 <- sort(list.files(dir_era5, pattern = "^era5_sul_brasil_.*\\.nc$",
                             full.names = TRUE))
message("Arquivos anuais do ERA5 encontrados: ", length(arqs_era5))

######@> Loop de extração ano a ano...
## O processamento é feito ano a ano (e não com todos os arquivos
## carregados de uma vez) para manter o uso de memória baixo e para que
## uma eventual falha em um ano específico seja facilmente identificada.
lista_anos <- vector("list", length(arqs_era5))
names(lista_anos) <- basename(arqs_era5)

for(i in seq_along(arqs_era5)) {
    message(sprintf("[%3d/%3d] Extraindo %s ...", i, length(arqs_era5),
                    basename(arqs_era5[i])))
    lista_anos[[i]] <- extrair_ano(arqs_era5[i], municipios)
}

######@> Concatenação temporal de toda a série...
## bind_rows() empilha as tabelas anuais, produzindo a série completa
## (1940-2026) em formato longo.
dados_longo <- bind_rows(lista_anos)

message("Registros extraídos (formato longo): ", nrow(dados_longo))

########################################################################
######@> Etapa 03 - Estruturação da base final...

######@> Pivotagem para o formato largo...
## Converte de "uma linha por variável" para "uma linha por
## município-mês, uma coluna por variável", que é o formato analítico
## mais conveniente para modelagem. É aqui que as variáveis provenientes
## dos quatro NetCDFs internos (com carimbos temporais distintos) se
## unem, graças à normalização prévia para ano/mês.
dados_largo <- dados_longo %>%
    pivot_wider(id_cols = c(geocodigo, ano, mes),
                names_from = variavel,
                values_from = valor)

######@> Junção com os metadados dos municípios...
## Recupera nome, área e centroide, descartando a geometria (as saídas
## são tabelas, não objetos espaciais).
meta_municipios <- municipios %>%
    st_drop_geometry() %>%
    select(geocodigo, municipio, area_km2, lon_centroide, lat_centroide)

dados_final <- meta_municipios %>%
    left_join(dados_largo, by = "geocodigo")

######@> Criação da coluna de data de referência...
## Primeiro dia do mês, para facilitar operações de série temporal.
dados_final <- dados_final %>%
    mutate(data = as.Date(sprintf("%d-%02d-01", ano, mes)),
           .after = mes)

######@> Cálculo de variáveis derivadas em unidades de uso corrente...
## As variáveis originais do ERA5 são mantidas INTACTAS; as versões
## convertidas recebem sufixo indicando a unidade. As conversões
## seguem a documentação do ERA5 para "monthly averaged reanalysis",
## em que os acumulados representam a média diária do mês:
##   - t2m: Kelvin -> graus Celsius (subtrair 273.15);
##   - tp/cp/e/pev: metros -> milímetros por dia (multiplicar por 1000);
##   - slhf/ssr: J m-2 acumulados no dia -> W m-2 (dividir por 86400 s);
##   - tcc: fração (0-1) -> percentual (multiplicar por 100);
##   - lsrr: kg m-2 s-1 -> mm por dia (multiplicar por 86400).
dados_final <- dados_final %>%
    mutate(t2m_C = t2m - 273.15,          ## Temperatura do ar a 2 m
           tp_mm_dia = tp * 1000,         ## Precipitação total
           cp_mm_dia = cp * 1000,         ## Precipitação convectiva
           e_mm_dia = e * 1000,           ## Evaporação (negativa = perda)
           pev_mm_dia = pev * 1000,       ## Evaporação potencial
           lsrr_mm_dia = lsrr * 86400,    ## Taxa de chuva de larga escala
           slhf_W_m2 = slhf / 86400,      ## Fluxo de calor latente
           ssr_W_m2 = ssr / 86400,        ## Radiação solar líquida
           tcc_pct = tcc * 100)           ## Cobertura de nuvens

######@> Cálculo da direção e velocidade do vento a 10 m...
## A partir das componentes zonal (u10) e meridional (v10):
##   - velocidade: módulo do vetor (sqrt(u^2 + v^2)). O ERA5 também
##     fornece si10, mas si10 é a média das velocidades instantâneas,
##     enquanto esta é a velocidade do vento MÉDIO - as duas são
##     mantidas por serem grandezas distintas;
##   - direção meteorológica: azimute de ONDE o vento SOPRA (convenção
##     0 = Norte, 90 = Leste), obtida por atan2 e ajustada para [0, 360).
dados_final <- dados_final %>%
    mutate(vento_vel_m_s = sqrt(u10^2 + v10^2),
           vento_dir_graus = (270 - atan2(v10, u10) * 180 / pi) %% 360)

######@> Ordenação final dos registros...
dados_final <- dados_final %>%
    arrange(municipio, data)

message("Base final: ", nrow(dados_final), " linhas x ",
        ncol(dados_final), " colunas")

########################################################################
######@> Etapa 04 - Exportação dos resultados...

######@> Tabela de referência das variáveis...
## Documenta o significado e a unidade de cada variável extraída,
## exportada junto às bases para assegurar a reprodutibilidade da
## interpretação dos dados.
dicionario <- tribble(
    ~variavel,         ~descricao,                                    ~unidade,
    "u10",             "Componente zonal do vento a 10 m",            "m s-1",
    "v10",             "Componente meridional do vento a 10 m",       "m s-1",
    "t2m",             "Temperatura do ar a 2 m",                     "K",
    "si10",            "Velocidade do vento a 10 m",                  "m s-1",
    "tcc",             "Cobertura total de nuvens",                   "0-1",
    "tcrw",            "Água de chuva na coluna total",               "kg m-2",
    "cvh",             "Cobertura de vegetação alta",                 "0-1",
    "cvl",             "Cobertura de vegetação baixa",                "0-1",
    "lai_hv",          "Índice de área foliar - vegetação alta",      "m2 m-2",
    "lai_lv",          "Índice de área foliar - vegetação baixa",     "m2 m-2",
    "tvh",             "Tipo de vegetação alta (moda; tab. 4.234)",   "código",
    "tvl",             "Tipo de vegetação baixa (moda; tab. 4.234)",  "código",
    "tp",              "Precipitação total",                          "m",
    "cp",              "Precipitação convectiva",                     "m",
    "e",               "Evaporação",                                  "m",
    "pev",             "Evaporação potencial",                        "m",
    "slhf",            "Fluxo de calor latente na superfície",        "J m-2",
    "ssr",             "Radiação solar líquida na superfície",        "J m-2",
    "lsrr",            "Taxa de chuva de larga escala",               "kg m-2 s-1",
    "ptype",           "Tipo de precipitação (média mensal já aplicada pelo ECMWF; ver nota no cabeçalho)", "índice 0-1",
    "t2m_C",           "Temperatura do ar a 2 m",                     "graus C",
    "tp_mm_dia",       "Precipitação total",                          "mm dia-1",
    "cp_mm_dia",       "Precipitação convectiva",                     "mm dia-1",
    "e_mm_dia",        "Evaporação (negativo = perda)",               "mm dia-1",
    "pev_mm_dia",      "Evaporação potencial",                        "mm dia-1",
    "lsrr_mm_dia",     "Taxa de chuva de larga escala",               "mm dia-1",
    "slhf_W_m2",       "Fluxo de calor latente na superfície",        "W m-2",
    "ssr_W_m2",        "Radiação solar líquida na superfície",        "W m-2",
    "tcc_pct",         "Cobertura total de nuvens",                   "%",
    "vento_vel_m_s",   "Velocidade do vento médio a 10 m",            "m s-1",
    "vento_dir_graus", "Direção do vento (de onde sopra; 0 = Norte)", "graus")

######@> Exportação da base consolidada...
## Além dos arquivos por município (solicitados), a base completa é
## gravada para permitir análises comparativas entre municípios sem
## necessidade de reunir os 37 arquivos individuais.
write_parquet(dados_final,
              file.path(dir_out_parquet, "ERA5_municipios_SC_completo.parquet"))
save(dados_final, dicionario,
     file = file.path(dir_out_rdata, "ERA5_municipios_SC_completo.RData"))

######@> Exportação do dicionário de variáveis...
write_parquet(dicionario,
              file.path(dir_out_parquet, "ERA5_dicionario_variaveis.parquet"))

######@> Exportação individual por município...
## Um par de arquivos (Parquet + RData) por município. O nome combina o
## geocódigo do IBGE (chave estável e sem ambiguidade) com o nome
## transliterado, o que mantém os arquivos legíveis e ordenáveis.
message("Exportando arquivos por município...")

for(g in unique(dados_final$geocodigo)) {
    ## Subconjunto dos dados do município corrente
    dados_municipio <- dados_final %>%
        filter(geocodigo == g)
    ## Montagem do nome-base do arquivo
    nome_muni <- limpar_nome(unique(dados_municipio$municipio))
    nome_base <- paste0("ERA5_", g, "_", nome_muni)
    ## Gravação em Parquet (formato colunar, compacto e interoperável
    ## com Python/R/QGIS)
    write_parquet(dados_municipio,
                  file.path(dir_out_parquet, paste0(nome_base, ".parquet")))
    ## Gravação em RData (formato nativo do R). O objeto é sempre salvo
    ## com o nome "dados_municipio", garantindo previsibilidade ao
    ## carregar qualquer um dos arquivos com load().
    save(dados_municipio,
         file = file.path(dir_out_rdata, paste0(nome_base, ".RData")))
    message(sprintf("  %-45s %5d linhas", nome_base, nrow(dados_municipio)))
}

######@> Resumo final do processamento...
message("\n=== Processamento concluído ===")
message("Municípios processados : ", length(unique(dados_final$geocodigo)))
message("Período coberto        : ",
        format(min(dados_final$data), "%Y-%m"), " a ",
        format(max(dados_final$data), "%Y-%m"))
message("Variáveis extraídas    : ", nrow(dicionario))
message("Saídas em              : ", normalizePath(dir_out))

########################################################################
##
##                  Creative Commons License 4.0
##                       (CC BY-NC-SA 4.0)
##
##  This is a humam-readable summary of (and not a substitute for) the
##  license (https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
##
##  You are free to:
##
##  Share - copy and redistribute the material in any medium or format.
##
##  The licensor cannot revoke these freedoms as long as you follow the
##  license terms.
##
##  Under the following terms:
##
##  Attribution - You must give appropriate credit, provide a link to
##  license, and indicate if changes were made. You may do so in any
##  reasonable manner, but not in any way that suggests the licensor
##  endorses you or your use.
##
##  NonCommercial - You may not use the material for commercial
##  purposes.
##
##  ShareAlike - If you remix, transform, or build upon the material,
##  you must distributive your contributions under the same license
##  as the  original.
##
##  No additional restrictions — You may not apply legal terms or
##  technological measures that legally restrict others from doing
##  anything the license permits.
##
########################################################################
